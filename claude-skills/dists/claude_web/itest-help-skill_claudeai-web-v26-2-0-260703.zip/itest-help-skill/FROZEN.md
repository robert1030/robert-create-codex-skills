# FROZEN（資料快照凍結帳本）

## v2.0｜2026-07-03：改用單一 SQLite 檔，取代逐檔版本

**改版原因**：v1.0 把 3012 個文字 chunk＋1799 個圖片說明 chunk 各自存成一個 `.md` 檔，
連同中繼資料共約 4822 個檔案，超過 claude.ai 網頁版 skill 的檔案數上限（200 個），
沒辦法直接上傳安裝。v2.0 把同一批資料整併進單一 SQLite 檔 `data/itest_help.db`，
skill 資料夾總檔案數壓到個位數。**資料內容跟 v1.0 完全相同，只是換了容器**，
檢索邏輯、加權規則、附注規矩全部原封不動照搬，`search_chunks.py` 的輸出格式也刻意
維持跟 v1.0 一致，兩版對同一組查詢的結果經比對是相同的。

- **凍結的檔案**：`data/itest_help.db`（唯一的資料檔，內含 `chunks` 資料表、
  `chunks_fts` 全文索引、`images` 資料表、`meta` 資料表）。
- **產生方式**：`scripts/build_db.py <來源 itest-help_ragchunk 資料夾>`，來源資料夾
  需含 `chunk_manifest.jsonl`、`text/*.md`、`images/*.md`（也就是 v1.0 版本用過的那批
  逐檔資料，v2.0 只是不把逐檔版本本身放進交付的 skill 包）。
- **來源**：與 v1.0 相同，使用者上傳的 `itest-help_ragchunk.zip`（Spirent iTest 26.2.0
  線上說明文件，原始壓縮檔名 `help_26_2_0.zip`）。
- **已知限制**：與 v1.0 相同，詳見 `references/original_validation_report.md`。

### 規則：絕不手動改 data/itest_help.db

跟 v1.0 的規則精神一樣，只是動作換成資料庫：

- 不要用 SQL 手動 `UPDATE`／`DELETE` 這個資料庫裡的資料，這會讓同一個 `chunk_id`
  在不同時間點對應到不同內容，之後沒辦法重現、也沒辦法追查。
- 如果 iTest 官方說明文件改版，正確做法是：
  1. 請使用者提供新版說明文件的 zip。
  2. 用 `rag-chunk-slicer` skill 重新切片，產出新的逐檔資料（`chunk_manifest.jsonl`／
     `text/`／`images/`）。
  3. 用 `python3 scripts/build_db.py <新的來源資料夾>` 整批重建 `data/itest_help.db`。
  4. 跑 `python3 tests/test_search_chunks.py`，確認回歸測試全綠（`EXPECTED_CHUNK_COUNT`／
     `EXPECTED_IMAGE_COUNT` 這類常數記得同步更新）。
  5. 更新這份 FROZEN.md，開一個新版本區塊（例如 v2.1），不要蓋掉既有版本的紀錄。
- 這麼做的原因跟 v1.0 一樣：之後有人問「這個答案是根據哪一版說明文件？」，要答得出來，
  不能含糊地說「資料庫裡的內容」。

### 對 claude.ai 檔案數上限的因應（跟房規六「透明安裝」的取捨）

- `search_chunks.py`／`build_db.py` 都只用 Python 標準庫（`sqlite3`／`json`／`re`），
  零額外相依，不需要 bootstrap 安裝任何套件。
- FTS5（SQLite 的全文索引擴充）是否可用，由 `build_db.py` 建置當下實測決定，並誠實
  記錄在資料庫的 `meta` 表（`fts5_available`）。`search_chunks.py` 執行檢索時，
  先看這個旗標決定要不要用 FTS5，沒有就自動退回全表 `LIKE` 掃描，不假裝有 FTS5、
  也不會因為缺 FTS5 就直接壞掉。這是房規五「能力邊界誠實，降級階梯不造假」在資料庫
  可攜性上的具體落實。

---

## v1.0｜2026-07-03（已停用，保留紀錄）

- **來源**：使用者上傳的 `itest-help_ragchunk.zip`，內容為 Spirent iTest 26.2.0 線上說明文件
  （原始壓縮檔名：`help_26_2_0.zip`，7004 個檔案），已用 `rag-chunk-slicer` skill 切成
  3012 個文字 chunk＋1799 個圖片 chunk。
- **凍結的檔案**：`data/chunk_manifest.jsonl`、`data/index_manifest.jsonl`、
  `data/text/*.md`（3012 個）、`data/images/*.md`（1799 個）、`data/search_corpus.jsonl`。
- **停用原因**：總檔案數（約 4822 個）超過 claude.ai 網頁版 skill 的檔案數上限（200 個），
  無法直接上傳安裝，改用 v2.0 的單一 SQLite 檔版本。
- **已知限制**：同 v2.0 段落所述，詳見 `references/original_validation_report.md`。

## 與 joan-skill-conventions 七條房規的對應關係（誠實記錄哪些套用、哪些不套用）

這支 skill 是「檢索問答」類，不是「視覺卡片／講義生成」類，套用房規時做了以下取捨，
如實記錄在這裡，避免日後有人誤以為每一條都原封不動照搬：

| 房規 | 是否套用 | 落地方式 |
|---|---|---|
| 一、凍結契約 | 套用（改用資料快照的概念） | 本檔案；`data/itest_help.db` 不手動改，只能整批重建，且改版一律另開版本號 |
| 二、驗證即閘門 | 套用 | `tests/test_search_chunks.py` 回歸測試；答案必須先跑 `search_chunks.py` 取得有分數依據的候選，不能靠模型印象 |
| 三、全形標點＋禁破折號 | 套用 | 對話輸出與任何生成的檔案都比照辦理；`scripts/validate_punct.py` 供產生書面檔案時使用 |
| 四、引擎／皮膚／內容三層 | 不適用 | 這支 skill 沒有視覺皮膚可換，資料（iTest 文件）與檢索邏輯（search_chunks.py）本來就是分開的兩層，性質不同，強套三層架構沒有意義 |
| 五、能力邊界誠實 | 套用（本 skill 的核心） | 見 SKILL.md「能力邊界」一節；找不到就老實說找不到，答案來源非本資料庫時必須附注；FTS5 有沒有裝好也誠實反映在旗標上，不假裝 |
| 六、透明自動安裝 | 套用（但很簡單） | 全部腳本只用 Python 標準庫，零額外相依，不需要 bootstrap；SQLite 檔案格式選擇本身也是為了因應 claude.ai 的檔案數限制 |
| 七、生成前對焦閘門 | 部分套用 | 不做多輪訪談（問答類任務問太多反而擾民），但遇到過於模糊的縮寫或代稱時，先問一句釐清，而不是照著自己猜的意思亂答 |
