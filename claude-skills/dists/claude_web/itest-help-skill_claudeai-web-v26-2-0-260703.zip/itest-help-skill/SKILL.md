---
name: itest-help-skill
description: 回答 Spirent iTest 自動化測試工具的寫程式問題，資料來源是官方線上說明文件的完整切片（3012 個段落，涵蓋 Tcl、Python driver、正則表達式／Analysis Rule、Avalanche API、除錯、Perspective／Editor 操作等主題），全部收在單一 SQLite 檔裡供檢索。觸發時機：使用者提到 "itest help"、"itest tcl"、"itest python"、"itest regex"、"itest analysis"、iTest 語法或指令查詢、Spirent iTest 報錯訊息、iTest Analysis Rule／Extractor 設定、Velocity driver 除錯、Avalanche API 指令（例如 av_apply）等，即使沒有明確講出「iTest」三個字，只要是在問 Tcl／Python 在 iTest 環境下怎麼寫、iTest 某個編輯器／精靈（wizard）怎麼用、iTest 錯誤訊息是什麼意思，都應該觸發這支 skill 先查資料再回答，不要單靠訓練資料裡的印象作答。
---

# itest-help-skill

這支 skill 讓 Claude 能夠根據 Spirent iTest 官方線上說明文件（v26.2.0，已切成 3012 個可檢索
段落）回答使用者寫程式時遇到的問題，並且清楚標示答案是不是真的來自這份文件。

**v2.0 改用單一 SQLite 檔（`data/itest_help.db`）承載全部資料**，取代 v1.0 逐檔存放
（近五千個 `.md` 檔）的做法，因為後者超過 claude.ai 網頁版 skill 的檔案數上限。
檢索邏輯、附注規則跟 v1.0 完全一樣，只是資料容器換了。改版原因與細節見 `FROZEN.md`。

它疊加在 `joan-skill-conventions` 的房規之上，套用方式與取捨記錄在 `FROZEN.md`，
建議先看那一份，理解「為什麼有些房規套用、有些不套用」。

## 為什麼要先查資料再回答

iTest 是一套小眾的商用測試自動化工具，介面、指令名稱、精靈的欄位名稱都是 Spirent 自訂的，
和「一般的 Tcl／Python 知識」不是同一回事。模型訓練資料裡對 iTest 的印象很可能片段、過時，
或者根本是把一般 Tcl／Python 語法誤套到 iTest 專屬情境上。所以這支 skill 的核心原則是：

> **先檢索、有依據才回答；查不到就老實說查不到，不要用「聽起來很合理」的答案糊弄過去。**

## 工作流程

### 第一步：用 search_chunks.py 檢索

在 skill 的目錄下執行（不需要安裝任何套件，純 Python 標準庫，含 `sqlite3`）：

```bash
python3 scripts/search_chunks.py "<把使用者問題的關鍵字抽出來，英文技術詞優先>" --top-k 5
```

**下關鍵字的訣竅**：

- 把使用者問題裡的技術詞（指令名稱、函式名稱、錯誤訊息裡的關鍵片段、精靈名稱）抽出來，
  中文問題也要抽出對應的英文技術詞一起查（例如使用者問「iTest 怎麼設定正則表達式擷取」，
  查詢詞應該包含 `regular expression extractor analysis rule`，而不是只查中文）。
- 如果使用者貼了一段完整的錯誤訊息或指令片段，直接整段丟進去查一次；完整子字串命中
  會額外加分，能抓到只搜關鍵字抓不到的精確匹配。
- 第一次查詢结果不理想（`result_count` 是 0，或分數普遍很低、`matched_terms` 只命中一兩個
  不重要的詞），換一組關鍵字再查一次，不要只查一次就放棄。

### 第二步：取出候選段落的完整原文

`search_chunks.py` 回傳的 `snippet` 只是片段，正式作答前，用 `--chunk` 參數讀出候選段落
的完整內容，確認真的切題再引用：

```bash
python3 scripts/search_chunks.py --chunk c_a7b2a88f4b9e
```

表格、步驟清單類的段落（`has_table` / `has_step_list` 為 true）尤其要看完整原文，
snippet 常常只截到表格的一小角，容易斷章取義。

如果搜尋結果的 `images` 欄位提到某張圖，想知道這張圖的分類判斷依據，可以用檔名查：

```bash
python3 scripts/search_chunks.py --image "agent_pythonDebug.png"
```

### 第三步：組織答案

依使用者偏好的語言與用詞習慣回覆（預設繁體中文、台灣用語、全形標點，且避免破折號；
若使用者本身用英文問，就用簡單常用的英文詞彙回覆），內容組織原則：

1. **先直接回答問題**，不要把整段原文貼上去；用自己的話重新組織成針對使用者情境的說明，
   需要精確重現的（指令語法、參數名稱、錯誤訊息文字）才逐字保留。
2. **附上資料來源**：用該 chunk 的 `breadcrumb`（章節路徑）標示來源，例如：

   > （資料來源：iTest Help > Spirent Avalanche sessions > Avalanche API Commands > av_apply）

   如果同一個答案綜合了好幾個段落，每個段落各自標明來源，不要籠統寫「參考官方文件」。
3. **表格／步驟／程式碼盡量保留原始結構**，這類內容改寫成散文反而更難照做，直接轉成
   markdown 表格或條列步驟即可，不算違反「重新組織」的原則。
4. **圖片**：搜尋結果 `images` 欄位若有非 decorative 的圖（`classification` 是
   `screenshot`／`diagram`／`unknown`），可以告訴使用者原文件裡有對應截圖／示意圖
   （寫出 `src` 檔名），但不要假裝自己看得到圖片內容或描述圖片畫面。這支 skill
   沒有圖片本體，只有「這裡有一張圖，分類是什麼」的中繼資料。

## 能力邊界誠實：找不到就老實說，並且標注來源

這是這支 skill 最重要的規矩，直接對應使用者的要求，**沒有例外**：

- **完全查得到、答案直接來自 iTest 官方文件**：正常回答＋附資料來源（見上）。
- **部分查得到**：查得到的部分照常附來源；查不到、需要靠一般 Tcl／Python／測試自動化
  常識補足的部分，**明確切開來講**，並在那部分加上附注，例如：

  > ⚠️ 以下這段不是來自 itest-help-skill 的官方文件資料，是一般 Tcl／Python 知識的推論，
  > 建議另外查證官方文件或洽詢 Spirent 支援。

- **完全查不到**（`search_chunks.py` 回傳空結果，或分數很低、換了幾組關鍵字都查不到切題的
  段落）：明確告訴使用者「itest-help-skill 資料庫裡沒有找到直接相關的段落」，如果要用一般
  知識回答，一定要用上面那句附注格式標注清楚，讓使用者知道這不是官方文件保證的行為，
  尤其是 iTest 特有的精靈欄位名稱、內部指令這類外部知識大概率是錯的或過時的地方，
  更要提醒使用者務必自行在 iTest 裡確認。
- **不要為了讓答案看起來更完整，就把「查不到」悄悄跳過**。查不到本身也是有用的資訊
  （代表這可能是很少人用到的功能、或者用詞需要換一個角度再查一次）。

## 遇到過於模糊的問題時

如果使用者只丟一個縮寫或代稱（例如「apply 是什麼意思」），先確認情境（是 Avalanche
API 的 `av_apply`？還是別的 apply？）比直接照自己猜的意思去查、答錯還更快更準。
不需要像做教學文件那樣做一整輪訪談，通常一句話確認就夠。

## 產生書面檔案時的檢查

如果使用者要求把答案整理成一份文件（.md／Word 等），輸出前跑一次共用的標點驗證器：

```bash
python3 scripts/validate_punct.py <輸出檔路徑>
```

退出碼非 0 表示還有半形標點夾在中文裡、或誤用了破折號，修正後再交付。
純聊天室內的簡短回覆不用特別跑這支腳本，但下筆時本來就該遵守全形標點、禁破折號的習慣。

## 資料快照與回歸測試

- 資料來源版本、凍結規則、七條房規的套用取捨、v1.0 到 v2.0 的改版原因：見 `FROZEN.md`。
- 修改 `scripts/search_chunks.py` 或 `scripts/build_db.py` 之後，跑一次
  `python3 tests/test_search_chunks.py`，全綠才算沒有破壞既有檢索行為。
- 如果收到新版 iTest 說明文件的切片結果，重建流程也寫在 `FROZEN.md`，不要手動改
  `data/itest_help.db` 裡的既有資料。

## 目錄結構

```
itest-help-skill/
├── SKILL.md
├── FROZEN.md                     資料快照凍結帳本＋房規套用取捨紀錄＋v1→v2 改版原因
├── scripts/
│   ├── search_chunks.py          主要檢索工具（見上）
│   ├── build_db.py               從逐檔切片資料重建 data/itest_help.db（只在資料更新時執行）
│   └── validate_punct.py         全形標點＋禁破折號驗證器（產生書面檔案時使用）
├── tests/
│   └── test_search_chunks.py     回歸測試
├── references/
│   ├── original_manifest.md      原始切片 manifest（說明整體切片範圍與規則）
│   └── original_validation_report.md   原始切片驗證報告（已知限制、統計數字）
└── data/
    └── itest_help.db             單一 SQLite 檔：chunks／chunks_fts／images／meta 四張表
```
