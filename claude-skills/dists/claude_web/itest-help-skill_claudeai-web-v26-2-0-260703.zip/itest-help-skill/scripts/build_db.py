#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_db.py：把 3012 個文字 chunk＋1799 個圖片說明 chunk 整併成單一 SQLite 檔
              data/itest_help.db，取代原本「一個 chunk 一個檔案」的做法。

背景（房規一：凍結契約，另開新版，絕不就地改定版）：
  v1.0 把 3012＋1799 個 .md 檔直接放進 skill 資料夾，總檔案數超過 4800，
  超過 claude.ai 網頁版 skill 的檔案數上限（200 個）。v2.0 改用單一 SQLite
  資料庫檔案承載同樣的資料，把檔案數壓到個位數，同時保留可全文檢索的能力
  （用 SQLite 內建的 FTS5，找不到 FTS5 才退回內建的 LIKE 掃描，不假裝、不硬做）。
  v1.0 的原始逐檔版本不隨這個版本一起交付，但取用方式與資料本身完全沒變，
  只是換了容器，讀者可以把這想成「同一批書，從散裝檔案夾換成一個資料庫檔案」。

用法：
    python3 scripts/build_db.py <來源 itest-help_ragchunk 資料夾路徑> [--out data/itest_help.db]

來源資料夾需含：chunk_manifest.jsonl、text/*.md、images/*.md
"""
import argparse
import json
import re
import sqlite3
import sys
from pathlib import Path

IMG_TITLE_RE = re.compile(r"^#\s*圖片：\s*(.+?)\s*$", re.MULTILINE)
# 註：實測 1799 個來源圖片說明檔的標題一律使用全形冒號，故正則表達式不需要
# 額外比對半形冒號；如果未來的來源資料出現半形冒號，這裡需要同步更新。


def clean_images(images):
    return [
        {"src": img.get("src", ""), "classification": img.get("classification", "")}
        for img in images
        if img.get("classification") != "decorative"
    ]


def build(source_dir: Path, out_path: Path) -> int:
    manifest_path = source_dir / "chunk_manifest.jsonl"
    text_dir = source_dir / "text"
    images_dir = source_dir / "images"

    if not manifest_path.exists():
        print(f"找不到 {manifest_path}，來源資料夾結構不對，請確認路徑。", file=sys.stderr)
        return 1

    out_path.parent.mkdir(parents=True, exist_ok=True)
    if out_path.exists():
        out_path.unlink()

    con = sqlite3.connect(str(out_path))
    cur = con.cursor()

    cur.execute("""
        CREATE TABLE chunks (
            chunk_id TEXT PRIMARY KEY,
            source_original_path TEXT,
            breadcrumb TEXT,
            toc_path_json TEXT,
            heading_path_json TEXT,
            anchor TEXT,
            context_ids_json TEXT,
            index_keywords_json TEXT,
            has_table INTEGER,
            has_step_list INTEGER,
            is_popup INTEGER,
            images_json TEXT,
            text TEXT,
            char_count INTEGER
        )
    """)

    fts_ok = True
    try:
        cur.execute("""
            CREATE VIRTUAL TABLE chunks_fts USING fts5(
                chunk_id UNINDEXED,
                breadcrumb,
                heading_path,
                context_ids,
                index_keywords,
                source_original_path,
                text,
                tokenize = 'unicode61'
            )
        """)
    except sqlite3.OperationalError as e:
        fts_ok = False
        print(f"警告：這個 SQLite 沒有編譯 FTS5（{e}），改用一般資料表＋LIKE 掃描做檢索。", file=sys.stderr)

    cur.execute("""
        CREATE TABLE images (
            img_id TEXT PRIMARY KEY,
            filename TEXT,
            raw_md TEXT
        )
    """)
    cur.execute("CREATE INDEX idx_images_filename ON images(filename)")

    cur.execute("CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT)")

    written = 0
    missing_text = 0
    with manifest_path.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            entry = json.loads(line)
            chunk_id = entry["chunk_id"]
            text_path = text_dir / entry["source_file"]
            body = text_path.read_text(encoding="utf-8") if text_path.exists() else ""
            if not text_path.exists():
                missing_text += 1

            images = clean_images(entry.get("images", []))
            heading_path = entry.get("heading_path", [])
            context_ids = entry.get("context_ids", [])
            index_keywords = entry.get("index_keywords", [])

            cur.execute(
                """INSERT INTO chunks
                   (chunk_id, source_original_path, breadcrumb, toc_path_json, heading_path_json,
                    anchor, context_ids_json, index_keywords_json, has_table, has_step_list,
                    is_popup, images_json, text, char_count)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    chunk_id,
                    entry.get("source_original_path", ""),
                    entry.get("breadcrumb", ""),
                    json.dumps(entry.get("toc_path", []), ensure_ascii=False),
                    json.dumps(heading_path, ensure_ascii=False),
                    entry.get("anchor", ""),
                    json.dumps(context_ids, ensure_ascii=False),
                    json.dumps(index_keywords, ensure_ascii=False),
                    int(bool(entry.get("has_table"))),
                    int(bool(entry.get("has_step_list"))),
                    int(bool(entry.get("is_popup"))),
                    json.dumps(images, ensure_ascii=False),
                    body,
                    len(body),
                ),
            )
            if fts_ok:
                cur.execute(
                    """INSERT INTO chunks_fts
                       (chunk_id, breadcrumb, heading_path, context_ids, index_keywords, source_original_path, text)
                       VALUES (?,?,?,?,?,?,?)""",
                    (
                        chunk_id,
                        entry.get("breadcrumb", ""),
                        " ".join(heading_path),
                        " ".join(context_ids),
                        " ".join(index_keywords),
                        entry.get("source_original_path", ""),
                        body,
                    ),
                )
            written += 1

    img_count = 0
    if images_dir.exists():
        for img_path in images_dir.glob("*.md"):
            raw = img_path.read_text(encoding="utf-8")
            m = IMG_TITLE_RE.search(raw)
            filename = m.group(1) if m else ""
            cur.execute(
                "INSERT INTO images (img_id, filename, raw_md) VALUES (?,?,?)",
                (img_path.stem, filename, raw),
            )
            img_count += 1

    cur.execute("INSERT INTO meta VALUES ('fts5_available', ?)", ("1" if fts_ok else "0",))
    cur.execute("INSERT INTO meta VALUES ('chunk_count', ?)", (str(written),))
    cur.execute("INSERT INTO meta VALUES ('image_count', ?)", (str(img_count),))
    cur.execute("INSERT INTO meta VALUES ('source_dir', ?)", (str(source_dir),))

    con.commit()
    con.close()

    print(f"完成：寫入 {written} 個 chunk、{img_count} 個圖片說明到 {out_path}")
    print(f"FTS5 全文索引：{'已建立' if fts_ok else '未建立（改用 LIKE 掃描）'}")
    if missing_text:
        print(f"警告：{missing_text} 筆在 text/ 中找不到對應的原始 .md 檔（body 留空）。", file=sys.stderr)
    return 0


def main():
    ap = argparse.ArgumentParser(description="把切片資料整併成單一 SQLite 檔")
    ap.add_argument("source_dir", help="來源 itest-help_ragchunk 資料夾路徑")
    ap.add_argument("--out", default=None, help="輸出的 .db 路徑，預設 <skill 根目錄>/data/itest_help.db")
    args = ap.parse_args()

    skill_root = Path(__file__).resolve().parent.parent
    out_path = Path(args.out) if args.out else skill_root / "data" / "itest_help.db"
    return build(Path(args.source_dir), out_path)


if __name__ == "__main__":
    sys.exit(main())
