#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
search_chunks.py：在 data/itest_help.db（單一 SQLite 檔）中搜尋 iTest 官方說明文件切片。

跟 v1.0（逐檔 jsonl／markdown）版本比，行為完全一樣，只是資料容器換成 SQLite，
檔案數從近五千個壓到個位數，才不會超過 claude.ai 網頁版 skill 的檔案數上限。

用法：
    python3 scripts/search_chunks.py "av_apply Avalanche" --top-k 5
    python3 scripts/search_chunks.py "regexp 正則表達式" --top-k 8 --min-score 2
    python3 scripts/search_chunks.py --chunk c_a7b2a88f4b9e      # 取出單一 chunk 全文
    python3 scripts/search_chunks.py --image topologies.14.jpg   # 用檔名查圖片說明

檢索邏輯（房規二：驗證即閘門，絕不靠肉眼）：
  優先用 SQLite FTS5 做候選篩選（bm25 排序），縮小候選集合之後，
  再用跟 v1.0 相同的加權規則對候選重新算分（breadcrumb／heading 命中權重最高，
  其次 context_ids／index_keywords，然後是檔名，內文命中權重最低但有次數加成）。
  這樣既有 FTS5 的效能，又保留原本「命中欄位越關鍵、分數越高」的可解釋排序。
  如果這個環境的 SQLite 沒編譯 FTS5（data/itest_help.db 建置時會記錄在 meta 表），
  自動退回全表 LIKE 掃描，結果一樣但速度較慢，不會因為缺 FTS5 就交出錯誤答案。
"""
import argparse
import json
import re
import sqlite3
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
DB_PATH = SKILL_ROOT / "data" / "itest_help.db"

TOKEN_RE = re.compile(r"[A-Za-z0-9_]+|[\u4e00-\u9fff]")
FTS_SPECIAL_RE = re.compile(r'["*^]')


def tokenize(s: str):
    return [t.lower() for t in TOKEN_RE.findall(s)]


def get_conn():
    if not DB_PATH.exists():
        print(
            f"找不到 {DB_PATH}。請先執行 python3 scripts/build_db.py <來源資料夾> 建置資料庫。",
            file=sys.stderr,
        )
        sys.exit(1)
    return sqlite3.connect(str(DB_PATH))


def fts5_available(con) -> bool:
    row = con.execute("SELECT value FROM meta WHERE key='fts5_available'").fetchone()
    return bool(row and row[0] == "1")


def fetch_candidates_fts(con, query_tokens, limit=300):
    match_expr = " OR ".join(FTS_SPECIAL_RE.sub(" ", t) for t in set(query_tokens) if t.strip())
    if not match_expr:
        return []
    try:
        rows = con.execute(
            """SELECT chunk_id FROM chunks_fts WHERE chunks_fts MATCH ? ORDER BY bm25(chunks_fts) LIMIT ?""",
            (match_expr, limit),
        ).fetchall()
        return [r[0] for r in rows]
    except sqlite3.OperationalError:
        return []


def fetch_candidates_like(con, query_tokens, limit=300):
    if not query_tokens:
        return []
    clauses = []
    params = []
    for tok in set(query_tokens):
        if not tok.strip():
            continue
        like = f"%{tok}%"
        clauses.append("(text LIKE ? OR breadcrumb LIKE ? OR source_original_path LIKE ?)")
        params.extend([like, like, like])
    if not clauses:
        return []
    sql = f"SELECT chunk_id FROM chunks WHERE {' OR '.join(clauses)} LIMIT ?"
    params.append(limit)
    rows = con.execute(sql, params).fetchall()
    return [r[0] for r in rows]


def score_row(row, query_tokens, query_lower):
    (chunk_id, source_original_path, breadcrumb, heading_path_json, anchor,
     context_ids_json, index_keywords_json, has_table, has_step_list, is_popup,
     images_json, text, char_count) = row

    heading_path = json.loads(heading_path_json) if heading_path_json else []
    context_ids = json.loads(context_ids_json) if context_ids_json else []
    index_keywords = json.loads(index_keywords_json) if index_keywords_json else []
    images = json.loads(images_json) if images_json else []

    heading_text = " ".join(heading_path + [breadcrumb]).lower()
    meta_text = " ".join(heading_path + [breadcrumb] + context_ids + index_keywords + [source_original_path]).lower()
    body_lower = (text or "").lower()

    score = 0
    matched = set()
    for tok in set(query_tokens):
        if not tok:
            continue
        if tok in meta_text:
            score += 5 if tok in heading_text else 4
            matched.add(tok)
        occ = body_lower.count(tok)
        if occ:
            score += min(occ, 5)
            matched.add(tok)

    if query_lower and query_lower in body_lower:
        score += 6
        matched.add(query_lower)
    if query_lower and query_lower in meta_text:
        score += 6
        matched.add(query_lower)

    return score, matched, {
        "chunk_id": chunk_id,
        "source_original_path": source_original_path,
        "breadcrumb": breadcrumb,
        "anchor": anchor,
        "has_table": bool(has_table),
        "has_step_list": bool(has_step_list),
        "is_popup": bool(is_popup),
        "images": images,
        "text": text,
        "char_count": char_count,
    }


def make_snippet(body: str, query_tokens, width: int = 140) -> str:
    body_lower = (body or "").lower()
    pos = -1
    for tok in query_tokens:
        idx = body_lower.find(tok)
        if idx != -1:
            pos = idx
            break
    if pos == -1:
        snippet = (body or "")[:width]
    else:
        start = max(0, pos - width // 2)
        end = min(len(body), pos + width // 2)
        snippet = ("…" if start > 0 else "") + body[start:end] + ("…" if end < len(body) else "")
    return " ".join(snippet.split())


def search(query: str, top_k: int = 5, min_score: int = 1):
    con = get_conn()
    query_tokens = tokenize(query)
    query_lower = query.strip().lower()

    candidate_ids = []
    if fts5_available(con):
        candidate_ids = fetch_candidates_fts(con, query_tokens)
    if not candidate_ids:
        candidate_ids = fetch_candidates_like(con, query_tokens)

    if not candidate_ids:
        con.close()
        return []

    placeholders = ",".join("?" for _ in candidate_ids)
    rows = con.execute(
        f"""SELECT chunk_id, source_original_path, breadcrumb, heading_path_json, anchor,
                   context_ids_json, index_keywords_json, has_table, has_step_list, is_popup,
                   images_json, text, char_count
            FROM chunks WHERE chunk_id IN ({placeholders})""",
        candidate_ids,
    ).fetchall()
    con.close()

    scored = []
    for row in rows:
        s, matched, info = score_row(row, query_tokens, query_lower)
        if s >= min_score:
            scored.append((s, matched, info))

    scored.sort(key=lambda x: x[0], reverse=True)
    results = []
    for s, matched, info in scored[:top_k]:
        results.append(
            {
                "chunk_id": info["chunk_id"],
                "score": s,
                "matched_terms": sorted(matched),
                "breadcrumb": info["breadcrumb"],
                "source_original_path": info["source_original_path"],
                "anchor": info["anchor"],
                "is_popup": info["is_popup"],
                "has_table": info["has_table"],
                "has_step_list": info["has_step_list"],
                "images": info["images"],
                "snippet": make_snippet(info["text"], query_tokens),
                "char_count": info["char_count"],
            }
        )
    return results


def get_full_chunk(chunk_id: str):
    con = get_conn()
    row = con.execute("SELECT text FROM chunks WHERE chunk_id=?", (chunk_id,)).fetchone()
    con.close()
    return row[0] if row else None


def get_image(filename: str):
    con = get_conn()
    rows = con.execute(
        "SELECT img_id, filename, raw_md FROM images WHERE filename LIKE ?", (f"%{filename}%",)
    ).fetchall()
    con.close()
    return [{"img_id": r[0], "filename": r[1], "raw_md": r[2]} for r in rows]


def main():
    ap = argparse.ArgumentParser(description="搜尋 iTest 官方說明文件切片（SQLite 版）")
    ap.add_argument("query", nargs="?", help="搜尋關鍵字或片語（可含多個詞，用空白分隔）")
    ap.add_argument("--top-k", type=int, default=5, help="回傳前 K 筆結果，預設 5")
    ap.add_argument("--min-score", type=int, default=1, help="最低分數門檻，預設 1")
    ap.add_argument("--chunk", help="直接取出指定 chunk_id 的完整原文")
    ap.add_argument("--image", help="用檔名關鍵字查圖片分類說明")
    args = ap.parse_args()

    if args.chunk:
        text = get_full_chunk(args.chunk)
        if text is None:
            print(json.dumps({"error": f"找不到 chunk_id={args.chunk}"}, ensure_ascii=False))
            sys.exit(1)
        print(json.dumps({"chunk_id": args.chunk, "text": text}, ensure_ascii=False, indent=2))
        return

    if args.image:
        results = get_image(args.image)
        print(json.dumps({"query": args.image, "result_count": len(results), "results": results}, ensure_ascii=False, indent=2))
        return

    if not args.query:
        print(json.dumps({"error": "請提供 query，或改用 --chunk <chunk_id> ／ --image <檔名>"}, ensure_ascii=False))
        sys.exit(2)

    results = search(args.query, top_k=args.top_k, min_score=args.min_score)
    print(json.dumps({"query": args.query, "result_count": len(results), "results": results}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
