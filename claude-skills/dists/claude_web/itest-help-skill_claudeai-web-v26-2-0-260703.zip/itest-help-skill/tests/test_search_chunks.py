#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
回歸測試（房規二：驗證即閘門，絕不靠肉眼）。SQLite 版。

跟 v1.0 檔案版的測試精神一樣，只是資料來源換成 data/itest_help.db。
用法：python3 tests/test_search_chunks.py
"""
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_ROOT / "scripts"))

import search_chunks as sc  # noqa: E402

EXPECTED_CHUNK_COUNT = 3012
EXPECTED_IMAGE_COUNT = 1799


def test_db_snapshot_size():
    con = sc.get_conn()
    chunk_count = con.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
    image_count = con.execute("SELECT COUNT(*) FROM images").fetchone()[0]
    con.close()
    assert chunk_count == EXPECTED_CHUNK_COUNT, (
        f"chunks 資料表筆數應為 {EXPECTED_CHUNK_COUNT}，實際為 {chunk_count}。"
        f"若確實用新版來源資料重建了 db，屬預期變動，請更新這個常數；否則代表資料庫被意外改動了。"
    )
    assert image_count == EXPECTED_IMAGE_COUNT, (
        f"images 資料表筆數應為 {EXPECTED_IMAGE_COUNT}，實際為 {image_count}。"
    )


def test_known_query_av_apply_hits_expected_topic():
    results = sc.search("av_apply Avalanche", top_k=5)
    assert results, "查詢 av_apply 應該至少有一筆結果"
    top_paths = {r["source_original_path"] for r in results}
    assert "topics/tgen_cmds_harness.htm" in top_paths, (
        "av_apply 查詢的最相關結果應該來自 topics/tgen_cmds_harness.htm"
        "（Avalanche API Commands > av_apply），實際命中的檔案不含它。"
    )


def test_known_query_python_agent_debug_hits_expected_topic():
    results = sc.search("debug python driver agent mode", top_k=5)
    assert results, "查詢 python agent debug 應該至少有一筆結果"
    top = results[0]
    assert "Debugging_Python_drivers_iTest_Agent_mode" in top["source_original_path"], (
        f"最高分結果應該是 Debugging Python drivers in iTest Agent mode 這一篇，"
        f"實際最高分是 {top['source_original_path']}"
    )


def test_unrelated_query_returns_empty():
    results = sc.search("quantum blockchain nft", top_k=5, min_score=4)
    assert results == [], (
        "完全不相關的查詢應該誠實回傳空結果，不能硬湊一個低分但看起來相關的答案"
        "（房規五「能力邊界誠實」在檢索工具上的具體落實）。"
    )


def test_image_lookup_by_filename():
    results = sc.get_image("topologies.14.jpg")
    assert results, "用完整檔名查圖片說明應該查得到"
    assert results[0]["filename"] == "topologies.14.jpg"


def test_fts5_flag_matches_actual_capability():
    con = sc.get_conn()
    flag = sc.fts5_available(con)
    try:
        con.execute("SELECT COUNT(*) FROM chunks_fts")
        table_exists = True
    except Exception:
        table_exists = False
    con.close()
    assert flag == table_exists, (
        "meta 表裡記錄的 fts5_available 旗標必須跟資料庫裡實際有沒有 chunks_fts 資料表一致，"
        "不能誠實邊界的旗標和實際能力對不上。"
    )


def test_tokenizer_keeps_code_identifiers_intact():
    tokens = sc.tokenize("av_apply is used with $testHandle")
    assert "av_apply" in tokens, "底線組成的技術識別字（如 av_apply）不應被拆散"


def _run_all():
    tests = [obj for name, obj in globals().items() if name.startswith("test_") and callable(obj)]
    failed = 0
    for t in tests:
        try:
            t()
            print(f"✅ {t.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"❌ {t.__name__}: {e}")
    print(f"\n{len(tests) - failed}/{len(tests)} 通過")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(_run_all())
