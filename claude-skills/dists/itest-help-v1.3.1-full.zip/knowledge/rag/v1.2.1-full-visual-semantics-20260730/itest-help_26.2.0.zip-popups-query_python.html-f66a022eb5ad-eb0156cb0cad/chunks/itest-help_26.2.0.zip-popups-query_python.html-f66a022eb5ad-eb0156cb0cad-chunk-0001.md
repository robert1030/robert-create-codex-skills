---
chunk_id: itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-chunk-0001
source_id: itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad
title: query
heading_path:
- query
section_titles:
- query
source_block_ids:
- itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-block-0001
- itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-block-0002
- itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-block-0003
- itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-block-0004
- itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-block-0005
- itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-block-0006
- itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-block-0007
- itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-block-0008
- itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-block-0009
- itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-block-0010
- itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-block-0011
- itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-block-0012
- itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-block-0013
- itest-help_26.2.0.zip-popups-query_python.html-f66a022eb5ad-eb0156cb0cad-block-0014
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 365
source_hash: eb0156cb0cadb4e8749334f952a658f536f0673726ba03481031375bf0bf007a
normalized_document_hash: 9c6a8b0edbc5d6905248ad507082f4bb7eb846c9d953a3d7bd96ece95dae1fb6
content_status: success
content_sha256: 8ca822138a308a14d544c2990cedf2f8d68efdc831867d3561cfae1315aee00c
---

# query

query

('variableName', 'mapperQuery') #alwaysList=True

Use the query command to insert the result of a query into a command or property.

The query command takes two arguments, the first is the location of the stored response. It is either an XPATH query to the location of the stored response on the heap, or a ".", to mean the response for the current step.

variable_name is a variable that stores the response content. The query command takes two arguments, the first is the location of the stored response. It is either an XPATH query to the location of the stored response on the heap, or a ".", to mean the response for the current step.

mapper_query is the query that is performed on the stored response, whose result is returned by the command.

alwaysList is an optional flag that causes a single extracted value to be stored in a list with a single element, rather than in a scalar string. (A response with zero values or multiple values is always stored in a list.) This setting is important when you're using the response as the argument to a foreach statement and a single extracted value can contain whitespace.

Example:

eval print("some: thing") Stores the response in a variable named "response". query('response', 'some()', alwaysList=False) Do not check the option Store only the text of the response, in Step Properties > Other Post-processing.

For details, see the online help: Inserting the results of a query

Here's a tip for the quickest way to insert a field replacement for a query command applied to a stored response

Also:

Field replacements: Substituting values into properties and commands
