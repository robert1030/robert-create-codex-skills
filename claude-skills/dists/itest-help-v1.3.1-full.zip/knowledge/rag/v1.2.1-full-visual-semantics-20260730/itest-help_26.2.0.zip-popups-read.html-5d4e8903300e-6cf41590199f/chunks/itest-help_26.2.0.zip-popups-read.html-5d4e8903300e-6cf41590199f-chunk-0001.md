---
chunk_id: itest-help_26.2.0.zip-popups-read.html-5d4e8903300e-6cf41590199f-chunk-0001
source_id: itest-help_26.2.0.zip-popups-read.html-5d4e8903300e-6cf41590199f
title: read
heading_path:
- read
section_titles:
- read
source_block_ids:
- itest-help_26.2.0.zip-popups-read.html-5d4e8903300e-6cf41590199f-block-0001
- itest-help_26.2.0.zip-popups-read.html-5d4e8903300e-6cf41590199f-block-0002
- itest-help_26.2.0.zip-popups-read.html-5d4e8903300e-6cf41590199f-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 73
source_hash: 6cf41590199f2e877598759f6179a98839ae5c8d89569fb53a2a4565ad61decf
normalized_document_hash: d5364d55bcc5fc0ff2f98558d3418c9064d2f126211a755042a293f1766fe4c1
content_status: success
content_sha256: 81502a31d2e52abd7e194a41bdbd199748851bdaad8e06332ad55f6b72da9fa0
---

# read

Returns all available data from the listen port. If timeout elapses and no data is received, continues to the next step.
( timeout in seconds ) A timeout of 0 (zero) causes the read operation to occur immediately.

For details, see the online help: UDP command reference section under the topic "UDP Session Editor Concept" .
