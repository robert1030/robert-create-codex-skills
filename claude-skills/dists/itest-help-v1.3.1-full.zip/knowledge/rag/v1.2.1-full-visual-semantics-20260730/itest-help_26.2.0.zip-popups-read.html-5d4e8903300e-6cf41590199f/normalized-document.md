# read

Returns all available data from the listen port. If timeout elapses and no data is received, continues to the next step.
( timeout in seconds ) A timeout of 0 (zero) causes the read operation to occur immediately.

For details, see the online help: UDP command reference section under the topic "UDP Session Editor Concept" .
