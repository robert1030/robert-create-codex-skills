---
chunk_id: itest-help_26.2.0.zip-popups-readfile.html-7f654ecee47a-6162d3a7a1ee-chunk-0001
source_id: itest-help_26.2.0.zip-popups-readfile.html-7f654ecee47a-6162d3a7a1ee
title: readFile
heading_path:
- readFile
section_titles:
- readFile
source_block_ids:
- itest-help_26.2.0.zip-popups-readfile.html-7f654ecee47a-6162d3a7a1ee-block-0001
- itest-help_26.2.0.zip-popups-readfile.html-7f654ecee47a-6162d3a7a1ee-block-0002
- itest-help_26.2.0.zip-popups-readfile.html-7f654ecee47a-6162d3a7a1ee-block-0003
- itest-help_26.2.0.zip-popups-readfile.html-7f654ecee47a-6162d3a7a1ee-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 66
source_hash: 6162d3a7a1eedeecae983a23cf9d8774ef0dfe636008e1fed189911777614bce
normalized_document_hash: c1f45ca33ce4355113482af8a8ce24ec6daa88827a4f3f15b0f5a3b8221c3271
content_status: success
content_sha256: 060ef2e54eb5766614746fe99713b2d4bcc3d9356eb3675d35ea190679fecc1d
---

# readFile

A readFile step returns the text of the file whose path is specified in the Description cell (the value of the Command property).

For example, the response to this example step is the text of the Testbed_A_Description.txt file.

For details, see the online help: The readFile action .
