# readFile

A readFile step returns the text of the file whose path is specified in the Description cell (the value of the Command property).

For example, the response to this example step is the text of the Testbed_A_Description.txt file.

For details, see the online help: The readFile action .
