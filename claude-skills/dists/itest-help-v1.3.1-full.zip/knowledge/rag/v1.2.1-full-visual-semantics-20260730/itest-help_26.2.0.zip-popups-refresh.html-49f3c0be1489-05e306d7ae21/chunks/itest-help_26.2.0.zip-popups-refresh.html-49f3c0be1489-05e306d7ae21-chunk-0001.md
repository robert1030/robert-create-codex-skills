---
chunk_id: itest-help_26.2.0.zip-popups-refresh.html-49f3c0be1489-05e306d7ae21-chunk-0001
source_id: itest-help_26.2.0.zip-popups-refresh.html-49f3c0be1489-05e306d7ae21
title: refresh
heading_path:
- refresh
section_titles:
- refresh
source_block_ids:
- itest-help_26.2.0.zip-popups-refresh.html-49f3c0be1489-05e306d7ae21-block-0001
- itest-help_26.2.0.zip-popups-refresh.html-49f3c0be1489-05e306d7ae21-block-0002
- itest-help_26.2.0.zip-popups-refresh.html-49f3c0be1489-05e306d7ae21-block-0003
- itest-help_26.2.0.zip-popups-refresh.html-49f3c0be1489-05e306d7ae21-block-0004
- itest-help_26.2.0.zip-popups-refresh.html-49f3c0be1489-05e306d7ae21-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 56
source_hash: 05e306d7ae21d3466103ef9d645b76e5453e43f8270b214f0d724c579ee3f408
normalized_document_hash: 2aee3db6b25f98bf2d7749b39ad4d3128094d3eaf1b2b9af92bb036f8cbe1765
content_status: success
content_sha256: 9c8fa9f8d68f47cca5ffb8ac1e4d38f046353154e5dc335667b22c5e4cb85df8
---

# refresh

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| refresh | Not Required | Not Required | Refreshes the page on the browser. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
