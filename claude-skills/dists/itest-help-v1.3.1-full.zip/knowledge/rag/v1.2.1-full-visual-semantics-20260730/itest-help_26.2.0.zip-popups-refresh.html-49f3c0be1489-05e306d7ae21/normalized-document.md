# refresh

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| refresh | Not Required | Not Required | Refreshes the page on the browser. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
