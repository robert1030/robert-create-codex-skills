---
chunk_id: itest-help_26.2.0.zip-popups-regexp.html-80ce55fb4c7a-a2a64710daa3-chunk-0001
source_id: itest-help_26.2.0.zip-popups-regexp.html-80ce55fb4c7a-a2a64710daa3
title: regexp
heading_path:
- regexp
section_titles:
- regexp
source_block_ids:
- itest-help_26.2.0.zip-popups-regexp.html-80ce55fb4c7a-a2a64710daa3-block-0001
- itest-help_26.2.0.zip-popups-regexp.html-80ce55fb4c7a-a2a64710daa3-block-0002
- itest-help_26.2.0.zip-popups-regexp.html-80ce55fb4c7a-a2a64710daa3-block-0003
- itest-help_26.2.0.zip-popups-regexp.html-80ce55fb4c7a-a2a64710daa3-block-0004
- itest-help_26.2.0.zip-popups-regexp.html-80ce55fb4c7a-a2a64710daa3-block-0005
- itest-help_26.2.0.zip-popups-regexp.html-80ce55fb4c7a-a2a64710daa3-block-0006
- itest-help_26.2.0.zip-popups-regexp.html-80ce55fb4c7a-a2a64710daa3-block-0007
- itest-help_26.2.0.zip-popups-regexp.html-80ce55fb4c7a-a2a64710daa3-block-0008
- itest-help_26.2.0.zip-popups-regexp.html-80ce55fb4c7a-a2a64710daa3-block-0009
- itest-help_26.2.0.zip-popups-regexp.html-80ce55fb4c7a-a2a64710daa3-block-0010
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 134
source_hash: a2a64710daa36b581ef11316d772ce8e61f05351593bb210b5613e9dacf858c5
normalized_document_hash: 76e6f7616150776116376b8a686fcd08ec1d88925dbf3813ca6af7552b7e5afe
content_status: success
content_sha256: 0a37d424e42c160b0a39b478512a83065ede976e3044a60e36e604eb55f963d6
---

# regexp

regexp ? switches ? regexp string ? matchVar ? ? subMatchVar subMatchVar ... ?

The regexp command matches a regular expression against a string.

The iTest regexp command uses Java regexps to implement the command. The syntax of regexp patterns is described at http://java.sun.com/javase/6/docs/api/java/util/regex/Pattern.html

The

regexp

command is compatible with its Tcl counterpart as more fully described at:

http://www.tcl.tk/man

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
