# regexp

regexp ? switches ? regexp string ? matchVar ? ? subMatchVar subMatchVar ... ?

The regexp command matches a regular expression against a string.

The iTest regexp command uses Java regexps to implement the command. The syntax of regexp patterns is described at http://java.sun.com/javase/6/docs/api/java/util/regex/Pattern.html

The

regexp

command is compatible with its Tcl counterpart as more fully described at:

http://www.tcl.tk/man

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
