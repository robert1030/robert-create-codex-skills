---
chunk_id: itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-chunk-0001
source_id: itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8
title: regsub
heading_path:
- regsub
section_titles:
- regsub
source_block_ids:
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0001
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0002
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0003
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0004
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0005
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0006
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0007
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0008
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0009
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0010
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0011
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0012
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0013
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0014
- itest-help_26.2.0.zip-popups-regsub.html-7fe33de3e456-6638e22369f8-block-0015
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 159
source_hash: 6638e22369f8ebb5022517e7112402090386e44df873a99df4c42575e0ed8c72
normalized_document_hash: 0ce7c5a0873a360459f77edcc99257d0e9bbcf1833d6df9bb15349d5cddcd762
content_status: success
content_sha256: e2cd465a7c9a5a87dc89e3efb2776199b1b64af5aed1278c7cdf5d205efed9e8
---

# regsub

regsub

?

switches

?

regExp string subSpec

?

varName

?

The regsub command performs substitutions based on regular expression pattern matching.

The command matches the regular expression regExp against string , and either copies string to the variable whose name is given by varName or returns string if varName is not present.

The syntax of Java regexps patterns is described at http://java.sun.com/javase/6/docs/api/java/util/regex/Pattern.html

The iTest regsub command is compatible with its Tcl counterpart as more fully described at http://www.tcl.tk/man

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
