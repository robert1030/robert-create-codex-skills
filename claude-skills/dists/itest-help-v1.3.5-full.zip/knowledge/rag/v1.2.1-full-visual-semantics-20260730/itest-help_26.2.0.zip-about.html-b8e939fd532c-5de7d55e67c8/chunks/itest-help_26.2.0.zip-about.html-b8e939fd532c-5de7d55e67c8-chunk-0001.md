---
chunk_id: itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8-chunk-0001
source_id: itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8
title: About iTest Plug-in
heading_path:
- About iTest Plug-in
section_titles:
- About iTest Plug-in
- License
- Copyright
- Links
source_block_ids:
- itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8-block-0001
- itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8-block-0002
- itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8-block-0003
- itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8-block-0004
- itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8-block-0005
- itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8-block-0006
- itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8-block-0007
- itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8-block-0008
- itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8-block-0009
- itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8-block-0010
- itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8-block-0011
- itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8-block-0012
- itest-help_26.2.0.zip-about.html-b8e939fd532c-5de7d55e67c8-block-0013
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 163
source_hash: 5de7d55e67c8f5d1d1d5e72c5cd6649e51c2d94f339898b1028bbfe91347e173
normalized_document_hash: 528ea35d9be0db7bde1ad7996c542c15164a2128ade8c11d8e98123b6d0b98bd
content_status: success
content_sha256: fa80a472f1307ab76d5f39d03b0441632b6656bcf59237a70e1b441b99ad5133
---

HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN"

# About iTest Plug-in

## License

See the Spirent Communications, Inc. End User License Agreement.

## Copyright

Copyright (C) 2005-2026, Spirent Communications, Inc. All rights reserved.

This computer program is protected by copyright law and international treaties.  Unauthorized reproduction or distribution of this program, or any portion of it, may result in severe civil and criminal penalties, and will be prosecuted to the maximum extent possible under the law.

This offering is powered by Eclipse technology and includes Eclipse plug-ins that can be installed and used with other Eclipse (3.5)-based offerings.

## Links

Spirent Communication's home page:

http://www.spirent.com/

Spirent Communication's support page:

http://support.spirentcom.com
