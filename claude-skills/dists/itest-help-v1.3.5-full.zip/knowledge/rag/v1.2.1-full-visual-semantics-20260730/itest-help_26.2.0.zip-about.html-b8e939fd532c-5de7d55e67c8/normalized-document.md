HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN"

# About iTest Plug-in

## License

See the Spirent Communications, Inc. End User License Agreement.

## Copyright

Copyright (C) 2005-2026, Spirent Communications, Inc. All rights reserved.

This computer program is protected by copyright law and international treaties.  Unauthorized reproduction or distribution of this program, or any portion of it, may result in severe civil and criminal penalties, and will be prosecuted to the maximum extent possible under the law.

This offering is powered by Eclipse technology and includes Eclipse plug-ins that can be installed and used with other Eclipse (3.5)-based offerings.

## Links

Spirent Communication's home page:

http://www.spirent.com/

Spirent Communication's support page:

http://support.spirentcom.com
