---
chunk_id: itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438-chunk-0001
source_id: itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438
title: Add a parameter (that will be replaced at runtime) into a command
heading_path:
- Add a parameter (that will be replaced at runtime) into a command
section_titles:
- Add a parameter (that will be replaced at runtime) into a command
source_block_ids:
- itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438-block-0001
- itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438-block-0002
- itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438-block-0003
- itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438-block-0004
- itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438-block-0005
- itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438-block-0006
- itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438-block-0007
- itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438-block-0008
- itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438-block-0009
- itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438-block-0010
- itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438-block-0011
- itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438-block-0012
- itest-help_26.2.0.zip-cheatsheets-add_parameter.xml-86a54266629a-89f4deecc438-block-0013
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 71
source_hash: 89f4deecc438ec1d56a28542d91406250d2afe19b634977597d7fe15af3828d7
normalized_document_hash: 954fa115119fecc18bb76c0da5b2798a5745282bc4a8150731b74378f25778ff
content_status: success
content_sha256: 33817395dc4b0582b1c38cf391caf90d1a4fc9bb114f638dc0ba53cc4114c65c
---

# Add a parameter (that will be replaced at runtime) into a command

param

pingCount

ping –c [param pingCount] 10.20.30.40

pingCount

6

ping –c 6 10.20.30.40

Let's insert a field substitution that inserts the value of a parameter into a step

Description

ping

22

22

Insert > Parameter...
