# Add a parameter (that will be replaced at runtime) into a command

param

pingCount

ping –c [param pingCount] 10.20.30.40

pingCount

6

ping –c 6 10.20.30.40

Let's insert a field substitution that inserts the value of a parameter into a step

Description

ping

22

22

Insert > Parameter...
