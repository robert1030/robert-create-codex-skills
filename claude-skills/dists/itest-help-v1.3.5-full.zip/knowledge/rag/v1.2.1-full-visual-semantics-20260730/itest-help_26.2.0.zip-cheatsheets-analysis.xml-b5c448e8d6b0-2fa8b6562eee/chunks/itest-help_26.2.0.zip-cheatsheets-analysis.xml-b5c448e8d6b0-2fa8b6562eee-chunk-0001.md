---
chunk_id: itest-help_26.2.0.zip-cheatsheets-analysis.xml-b5c448e8d6b0-2fa8b6562eee-chunk-0001
source_id: itest-help_26.2.0.zip-cheatsheets-analysis.xml-b5c448e8d6b0-2fa8b6562eee
title: Compare a field to an expected value (Add an analysis rule to a step)
heading_path:
- Compare a field to an expected value (Add an analysis rule to a step)
section_titles:
- Compare a field to an expected value (Add an analysis rule to a step)
source_block_ids:
- itest-help_26.2.0.zip-cheatsheets-analysis.xml-b5c448e8d6b0-2fa8b6562eee-block-0001
- itest-help_26.2.0.zip-cheatsheets-analysis.xml-b5c448e8d6b0-2fa8b6562eee-block-0002
- itest-help_26.2.0.zip-cheatsheets-analysis.xml-b5c448e8d6b0-2fa8b6562eee-block-0003
- itest-help_26.2.0.zip-cheatsheets-analysis.xml-b5c448e8d6b0-2fa8b6562eee-block-0004
- itest-help_26.2.0.zip-cheatsheets-analysis.xml-b5c448e8d6b0-2fa8b6562eee-block-0005
- itest-help_26.2.0.zip-cheatsheets-analysis.xml-b5c448e8d6b0-2fa8b6562eee-block-0006
- itest-help_26.2.0.zip-cheatsheets-analysis.xml-b5c448e8d6b0-2fa8b6562eee-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 155
source_hash: 2fa8b6562eee0cce272f87357956fe36c931145f31d6202a10255f859ba896c7
normalized_document_hash: 1a369c58e1055ae2a6d0ec0fb0281eca43d328841ec6e7745c4ec868b67d3b05
content_status: success
content_sha256: 75f7c9f26664bc9e0f2029bf35a2114c1f07dca639a95ff6542e97266e8e3f55
---

# Compare a field to an expected value (Add an analysis rule to a step)

clearStats

Specifying an analysis rule for a step (using the <b>Analysis Rule</b> wizard)

Analysis Rule

1. In the Test Case editor, select the step whose response includes the data to validate, select any one of the following: -- Select the step -- In the Response view, select the data to validate --  In the Structure view, select the item that returns the data -- In the Queries view, select the query that returns the data

2. Right-click the selection and select Add Analysis Rule. The Analysis Rule wizard starts.

3. Follow the instructions provided by the wizard. See the online help for details.
