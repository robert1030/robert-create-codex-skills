# Compare a field to an expected value (Add an analysis rule to a step)

clearStats

Specifying an analysis rule for a step (using the <b>Analysis Rule</b> wizard)

Analysis Rule

1. In the Test Case editor, select the step whose response includes the data to validate, select any one of the following: -- Select the step -- In the Response view, select the data to validate --  In the Structure view, select the item that returns the data -- In the Queries view, select the query that returns the data

2. Right-click the selection and select Add Analysis Rule. The Analysis Rule wizard starts.

3. Follow the instructions provided by the wizard. See the online help for details.
