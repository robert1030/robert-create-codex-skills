---
chunk_id: itest-help_26.2.0.zip-cheatsheets-analysis_string.xml-acd9fd51f6e9-a69e511fc0c8-chunk-0001
source_id: itest-help_26.2.0.zip-cheatsheets-analysis_string.xml-acd9fd51f6e9-a69e511fc0c8
title: Check for a string in a response (Add an analysis rule to a step)
heading_path:
- Check for a string in a response (Add an analysis rule to a step)
section_titles:
- Check for a string in a response (Add an analysis rule to a step)
source_block_ids:
- itest-help_26.2.0.zip-cheatsheets-analysis_string.xml-acd9fd51f6e9-a69e511fc0c8-block-0001
- itest-help_26.2.0.zip-cheatsheets-analysis_string.xml-acd9fd51f6e9-a69e511fc0c8-block-0002
- itest-help_26.2.0.zip-cheatsheets-analysis_string.xml-acd9fd51f6e9-a69e511fc0c8-block-0003
- itest-help_26.2.0.zip-cheatsheets-analysis_string.xml-acd9fd51f6e9-a69e511fc0c8-block-0004
- itest-help_26.2.0.zip-cheatsheets-analysis_string.xml-acd9fd51f6e9-a69e511fc0c8-block-0005
- itest-help_26.2.0.zip-cheatsheets-analysis_string.xml-acd9fd51f6e9-a69e511fc0c8-block-0006
- itest-help_26.2.0.zip-cheatsheets-analysis_string.xml-acd9fd51f6e9-a69e511fc0c8-block-0007
- itest-help_26.2.0.zip-cheatsheets-analysis_string.xml-acd9fd51f6e9-a69e511fc0c8-block-0008
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 210
source_hash: a69e511fc0c83f4c26a80a55d8d6b173be4fafec3df4c39cfd739a7f2c140977
normalized_document_hash: 7cd0ac0ad72f6f601c29018c358302d93cffb1d67cabed4733c62b83ed0cebb4
content_status: success
content_sha256: ea5ab745ddaeaa319f896bf6b3f89266bd5bd1f1269aad6cdc42692b15bdb28a
---

# Check for a string in a response (Add an analysis rule to a step)

One of the most important functions of a test case is to analyze (validate) the responses to steps, and then, based on the results of the analysis, take some specified action (like set the test as Pass or Fail, add an execution message about whether the test passed or failed, and then send email). In this cheat sheet, we'll check whether a particular string appears in a response and then specify the action to take.

Specifying an analysis rule for a step (using the Analysis Rule wizard)

Analysis Rule

1. In the Test Case editor, select the step whose response includes the string to validate.

2. In the Response view, select the string that you want to validate

2. Right-click the selection and select Add Analysis Rule. The Analysis Rule wizard starts.

3. Follow the instructions provided by the wizard. See the online help for details.
