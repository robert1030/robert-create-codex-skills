# Check for a string in a response (Add an analysis rule to a step)

One of the most important functions of a test case is to analyze (validate) the responses to steps, and then, based on the results of the analysis, take some specified action (like set the test as Pass or Fail, add an execution message about whether the test passed or failed, and then send email). In this cheat sheet, we'll check whether a particular string appears in a response and then specify the action to take.

Specifying an analysis rule for a step (using the Analysis Rule wizard)

Analysis Rule

1. In the Test Case editor, select the step whose response includes the string to validate.

2. In the Response view, select the string that you want to validate

2. Right-click the selection and select Add Analysis Rule. The Analysis Rule wizard starts.

3. Follow the instructions provided by the wizard. See the online help for details.
