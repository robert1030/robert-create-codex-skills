---
chunk_id: itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-chunk-0001
source_id: itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5
title: Capture and document a manual test (interacitve sessions)
heading_path:
- Capture and document a manual test (interacitve sessions)
section_titles:
- Capture and document a manual test (interacitve sessions)
source_block_ids:
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0001
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0002
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0003
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0004
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0005
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0006
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0007
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0008
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0009
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0010
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0011
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0012
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0013
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0014
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0015
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0016
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0017
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0018
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0019
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0020
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0021
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0022
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0023
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0024
- itest-help_26.2.0.zip-cheatsheets-capture_n_doc_test_case.xml-41ba5ae3b68e-cc49edb12ef5-block-0025
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 401
source_hash: cc49edb12ef5ddda1e79b7a49a77721a2de67d905ea5acd496de89b0bb243888
normalized_document_hash: 7128b68255ad88045d87f98c01784e473a58d81b0652624176a01ecbfa095cfb
content_status: success
content_sha256: 4826fd028e214da46f4610c224940eef888e914b735a0c20a4a1661a6de42121
---

# Capture and document a manual test (interacitve sessions)

iTest always “observes” while you interact with sessions and then captures session open and close actions, the actions that you send to sessions on devices, the sessions’ responses, and so on. The system displays the ordered list of captured items in the Capture view.</br></br> This cheat sheet explains how to capture a manual test that involves sessions with multiple devices.

Switch to the Test perspective

Test

Start a session

Favorites

Work with the session

Enter commands or use the application's browser to do your testing as you normally would.

Don't worry about mistakes!  If you make a typo or enter commands that shouldn't appear in the final automated test case, don't worry--you can clean up mistakes later after you save your captured commands as a test case.

Tip: An easy way to repeat a command or sequence of commands is to drag the items from the Capture view into the appropriate session editor. You can even drag commands from a text editor.

Notice that iTest is capturing steps

iTest captures each command you submit or action you take on a browser in the Capture view. See the help for details.

Start additional sessions

Start

Move between sessions as needed

Get the information that you want ot validate (analyze)

Restore the devices to a known state

UNDER CONSTRUCTION

Close sessions when you are finished

Typically, you will finish testing by closing all sessions. While this is not strictly required, it is the best practice for keeping your workstation in good order.

Review the captured information

UNDER CONSTRUCTION

Create a capture report if you want one

If the capture information looks useful, you can create a Capture report document that you can  share with coworkers. See the Help for details.

At this point, you could create an automated test case
