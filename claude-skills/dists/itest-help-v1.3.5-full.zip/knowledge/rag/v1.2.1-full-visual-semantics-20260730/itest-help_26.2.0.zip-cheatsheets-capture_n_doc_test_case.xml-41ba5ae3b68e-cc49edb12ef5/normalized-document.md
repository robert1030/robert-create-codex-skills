# Capture and document a manual test (interacitve sessions)

iTest always “observes” while you interact with sessions and then captures session open and close actions, the actions that you send to sessions on devices, the sessions’ responses, and so on. The system displays the ordered list of captured items in the Capture view.</br></br> This cheat sheet explains how to capture a manual test that involves sessions with multiple devices.

Switch to the Test perspective

Test

Start a session

Favorites

Work with the session

Enter commands or use the application's browser to do your testing as you normally would.

Don't worry about mistakes!  If you make a typo or enter commands that shouldn't appear in the final automated test case, don't worry--you can clean up mistakes later after you save your captured commands as a test case.

Tip: An easy way to repeat a command or sequence of commands is to drag the items from the Capture view into the appropriate session editor. You can even drag commands from a text editor.

Notice that iTest is capturing steps

iTest captures each command you submit or action you take on a browser in the Capture view. See the help for details.

Start additional sessions

Start

Move between sessions as needed

Get the information that you want ot validate (analyze)

Restore the devices to a known state

UNDER CONSTRUCTION

Close sessions when you are finished

Typically, you will finish testing by closing all sessions. While this is not strictly required, it is the best practice for keeping your workstation in good order.

Review the captured information

UNDER CONSTRUCTION

Create a capture report if you want one

If the capture information looks useful, you can create a Capture report document that you can  share with coworkers. See the Help for details.

At this point, you could create an automated test case
