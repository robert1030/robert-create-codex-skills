---
chunk_id: itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45-chunk-0001
source_id: itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45
title: Checkout example projects from Spirent
heading_path:
- Checkout example projects from Spirent
section_titles:
- Checkout example projects from Spirent
source_block_ids:
- itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45-block-0001
- itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45-block-0002
- itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45-block-0003
- itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45-block-0004
- itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45-block-0005
- itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45-block-0006
- itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45-block-0007
- itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45-block-0008
- itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45-block-0009
- itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45-block-0010
- itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45-block-0011
- itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45-block-0012
- itest-help_26.2.0.zip-cheatsheets-checkout_example_from_svn.xml-e74417123827-fa062080cd45-block-0013
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 172
source_hash: fa062080cd45aba0e27487b4c28ac35d0cdfc6e4b2debaf215f113fe217ca21c
normalized_document_hash: 0e7d7235ed313d405ee953e5a84df32df56159cdbba63cdab8ceb1ffbcbfc8d3
content_status: success
content_sha256: 77c7b6a905feaa2aa39ce15fcaa2cd389b8ba2caa25301aed7f1e28d99eb3dac
---

# Checkout example projects from Spirent

This cheet sheet will guide you though the process of checking out an example iTest project from Spirent's public subversion repository.

Start the Checkout Projects from SVN wizard

Checkout Projects from SVN

Step through the wizard

Next

Finish

Select "Create a New Repository Loacation"

Create a new repository location using  the following URL  http://svn.fanfaresoftware.com/examples

Pick one or more of the example projects by selecting them from the tree.  For example, if you work with Cisco equipment, you might choose 'cisco_ios'

Accept the default name

Done

It will take a few seconds to dowload the example projects over the internet.  You are new ready to start using the files in the example project.

See http://trac.fanfaresoftware.com/examples for more information..
