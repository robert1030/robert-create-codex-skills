# Checkout example projects from Spirent

This cheet sheet will guide you though the process of checking out an example iTest project from Spirent's public subversion repository.

Start the Checkout Projects from SVN wizard

Checkout Projects from SVN

Step through the wizard

Next

Finish

Select "Create a New Repository Loacation"

Create a new repository location using  the following URL  http://svn.fanfaresoftware.com/examples

Pick one or more of the example projects by selecting them from the tree.  For example, if you work with Cisco equipment, you might choose 'cisco_ios'

Accept the default name

Done

It will take a few seconds to dowload the example projects over the internet.  You are new ready to start using the files in the example project.

See http://trac.fanfaresoftware.com/examples for more information..
