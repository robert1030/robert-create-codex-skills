---
chunk_id: itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-chunk-0001
source_id: itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986
title: Creating an Automated Test Case from Captured Sessions
heading_path:
- Creating an Automated Test Case from Captured Sessions
section_titles:
- Creating an Automated Test Case from Captured Sessions
source_block_ids:
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0001
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0002
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0003
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0004
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0005
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0006
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0007
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0008
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0009
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0010
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0011
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0012
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0013
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0014
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0015
- itest-help_26.2.0.zip-cheatsheets-create_automated_test_case_from_ca-46ee19b91ab6-d3c64b96d986-block-0016
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 138
source_hash: d3c64b96d9866d8b9711ed2450d841cc68661f173852251e9ecbe840d9a147f1
normalized_document_hash: 5ba5a327ee925010ab8eb76d03a657d1d0760c502b020d4e0ef9177b77cb1694
content_status: success
content_sha256: abb677a29a11f87b940ef350b3d474bb04d4bfba496375962eb60b8122e31368
---

# Creating an Automated Test Case from Captured Sessions

It's easy to convert a manual testing session (or just selected steps) into an automated test case. This cheat sheet shows you how.

Open or select the Capture view

Window > Show View > Capture View

Find one or more captured sessions or capture them now

Capturing and documenting a manual test

In the Capture view, select the sessions or steps

Save the selected items as a test case

Save as Test Case

Save as Test Case

Finish

iTest asks you to switch to the Develop perspective

Review the resulting test case

Note:

Run the test case!

Troubleshooting Test Case Execution
