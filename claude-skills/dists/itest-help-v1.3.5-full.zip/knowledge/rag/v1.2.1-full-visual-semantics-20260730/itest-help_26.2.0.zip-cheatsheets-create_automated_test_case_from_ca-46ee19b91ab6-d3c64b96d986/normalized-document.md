# Creating an Automated Test Case from Captured Sessions

It's easy to convert a manual testing session (or just selected steps) into an automated test case. This cheat sheet shows you how.

Open or select the Capture view

Window > Show View > Capture View

Find one or more captured sessions or capture them now

Capturing and documenting a manual test

In the Capture view, select the sessions or steps

Save the selected items as a test case

Save as Test Case

Save as Test Case

Finish

iTest asks you to switch to the Develop perspective

Review the resulting test case

Note:

Run the test case!

Troubleshooting Test Case Execution
