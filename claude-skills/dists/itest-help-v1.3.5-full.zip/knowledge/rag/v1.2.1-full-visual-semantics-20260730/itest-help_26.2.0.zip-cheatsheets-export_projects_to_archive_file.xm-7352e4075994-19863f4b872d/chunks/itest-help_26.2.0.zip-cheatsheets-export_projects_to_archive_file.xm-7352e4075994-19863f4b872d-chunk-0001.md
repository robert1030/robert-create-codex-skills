---
chunk_id: itest-help_26.2.0.zip-cheatsheets-export_projects_to_archive_file.xm-7352e4075994-19863f4b872d-chunk-0001
source_id: itest-help_26.2.0.zip-cheatsheets-export_projects_to_archive_file.xm-7352e4075994-19863f4b872d
title: Archiving a Set of Projects
heading_path:
- Archiving a Set of Projects
section_titles:
- Archiving a Set of Projects
source_block_ids:
- itest-help_26.2.0.zip-cheatsheets-export_projects_to_archive_file.xm-7352e4075994-19863f4b872d-block-0001
- itest-help_26.2.0.zip-cheatsheets-export_projects_to_archive_file.xm-7352e4075994-19863f4b872d-block-0002
- itest-help_26.2.0.zip-cheatsheets-export_projects_to_archive_file.xm-7352e4075994-19863f4b872d-block-0003
- itest-help_26.2.0.zip-cheatsheets-export_projects_to_archive_file.xm-7352e4075994-19863f4b872d-block-0004
- itest-help_26.2.0.zip-cheatsheets-export_projects_to_archive_file.xm-7352e4075994-19863f4b872d-block-0005
- itest-help_26.2.0.zip-cheatsheets-export_projects_to_archive_file.xm-7352e4075994-19863f4b872d-block-0006
- itest-help_26.2.0.zip-cheatsheets-export_projects_to_archive_file.xm-7352e4075994-19863f4b872d-block-0007
- itest-help_26.2.0.zip-cheatsheets-export_projects_to_archive_file.xm-7352e4075994-19863f4b872d-block-0008
- itest-help_26.2.0.zip-cheatsheets-export_projects_to_archive_file.xm-7352e4075994-19863f4b872d-block-0009
- itest-help_26.2.0.zip-cheatsheets-export_projects_to_archive_file.xm-7352e4075994-19863f4b872d-block-0010
- itest-help_26.2.0.zip-cheatsheets-export_projects_to_archive_file.xm-7352e4075994-19863f4b872d-block-0011
- itest-help_26.2.0.zip-cheatsheets-export_projects_to_archive_file.xm-7352e4075994-19863f4b872d-block-0012
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 98
source_hash: 19863f4b872d17848fc5f34b4a9e19074410a4df0b0f446c490b7e0f814db8ce
normalized_document_hash: b1233babf90e3f2799bec4a6c2539b969a8b65f11682baad3960fbd005636b59
content_status: success
content_sha256: 78ae60c205026fd58902fd48c68d4939094cca488c76e593e4c3b2bd4cdf3772
---

# Archiving a Set of Projects

If you need to seend some or all of the projects in your iTest workspace to another user or to Spirent support, you will need to export them as an archive file.

Start the Archive File Export Wizard

File > Export

Archive File

General

Select Projects

Select All

Supply a Filename

To archive file

All Done!

Now simply send the archive file that you just created to another user or Spirent support.
