# Archiving a Set of Projects

If you need to seend some or all of the projects in your iTest workspace to another user or to Spirent support, you will need to export them as an archive file.

Start the Archive File Export Wizard

File > Export

Archive File

General

Select Projects

Select All

Supply a Filename

To archive file

All Done!

Now simply send the archive file that you just created to another user or Spirent support.
