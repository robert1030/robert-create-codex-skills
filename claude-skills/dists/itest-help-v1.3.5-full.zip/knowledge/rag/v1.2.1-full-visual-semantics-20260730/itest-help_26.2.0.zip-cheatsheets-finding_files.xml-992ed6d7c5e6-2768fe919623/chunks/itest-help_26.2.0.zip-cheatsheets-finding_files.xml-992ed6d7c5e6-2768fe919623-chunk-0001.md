---
chunk_id: itest-help_26.2.0.zip-cheatsheets-finding_files.xml-992ed6d7c5e6-2768fe919623-chunk-0001
source_id: itest-help_26.2.0.zip-cheatsheets-finding_files.xml-992ed6d7c5e6-2768fe919623
title: Find the session or file that you need
heading_path:
- Find the session or file that you need
section_titles:
- Find the session or file that you need
source_block_ids:
- itest-help_26.2.0.zip-cheatsheets-finding_files.xml-992ed6d7c5e6-2768fe919623-block-0001
- itest-help_26.2.0.zip-cheatsheets-finding_files.xml-992ed6d7c5e6-2768fe919623-block-0002
- itest-help_26.2.0.zip-cheatsheets-finding_files.xml-992ed6d7c5e6-2768fe919623-block-0003
- itest-help_26.2.0.zip-cheatsheets-finding_files.xml-992ed6d7c5e6-2768fe919623-block-0004
- itest-help_26.2.0.zip-cheatsheets-finding_files.xml-992ed6d7c5e6-2768fe919623-block-0005
- itest-help_26.2.0.zip-cheatsheets-finding_files.xml-992ed6d7c5e6-2768fe919623-block-0006
- itest-help_26.2.0.zip-cheatsheets-finding_files.xml-992ed6d7c5e6-2768fe919623-block-0007
- itest-help_26.2.0.zip-cheatsheets-finding_files.xml-992ed6d7c5e6-2768fe919623-block-0008
- itest-help_26.2.0.zip-cheatsheets-finding_files.xml-992ed6d7c5e6-2768fe919623-block-0009
- itest-help_26.2.0.zip-cheatsheets-finding_files.xml-992ed6d7c5e6-2768fe919623-block-0010
- itest-help_26.2.0.zip-cheatsheets-finding_files.xml-992ed6d7c5e6-2768fe919623-block-0011
- itest-help_26.2.0.zip-cheatsheets-finding_files.xml-992ed6d7c5e6-2768fe919623-block-0012
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 139
source_hash: 2768fe919623303e540c06e40f147eeed7fb86bf5afcc0e38ff6f1e190692fde
normalized_document_hash: d8a583a6432cbc5b1969efd6c270bd2abee0886735ecb25f3c44d279705dbcdc
content_status: success
content_sha256: 93885a70f062ef7b3995b492c0e4b056030b1c524313155a578801c7c028032f
---

# Find the session or file that you need

You know you created a session profile for that device! Where is it?

This cheat sheet describes the tools that you can use to locate any iTest document.

Use the iTest Explorer

Check the Favorites view

If you saved your test case or session profile to the Favorites view, then it should appear in the appropriate folder in the view (alphabetic sort).

About iTest file extensions

.ffsp

Search for a file

Edit > Search

Search

Search for text within a file

You can search for a file based on text that appears in the file. See the Help for details.
