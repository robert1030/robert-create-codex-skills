# Find the session or file that you need

You know you created a session profile for that device! Where is it?

This cheat sheet describes the tools that you can use to locate any iTest document.

Use the iTest Explorer

Check the Favorites view

If you saved your test case or session profile to the Favorites view, then it should appear in the appropriate folder in the view (alphabetic sort).

About iTest file extensions

.ffsp

Search for a file

Edit > Search

Search

Search for text within a file

You can search for a file based on text that appears in the file. See the Help for details.
