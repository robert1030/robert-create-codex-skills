---
chunk_id: itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-chunk-0001
source_id: itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e
title: Mapping a response
heading_path:
- Mapping a response
section_titles:
- Mapping a response
source_block_ids:
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0001
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0002
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0003
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0004
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0005
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0006
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0007
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0008
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0009
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0010
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0011
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0012
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0013
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0014
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0015
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0016
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0017
- itest-help_26.2.0.zip-cheatsheets-first.xml-0f3fdaee2870-520526d4631e-block-0018
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 225
source_hash: 520526d4631e038fb9e82763eec13c3d06c5e474622b90abd5599c4ceb195343
normalized_document_hash: 8474133d091eefcedf8b26397ee24e106b883fb9296726666627e47fa00af7d8
content_status: success
content_sha256: 39d328f1b85c5b912155f5ad0bb7237ae855474e7cbcd57f32e9ef3cedda175c
---

# Mapping a response

response map

Help

Create a response map

New Response Map

Finish

Confirm Perspective Switch

Yes

Identifying and copy the data to extract from the response

Response

Add a regular expression map

Overview

Mappers

Regex

Click the Add button to add a regular expression mapper definition. This is the regex group that will extract the value from each response to the show version command. The group is assigned a default Group name. You can supply a more meaningful name (motherboard_revision_number would be a good name in our example).

Paste the text into the Identifying Text box. iTest immediately ties to “guess” which parts of the text you will be interested in analyzing. It selects the number 20 and suggests that the regular expression \S+ should match this portion of the text in most instances. This is a pretty good guess, except that we want to extract the number so that we can determine whether it is greater than 18. So, let’s specify a different regular expression.

Save the response map

Save
