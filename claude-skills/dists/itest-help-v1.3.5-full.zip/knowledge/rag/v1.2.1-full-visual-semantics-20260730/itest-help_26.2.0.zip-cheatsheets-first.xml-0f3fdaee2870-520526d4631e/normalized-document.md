# Mapping a response

response map

Help

Create a response map

New Response Map

Finish

Confirm Perspective Switch

Yes

Identifying and copy the data to extract from the response

Response

Add a regular expression map

Overview

Mappers

Regex

Click the Add button to add a regular expression mapper definition. This is the regex group that will extract the value from each response to the show version command. The group is assigned a default Group name. You can supply a more meaningful name (motherboard_revision_number would be a good name in our example).

Paste the text into the Identifying Text box. iTest immediately ties to “guess” which parts of the text you will be interested in analyzing. It selects the number 20 and suggests that the regular expression \S+ should match this portion of the text in most instances. This is a pretty good guess, except that we want to extract the number so that we can determine whether it is greater than 18. So, let’s specify a different regular expression.

Save the response map

Save
