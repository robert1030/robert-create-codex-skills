---
chunk_id: itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-chunk-0001
source_id: itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105
title: Follow these steps to become an iTest Rock Star
heading_path:
- Follow these steps to become an iTest Rock Star
section_titles:
- Follow these steps to become an iTest Rock Star
- 'iTest Skills: Follow each of these cheat sheets in order'
source_block_ids:
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0001
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0002
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0003
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0004
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0005
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0006
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0007
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0008
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0009
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0010
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0011
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0012
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0013
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0014
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0015
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0016
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0017
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0018
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0019
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0020
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0021
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0022
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0023
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0024
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0025
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0026
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0027
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0028
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0029
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0030
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0031
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0032
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0033
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0034
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0035
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0036
- itest-help_26.2.0.zip-cheatsheets-getting_started_with_itest.xml-98d637cd48f3-d609d151c105-block-0037
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 264
source_hash: d609d151c105fa565b4229824e3d4b13c36e67248d0f9ed76b8fe4f3fa8388f7
normalized_document_hash: 509723ee8cd692dd4479b48ec36b9e74ed5cbd24276949a7f644021b68f28b85
content_status: success
content_sha256: 115370081fddda1d3af3dd3257074e65e4f20d91925c50fa521838b35dc00e29
---

# Follow these steps to become an iTest Rock Star

## iTest Skills: Follow each of these cheat sheets in order

This group of cheat sheets will help you to learn how to use iTest to perform a variety of test automation and documentation tasks.

Congratulations.

1. Create a robust session profile for connecting to a device

Introduction

Conclusion

2. Capture and document a manual test

Let's use iTest to capture a manual test

You now know how to capture a manual test.

3. Create an automated test ase from captured sessions

Introduction

Conclusion

4. Find the session or file that you are looking for

Introduction

Conclusion

5. Restore the iTest layout to its original state

Introduction

Conclusion

6. Run a test case and review the resulting report

Introduction

Conclusion

7. Troubleshoot a test case that “hangs” during execution

Introduction

Conclusion

8. Check for a string in a response (Add an analysis rule to a step)

Introduction

Conclusion

9. Compare a field to an expected value (Add an analysis rule to a step)

Introduction

Conclusion

10. Add a loop to a test case to repeat a sequence of steps

Introduction

Conclusion

11. Add a parameter into a command that will be replaced at runtime

Introduction

Conclusion
