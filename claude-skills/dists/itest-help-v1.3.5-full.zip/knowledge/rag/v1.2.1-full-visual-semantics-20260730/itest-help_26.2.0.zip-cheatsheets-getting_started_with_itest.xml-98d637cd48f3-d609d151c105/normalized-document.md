# Follow these steps to become an iTest Rock Star

## iTest Skills: Follow each of these cheat sheets in order

This group of cheat sheets will help you to learn how to use iTest to perform a variety of test automation and documentation tasks.

Congratulations.

1. Create a robust session profile for connecting to a device

Introduction

Conclusion

2. Capture and document a manual test

Let's use iTest to capture a manual test

You now know how to capture a manual test.

3. Create an automated test ase from captured sessions

Introduction

Conclusion

4. Find the session or file that you are looking for

Introduction

Conclusion

5. Restore the iTest layout to its original state

Introduction

Conclusion

6. Run a test case and review the resulting report

Introduction

Conclusion

7. Troubleshoot a test case that “hangs” during execution

Introduction

Conclusion

8. Check for a string in a response (Add an analysis rule to a step)

Introduction

Conclusion

9. Compare a field to an expected value (Add an analysis rule to a step)

Introduction

Conclusion

10. Add a loop to a test case to repeat a sequence of steps

Introduction

Conclusion

11. Add a parameter into a command that will be replaced at runtime

Introduction

Conclusion
