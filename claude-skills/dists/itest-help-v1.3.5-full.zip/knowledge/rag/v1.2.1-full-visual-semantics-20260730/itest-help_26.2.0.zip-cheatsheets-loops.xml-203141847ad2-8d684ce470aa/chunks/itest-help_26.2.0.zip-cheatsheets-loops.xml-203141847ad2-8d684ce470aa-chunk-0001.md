---
chunk_id: itest-help_26.2.0.zip-cheatsheets-loops.xml-203141847ad2-8d684ce470aa-chunk-0001
source_id: itest-help_26.2.0.zip-cheatsheets-loops.xml-203141847ad2-8d684ce470aa
title: Add a loop to repeat a sequence of steps
heading_path:
- Add a loop to repeat a sequence of steps
section_titles:
- Add a loop to repeat a sequence of steps
source_block_ids:
- itest-help_26.2.0.zip-cheatsheets-loops.xml-203141847ad2-8d684ce470aa-block-0001
- itest-help_26.2.0.zip-cheatsheets-loops.xml-203141847ad2-8d684ce470aa-block-0002
- itest-help_26.2.0.zip-cheatsheets-loops.xml-203141847ad2-8d684ce470aa-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 48
source_hash: 8d684ce470aa1ed295ba3911b3cc3b1847922e5887d0436f3bcc7e888c00044b
normalized_document_hash: 24285d0b623f8f44ee870649415dd7115b4bfbc579880731a48b962f6cf57f59
content_status: success
content_sha256: faf8546698b0fc4e7e4b245eec938cc43430e9c275b354c68b7c6979456c62a1
---

# Add a loop to repeat a sequence of steps

Add the steps that should be inside the loop

Create the steps that should appear within the loop and then follow the instructions that appear in the Help.
