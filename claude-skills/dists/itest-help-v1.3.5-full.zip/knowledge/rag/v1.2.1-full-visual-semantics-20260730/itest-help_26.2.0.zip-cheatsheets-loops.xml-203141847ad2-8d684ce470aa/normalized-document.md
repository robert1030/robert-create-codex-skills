# Add a loop to repeat a sequence of steps

Add the steps that should be inside the loop

Create the steps that should appear within the loop and then follow the instructions that appear in the Help.
