---
chunk_id: itest-help_26.2.0.zip-cheatsheets-restore_layout.xml-6ebc5db7105f-1fddce962956-chunk-0001
source_id: itest-help_26.2.0.zip-cheatsheets-restore_layout.xml-6ebc5db7105f-1fddce962956
title: Restore the iTest layout to its original state
heading_path:
- Restore the iTest layout to its original state
section_titles:
- Restore the iTest layout to its original state
source_block_ids:
- itest-help_26.2.0.zip-cheatsheets-restore_layout.xml-6ebc5db7105f-1fddce962956-block-0001
- itest-help_26.2.0.zip-cheatsheets-restore_layout.xml-6ebc5db7105f-1fddce962956-block-0002
- itest-help_26.2.0.zip-cheatsheets-restore_layout.xml-6ebc5db7105f-1fddce962956-block-0003
- itest-help_26.2.0.zip-cheatsheets-restore_layout.xml-6ebc5db7105f-1fddce962956-block-0004
- itest-help_26.2.0.zip-cheatsheets-restore_layout.xml-6ebc5db7105f-1fddce962956-block-0005
- itest-help_26.2.0.zip-cheatsheets-restore_layout.xml-6ebc5db7105f-1fddce962956-block-0006
- itest-help_26.2.0.zip-cheatsheets-restore_layout.xml-6ebc5db7105f-1fddce962956-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 41
source_hash: 1fddce962956511ae19b7b82931c6a07313eb47ee1db0165bfe86051b8651496
normalized_document_hash: fecad1b1a1e80275a1c74e9bb192636878a229871e561909ae90e77ffad9d292
content_status: success
content_sha256: ac3dae9232c54a883c426f4db37157bf7c2d2f1f008f753302aa3ececb5dcf9e
---

# Restore the iTest layout to its original state

Restoring the current perspective to its default appearance

Window > Reset Window Layout

Switching perspectives

Map

Automatically switching perspectives when performing a new task

Develop
