# Restore the iTest layout to its original state

Restoring the current perspective to its default appearance

Window > Reset Window Layout

Switching perspectives

Map

Automatically switching perspectives when performing a new task

Develop
