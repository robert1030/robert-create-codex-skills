---
chunk_id: itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-chunk-0001
source_id: itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8
title: Creating a robust session profile for connecting to a device
heading_path:
- Creating a robust session profile for connecting to a device
section_titles:
- Creating a robust session profile for connecting to a device
source_block_ids:
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0001
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0002
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0003
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0004
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0005
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0006
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0007
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0008
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0009
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0010
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0011
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0012
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0013
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0014
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0015
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0016
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0017
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0018
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0019
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0020
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0021
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0022
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0023
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0024
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0025
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0026
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0027
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0028
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0029
- itest-help_26.2.0.zip-cheatsheets-sessionprofile_01.xml-eb9d24ba0bd8-d252caa77ea8-block-0030
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 290
source_hash: d252caa77ea8eb871f176d54e8d937c6d0564c91f8d1a59685b3578759fc7aa2
normalized_document_hash: 71372d45abc6a74694af3ca1d09b21ea4f0932bea9df82d0e0f7d9f0af4cca61
content_status: success
content_sha256: 585c3c287379b40a894a49cd5405f114209ea3c56892137757f1f08ae134d796
---

# Creating a robust session profile for connecting to a device

session profile

Help

Open the Session Profile editor

New Session

Start a New Session

Select a session type

Session Type

Telnet

SSH

Describe (configure) the session

Session Name

telenet_Lab_Router3

IP address

Port

More

Start the session

Send commands in the session to train iTest

Close the session

Submit an “exit” command (or whichever command ends sessions). Alternatively, you can just close the Session window.

Complete the Update Session Profile wizard

Use the updated session profile to start a new session

Show View > iTest Explorer

Update Session Profile

Repeat the process of creating a session profile for each device/session type combination that you will use

It is best for you to teach iTest about each of the devices and/or session types that you will be using before you start trying to create automated tests.

Review the Favorites view to see all of your session profiles

Try launching multiple sessions so that they are all running concurrently

13) What next?

If you have created all the session profiles you need, you have accomplished an important task — sessions that iTest starts will respond correctly during manual testing. Your next task is to run some realistic manual tests that you will eventually use as the basis for automated tests. See the cheat sheet named Capturing Manual Tests.
