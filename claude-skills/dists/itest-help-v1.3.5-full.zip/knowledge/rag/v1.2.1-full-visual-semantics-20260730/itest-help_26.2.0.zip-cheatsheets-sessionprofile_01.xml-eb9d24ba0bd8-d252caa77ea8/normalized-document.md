# Creating a robust session profile for connecting to a device

session profile

Help

Open the Session Profile editor

New Session

Start a New Session

Select a session type

Session Type

Telnet

SSH

Describe (configure) the session

Session Name

telenet_Lab_Router3

IP address

Port

More

Start the session

Send commands in the session to train iTest

Close the session

Submit an “exit” command (or whichever command ends sessions). Alternatively, you can just close the Session window.

Complete the Update Session Profile wizard

Use the updated session profile to start a new session

Show View > iTest Explorer

Update Session Profile

Repeat the process of creating a session profile for each device/session type combination that you will use

It is best for you to teach iTest about each of the devices and/or session types that you will be using before you start trying to create automated tests.

Review the Favorites view to see all of your session profiles

Try launching multiple sessions so that they are all running concurrently

13) What next?

If you have created all the session profiles you need, you have accomplished an important task — sessions that iTest starts will respond correctly during manual testing. Your next task is to run some realistic manual tests that you will eventually use as the basis for automated tests. See the cheat sheet named Capturing Manual Tests.
