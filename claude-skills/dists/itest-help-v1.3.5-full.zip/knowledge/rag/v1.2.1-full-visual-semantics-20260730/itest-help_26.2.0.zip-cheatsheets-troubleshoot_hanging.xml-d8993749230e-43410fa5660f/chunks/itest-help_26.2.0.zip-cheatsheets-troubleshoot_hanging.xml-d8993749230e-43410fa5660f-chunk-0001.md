---
chunk_id: itest-help_26.2.0.zip-cheatsheets-troubleshoot_hanging.xml-d8993749230e-43410fa5660f-chunk-0001
source_id: itest-help_26.2.0.zip-cheatsheets-troubleshoot_hanging.xml-d8993749230e-43410fa5660f
title: Troubleshoot a test case that “hangs” during execution
heading_path:
- Troubleshoot a test case that “hangs” during execution
section_titles:
- Troubleshoot a test case that “hangs” during execution
source_block_ids:
- itest-help_26.2.0.zip-cheatsheets-troubleshoot_hanging.xml-d8993749230e-43410fa5660f-block-0001
- itest-help_26.2.0.zip-cheatsheets-troubleshoot_hanging.xml-d8993749230e-43410fa5660f-block-0002
- itest-help_26.2.0.zip-cheatsheets-troubleshoot_hanging.xml-d8993749230e-43410fa5660f-block-0003
- itest-help_26.2.0.zip-cheatsheets-troubleshoot_hanging.xml-d8993749230e-43410fa5660f-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 91
source_hash: 43410fa5660fd82f8a51a5161555d7ccc6ba2404a237cf674a6ce359caede592
normalized_document_hash: 072211323faabe14b5a3fd78ab0def5458e7da4e71386473f2dc40c416ae7132
content_status: success
content_sha256: a6b0611faf2a1f08276176ab033e3f0c7f36d4b26085f8394f500e444d014a25
---

# Troubleshoot a test case that “hangs” during execution

Execute One Step

Avoiding the problem in the future

To enable the steps to replay without interruption in the future, you can “teach” iTest about the new prompt format by adding a prompt definition.  iTest will recognize the prompt from then on.
</br></br> For instructions, see the section in the Help titled “Example prompts that require custom definitions”.
