# Troubleshoot a test case that “hangs” during execution

Execute One Step

Avoiding the problem in the future

To enable the steps to replay without interruption in the future, you can “teach” iTest about the new prompt format by adding a prompt definition.  iTest will recognize the prompt from then on.
</br></br> For instructions, see the section in the Help titled “Example prompts that require custom definitions”.
