---
chunk_id: itest-help_26.2.0.zip-popups-answerprompt.html-487b12a60616-7503b3f88975-chunk-0001
source_id: itest-help_26.2.0.zip-popups-answerprompt.html-487b12a60616-7503b3f88975
title: answerPrompt
heading_path:
- answerPrompt
section_titles:
- answerPrompt
source_block_ids:
- itest-help_26.2.0.zip-popups-answerprompt.html-487b12a60616-7503b3f88975-block-0001
- itest-help_26.2.0.zip-popups-answerprompt.html-487b12a60616-7503b3f88975-block-0002
- itest-help_26.2.0.zip-popups-answerprompt.html-487b12a60616-7503b3f88975-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 57
source_hash: 7503b3f88975b99744a1f0316261216dfe8f589dda0bac9523dfab943e7a1f40
normalized_document_hash: af17f1ee99573b282f186917a2720eb70ffba8bd6abafe659e24ca92ba507d49
content_status: success
content_sha256: 587d7bfbdda15cea33d2db79915efecc89ce1ea60c5f14300e12a0ecfd76c930
---

# answerPrompt

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| answerPrompt | Not Required | Required | Returns the answerString specified in the Command property as the response to the next prompt. |

For details, see the online help: Selenium action reference .
