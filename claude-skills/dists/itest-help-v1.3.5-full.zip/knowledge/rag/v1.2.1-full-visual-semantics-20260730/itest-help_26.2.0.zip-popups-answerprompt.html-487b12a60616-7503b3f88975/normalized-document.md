# answerPrompt

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| answerPrompt | Not Required | Required | Returns the answerString specified in the Command property as the response to the next prompt. |

For details, see the online help: Selenium action reference .
