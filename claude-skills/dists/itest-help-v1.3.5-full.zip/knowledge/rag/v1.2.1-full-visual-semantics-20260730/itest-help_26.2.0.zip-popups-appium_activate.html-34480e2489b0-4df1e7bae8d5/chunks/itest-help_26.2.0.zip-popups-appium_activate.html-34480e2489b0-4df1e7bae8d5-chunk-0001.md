---
chunk_id: itest-help_26.2.0.zip-popups-appium_activate.html-34480e2489b0-4df1e7bae8d5-chunk-0001
source_id: itest-help_26.2.0.zip-popups-appium_activate.html-34480e2489b0-4df1e7bae8d5
title: activate
heading_path:
- activate
section_titles:
- activate
source_block_ids:
- itest-help_26.2.0.zip-popups-appium_activate.html-34480e2489b0-4df1e7bae8d5-block-0001
- itest-help_26.2.0.zip-popups-appium_activate.html-34480e2489b0-4df1e7bae8d5-block-0002
- itest-help_26.2.0.zip-popups-appium_activate.html-34480e2489b0-4df1e7bae8d5-block-0003
- itest-help_26.2.0.zip-popups-appium_activate.html-34480e2489b0-4df1e7bae8d5-block-0004
- itest-help_26.2.0.zip-popups-appium_activate.html-34480e2489b0-4df1e7bae8d5-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 97
source_hash: 4df1e7bae8d549ada2a8ffdab8c68a964585d34a413d16daab0fae2d9bbd474a
normalized_document_hash: fe0a21a0eaa3bc983db70ce3bf806a1cbcfcd885f03e02ff50db852a74bfc76a
content_status: success
content_sha256: b31298f3635c9fc023b86fbdd0f8b727d95f0e1774a7a79473cc1480d8ae958b
---

# activate

Launches the installed application or brings to foreground an application which is running in the background.

| Command | iOS bundleID or Android package name of the application to activate |
| --- | --- |
| Step Properties | Application ID: iOS bundleID or Android package name of the application to activate |
| Examples | activate com.spirent.HelloWorldBundle activate com.spirent.mypackage |

This command uses Activate App Appium API.

See also the online help topic: Appium action commands .
