# activate

Launches the installed application or brings to foreground an application which is running in the background.

| Command | iOS bundleID or Android package name of the application to activate |
| --- | --- |
| Step Properties | Application ID: iOS bundleID or Android package name of the application to activate |
| Examples | activate com.spirent.HelloWorldBundle activate com.spirent.mypackage |

This command uses Activate App Appium API.

See also the online help topic: Appium action commands .
