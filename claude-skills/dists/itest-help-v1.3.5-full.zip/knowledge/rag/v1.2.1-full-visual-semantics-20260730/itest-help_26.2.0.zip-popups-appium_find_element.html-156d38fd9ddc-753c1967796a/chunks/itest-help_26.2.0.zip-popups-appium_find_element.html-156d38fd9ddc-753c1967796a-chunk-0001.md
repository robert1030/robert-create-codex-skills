---
chunk_id: itest-help_26.2.0.zip-popups-appium_find_element.html-156d38fd9ddc-753c1967796a-chunk-0001
source_id: itest-help_26.2.0.zip-popups-appium_find_element.html-156d38fd9ddc-753c1967796a
title: find_element
heading_path:
- find_element
section_titles:
- find_element
source_block_ids:
- itest-help_26.2.0.zip-popups-appium_find_element.html-156d38fd9ddc-753c1967796a-block-0001
- itest-help_26.2.0.zip-popups-appium_find_element.html-156d38fd9ddc-753c1967796a-block-0002
- itest-help_26.2.0.zip-popups-appium_find_element.html-156d38fd9ddc-753c1967796a-block-0003
- itest-help_26.2.0.zip-popups-appium_find_element.html-156d38fd9ddc-753c1967796a-block-0004
- itest-help_26.2.0.zip-popups-appium_find_element.html-156d38fd9ddc-753c1967796a-block-0005
- itest-help_26.2.0.zip-popups-appium_find_element.html-156d38fd9ddc-753c1967796a-block-0006
- itest-help_26.2.0.zip-popups-appium_find_element.html-156d38fd9ddc-753c1967796a-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 83
source_hash: 753c1967796ab0d9f36b0b426bbab89968599ef0ff646e2ab4bd4c23b2831731
normalized_document_hash: 0261f04adf75b79682de517ad0a4f72a966d96aea797ad1b33e26424b4f0d4d8
content_status: success
content_sha256: e3ee645030db0f063a5311a6e761722b43b9fa0458d09b82e1e05b61baf96c5c
---

# find_element

Allows you to find the requested element (by ID, name, etc.)

Selector: (enumerated string, required, cannot be substituted) selector used to find the element.

Target: (string, required) value to use with the selector to find the element.

Step string representation: selector='target'

This command uses Find Element Appium API.

See also the online help topic: Appium action commands .
