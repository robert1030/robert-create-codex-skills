# find_element

Allows you to find the requested element (by ID, name, etc.)

Selector: (enumerated string, required, cannot be substituted) selector used to find the element.

Target: (string, required) value to use with the selector to find the element.

Step string representation: selector='target'

This command uses Find Element Appium API.

See also the online help topic: Appium action commands .
