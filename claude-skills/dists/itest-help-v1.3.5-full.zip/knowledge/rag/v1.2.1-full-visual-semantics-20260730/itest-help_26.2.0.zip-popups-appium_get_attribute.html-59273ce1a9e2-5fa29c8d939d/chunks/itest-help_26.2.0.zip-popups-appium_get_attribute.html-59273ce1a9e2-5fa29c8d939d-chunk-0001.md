---
chunk_id: itest-help_26.2.0.zip-popups-appium_get_attribute.html-59273ce1a9e2-5fa29c8d939d-chunk-0001
source_id: itest-help_26.2.0.zip-popups-appium_get_attribute.html-59273ce1a9e2-5fa29c8d939d
title: get_attribute
heading_path:
- get_attribute
section_titles:
- get_attribute
source_block_ids:
- itest-help_26.2.0.zip-popups-appium_get_attribute.html-59273ce1a9e2-5fa29c8d939d-block-0001
- itest-help_26.2.0.zip-popups-appium_get_attribute.html-59273ce1a9e2-5fa29c8d939d-block-0002
- itest-help_26.2.0.zip-popups-appium_get_attribute.html-59273ce1a9e2-5fa29c8d939d-block-0003
- itest-help_26.2.0.zip-popups-appium_get_attribute.html-59273ce1a9e2-5fa29c8d939d-block-0004
- itest-help_26.2.0.zip-popups-appium_get_attribute.html-59273ce1a9e2-5fa29c8d939d-block-0005
- itest-help_26.2.0.zip-popups-appium_get_attribute.html-59273ce1a9e2-5fa29c8d939d-block-0006
- itest-help_26.2.0.zip-popups-appium_get_attribute.html-59273ce1a9e2-5fa29c8d939d-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 89
source_hash: 5fa29c8d939da3b85d223967e47ad34f1b0135e844f38cbf61b084c0034ee9ab
normalized_document_hash: 9d504e37d4cc18c0d6ecc7be63481a01e6d2ae884a5a2aff84859a93ee4227e0
content_status: success
content_sha256: 688777bf75309027de150eb4f9414b3e69d84cdb7a09bb10f9c17f7f340d2669
---

# get_attribute

Allows you to find a specific attribute of the selected element

Element: (required) Selector and value pair to find the element (same as for find_element): Selector and Value .

Attribute: (string, required) name of the attribute of the selected element.

Step string representation: selector='target', attribute='attribute'

This command uses Get Element Attribute Appium API.

See also the online help topic: Appium action commands .
