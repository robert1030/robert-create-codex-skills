# get_attribute

Allows you to find a specific attribute of the selected element

Element: (required) Selector and value pair to find the element (same as for find_element): Selector and Value .

Attribute: (string, required) name of the attribute of the selected element.

Step string representation: selector='target', attribute='attribute'

This command uses Get Element Attribute Appium API.

See also the online help topic: Appium action commands .
