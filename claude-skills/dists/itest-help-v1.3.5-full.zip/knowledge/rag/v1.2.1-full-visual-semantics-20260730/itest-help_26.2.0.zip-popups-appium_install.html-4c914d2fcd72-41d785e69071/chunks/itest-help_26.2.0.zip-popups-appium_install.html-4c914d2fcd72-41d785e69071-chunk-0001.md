---
chunk_id: itest-help_26.2.0.zip-popups-appium_install.html-4c914d2fcd72-41d785e69071-chunk-0001
source_id: itest-help_26.2.0.zip-popups-appium_install.html-4c914d2fcd72-41d785e69071
title: install
heading_path:
- install
section_titles:
- install
source_block_ids:
- itest-help_26.2.0.zip-popups-appium_install.html-4c914d2fcd72-41d785e69071-block-0001
- itest-help_26.2.0.zip-popups-appium_install.html-4c914d2fcd72-41d785e69071-block-0002
- itest-help_26.2.0.zip-popups-appium_install.html-4c914d2fcd72-41d785e69071-block-0003
- itest-help_26.2.0.zip-popups-appium_install.html-4c914d2fcd72-41d785e69071-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 93
source_hash: 41d785e69071c4e98c6e2728083d41dc88eafcb58a65f1145e2e6e9b66e8cae8
normalized_document_hash: 3730924a15d177ea8544b225bac238cac8ec5de64aae847b183c4c6f29cd10f1
content_status: success
content_sha256: 002c76f3478d17746e8086b8dba6342bdfb67098e43c08711d1f1636f2e4a73c
---

# install

Installs the application onto the device. Does not launch an application after the installation.

| Command | The local or remote path to the application to install |
| --- | --- |
| Step Properties | Application Path: the local or remote path to the .app/.apk application to install |
| Examples | install /Users/user/Develop/HelloWorld.app install http://example.com/resources/HelloWorld.apk |

This command uses Install App Appium API.
