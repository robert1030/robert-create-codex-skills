---
chunk_id: itest-help_26.2.0.zip-popups-appium_screenshot.html-e84cdad99578-888783f5eee5-chunk-0001
source_id: itest-help_26.2.0.zip-popups-appium_screenshot.html-e84cdad99578-888783f5eee5
title: screenshot
heading_path:
- screenshot
section_titles:
- screenshot
source_block_ids:
- itest-help_26.2.0.zip-popups-appium_screenshot.html-e84cdad99578-888783f5eee5-block-0001
- itest-help_26.2.0.zip-popups-appium_screenshot.html-e84cdad99578-888783f5eee5-block-0002
- itest-help_26.2.0.zip-popups-appium_screenshot.html-e84cdad99578-888783f5eee5-block-0003
- itest-help_26.2.0.zip-popups-appium_screenshot.html-e84cdad99578-888783f5eee5-block-0004
- itest-help_26.2.0.zip-popups-appium_screenshot.html-e84cdad99578-888783f5eee5-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 82
source_hash: 888783f5eee5248d4fedbc644327eda36b1ed42aadc8836f01bf6ae5d0dba9ed
normalized_document_hash: 943cd1691fb614abe588ac17916cbd581359cf8c752d8ce78c33f02526303388
content_status: success
content_sha256: 4be654bdee7ecc840bdfa52f063fc62615f99baaa0b927056bd91b4e4a30efd6
---

# screenshot

Takes the screenshot of the device under test.
Test report will contain the screenshot image in the response of the step.

| Command | None. No arguments are required. The screenshot command will be captured and saved in a test case. |
| --- | --- |
| Response | Screenshot image |

This command uses Screenshot Appium API.

See also the online help topic: Appium action commands .
