# screenshot

Takes the screenshot of the device under test.
Test report will contain the screenshot image in the response of the step.

| Command | None. No arguments are required. The screenshot command will be captured and saved in a test case. |
| --- | --- |
| Response | Screenshot image |

This command uses Screenshot Appium API.

See also the online help topic: Appium action commands .
