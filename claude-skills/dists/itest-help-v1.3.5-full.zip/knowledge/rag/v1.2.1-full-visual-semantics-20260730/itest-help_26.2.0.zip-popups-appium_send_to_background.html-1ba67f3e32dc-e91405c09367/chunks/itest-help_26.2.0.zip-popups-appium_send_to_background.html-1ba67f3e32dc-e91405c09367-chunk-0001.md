---
chunk_id: itest-help_26.2.0.zip-popups-appium_send_to_background.html-1ba67f3e32dc-e91405c09367-chunk-0001
source_id: itest-help_26.2.0.zip-popups-appium_send_to_background.html-1ba67f3e32dc-e91405c09367
title: send_to_background
heading_path:
- send_to_background
section_titles:
- send_to_background
source_block_ids:
- itest-help_26.2.0.zip-popups-appium_send_to_background.html-1ba67f3e32dc-e91405c09367-block-0001
- itest-help_26.2.0.zip-popups-appium_send_to_background.html-1ba67f3e32dc-e91405c09367-block-0002
- itest-help_26.2.0.zip-popups-appium_send_to_background.html-1ba67f3e32dc-e91405c09367-block-0003
- itest-help_26.2.0.zip-popups-appium_send_to_background.html-1ba67f3e32dc-e91405c09367-block-0004
- itest-help_26.2.0.zip-popups-appium_send_to_background.html-1ba67f3e32dc-e91405c09367-block-0005
- itest-help_26.2.0.zip-popups-appium_send_to_background.html-1ba67f3e32dc-e91405c09367-block-0006
- itest-help_26.2.0.zip-popups-appium_send_to_background.html-1ba67f3e32dc-e91405c09367-block-0007
- itest-help_26.2.0.zip-popups-appium_send_to_background.html-1ba67f3e32dc-e91405c09367-block-0008
- itest-help_26.2.0.zip-popups-appium_send_to_background.html-1ba67f3e32dc-e91405c09367-block-0009
- itest-help_26.2.0.zip-popups-appium_send_to_background.html-1ba67f3e32dc-e91405c09367-block-0010
- itest-help_26.2.0.zip-popups-appium_send_to_background.html-1ba67f3e32dc-e91405c09367-block-0012
- itest-help_26.2.0.zip-popups-appium_send_to_background.html-1ba67f3e32dc-e91405c09367-block-0013
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 198
source_hash: e91405c09367225b952185a6d47fa7e0d711bad1d5813d3d550a56e93c1b19ba
normalized_document_hash: a1a991bd01a5ed773cd7baec6507063743000f0741fceb7b5cef9db3bd72143d
content_status: success
content_sha256: fd37a5c09261e42123e22a26d9db8865679849b55654a0c2eda5cdb7ddfb4948
---

# send_to_background

Sends the currently running application to the background.

Note: The applicate sent to the background may be returned after a certain amount of time, or be deactivated.

You may pass three types of parameters:

1. Specify the number of seconds for which the application is sent to the background. For example, {"seconds": secs}, where secs is an integer.

To deactivate the application, the argument -1 is used.

2. Null indicates the application is deactivated. You may also deactivate an application by specifying the argument

-1

.

| Command | None. No arguments are required. The send_to_background command will be captured and saved in a test case. |
| --- | --- |
| Step Properties | Application ID ( not required ) : The command is executed on the current active application<br>                and does not require application ID. |
| Example |  |

This command uses Background App Appium API.

See also the online help topic: Appium action commands .
