# send_to_background

Sends the currently running application to the background.

Note: The applicate sent to the background may be returned after a certain amount of time, or be deactivated.

You may pass three types of parameters:

1. Specify the number of seconds for which the application is sent to the background. For example, {"seconds": secs}, where secs is an integer.

To deactivate the application, the argument -1 is used.

2. Null indicates the application is deactivated. You may also deactivate an application by specifying the argument

-1

.

| Command | None. No arguments are required. The send_to_background command will be captured and saved in a test case. |
| --- | --- |
| Step Properties | Application ID ( not required ) : The command is executed on the current active application<br>                and does not require application ID. |
| Example |  |

This command uses Background App Appium API.

See also the online help topic: Appium action commands .
