---
chunk_id: itest-help_26.2.0.zip-popups-appium_terminate.html-ceac409a9bc1-cf8e12e216cc-chunk-0001
source_id: itest-help_26.2.0.zip-popups-appium_terminate.html-ceac409a9bc1-cf8e12e216cc
title: terminate
heading_path:
- terminate
section_titles:
- terminate
source_block_ids:
- itest-help_26.2.0.zip-popups-appium_terminate.html-ceac409a9bc1-cf8e12e216cc-block-0001
- itest-help_26.2.0.zip-popups-appium_terminate.html-ceac409a9bc1-cf8e12e216cc-block-0002
- itest-help_26.2.0.zip-popups-appium_terminate.html-ceac409a9bc1-cf8e12e216cc-block-0003
- itest-help_26.2.0.zip-popups-appium_terminate.html-ceac409a9bc1-cf8e12e216cc-block-0004
- itest-help_26.2.0.zip-popups-appium_terminate.html-ceac409a9bc1-cf8e12e216cc-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 112
source_hash: cf8e12e216cc2e978177146f288ff16fcdb6befc863829778ddecd8a7d28e70c
normalized_document_hash: a5036253f4f45a1e2dbda9e1d2f7a25068b25844bdce860c17f1fac41d3b726c
content_status: success
content_sha256: cf89d1d0fc81c00ffac5745d843f232d0f56b70bd70ccbcd2f659d87edb50110
---

# terminate

Terminates the specified application (currently running) on the device under test.
If the specified application is not installed an error displays.
If the application is not running then nothing is done.

| Command | None |
| --- | --- |
| Step Properties | Application ID (string, required) : Id of an installed application. Response: True if the application was successfully terminated, otherwise false |
| Example | driver.terminate_app{'com.apple.shortcuts'} |

This command uses Terminate App Appium API.

See also the online help topic: Appium action commands .
