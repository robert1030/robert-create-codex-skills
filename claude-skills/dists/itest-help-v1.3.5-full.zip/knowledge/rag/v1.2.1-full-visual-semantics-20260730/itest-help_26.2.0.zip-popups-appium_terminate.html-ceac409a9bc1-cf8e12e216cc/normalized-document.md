# terminate

Terminates the specified application (currently running) on the device under test.
If the specified application is not installed an error displays.
If the application is not running then nothing is done.

| Command | None |
| --- | --- |
| Step Properties | Application ID (string, required) : Id of an installed application. Response: True if the application was successfully terminated, otherwise false |
| Example | driver.terminate_app{'com.apple.shortcuts'} |

This command uses Terminate App Appium API.

See also the online help topic: Appium action commands .
