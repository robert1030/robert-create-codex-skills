---
chunk_id: itest-help_26.2.0.zip-popups-appium_uninstall.html-4eb513bc792d-9791ed0b9ada-chunk-0001
source_id: itest-help_26.2.0.zip-popups-appium_uninstall.html-4eb513bc792d-9791ed0b9ada
title: uninstall
heading_path:
- uninstall
section_titles:
- uninstall
source_block_ids:
- itest-help_26.2.0.zip-popups-appium_uninstall.html-4eb513bc792d-9791ed0b9ada-block-0001
- itest-help_26.2.0.zip-popups-appium_uninstall.html-4eb513bc792d-9791ed0b9ada-block-0002
- itest-help_26.2.0.zip-popups-appium_uninstall.html-4eb513bc792d-9791ed0b9ada-block-0003
- itest-help_26.2.0.zip-popups-appium_uninstall.html-4eb513bc792d-9791ed0b9ada-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 73
source_hash: 9791ed0b9adada29bacbd47464750979562655fe0ac9d0842a07419cb0bd2feb
normalized_document_hash: 2fe75178ba8bd5f4d9cb44c2bc0ad9cd280a66212685fc4b3841d25339494872
content_status: success
content_sha256: 80645491f565a98a57d50be78cfb16d199587f246c37d980b95f859c2ab7f448
---

# uninstall

Uninstalls the application from the device.

| Command | iOS bundleID or Android package name of the application to uninstall |
| --- | --- |
| Step Properties | Application ID: iOS bundleID or Android package name of the application to uninstall |
| Examples | uninstall com.spirent.HelloWorldBundle uninstall com.spirent.mypackage |

This command uses Remove App Appium API.
