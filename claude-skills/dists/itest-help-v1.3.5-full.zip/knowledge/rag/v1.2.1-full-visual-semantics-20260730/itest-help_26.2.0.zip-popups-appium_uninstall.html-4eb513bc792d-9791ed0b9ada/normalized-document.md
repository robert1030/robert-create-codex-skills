# uninstall

Uninstalls the application from the device.

| Command | iOS bundleID or Android package name of the application to uninstall |
| --- | --- |
| Step Properties | Application ID: iOS bundleID or Android package name of the application to uninstall |
| Examples | uninstall com.spirent.HelloWorldBundle uninstall com.spirent.mypackage |

This command uses Remove App Appium API.
