---
chunk_id: itest-help_26.2.0.zip-popups-appium_upgrade.html-654ed395b642-da51d980bc89-chunk-0001
source_id: itest-help_26.2.0.zip-popups-appium_upgrade.html-654ed395b642-da51d980bc89
title: upgrade
heading_path:
- upgrade
section_titles:
- upgrade
source_block_ids:
- itest-help_26.2.0.zip-popups-appium_upgrade.html-654ed395b642-da51d980bc89-block-0001
- itest-help_26.2.0.zip-popups-appium_upgrade.html-654ed395b642-da51d980bc89-block-0002
- itest-help_26.2.0.zip-popups-appium_upgrade.html-654ed395b642-da51d980bc89-block-0003
- itest-help_26.2.0.zip-popups-appium_upgrade.html-654ed395b642-da51d980bc89-block-0004
- itest-help_26.2.0.zip-popups-appium_upgrade.html-654ed395b642-da51d980bc89-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 99
source_hash: da51d980bc8923bc6e0c8e8a088aa7443cc336cb8a6dcad0136639cd291a7199
normalized_document_hash: a20b3ad3fbd3647d5e05349d91d2df56dc47d3d9bc19349e0a896e43b493d949
content_status: success
content_sha256: 43fa83b4e5c09db0cc7cbe9fa1cd211bbafba44f421eef7dbf2c5ffdbc638baf
---

# upgrade

Uninstalls and then installs again the application.

| Command | None |
| --- | --- |
| Step Properties | Uninstalled Application ID: iOS bundleID or Android package name of the application to upgrade. Needed to perform uninstallation Installed Application Path: the local or remote path to the .app/.apk application to upgrade. Needed to perform installation |
| Examples | None |

This command uses Remove App and Install App Appium API.

See also the online help topic: Appium action commands .
