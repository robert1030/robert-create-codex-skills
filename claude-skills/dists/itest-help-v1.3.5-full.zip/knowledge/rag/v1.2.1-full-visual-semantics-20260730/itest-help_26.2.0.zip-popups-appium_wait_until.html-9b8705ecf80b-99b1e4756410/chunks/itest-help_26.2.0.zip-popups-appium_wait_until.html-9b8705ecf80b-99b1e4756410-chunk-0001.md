---
chunk_id: itest-help_26.2.0.zip-popups-appium_wait_until.html-9b8705ecf80b-99b1e4756410-chunk-0001
source_id: itest-help_26.2.0.zip-popups-appium_wait_until.html-9b8705ecf80b-99b1e4756410
title: wait_until
heading_path:
- wait_until
section_titles:
- wait_until
source_block_ids:
- itest-help_26.2.0.zip-popups-appium_wait_until.html-9b8705ecf80b-99b1e4756410-block-0001
- itest-help_26.2.0.zip-popups-appium_wait_until.html-9b8705ecf80b-99b1e4756410-block-0002
- itest-help_26.2.0.zip-popups-appium_wait_until.html-9b8705ecf80b-99b1e4756410-block-0003
- itest-help_26.2.0.zip-popups-appium_wait_until.html-9b8705ecf80b-99b1e4756410-block-0004
- itest-help_26.2.0.zip-popups-appium_wait_until.html-9b8705ecf80b-99b1e4756410-block-0005
- itest-help_26.2.0.zip-popups-appium_wait_until.html-9b8705ecf80b-99b1e4756410-block-0006
- itest-help_26.2.0.zip-popups-appium_wait_until.html-9b8705ecf80b-99b1e4756410-block-0007
- itest-help_26.2.0.zip-popups-appium_wait_until.html-9b8705ecf80b-99b1e4756410-block-0008
- itest-help_26.2.0.zip-popups-appium_wait_until.html-9b8705ecf80b-99b1e4756410-block-0009
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 120
source_hash: 99b1e47564103b3ac460b35f44b53253167acc1fee666c8f38b735af80a1b521
normalized_document_hash: a02b7cc40bc9a6d76420cbeceb4896aeb6e718137a7cfa98d7840da4db38b539
content_status: success
content_sha256: 93c6a13423a560882ddba991ba337d5ed54fc3fba589ec8bd553dee1fba16254
---

# wait_until

Allows determine whether the element appears on the screen within expected duration.

Condition: (enumerated string, required) expected condition to be met (wait until).

Element: (required) Selector and value pair to find the element (same as for find_element): Selector and Value .

Attribute: (string, required) name of the attribute of the selected element.

Wait timeout: (float, required) timeout in seconds.

Step string representation: condition='condition', locator='target', timeout='timeout'

This command uses wait until Appium API.

See also the online help topic: Appium action commands .
