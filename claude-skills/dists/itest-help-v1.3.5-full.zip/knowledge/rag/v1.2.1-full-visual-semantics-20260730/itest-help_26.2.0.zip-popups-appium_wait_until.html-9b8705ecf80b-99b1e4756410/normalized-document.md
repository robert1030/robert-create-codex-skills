# wait_until

Allows determine whether the element appears on the screen within expected duration.

Condition: (enumerated string, required) expected condition to be met (wait until).

Element: (required) Selector and value pair to find the element (same as for find_element): Selector and Value .

Attribute: (string, required) name of the attribute of the selected element.

Wait timeout: (float, required) timeout in seconds.

Step string representation: condition='condition', locator='target', timeout='timeout'

This command uses wait until Appium API.

See also the online help topic: Appium action commands .
