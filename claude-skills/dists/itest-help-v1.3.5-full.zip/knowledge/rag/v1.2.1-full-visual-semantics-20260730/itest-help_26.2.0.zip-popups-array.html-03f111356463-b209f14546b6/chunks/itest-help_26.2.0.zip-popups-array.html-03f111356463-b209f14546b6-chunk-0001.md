---
chunk_id: itest-help_26.2.0.zip-popups-array.html-03f111356463-b209f14546b6-chunk-0001
source_id: itest-help_26.2.0.zip-popups-array.html-03f111356463-b209f14546b6
title: array
heading_path:
- array
section_titles:
- array
source_block_ids:
- itest-help_26.2.0.zip-popups-array.html-03f111356463-b209f14546b6-block-0001
- itest-help_26.2.0.zip-popups-array.html-03f111356463-b209f14546b6-block-0002
- itest-help_26.2.0.zip-popups-array.html-03f111356463-b209f14546b6-block-0003
- itest-help_26.2.0.zip-popups-array.html-03f111356463-b209f14546b6-block-0004
- itest-help_26.2.0.zip-popups-array.html-03f111356463-b209f14546b6-block-0005
- itest-help_26.2.0.zip-popups-array.html-03f111356463-b209f14546b6-block-0006
- itest-help_26.2.0.zip-popups-array.html-03f111356463-b209f14546b6-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 139
source_hash: b209f14546b645c173d5041a114c64e5061c28b20f60aa5e08884f0f1d39c044
normalized_document_hash: abf07a2bc46579838ddab8ae0272a8237fbdba8231c155fadf5c18f9b35c6137
content_status: success
content_sha256: 9fe0170cee37335ab317159b5e0427d1ea2c13236631f7d987f05e24ed18fc82
---

# array

array ? -g ? subcommand arrayName ? arg arg ... ?

Performs the specified operation on the existing array variable given by arrayName .  The optional -g argument indicates a global array.

For array commands that use the optional pattern , only the * and ? wildcard characters are supported. The [chars] and \x options are not supported. The following subcommands are supported:

compare array1 array2 exists arrayName get arrayName ? pattern ? names arrayName ? pattern ? set arrayName list size arrayName unset arrayName ? pattern ?

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
