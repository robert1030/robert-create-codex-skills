# array

array ? -g ? subcommand arrayName ? arg arg ... ?

Performs the specified operation on the existing array variable given by arrayName .  The optional -g argument indicates a global array.

For array commands that use the optional pattern , only the * and ? wildcard characters are supported. The [chars] and \x options are not supported. The following subcommands are supported:

compare array1 array2 exists arrayName get arrayName ? pattern ? names arrayName ? pattern ? set arrayName list size arrayName unset arrayName ? pattern ?

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
