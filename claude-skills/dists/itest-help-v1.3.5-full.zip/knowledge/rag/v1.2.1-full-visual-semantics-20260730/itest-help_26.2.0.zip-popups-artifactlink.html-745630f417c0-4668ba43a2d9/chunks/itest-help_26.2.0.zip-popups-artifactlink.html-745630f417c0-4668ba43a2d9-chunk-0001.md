---
chunk_id: itest-help_26.2.0.zip-popups-artifactlink.html-745630f417c0-4668ba43a2d9-chunk-0001
source_id: itest-help_26.2.0.zip-popups-artifactlink.html-745630f417c0-4668ba43a2d9
title: artifactLink
heading_path:
- artifactLink
section_titles:
- artifactLink
source_block_ids:
- itest-help_26.2.0.zip-popups-artifactlink.html-745630f417c0-4668ba43a2d9-block-0001
- itest-help_26.2.0.zip-popups-artifactlink.html-745630f417c0-4668ba43a2d9-block-0002
- itest-help_26.2.0.zip-popups-artifactlink.html-745630f417c0-4668ba43a2d9-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 45
source_hash: 4668ba43a2d9e96bded5c3f805bd6151f337aee806f05adae52959904ad4db2f
normalized_document_hash: 3fbd45280d4d0f431dba0e6cee79db885cf681f968fafc4b1fecdb6fbeff1c47
content_status: success
content_sha256: 11a649e5c77d0a80c0bd3bfacf20a2487331426ad3666030d61d5cdd64cbb3e6
---

# artifactLink

A artifactLink adds to the execution report's Artifacts part a link to the resource specified in Link with the text taken from the Description .

For details, see the online help: The artifactLink action .
