# artifactLink

A artifactLink adds to the execution report's Artifacts part a link to the resource specified in Link with the text taken from the Description .

For details, see the online help: The artifactLink action .
