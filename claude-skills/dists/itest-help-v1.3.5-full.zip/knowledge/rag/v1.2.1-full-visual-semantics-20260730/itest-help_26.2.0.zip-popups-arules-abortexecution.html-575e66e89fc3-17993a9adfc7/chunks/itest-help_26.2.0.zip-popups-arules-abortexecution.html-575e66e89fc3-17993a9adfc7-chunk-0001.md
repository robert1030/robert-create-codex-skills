---
chunk_id: itest-help_26.2.0.zip-popups-arules-abortexecution.html-575e66e89fc3-17993a9adfc7-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-abortexecution.html-575e66e89fc3-17993a9adfc7
title: AbortExecution action
heading_path:
- AbortExecution action
section_titles:
- AbortExecution action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-abortexecution.html-575e66e89fc3-17993a9adfc7-block-0001
- itest-help_26.2.0.zip-popups-arules-abortexecution.html-575e66e89fc3-17993a9adfc7-block-0002
- itest-help_26.2.0.zip-popups-arules-abortexecution.html-575e66e89fc3-17993a9adfc7-block-0003
- itest-help_26.2.0.zip-popups-arules-abortexecution.html-575e66e89fc3-17993a9adfc7-block-0004
- itest-help_26.2.0.zip-popups-arules-abortexecution.html-575e66e89fc3-17993a9adfc7-block-0005
- itest-help_26.2.0.zip-popups-arules-abortexecution.html-575e66e89fc3-17993a9adfc7-block-0006
- itest-help_26.2.0.zip-popups-arules-abortexecution.html-575e66e89fc3-17993a9adfc7-block-0007
- itest-help_26.2.0.zip-popups-arules-abortexecution.html-575e66e89fc3-17993a9adfc7-block-0008
- itest-help_26.2.0.zip-popups-arules-abortexecution.html-575e66e89fc3-17993a9adfc7-block-0009
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 111
source_hash: 17993a9adfc7d934ddf78bf84ad4e07fb4e2c51497fc5cf55b12bc475ed28f02
normalized_document_hash: ea3953a5159307849a06031d4a3824e70b06b3be43c96d5b62f19d7560441d10
content_status: success
content_sha256: 05de977e22774f1d5b8fa6620cf087cf4d9c295104cbf5771fb235e0dc71e830
---

# AbortExecution action

Stops execution.

Note:

Because this action alters the flow of execution, it is deferred (not executed) until all other actions for the step are executed. See

About deferred actions

.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
