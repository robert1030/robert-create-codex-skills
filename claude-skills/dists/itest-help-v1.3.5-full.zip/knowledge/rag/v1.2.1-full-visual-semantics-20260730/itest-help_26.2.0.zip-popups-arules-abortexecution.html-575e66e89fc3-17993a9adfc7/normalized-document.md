# AbortExecution action

Stops execution.

Note:

Because this action alters the flow of execution, it is deferred (not executed) until all other actions for the step are executed. See

About deferred actions

.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
