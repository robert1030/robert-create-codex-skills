---
chunk_id: itest-help_26.2.0.zip-popups-arules-abortstep.html-a9536ea4536b-d62f63a26645-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-abortstep.html-a9536ea4536b-d62f63a26645
title: AbortStep action
heading_path:
- AbortStep action
section_titles:
- AbortStep action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-abortstep.html-a9536ea4536b-d62f63a26645-block-0001
- itest-help_26.2.0.zip-popups-arules-abortstep.html-a9536ea4536b-d62f63a26645-block-0002
- itest-help_26.2.0.zip-popups-arules-abortstep.html-a9536ea4536b-d62f63a26645-block-0003
- itest-help_26.2.0.zip-popups-arules-abortstep.html-a9536ea4536b-d62f63a26645-block-0004
- itest-help_26.2.0.zip-popups-arules-abortstep.html-a9536ea4536b-d62f63a26645-block-0005
- itest-help_26.2.0.zip-popups-arules-abortstep.html-a9536ea4536b-d62f63a26645-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 116
source_hash: d62f63a26645e1c91ebe42434d354f461840efd9780405b2182207a067d50774
normalized_document_hash: b0fe9f14cbcf0445e1af6731a3e7c5eec0c5691eb2caf2e93a02ae317b756eb2
content_status: success
content_sha256: eecf545a68e5d03da04f727bcef6089fa89f14003db1958fa27cb22ffd741b0a
---

# AbortStep action

Immediately stop executing the step and then proceed to the next step.

In an analysis rule, this action has the effect of not performing remaining analysis rules and then continuing to the next step.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
