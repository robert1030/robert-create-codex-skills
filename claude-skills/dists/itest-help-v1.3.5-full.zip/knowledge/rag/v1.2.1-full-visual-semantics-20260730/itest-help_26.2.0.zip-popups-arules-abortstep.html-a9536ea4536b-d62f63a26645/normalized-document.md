# AbortStep action

Immediately stop executing the step and then proceed to the next step.

In an analysis rule, this action has the effect of not performing remaining analysis rules and then continuing to the next step.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
