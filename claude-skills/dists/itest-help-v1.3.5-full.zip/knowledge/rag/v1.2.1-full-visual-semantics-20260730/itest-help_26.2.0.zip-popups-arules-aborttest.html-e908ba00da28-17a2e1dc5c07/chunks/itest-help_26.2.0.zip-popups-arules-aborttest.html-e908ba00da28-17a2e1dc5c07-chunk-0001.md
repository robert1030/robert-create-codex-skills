---
chunk_id: itest-help_26.2.0.zip-popups-arules-aborttest.html-e908ba00da28-17a2e1dc5c07-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-aborttest.html-e908ba00da28-17a2e1dc5c07
title: AbortTest action
heading_path:
- AbortTest action
section_titles:
- AbortTest action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-aborttest.html-e908ba00da28-17a2e1dc5c07-block-0001
- itest-help_26.2.0.zip-popups-arules-aborttest.html-e908ba00da28-17a2e1dc5c07-block-0002
- itest-help_26.2.0.zip-popups-arules-aborttest.html-e908ba00da28-17a2e1dc5c07-block-0003
- itest-help_26.2.0.zip-popups-arules-aborttest.html-e908ba00da28-17a2e1dc5c07-block-0004
- itest-help_26.2.0.zip-popups-arules-aborttest.html-e908ba00da28-17a2e1dc5c07-block-0005
- itest-help_26.2.0.zip-popups-arules-aborttest.html-e908ba00da28-17a2e1dc5c07-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 115
source_hash: 17a2e1dc5c07b389a2e77e6ff9115917f1120e62efb6163479bf7682946229af
normalized_document_hash: b81e97ae925253e855d7a1311c6963ac0955119b717b0e7db57aea97575322f2
content_status: success
content_sha256: 9b0bbeea8e25378c7b55db6709882c79eedc56909b34cd0698531c46d1d2eefc
---

# AbortTest action

Set the test execution result as Abort. Continue to execute (execution is not stopped).

Displays an appropriate execution message in the Execution view, in the Step Issues view, and in test reports.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
