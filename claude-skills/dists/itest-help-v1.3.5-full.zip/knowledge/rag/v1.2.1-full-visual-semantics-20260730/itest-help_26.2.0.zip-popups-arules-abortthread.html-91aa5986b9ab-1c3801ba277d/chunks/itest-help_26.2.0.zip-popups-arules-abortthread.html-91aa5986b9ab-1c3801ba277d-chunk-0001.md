---
chunk_id: itest-help_26.2.0.zip-popups-arules-abortthread.html-91aa5986b9ab-1c3801ba277d-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-abortthread.html-91aa5986b9ab-1c3801ba277d
title: AbortThread action
heading_path:
- AbortThread action
section_titles:
- AbortThread action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-abortthread.html-91aa5986b9ab-1c3801ba277d-block-0001
- itest-help_26.2.0.zip-popups-arules-abortthread.html-91aa5986b9ab-1c3801ba277d-block-0002
- itest-help_26.2.0.zip-popups-arules-abortthread.html-91aa5986b9ab-1c3801ba277d-block-0003
- itest-help_26.2.0.zip-popups-arules-abortthread.html-91aa5986b9ab-1c3801ba277d-block-0004
- itest-help_26.2.0.zip-popups-arules-abortthread.html-91aa5986b9ab-1c3801ba277d-block-0005
- itest-help_26.2.0.zip-popups-arules-abortthread.html-91aa5986b9ab-1c3801ba277d-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 104
source_hash: 1c3801ba277d19a3959eee3c171af9949f7cb5eed05a41248a2fc8823d64a0a6
normalized_document_hash: 1561f9bec8c245929198778009dd1242370e04511716eef534a04797182386cf
content_status: success
content_sha256: 444ee66c048dc9028eea17bb8322939ec3c8fc6570aa6ef481d0148283435204
---

# AbortThread action

Immediately stops executing the current thread.

Displays an appropriate execution message in the Execution view, in the Step Issues view, and in test reports.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
