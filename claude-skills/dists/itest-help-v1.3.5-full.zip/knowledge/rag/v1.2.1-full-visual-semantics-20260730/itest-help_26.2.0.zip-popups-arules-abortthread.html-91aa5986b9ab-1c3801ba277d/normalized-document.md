# AbortThread action

Immediately stops executing the current thread.

Displays an appropriate execution message in the Execution view, in the Step Issues view, and in test reports.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
