---
chunk_id: itest-help_26.2.0.zip-popups-arules-appendtoprocedureresponse.html-5cc7410a8aae-c631bec770c6-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-appendtoprocedureresponse.html-5cc7410a8aae-c631bec770c6
title: AppendToProcedureResponse action
heading_path:
- AppendToProcedureResponse action
section_titles:
- AppendToProcedureResponse action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-appendtoprocedureresponse.html-5cc7410a8aae-c631bec770c6-block-0001
- itest-help_26.2.0.zip-popups-arules-appendtoprocedureresponse.html-5cc7410a8aae-c631bec770c6-block-0002
- itest-help_26.2.0.zip-popups-arules-appendtoprocedureresponse.html-5cc7410a8aae-c631bec770c6-block-0003
- itest-help_26.2.0.zip-popups-arules-appendtoprocedureresponse.html-5cc7410a8aae-c631bec770c6-block-0004
- itest-help_26.2.0.zip-popups-arules-appendtoprocedureresponse.html-5cc7410a8aae-c631bec770c6-block-0005
- itest-help_26.2.0.zip-popups-arules-appendtoprocedureresponse.html-5cc7410a8aae-c631bec770c6-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 101
source_hash: c631bec770c606024d8a02a5fd6e1afd0e7aef5a266219a20dcfc55520be4693
normalized_document_hash: 33b025521100656f709cd81c402b9edf94082c87b46b222c78c73708948a2e79
content_status: success
content_sha256: 11d5ae475e8f3117516596048c5187fd5c5e98b4467feaeb6801092a23916724
---

# AppendToProcedureResponse action

Writes the specified text to a procedure’s return buffer.

To return the full response, set the Content text to [response .]

Supports field replacements.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
