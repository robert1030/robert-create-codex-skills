# AppendToProcedureResponse action

Writes the specified text to a procedure’s return buffer.

To return the full response, set the Content text to [response .]

Supports field replacements.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
