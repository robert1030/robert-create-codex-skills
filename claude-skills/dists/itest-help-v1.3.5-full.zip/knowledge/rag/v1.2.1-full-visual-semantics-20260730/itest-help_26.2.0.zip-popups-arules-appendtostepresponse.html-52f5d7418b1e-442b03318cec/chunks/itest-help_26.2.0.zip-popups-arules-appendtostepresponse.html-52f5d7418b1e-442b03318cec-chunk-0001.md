---
chunk_id: itest-help_26.2.0.zip-popups-arules-appendtostepresponse.html-52f5d7418b1e-442b03318cec-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-appendtostepresponse.html-52f5d7418b1e-442b03318cec
title: AppendToStepResponse action
heading_path:
- AppendToStepResponse action
section_titles:
- AppendToStepResponse action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-appendtostepresponse.html-52f5d7418b1e-442b03318cec-block-0001
- itest-help_26.2.0.zip-popups-arules-appendtostepresponse.html-52f5d7418b1e-442b03318cec-block-0002
- itest-help_26.2.0.zip-popups-arules-appendtostepresponse.html-52f5d7418b1e-442b03318cec-block-0003
- itest-help_26.2.0.zip-popups-arules-appendtostepresponse.html-52f5d7418b1e-442b03318cec-block-0004
- itest-help_26.2.0.zip-popups-arules-appendtostepresponse.html-52f5d7418b1e-442b03318cec-block-0005
- itest-help_26.2.0.zip-popups-arules-appendtostepresponse.html-52f5d7418b1e-442b03318cec-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 101
source_hash: 442b03318cecd9fdb76bd1db46fc76d023308dcd6c419efb429b29584c3c908f
normalized_document_hash: aea739fb47f22bd3be466f83766b1ca69ef9b5ae0b3dddb8bcce26a9bd4ae7f4
content_status: success
content_sha256: e654c8f9a46aa1bbd14e374cbfbeb69313b8bf1be36f0393e82a2b952f5822e7
---

# AppendToStepResponse action

Writes the specified text to a step’s return buffer.

To return the full response, set the Content text to [response .]

Supports field replacements.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
