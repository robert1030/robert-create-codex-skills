---
chunk_id: itest-help_26.2.0.zip-popups-arules-assert.html-fc72c1dd47d5-d3a798d5cf04-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-assert.html-fc72c1dd47d5-d3a798d5cf04
title: assert processor
heading_path:
- assert processor
section_titles:
- assert processor
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-assert.html-fc72c1dd47d5-d3a798d5cf04-block-0001
- itest-help_26.2.0.zip-popups-arules-assert.html-fc72c1dd47d5-d3a798d5cf04-block-0002
- itest-help_26.2.0.zip-popups-arules-assert.html-fc72c1dd47d5-d3a798d5cf04-block-0003
- itest-help_26.2.0.zip-popups-arules-assert.html-fc72c1dd47d5-d3a798d5cf04-block-0004
- itest-help_26.2.0.zip-popups-arules-assert.html-fc72c1dd47d5-d3a798d5cf04-block-0005
- itest-help_26.2.0.zip-popups-arules-assert.html-fc72c1dd47d5-d3a798d5cf04-block-0006
- itest-help_26.2.0.zip-popups-arules-assert.html-fc72c1dd47d5-d3a798d5cf04-block-0007
- itest-help_26.2.0.zip-popups-arules-assert.html-fc72c1dd47d5-d3a798d5cf04-block-0008
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 180
source_hash: d3a798d5cf040f282f034336ef54e2d17a3d4f22e902fabea1ad7e5b149b1191
normalized_document_hash: 9df3f9b873fba7b255d5cc64db7a6b86fe0ea298a7a1e90070ecf5b3e039cb58
content_status: success
content_sha256: 50d6620e99aaa0dae29d135714a7ee727c221e6d9781c51ad4af3012daac4631
---

# assert processor

The assert processor places the extracted data into an assertion and then tests the assertion. For example, the assertion $value == 42 tests whether the value is equal to 42.

If the value is equal to 42, then the assertion returns the value 1 (True). If not, then the assertion returns the value 0 (False). In the lines following the processor, you specify the actions that should occur based on the returned value:

- In the When True section, you specify the actions to take when the assertion returns 1 (True)
- In the When False section, you specify the actions to take when the assertion returns 0 (False)

For details on using this and other processor types, see

Analysis rules: Properties of the processor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
