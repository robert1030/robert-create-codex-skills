# assert processor

The assert processor places the extracted data into an assertion and then tests the assertion. For example, the assertion $value == 42 tests whether the value is equal to 42.

If the value is equal to 42, then the assertion returns the value 1 (True). If not, then the assertion returns the value 0 (False). In the lines following the processor, you specify the actions that should occur based on the returned value:

- In the When True section, you specify the actions to take when the assertion returns 1 (True)
- In the When False section, you specify the actions to take when the assertion returns 0 (False)

For details on using this and other processor types, see

Analysis rules: Properties of the processor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
