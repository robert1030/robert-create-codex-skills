---
chunk_id: itest-help_26.2.0.zip-popups-arules-break.html-7c882b06ee55-c110dccc146a-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-break.html-7c882b06ee55-c110dccc146a
title: Break action
heading_path:
- Break action
section_titles:
- Break action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-break.html-7c882b06ee55-c110dccc146a-block-0001
- itest-help_26.2.0.zip-popups-arules-break.html-7c882b06ee55-c110dccc146a-block-0002
- itest-help_26.2.0.zip-popups-arules-break.html-7c882b06ee55-c110dccc146a-block-0003
- itest-help_26.2.0.zip-popups-arules-break.html-7c882b06ee55-c110dccc146a-block-0004
- itest-help_26.2.0.zip-popups-arules-break.html-7c882b06ee55-c110dccc146a-block-0005
- itest-help_26.2.0.zip-popups-arules-break.html-7c882b06ee55-c110dccc146a-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 121
source_hash: c110dccc146a0b82e04c78d9fb392a65a3b974d5937bf079cc799665d4f7b7f6
normalized_document_hash: 479c0ab54f60b44fad3cef930e1cff76d350dc2cff1cb5834e4a0f981e581098
content_status: success
content_sha256: 1e460c2f23e6d65aaf7644e50f47de2fdddfe9ca61a70b43bddf83716ce4e9c1
---

# Break action

Submit a command break character. (Typically Ctrl-C. Defined in the session profile.)

Note : Because this action alters the flow of execution, it is deferred (not executed) until all other actions for the step are executed.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
