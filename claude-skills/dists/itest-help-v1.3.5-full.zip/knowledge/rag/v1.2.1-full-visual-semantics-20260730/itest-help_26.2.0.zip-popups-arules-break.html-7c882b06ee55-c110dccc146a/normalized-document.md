# Break action

Submit a command break character. (Typically Ctrl-C. Defined in the session profile.)

Note : Because this action alters the flow of execution, it is deferred (not executed) until all other actions for the step are executed.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
