---
chunk_id: itest-help_26.2.0.zip-popups-arules-callprocedure.html-0504455d117d-91e5f8908bb3-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-callprocedure.html-0504455d117d-91e5f8908bb3
title: CallProcedure action
heading_path:
- CallProcedure action
section_titles:
- CallProcedure action
- 'Properties:'
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-callprocedure.html-0504455d117d-91e5f8908bb3-block-0001
- itest-help_26.2.0.zip-popups-arules-callprocedure.html-0504455d117d-91e5f8908bb3-block-0002
- itest-help_26.2.0.zip-popups-arules-callprocedure.html-0504455d117d-91e5f8908bb3-block-0003
- itest-help_26.2.0.zip-popups-arules-callprocedure.html-0504455d117d-91e5f8908bb3-block-0004
- itest-help_26.2.0.zip-popups-arules-callprocedure.html-0504455d117d-91e5f8908bb3-block-0005
- itest-help_26.2.0.zip-popups-arules-callprocedure.html-0504455d117d-91e5f8908bb3-block-0006
- itest-help_26.2.0.zip-popups-arules-callprocedure.html-0504455d117d-91e5f8908bb3-block-0007
- itest-help_26.2.0.zip-popups-arules-callprocedure.html-0504455d117d-91e5f8908bb3-block-0008
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 148
source_hash: 91e5f8908bb36a9da9a2f8e9dbea7fb867db8be9afdc3a46204917b98faee099
normalized_document_hash: eee941f08c75d96ec43b36d9b7d0c3d6e4a9eae0074f3165c81c8ab6b43cf5af
content_status: success
content_sha256: d3444a9849c012e716bb08e18c8793cd46092fa000bcdaed5a7ee085ae2443be
---

# CallProcedure action

Call the specified procedure (local or foreign).

iTest provides interactive support for specifying the procedure.

Note : Because this action alters the flow of execution, it is deferred (not executed) until all other actions for the step are executed.

###### Properties:

Procedure name and arguments: Specify the procedure name followed by argument values if appropriate. For example, SetupDevice deviceNumber 3

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
