# CallProcedure action

Call the specified procedure (local or foreign).

iTest provides interactive support for specifying the procedure.

Note : Because this action alters the flow of execution, it is deferred (not executed) until all other actions for the step are executed.

###### Properties:

Procedure name and arguments: Specify the procedure name followed by argument values if appropriate. For example, SetupDevice deviceNumber 3

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
