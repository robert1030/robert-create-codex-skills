---
chunk_id: itest-help_26.2.0.zip-popups-arules-chart_as_bar.html-c801123e3df2-b709bdec6d13-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-chart_as_bar.html-c801123e3df2-b709bdec6d13
title: chart_as_bar processor
heading_path:
- chart_as_bar processor
section_titles:
- chart_as_bar processor
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-chart_as_bar.html-c801123e3df2-b709bdec6d13-block-0001
- itest-help_26.2.0.zip-popups-arules-chart_as_bar.html-c801123e3df2-b709bdec6d13-block-0002
- itest-help_26.2.0.zip-popups-arules-chart_as_bar.html-c801123e3df2-b709bdec6d13-block-0003
- itest-help_26.2.0.zip-popups-arules-chart_as_bar.html-c801123e3df2-b709bdec6d13-block-0004
- itest-help_26.2.0.zip-popups-arules-chart_as_bar.html-c801123e3df2-b709bdec6d13-block-0005
- itest-help_26.2.0.zip-popups-arules-chart_as_bar.html-c801123e3df2-b709bdec6d13-block-0006
- itest-help_26.2.0.zip-popups-arules-chart_as_bar.html-c801123e3df2-b709bdec6d13-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 133
source_hash: b709bdec6d13b628ed794d26c921d0fd127cd1bd49b7be54662b8be1d026e9e1
normalized_document_hash: 67271e057f2a2059744ca596e073668a819dea913249d0d09603e29022ef3d35
content_status: success
content_sha256: 7f4692f40c4d500e2da9b48774c250705898650388876db8c73b544d297c4539
---

# chart_as_bar processor

chart_as_bar plots successive values of the extracted data on a bar chart. Used to represent changes in numerical values over time (for example values returned in iterative loops) or over other variables.

The chart processors generate charts and display them in the Charts view. You specify the property settings for the chart in the Processors property group called Chart Using chartType . The property settings for the chart are summarized in the Description cell.

For details on using this and other processor types, see

Analysis rules: Properties of the processor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
