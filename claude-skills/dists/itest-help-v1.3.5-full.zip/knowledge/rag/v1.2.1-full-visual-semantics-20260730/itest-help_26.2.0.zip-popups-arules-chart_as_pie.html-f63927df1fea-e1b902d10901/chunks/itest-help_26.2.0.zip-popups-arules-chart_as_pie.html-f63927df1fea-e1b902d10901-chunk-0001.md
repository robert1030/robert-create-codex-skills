---
chunk_id: itest-help_26.2.0.zip-popups-arules-chart_as_pie.html-f63927df1fea-e1b902d10901-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-chart_as_pie.html-f63927df1fea-e1b902d10901
title: chart_as_pie processor
heading_path:
- chart_as_pie processor
section_titles:
- chart_as_pie processor
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-chart_as_pie.html-f63927df1fea-e1b902d10901-block-0001
- itest-help_26.2.0.zip-popups-arules-chart_as_pie.html-f63927df1fea-e1b902d10901-block-0002
- itest-help_26.2.0.zip-popups-arules-chart_as_pie.html-f63927df1fea-e1b902d10901-block-0003
- itest-help_26.2.0.zip-popups-arules-chart_as_pie.html-f63927df1fea-e1b902d10901-block-0004
- itest-help_26.2.0.zip-popups-arules-chart_as_pie.html-f63927df1fea-e1b902d10901-block-0005
- itest-help_26.2.0.zip-popups-arules-chart_as_pie.html-f63927df1fea-e1b902d10901-block-0006
- itest-help_26.2.0.zip-popups-arules-chart_as_pie.html-f63927df1fea-e1b902d10901-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 120
source_hash: e1b902d1090150614ddd0e8637cb5a9fe25a689d4b9b75a02c0ee675510a2355
normalized_document_hash: f5633700c19a2d0cf8deb78da8aa5433a86c61d58e78b2a7ba9059a624ec01d5
content_status: success
content_sha256: 2a675219d68bdf9d5d855a35d883000458633eeec0734cd43d313e3c2102dd80
---

# chart_as_pie processor

chart_as_pie plots successive values of the extracted data on a pie chart. Used to compare multiple numerical values with or without time dependency.

The chart processors generate charts and display them in the Charts view. You specify the property settings for the chart in the Processors property group called Chart Using chartType . The property settings for the chart are summarized in the Description cell.

For details on using this and other processor types, see

Analysis rules: Properties of the processor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
