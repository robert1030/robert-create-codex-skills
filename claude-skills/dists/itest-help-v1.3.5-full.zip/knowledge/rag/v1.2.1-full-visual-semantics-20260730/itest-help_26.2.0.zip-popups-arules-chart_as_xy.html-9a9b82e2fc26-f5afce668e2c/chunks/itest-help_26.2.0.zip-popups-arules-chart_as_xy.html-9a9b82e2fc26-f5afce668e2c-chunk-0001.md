---
chunk_id: itest-help_26.2.0.zip-popups-arules-chart_as_xy.html-9a9b82e2fc26-f5afce668e2c-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-chart_as_xy.html-9a9b82e2fc26-f5afce668e2c
title: chart_as_xy processor
heading_path:
- chart_as_xy processor
section_titles:
- chart_as_xy processor
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-chart_as_xy.html-9a9b82e2fc26-f5afce668e2c-block-0001
- itest-help_26.2.0.zip-popups-arules-chart_as_xy.html-9a9b82e2fc26-f5afce668e2c-block-0002
- itest-help_26.2.0.zip-popups-arules-chart_as_xy.html-9a9b82e2fc26-f5afce668e2c-block-0003
- itest-help_26.2.0.zip-popups-arules-chart_as_xy.html-9a9b82e2fc26-f5afce668e2c-block-0004
- itest-help_26.2.0.zip-popups-arules-chart_as_xy.html-9a9b82e2fc26-f5afce668e2c-block-0005
- itest-help_26.2.0.zip-popups-arules-chart_as_xy.html-9a9b82e2fc26-f5afce668e2c-block-0006
- itest-help_26.2.0.zip-popups-arules-chart_as_xy.html-9a9b82e2fc26-f5afce668e2c-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 131
source_hash: f5afce668e2c03e496e1bd030bed6f02aff9155be353f1fc45f9cfbf08ed8296
normalized_document_hash: 17280be69d2ad15187378889ace36ae64617e44e2383341e63fe15adcd39c37e
content_status: success
content_sha256: 08406a8ab10020220fbf3f031879733478279688ae65f712aa55357f1e85cada
---

# chart_as_xy processor

chart_as_xy plots successive values of the extracted data on an XY-coordinate chart. Used to represent changes in numerical values over time (for example values returned in iterative loops) or other variables.

The chart processors generate charts and display them in the Charts view. You specify the property settings for the chart in the Processors property group called Chart Using chartType . The property settings for the chart are summarized in the Description cell.

For details on using this and other processor types, see

Analysis rules: Properties of the processor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
