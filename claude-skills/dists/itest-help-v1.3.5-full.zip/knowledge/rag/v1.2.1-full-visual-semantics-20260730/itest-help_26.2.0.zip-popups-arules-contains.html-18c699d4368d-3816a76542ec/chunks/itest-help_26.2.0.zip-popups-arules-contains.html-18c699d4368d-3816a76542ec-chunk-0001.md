---
chunk_id: itest-help_26.2.0.zip-popups-arules-contains.html-18c699d4368d-3816a76542ec-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-contains.html-18c699d4368d-3816a76542ec
title: contains extractor
heading_path:
- contains extractor
section_titles:
- contains extractor
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-contains.html-18c699d4368d-3816a76542ec-block-0001
- itest-help_26.2.0.zip-popups-arules-contains.html-18c699d4368d-3816a76542ec-block-0002
- itest-help_26.2.0.zip-popups-arules-contains.html-18c699d4368d-3816a76542ec-block-0003
- itest-help_26.2.0.zip-popups-arules-contains.html-18c699d4368d-3816a76542ec-block-0004
- itest-help_26.2.0.zip-popups-arules-contains.html-18c699d4368d-3816a76542ec-block-0005
- itest-help_26.2.0.zip-popups-arules-contains.html-18c699d4368d-3816a76542ec-block-0006
- itest-help_26.2.0.zip-popups-arules-contains.html-18c699d4368d-3816a76542ec-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 103
source_hash: 3816a76542ec777a602838f9b6cb6df1beb80b82de10b9f2552225147b75e480
normalized_document_hash: d9b05d30f8a8a357bf4593f56b4b657f0dfc6ad6c9afeae24229cf0d0274981d
content_status: success
content_sha256: be9a87f7fcdc1f0664a673f995dbfbe8755826672fd0655b4ae29448cca63b11
---

# contains extractor

The contains extractor returns the value 1 (True) if the specified string appears in the response and returns 0 (False) if the specified string does not appear in the response.

For Global rules, the Extract using cell displays contains and the What to Extract cell displays the search text.

For details on using this and other extractor types, see

Analysis rules: Properties of the extractor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
