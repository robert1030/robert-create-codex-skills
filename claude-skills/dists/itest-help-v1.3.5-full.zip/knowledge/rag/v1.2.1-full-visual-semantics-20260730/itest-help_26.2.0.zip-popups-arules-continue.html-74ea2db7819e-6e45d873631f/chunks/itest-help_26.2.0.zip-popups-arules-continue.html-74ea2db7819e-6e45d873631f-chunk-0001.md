---
chunk_id: itest-help_26.2.0.zip-popups-arules-continue.html-74ea2db7819e-6e45d873631f-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-continue.html-74ea2db7819e-6e45d873631f
title: Continue action
heading_path:
- Continue action
section_titles:
- Continue action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-continue.html-74ea2db7819e-6e45d873631f-block-0001
- itest-help_26.2.0.zip-popups-arules-continue.html-74ea2db7819e-6e45d873631f-block-0002
- itest-help_26.2.0.zip-popups-arules-continue.html-74ea2db7819e-6e45d873631f-block-0003
- itest-help_26.2.0.zip-popups-arules-continue.html-74ea2db7819e-6e45d873631f-block-0004
- itest-help_26.2.0.zip-popups-arules-continue.html-74ea2db7819e-6e45d873631f-block-0005
- itest-help_26.2.0.zip-popups-arules-continue.html-74ea2db7819e-6e45d873631f-block-0006
- itest-help_26.2.0.zip-popups-arules-continue.html-74ea2db7819e-6e45d873631f-block-0007
- itest-help_26.2.0.zip-popups-arules-continue.html-74ea2db7819e-6e45d873631f-block-0008
- itest-help_26.2.0.zip-popups-arules-continue.html-74ea2db7819e-6e45d873631f-block-0009
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 208
source_hash: 6e45d873631f758908b227d2aaad1f48f4b2560d11be39777a69fa6801dd4a45
normalized_document_hash: c37d4830effd003b3fadc79987c8e9e1f4f9fb518bf7d42f278af3aa40556aab
content_status: success
content_sha256: 3c6006c0182d19fdf4d454ce3ae251d568f866aced458f1bfb005b980e60e76c
---

# Continue action

The Continue action causes the current script to be aborted out to the innermost containing for , foreach , or while loop command. The loop then continues with the next iteration of the loop.

Note:

Because this action alters the flow of execution, it is deferred (not executed) until all other actions for the step are executed. See the help topic titled "About deferred actions".

Use the Continue action when you want to execute particular steps for some iterations of the loop, but not for other iterations.

- The asynchronous property of a continue step is ignored
- Steps nested inside a continue step are never used

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
