# Continue action

The Continue action causes the current script to be aborted out to the innermost containing for , foreach , or while loop command. The loop then continues with the next iteration of the loop.

Note:

Because this action alters the flow of execution, it is deferred (not executed) until all other actions for the step are executed. See the help topic titled "About deferred actions".

Use the Continue action when you want to execute particular steps for some iterations of the loop, but not for other iterations.

- The asynchronous property of a continue step is ignored
- Steps nested inside a continue step are never used

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
