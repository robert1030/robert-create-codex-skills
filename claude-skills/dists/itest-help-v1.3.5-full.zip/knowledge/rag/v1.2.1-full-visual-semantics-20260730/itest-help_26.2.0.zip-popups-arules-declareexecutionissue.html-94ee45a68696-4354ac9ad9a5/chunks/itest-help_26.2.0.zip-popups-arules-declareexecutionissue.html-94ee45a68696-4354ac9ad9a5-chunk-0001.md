---
chunk_id: itest-help_26.2.0.zip-popups-arules-declareexecutionissue.html-94ee45a68696-4354ac9ad9a5-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-declareexecutionissue.html-94ee45a68696-4354ac9ad9a5
title: DeclareExecutionIssue action
heading_path:
- DeclareExecutionIssue action
section_titles:
- DeclareExecutionIssue action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-declareexecutionissue.html-94ee45a68696-4354ac9ad9a5-block-0001
- itest-help_26.2.0.zip-popups-arules-declareexecutionissue.html-94ee45a68696-4354ac9ad9a5-block-0002
- itest-help_26.2.0.zip-popups-arules-declareexecutionissue.html-94ee45a68696-4354ac9ad9a5-block-0003
- itest-help_26.2.0.zip-popups-arules-declareexecutionissue.html-94ee45a68696-4354ac9ad9a5-block-0004
- itest-help_26.2.0.zip-popups-arules-declareexecutionissue.html-94ee45a68696-4354ac9ad9a5-block-0005
- itest-help_26.2.0.zip-popups-arules-declareexecutionissue.html-94ee45a68696-4354ac9ad9a5-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 209
source_hash: 4354ac9ad9a554abb8841f51880966b3b487f990d4a22318cb3352a68bd5921b
normalized_document_hash: f8d9df922f80aab32077af639a42b10c6828d303a602707d801bde30074a78df
content_status: success
content_sha256: 6811bc5f30faa88f411cfebc4a5c48815725086b099f00d1e445cfdd132022ac
---

# DeclareExecutionIssue action

Display an execution message in the Execution view, in the Step Issues view, and in test reports. Specify the message text in the Description cell.

Properties:

- Severity: This setting determines the type of message that is displayed in the Execution view and in test reports. Select the type of message: OK, Information, Warning, Error
- Message: Specify the text message to display in the Execution view and in test reports. Field replacements are supported. iTest can generate a plain language sentence for the execution message (for example, "Extracted value $value is equal to "Up"). To use this feature, use {auto_message_true} or {auto_message_false}, as appropriate.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
