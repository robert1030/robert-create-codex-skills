# DeclareExecutionIssue action

Display an execution message in the Execution view, in the Step Issues view, and in test reports. Specify the message text in the Description cell.

Properties:

- Severity: This setting determines the type of message that is displayed in the Execution view and in test reports. Select the type of message: OK, Information, Warning, Error
- Message: Specify the text message to display in the Execution view and in test reports. Field replacements are supported. iTest can generate a plain language sentence for the execution message (for example, "Extracted value $value is equal to "Up"). To use this feature, use {auto_message_true} or {auto_message_false}, as appropriate.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
