---
chunk_id: itest-help_26.2.0.zip-popups-arules-eval.html-4d6fadd6096a-72881de8c4ee-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-eval.html-4d6fadd6096a-72881de8c4ee
title: Eval action
heading_path:
- Eval action
section_titles:
- Eval action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-eval.html-4d6fadd6096a-72881de8c4ee-block-0001
- itest-help_26.2.0.zip-popups-arules-eval.html-4d6fadd6096a-72881de8c4ee-block-0002
- itest-help_26.2.0.zip-popups-arules-eval.html-4d6fadd6096a-72881de8c4ee-block-0003
- itest-help_26.2.0.zip-popups-arules-eval.html-4d6fadd6096a-72881de8c4ee-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 79
source_hash: 72881de8c4ee3018887944a745dc17d8cc013e0d9d791d6c06cb7466b98cc32f
normalized_document_hash: e42a7d558d753feec429f8208821e4ee086334c6fbbde015efee37a46a5ace25
content_status: success
content_sha256: 33289fac858d3d7f847fad20641029c21faa1324b91c69d0457fc20f32e648fb
---

# Eval action

Evaluate the statements specified in the Description cell.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
