---
chunk_id: itest-help_26.2.0.zip-popups-arules-executionduration.html-f0eee3281645-598ec110923f-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-executionduration.html-f0eee3281645-598ec110923f
title: executionDuration extractor
heading_path:
- executionDuration extractor
section_titles:
- executionDuration extractor
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-executionduration.html-f0eee3281645-598ec110923f-block-0001
- itest-help_26.2.0.zip-popups-arules-executionduration.html-f0eee3281645-598ec110923f-block-0002
- itest-help_26.2.0.zip-popups-arules-executionduration.html-f0eee3281645-598ec110923f-block-0003
- itest-help_26.2.0.zip-popups-arules-executionduration.html-f0eee3281645-598ec110923f-block-0004
- itest-help_26.2.0.zip-popups-arules-executionduration.html-f0eee3281645-598ec110923f-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 123
source_hash: 598ec110923fa5851724409afa91840ac4dd4ce9dbf43a3509ea46d92ed47b16
normalized_document_hash: 085942105f11e7b1f1b1253c4ef952a1b968c3ed3d338abcf2522031718284c1
content_status: success
content_sha256: 1cbae75458582703493b918fe74154fe78711d39b947eef1b0f9076daa2af692
---

# executionDuration extractor

An analysis rule that uses the executionDuration extractor extracts the execution time of the current step (in seconds) and makes the value available for processing.

For Global rules, the Extract using cell displays executionDuration and the What to Extract cell is blank.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
