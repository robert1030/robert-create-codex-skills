---
chunk_id: itest-help_26.2.0.zip-popups-arules-exitexecution.html-a3037f8570a6-8ce9c0cffc7e-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-exitexecution.html-a3037f8570a6-8ce9c0cffc7e
title: ExitExecution
heading_path:
- ExitExecution
section_titles:
- ExitExecution
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-exitexecution.html-a3037f8570a6-8ce9c0cffc7e-block-0001
- itest-help_26.2.0.zip-popups-arules-exitexecution.html-a3037f8570a6-8ce9c0cffc7e-block-0002
- itest-help_26.2.0.zip-popups-arules-exitexecution.html-a3037f8570a6-8ce9c0cffc7e-block-0003
- itest-help_26.2.0.zip-popups-arules-exitexecution.html-a3037f8570a6-8ce9c0cffc7e-block-0004
- itest-help_26.2.0.zip-popups-arules-exitexecution.html-a3037f8570a6-8ce9c0cffc7e-block-0005
- itest-help_26.2.0.zip-popups-arules-exitexecution.html-a3037f8570a6-8ce9c0cffc7e-block-0006
- itest-help_26.2.0.zip-popups-arules-exitexecution.html-a3037f8570a6-8ce9c0cffc7e-block-0007
- itest-help_26.2.0.zip-popups-arules-exitexecution.html-a3037f8570a6-8ce9c0cffc7e-block-0008
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 165
source_hash: 8ce9c0cffc7eb03f2e6ffdcd9b0fcb8ce5685be4059042f1c6caab9b1802eeef
normalized_document_hash: b8a044addfdc7cfa97eeec6eba050639bcb4b955cc8f8adfc24d166c3e4c3be0
content_status: success
content_sha256: b60c1749a6d75c2f430c20d46612debc50b92727138bd3e2508226137821d3e5
---

# ExitExecution

Immediately stops executing the current procedure and all threads to end test case execution.

Does not change the existing execution result of the test case (Pass, Fail, Abort, or Indeterminate).

Note : Because this action alters the flow of execution, it is deferred (not executed) until all other actions for the step are executed.

An appropriate execution message appears in the Execution view, in the Step Issues view,  and in test reports.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
