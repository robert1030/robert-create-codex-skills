---
chunk_id: itest-help_26.2.0.zip-popups-arules-exitprocedure.html-c69561ae2a00-96242f0be79b-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-exitprocedure.html-c69561ae2a00-96242f0be79b
title: ExitProcedure action
heading_path:
- ExitProcedure action
section_titles:
- ExitProcedure action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-exitprocedure.html-c69561ae2a00-96242f0be79b-block-0001
- itest-help_26.2.0.zip-popups-arules-exitprocedure.html-c69561ae2a00-96242f0be79b-block-0002
- itest-help_26.2.0.zip-popups-arules-exitprocedure.html-c69561ae2a00-96242f0be79b-block-0003
- itest-help_26.2.0.zip-popups-arules-exitprocedure.html-c69561ae2a00-96242f0be79b-block-0004
- itest-help_26.2.0.zip-popups-arules-exitprocedure.html-c69561ae2a00-96242f0be79b-block-0005
- itest-help_26.2.0.zip-popups-arules-exitprocedure.html-c69561ae2a00-96242f0be79b-block-0006
- itest-help_26.2.0.zip-popups-arules-exitprocedure.html-c69561ae2a00-96242f0be79b-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 138
source_hash: 96242f0be79b74737577147e009af06dd46dd39b874e88bd05539e777b11cbf5
normalized_document_hash: c4c14ba74652144cbcd9497222545164c3aa9c3a288530cafc629531943f0d6c
content_status: success
content_sha256: 8e42599a5fbef83425938db46f750619d96b9e568106dd30a485919b66cdb012
---

# ExitProcedure action

Immediately stop executing the current procedure and continue execution.

Displays an appropriate execution message in the Execution view, in the Step Issues view, and in test reports.

Note : Because this action alters the flow of execution, it is deferred (not executed) until all other actions for the step are executed.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
