# ExitProcedure action

Immediately stop executing the current procedure and continue execution.

Displays an appropriate execution message in the Execution view, in the Step Issues view, and in test reports.

Note : Because this action alters the flow of execution, it is deferred (not executed) until all other actions for the step are executed.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
