---
chunk_id: itest-help_26.2.0.zip-popups-arules-failtest.html-3d4edd071194-ba0437e6aa76-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-failtest.html-3d4edd071194-ba0437e6aa76
title: FailTest action
heading_path:
- FailTest action
section_titles:
- FailTest action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-failtest.html-3d4edd071194-ba0437e6aa76-block-0001
- itest-help_26.2.0.zip-popups-arules-failtest.html-3d4edd071194-ba0437e6aa76-block-0002
- itest-help_26.2.0.zip-popups-arules-failtest.html-3d4edd071194-ba0437e6aa76-block-0003
- itest-help_26.2.0.zip-popups-arules-failtest.html-3d4edd071194-ba0437e6aa76-block-0004
- itest-help_26.2.0.zip-popups-arules-failtest.html-3d4edd071194-ba0437e6aa76-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 86
source_hash: ba0437e6aa763ecb06290f2b64297603b0d616f6b6adf601defb7b6a394dca60
normalized_document_hash: 1056ae803582a3c1e09e9c338df44fb412b6e2e0e66264f2a92213da2aca5f5f
content_status: success
content_sha256: c14b8bdc6dcd422c9af4196b1b6cf51478129adbea55cc7c3b46eaae80949cd1
---

# FailTest action

Set the test execution result as Fail . Continue to execute.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
