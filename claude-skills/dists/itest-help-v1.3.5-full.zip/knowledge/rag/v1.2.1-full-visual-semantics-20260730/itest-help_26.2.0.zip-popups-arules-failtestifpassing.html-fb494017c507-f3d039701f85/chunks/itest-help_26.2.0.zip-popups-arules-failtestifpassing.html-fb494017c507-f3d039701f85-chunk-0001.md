---
chunk_id: itest-help_26.2.0.zip-popups-arules-failtestifpassing.html-fb494017c507-f3d039701f85-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-failtestifpassing.html-fb494017c507-f3d039701f85
title: FailTestIfPassing action
heading_path:
- FailTestIfPassing action
section_titles:
- FailTestIfPassing action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-failtestifpassing.html-fb494017c507-f3d039701f85-block-0001
- itest-help_26.2.0.zip-popups-arules-failtestifpassing.html-fb494017c507-f3d039701f85-block-0002
- itest-help_26.2.0.zip-popups-arules-failtestifpassing.html-fb494017c507-f3d039701f85-block-0003
- itest-help_26.2.0.zip-popups-arules-failtestifpassing.html-fb494017c507-f3d039701f85-block-0004
- itest-help_26.2.0.zip-popups-arules-failtestifpassing.html-fb494017c507-f3d039701f85-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 98
source_hash: f3d039701f853e193ee65404dbcdcdb5516653cc4aec01e15e79e7aee3f4841b
normalized_document_hash: a32319ba85ccd24c61f2daea7e32103650d483aeec9d71441f7e968f277d7b67
content_status: success
content_sha256: 4c1cf8553c051539cda2649c9e7300092143d70b6fdcd4341e232761570354d9
---

# FailTestIfPassing action

Set the test execution result as Fail if the test is not already failed or aborted. Continue to execute.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
