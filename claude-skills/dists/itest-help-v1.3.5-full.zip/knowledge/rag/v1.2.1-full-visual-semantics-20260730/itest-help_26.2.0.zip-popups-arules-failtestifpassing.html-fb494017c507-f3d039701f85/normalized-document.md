# FailTestIfPassing action

Set the test execution result as Fail if the test is not already failed or aborted. Continue to execute.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
