---
chunk_id: itest-help_26.2.0.zip-popups-arules-message.html-97d6283a19f6-7090fafe16da-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-message.html-97d6283a19f6-7090fafe16da
title: message processor
heading_path:
- message processor
section_titles:
- message processor
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-message.html-97d6283a19f6-7090fafe16da-block-0001
- itest-help_26.2.0.zip-popups-arules-message.html-97d6283a19f6-7090fafe16da-block-0002
- itest-help_26.2.0.zip-popups-arules-message.html-97d6283a19f6-7090fafe16da-block-0003
- itest-help_26.2.0.zip-popups-arules-message.html-97d6283a19f6-7090fafe16da-block-0004
- itest-help_26.2.0.zip-popups-arules-message.html-97d6283a19f6-7090fafe16da-block-0005
- itest-help_26.2.0.zip-popups-arules-message.html-97d6283a19f6-7090fafe16da-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 84
source_hash: 7090fafe16da13c663d2221ed4bb12274c064f3b3285d8594026b7cfddbe22dd
normalized_document_hash: 7b4970d2772659af503df9e17c341b362680252659f306ac863a4243bbdec05b
content_status: success
content_sha256: bc6a868682eede668ff5780eca86a7f371187979a30d11a176692fe52ec1b5b8
---

# message processor

The message processor generates execution messages using the text specified in the Description cell (field replacements are supported). The messages appear in the Execution view, in the Step Issues view, and in test reports.

For details on using this and other processor types, see

Analysis rules: Properties of the processor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
