---
chunk_id: itest-help_26.2.0.zip-popups-arules-none.html-0ace7257d4f7-3bb36b378208-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-none.html-0ace7257d4f7-3bb36b378208
title: none extractor
heading_path:
- none extractor
section_titles:
- none extractor
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-none.html-0ace7257d4f7-3bb36b378208-block-0001
- itest-help_26.2.0.zip-popups-arules-none.html-0ace7257d4f7-3bb36b378208-block-0002
- itest-help_26.2.0.zip-popups-arules-none.html-0ace7257d4f7-3bb36b378208-block-0003
- itest-help_26.2.0.zip-popups-arules-none.html-0ace7257d4f7-3bb36b378208-block-0004
- itest-help_26.2.0.zip-popups-arules-none.html-0ace7257d4f7-3bb36b378208-block-0005
- itest-help_26.2.0.zip-popups-arules-none.html-0ace7257d4f7-3bb36b378208-block-0006
- itest-help_26.2.0.zip-popups-arules-none.html-0ace7257d4f7-3bb36b378208-block-0007
- itest-help_26.2.0.zip-popups-arules-none.html-0ace7257d4f7-3bb36b378208-block-0008
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 149
source_hash: 3bb36b3782089ff8d0c06dbd88a3c887ade50d3efce77f6989cd1364be56dc89
normalized_document_hash: 6d9dbbab4b156986c7bd0b1f550151894c055e49b4d05ba2348e4d7b89a31c10
content_status: success
content_sha256: 2b0c9e9c7904fbae0878fa306fe0c1cd56a0bb1235a0a30bffa3baf9c129f461
---

# none extractor

An analysis rule that uses the " none " extractor is successful regardless of the response. Use this kind of rule to take an action in any case.

This is useful, for example, to produce a message or perform an assertion that is not based on extracted data.  For example, your assertion might be $i > $j.  This has nothing to do with extracted data, so use the none extractor.

For Global rules, the Extract using cell displays none and the What to Extract cell is blank.

For details on using this and other extractor types, see

Analysis rules: Properties of the extractor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
