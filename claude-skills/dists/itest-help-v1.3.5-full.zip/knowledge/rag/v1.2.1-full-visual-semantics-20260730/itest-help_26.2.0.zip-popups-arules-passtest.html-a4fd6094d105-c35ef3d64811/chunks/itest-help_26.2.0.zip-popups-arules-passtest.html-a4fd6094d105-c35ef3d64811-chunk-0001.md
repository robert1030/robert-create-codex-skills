---
chunk_id: itest-help_26.2.0.zip-popups-arules-passtest.html-a4fd6094d105-c35ef3d64811-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-passtest.html-a4fd6094d105-c35ef3d64811
title: PassTest action
heading_path:
- PassTest action
section_titles:
- PassTest action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-passtest.html-a4fd6094d105-c35ef3d64811-block-0001
- itest-help_26.2.0.zip-popups-arules-passtest.html-a4fd6094d105-c35ef3d64811-block-0002
- itest-help_26.2.0.zip-popups-arules-passtest.html-a4fd6094d105-c35ef3d64811-block-0003
- itest-help_26.2.0.zip-popups-arules-passtest.html-a4fd6094d105-c35ef3d64811-block-0004
- itest-help_26.2.0.zip-popups-arules-passtest.html-a4fd6094d105-c35ef3d64811-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 86
source_hash: c35ef3d6481125e6fd179a71d679f9519fb67c13ae1be40326dc0ef399236d9c
normalized_document_hash: ede2e5ed4092cec97e52cc8c79a6aeb555ee8c3affa1c3e33bfd1f84c289e6c7
content_status: success
content_sha256: 75cc906711e3ac27770ce207593c5315bac386c99076ea6289de035dea7c2350
---

# PassTest action

Set the test execution result as Pass . Continue to execute.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
