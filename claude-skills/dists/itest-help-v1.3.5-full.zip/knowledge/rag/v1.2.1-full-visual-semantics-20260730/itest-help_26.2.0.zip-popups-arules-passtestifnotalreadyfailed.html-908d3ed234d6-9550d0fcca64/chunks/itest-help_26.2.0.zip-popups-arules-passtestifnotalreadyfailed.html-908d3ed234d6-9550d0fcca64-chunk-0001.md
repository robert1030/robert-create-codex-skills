---
chunk_id: itest-help_26.2.0.zip-popups-arules-passtestifnotalreadyfailed.html-908d3ed234d6-9550d0fcca64-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-passtestifnotalreadyfailed.html-908d3ed234d6-9550d0fcca64
title: PassTestIfNotAlreadyFailed action
heading_path:
- PassTestIfNotAlreadyFailed action
section_titles:
- PassTestIfNotAlreadyFailed action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-passtestifnotalreadyfailed.html-908d3ed234d6-9550d0fcca64-block-0001
- itest-help_26.2.0.zip-popups-arules-passtestifnotalreadyfailed.html-908d3ed234d6-9550d0fcca64-block-0002
- itest-help_26.2.0.zip-popups-arules-passtestifnotalreadyfailed.html-908d3ed234d6-9550d0fcca64-block-0003
- itest-help_26.2.0.zip-popups-arules-passtestifnotalreadyfailed.html-908d3ed234d6-9550d0fcca64-block-0004
- itest-help_26.2.0.zip-popups-arules-passtestifnotalreadyfailed.html-908d3ed234d6-9550d0fcca64-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 98
source_hash: 9550d0fcca64ba3a311f5e62e9a35f1fe5b11c33e01b0befa4e8e8d9210ec494
normalized_document_hash: 5cacd8e051222b00fd63fabf5953ea0dffa04b5c3422e8cbf94a1c1c64b73b72
content_status: success
content_sha256: a8767ed80dcf6f9a1e4bf02e22f1dead8e96c959ca162d2031b426fa7134c58f
---

# PassTestIfNotAlreadyFailed action

If the test result is not already Fail , then set the test execution result as Pass . Continue to execute.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
