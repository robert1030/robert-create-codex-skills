---
chunk_id: itest-help_26.2.0.zip-popups-arules-pauseexecution.html-625f34006489-71b53ae2e0ce-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-pauseexecution.html-625f34006489-71b53ae2e0ce
title: PauseExecution action
heading_path:
- PauseExecution action
section_titles:
- PauseExecution action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-pauseexecution.html-625f34006489-71b53ae2e0ce-block-0001
- itest-help_26.2.0.zip-popups-arules-pauseexecution.html-625f34006489-71b53ae2e0ce-block-0002
- itest-help_26.2.0.zip-popups-arules-pauseexecution.html-625f34006489-71b53ae2e0ce-block-0003
- itest-help_26.2.0.zip-popups-arules-pauseexecution.html-625f34006489-71b53ae2e0ce-block-0004
- itest-help_26.2.0.zip-popups-arules-pauseexecution.html-625f34006489-71b53ae2e0ce-block-0005
- itest-help_26.2.0.zip-popups-arules-pauseexecution.html-625f34006489-71b53ae2e0ce-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 110
source_hash: 71b53ae2e0cee0ad9596ccad05c347c548b970f38067411e8309649e2a9fc7c0
normalized_document_hash: 4f0abd58b567aebadb4da1b863dd2f5a7285fb3ce30ab6f95c9bef82dcccf1aa
content_status: success
content_sha256: 9ea3be1c02adda5bf3fea0fc59714228c9405f1c2571cce042eab7ef0f1d6465
---

# PauseExecution action

Immediately pauses execution. Brings the Execution view to the front.

Displays an appropriate execution message in the Execution view, in the Step Issues view, and in test reports.

No configurable properties.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
