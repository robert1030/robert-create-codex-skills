---
chunk_id: itest-help_26.2.0.zip-popups-arules-regex.html-02b479b02e23-cd24a52aa8e8-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-regex.html-02b479b02e23-cd24a52aa8e8
title: regex extractor
heading_path:
- regex extractor
section_titles:
- regex extractor
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-regex.html-02b479b02e23-cd24a52aa8e8-block-0001
- itest-help_26.2.0.zip-popups-arules-regex.html-02b479b02e23-cd24a52aa8e8-block-0002
- itest-help_26.2.0.zip-popups-arules-regex.html-02b479b02e23-cd24a52aa8e8-block-0003
- itest-help_26.2.0.zip-popups-arules-regex.html-02b479b02e23-cd24a52aa8e8-block-0004
- itest-help_26.2.0.zip-popups-arules-regex.html-02b479b02e23-cd24a52aa8e8-block-0005
- itest-help_26.2.0.zip-popups-arules-regex.html-02b479b02e23-cd24a52aa8e8-block-0006
- itest-help_26.2.0.zip-popups-arules-regex.html-02b479b02e23-cd24a52aa8e8-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 90
source_hash: cd24a52aa8e8530eb406380596ea20ef994348a6062fd9c59c311a2d9b196946
normalized_document_hash: c1e05a58eb4e4938a0e9aedc347cfcbf878b78d2a57e18f5592178edf7c2079d
content_status: success
content_sha256: 8799679d5382a87f19d78097e0a3c6b86718c0362a81e303569c20653a7e561b
---

# regex extractor

The regex extractor finds all matches to the specified regular expression in the response body for the step.

For Global rules, the Extract using cell displays regex and the What to Extract cell displays the text of the regular expression.

For details on using this and other extractor types, see

Analysis rules: Properties of the extractor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
