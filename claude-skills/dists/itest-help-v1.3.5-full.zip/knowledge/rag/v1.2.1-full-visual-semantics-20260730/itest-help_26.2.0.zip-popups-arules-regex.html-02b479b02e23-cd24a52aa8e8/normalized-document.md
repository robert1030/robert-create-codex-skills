# regex extractor

The regex extractor finds all matches to the specified regular expression in the response body for the step.

For Global rules, the Extract using cell displays regex and the What to Extract cell displays the text of the regular expression.

For details on using this and other extractor types, see

Analysis rules: Properties of the extractor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
