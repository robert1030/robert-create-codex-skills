---
chunk_id: itest-help_26.2.0.zip-popups-arules-repeatstep.html-3e3de284063f-f8bb9b4b3ea3-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-repeatstep.html-3e3de284063f-f8bb9b4b3ea3
title: RepeatStep action
heading_path:
- RepeatStep action
section_titles:
- RepeatStep action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-repeatstep.html-3e3de284063f-f8bb9b4b3ea3-block-0001
- itest-help_26.2.0.zip-popups-arules-repeatstep.html-3e3de284063f-f8bb9b4b3ea3-block-0002
- itest-help_26.2.0.zip-popups-arules-repeatstep.html-3e3de284063f-f8bb9b4b3ea3-block-0003
- itest-help_26.2.0.zip-popups-arules-repeatstep.html-3e3de284063f-f8bb9b4b3ea3-block-0004
- itest-help_26.2.0.zip-popups-arules-repeatstep.html-3e3de284063f-f8bb9b4b3ea3-block-0005
- itest-help_26.2.0.zip-popups-arules-repeatstep.html-3e3de284063f-f8bb9b4b3ea3-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 117
source_hash: f8bb9b4b3ea31bfc538a6a72137fde74eea3558df291bf820e113feeebdcaa6f
normalized_document_hash: 4c7b42ca2fb1ad64540adf258e765ea89b448f319bb0482db06138c4b2800709
content_status: success
content_sha256: 3f411684db72a23f7db3145d981bb38375f55e7eaf5c694de0da743ea61cc869
---

# RepeatStep action

Repeats the current step.

Properties

- Maximum number of attempts : Specify the maximum number of attempts to execute the step.
- Delay between attempts : Specify how long to wait between attempts to execute a the step (in seconds).

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor . Also, see: Analysis rules: Validating responses and setting Pass / Fail .

For details on using this action and other actions for events, see Actions on events: Definitions .
