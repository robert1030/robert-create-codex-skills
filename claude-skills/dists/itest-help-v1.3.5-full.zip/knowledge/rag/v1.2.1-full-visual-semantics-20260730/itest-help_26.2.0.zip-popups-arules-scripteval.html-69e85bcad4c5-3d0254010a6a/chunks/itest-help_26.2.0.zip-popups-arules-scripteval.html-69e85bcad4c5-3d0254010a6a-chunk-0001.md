---
chunk_id: itest-help_26.2.0.zip-popups-arules-scripteval.html-69e85bcad4c5-3d0254010a6a-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-scripteval.html-69e85bcad4c5-3d0254010a6a
title: scriptEval
heading_path:
- scriptEval
section_titles:
- scriptEval
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-scripteval.html-69e85bcad4c5-3d0254010a6a-block-0001
- itest-help_26.2.0.zip-popups-arules-scripteval.html-69e85bcad4c5-3d0254010a6a-block-0002
- itest-help_26.2.0.zip-popups-arules-scripteval.html-69e85bcad4c5-3d0254010a6a-block-0003
- itest-help_26.2.0.zip-popups-arules-scripteval.html-69e85bcad4c5-3d0254010a6a-block-0004
- itest-help_26.2.0.zip-popups-arules-scripteval.html-69e85bcad4c5-3d0254010a6a-block-0005
- itest-help_26.2.0.zip-popups-arules-scripteval.html-69e85bcad4c5-3d0254010a6a-block-0006
- itest-help_26.2.0.zip-popups-arules-scripteval.html-69e85bcad4c5-3d0254010a6a-block-0007
- itest-help_26.2.0.zip-popups-arules-scripteval.html-69e85bcad4c5-3d0254010a6a-block-0008
- itest-help_26.2.0.zip-popups-arules-scripteval.html-69e85bcad4c5-3d0254010a6a-block-0009
- itest-help_26.2.0.zip-popups-arules-scripteval.html-69e85bcad4c5-3d0254010a6a-block-0010
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 137
source_hash: 3d0254010a6a83de360ea5e8411c24ccb78a0e69c307587b340d093bb6cd788f
normalized_document_hash: 515dae9b7825005dc17a70c2259a4ffb4da08ccc45add58e1338ab4f23533d2d
content_status: success
content_sha256: 24388555f7452f0e1b4491bcceab77530eb3d103d88a8ff2143f12902e84bf9d
---

# scriptEval

Evaluates the script specified in the Description cell using the Tcl interpreter attached to the execution kernel.

- The following types of substitution are not made to the text of the statement before it is evaluated:
- Command field replacements
- Variables
- Backslash characters used to escape special characters

The response is populated (including structured data) in a way consistent with how a Tcl Shell Command step works (including result, STDOUT, and/or STDERR).

For details on using this action and other actions for the

assert

processor, see

Analysis rules: Properties of the processor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
