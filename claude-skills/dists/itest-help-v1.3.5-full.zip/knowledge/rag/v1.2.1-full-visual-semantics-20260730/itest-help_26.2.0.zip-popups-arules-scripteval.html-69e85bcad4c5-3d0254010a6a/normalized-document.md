# scriptEval

Evaluates the script specified in the Description cell using the Tcl interpreter attached to the execution kernel.

- The following types of substitution are not made to the text of the statement before it is evaluated:
- Command field replacements
- Variables
- Backslash characters used to escape special characters

The response is populated (including structured data) in a way consistent with how a Tcl Shell Command step works (including result, STDOUT, and/or STDERR).

For details on using this action and other actions for the

assert

processor, see

Analysis rules: Properties of the processor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
