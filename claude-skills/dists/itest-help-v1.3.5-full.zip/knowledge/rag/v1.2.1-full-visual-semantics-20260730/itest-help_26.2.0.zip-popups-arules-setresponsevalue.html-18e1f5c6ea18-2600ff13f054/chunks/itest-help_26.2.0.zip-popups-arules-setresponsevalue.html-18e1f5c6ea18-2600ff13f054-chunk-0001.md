---
chunk_id: itest-help_26.2.0.zip-popups-arules-setresponsevalue.html-18e1f5c6ea18-2600ff13f054-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-setresponsevalue.html-18e1f5c6ea18-2600ff13f054
title: SetResponseValue action
heading_path:
- SetResponseValue action
section_titles:
- SetResponseValue action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-setresponsevalue.html-18e1f5c6ea18-2600ff13f054-block-0001
- itest-help_26.2.0.zip-popups-arules-setresponsevalue.html-18e1f5c6ea18-2600ff13f054-block-0002
- itest-help_26.2.0.zip-popups-arules-setresponsevalue.html-18e1f5c6ea18-2600ff13f054-block-0003
- itest-help_26.2.0.zip-popups-arules-setresponsevalue.html-18e1f5c6ea18-2600ff13f054-block-0004
- itest-help_26.2.0.zip-popups-arules-setresponsevalue.html-18e1f5c6ea18-2600ff13f054-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 113
source_hash: 2600ff13f0541e2a04492edf451bab6e66e7f270647958862be9899be81ddcc3
normalized_document_hash: e77224a9e0eaed67a3fe666354852d29885f7bf3e7a0c515a67e9647a74c1399
content_status: success
content_sha256: 8a78f9ea5576ac1d716dffbe9fb0d81ad2dd02617d7e023632297ab48d40adbe
---

# SetResponseValue action

SetResponseValue value

To specify the actions that should occur upon True and False results, specify Rule Actions for When True and When False. For example, enter the Action SetResponseValue and specify a response in the Description cell. The action SetResponseValue, displays the Action Properties section.

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor .

For details on using this action and other actions for events, see Actions on events: Definitions .
