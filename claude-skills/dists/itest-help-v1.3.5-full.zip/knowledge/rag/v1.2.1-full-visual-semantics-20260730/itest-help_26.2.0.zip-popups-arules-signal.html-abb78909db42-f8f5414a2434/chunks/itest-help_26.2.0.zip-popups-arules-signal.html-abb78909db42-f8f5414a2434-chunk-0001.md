---
chunk_id: itest-help_26.2.0.zip-popups-arules-signal.html-abb78909db42-f8f5414a2434-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-signal.html-abb78909db42-f8f5414a2434
title: signal action
heading_path:
- signal action
section_titles:
- signal action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-signal.html-abb78909db42-f8f5414a2434-block-0001
- itest-help_26.2.0.zip-popups-arules-signal.html-abb78909db42-f8f5414a2434-block-0002
- itest-help_26.2.0.zip-popups-arules-signal.html-abb78909db42-f8f5414a2434-block-0003
- itest-help_26.2.0.zip-popups-arules-signal.html-abb78909db42-f8f5414a2434-block-0004
- itest-help_26.2.0.zip-popups-arules-signal.html-abb78909db42-f8f5414a2434-block-0005
- itest-help_26.2.0.zip-popups-arules-signal.html-abb78909db42-f8f5414a2434-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 98
source_hash: f8f5414a24341c92a1d995ef51d441dde08abcab3b9831b0086a004d91050caa
normalized_document_hash: 672c9e2619345e4f221e9cc18297b39229e45996b691aaf772d2534af6caa96f
content_status: success
content_sha256: 78bd40feb4416882c36518b63ed4c4d2894b43dd69b0ea1f4d3858a0f98e361f
---

# signal action

signal eventName

During synchronous execution: Wakes a thread that is waiting on eventName and causes it to continue execution.

For full details, see signal: Wake a thread that is waiting on an event .

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor .

For details on using this action and other actions for events, see Actions on events: Definitions .
