# signal action

signal eventName

During synchronous execution: Wakes a thread that is waiting on eventName and causes it to continue execution.

For full details, see signal: Wake a thread that is waiting on an event .

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor .

For details on using this action and other actions for events, see Actions on events: Definitions .
