---
chunk_id: itest-help_26.2.0.zip-popups-arules-signalactivate.html-7e87322d38d2-346e4ddc25a6-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-signalactivate.html-7e87322d38d2-346e4ddc25a6
title: signalActivate action
heading_path:
- signalActivate action
section_titles:
- signalActivate action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-signalactivate.html-7e87322d38d2-346e4ddc25a6-block-0001
- itest-help_26.2.0.zip-popups-arules-signalactivate.html-7e87322d38d2-346e4ddc25a6-block-0002
- itest-help_26.2.0.zip-popups-arules-signalactivate.html-7e87322d38d2-346e4ddc25a6-block-0003
- itest-help_26.2.0.zip-popups-arules-signalactivate.html-7e87322d38d2-346e4ddc25a6-block-0004
- itest-help_26.2.0.zip-popups-arules-signalactivate.html-7e87322d38d2-346e4ddc25a6-block-0005
- itest-help_26.2.0.zip-popups-arules-signalactivate.html-7e87322d38d2-346e4ddc25a6-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 82
source_hash: 346e4ddc25a6056d9b2a68322158ae8746d7092bc780093f7f64a818c31df327
normalized_document_hash: 0971cd413f806f99f434efdaf35c4b31d9c5327a221ed27974e5b299d0c64cd1
content_status: success
content_sha256: 5ec52976f425b6d66374e0e5ab7a4d1300710937233a0601e81b6edb75c14720
---

# signalActivate action

signalActivate eventName

During synchronous execution: Turns on the event called eventName .

For full details, see signalActivate: Turn a signal on .

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor .

For details on using this action and other actions for events, see Actions on events: Definitions .
