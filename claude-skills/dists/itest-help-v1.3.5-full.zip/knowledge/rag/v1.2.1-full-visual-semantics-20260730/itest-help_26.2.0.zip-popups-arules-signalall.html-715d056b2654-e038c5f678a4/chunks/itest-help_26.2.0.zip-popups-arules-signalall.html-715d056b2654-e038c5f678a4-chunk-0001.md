---
chunk_id: itest-help_26.2.0.zip-popups-arules-signalall.html-715d056b2654-e038c5f678a4-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-signalall.html-715d056b2654-e038c5f678a4
title: signalAll action
heading_path:
- signalAll action
section_titles:
- signalAll action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-signalall.html-715d056b2654-e038c5f678a4-block-0001
- itest-help_26.2.0.zip-popups-arules-signalall.html-715d056b2654-e038c5f678a4-block-0002
- itest-help_26.2.0.zip-popups-arules-signalall.html-715d056b2654-e038c5f678a4-block-0003
- itest-help_26.2.0.zip-popups-arules-signalall.html-715d056b2654-e038c5f678a4-block-0004
- itest-help_26.2.0.zip-popups-arules-signalall.html-715d056b2654-e038c5f678a4-block-0005
- itest-help_26.2.0.zip-popups-arules-signalall.html-715d056b2654-e038c5f678a4-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 106
source_hash: e038c5f678a49b48464117f395ac1468fdee42855d83f48c662c90c3b9f20597
normalized_document_hash: a3fc23207643e090e09de36189c5a7f92b3287f8dd8d35277fa638eab7517e0a
content_status: success
content_sha256: dd5ab1bcdadc1a3a63372a7bb48e7657ea5fbfcc977d6a6079fcbe1683c2517d
---

# signalAll action

signalAll eventName

For synchronous execution: Causes the currently executing thread to sleep until all specified events have been signaled or activated ( signal , signalAll , or signalActivate ).

For full details, see signalAll: Wake all threads that are waiting on an event .

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor .

For details on using this action and other actions for events, see Actions on events: Definitions .
