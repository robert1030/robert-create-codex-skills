# signalAll action

signalAll eventName

For synchronous execution: Causes the currently executing thread to sleep until all specified events have been signaled or activated ( signal , signalAll , or signalActivate ).

For full details, see signalAll: Wake all threads that are waiting on an event .

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor .

For details on using this action and other actions for events, see Actions on events: Definitions .
