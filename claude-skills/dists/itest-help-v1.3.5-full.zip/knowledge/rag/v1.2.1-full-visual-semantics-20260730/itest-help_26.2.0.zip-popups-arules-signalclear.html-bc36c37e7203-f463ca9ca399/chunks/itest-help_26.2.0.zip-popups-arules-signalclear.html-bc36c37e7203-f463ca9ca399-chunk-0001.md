---
chunk_id: itest-help_26.2.0.zip-popups-arules-signalclear.html-bc36c37e7203-f463ca9ca399-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-signalclear.html-bc36c37e7203-f463ca9ca399
title: signalClear action
heading_path:
- signalClear action
section_titles:
- signalClear action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-signalclear.html-bc36c37e7203-f463ca9ca399-block-0001
- itest-help_26.2.0.zip-popups-arules-signalclear.html-bc36c37e7203-f463ca9ca399-block-0002
- itest-help_26.2.0.zip-popups-arules-signalclear.html-bc36c37e7203-f463ca9ca399-block-0003
- itest-help_26.2.0.zip-popups-arules-signalclear.html-bc36c37e7203-f463ca9ca399-block-0004
- itest-help_26.2.0.zip-popups-arules-signalclear.html-bc36c37e7203-f463ca9ca399-block-0005
- itest-help_26.2.0.zip-popups-arules-signalclear.html-bc36c37e7203-f463ca9ca399-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 102
source_hash: f463ca9ca399af5d46d6d9e2c9c3e356e8ad574377cdab81fc6d24a8fda8c47e
normalized_document_hash: 4a085352fe3315f8285767ce05f1e9ef1aefdfc78d87a6ce8e902f4c69fc1a42
content_status: success
content_sha256: dae6026fd676261926ee0cdacfb3008239fdc3690f7908b6dc5c4865b77f3534
---

# signalClear action

signalClear eventName

For synchronous execution: Removes any instances of the event named eventName that had previously been activated either by a signalActivate step or by a signal command.

For full details, see signalClear: Deactivate a signal .

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor .

For details on using this action and other actions for events, see Actions on events: Definitions .
