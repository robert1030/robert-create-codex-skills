# signalClear action

signalClear eventName

For synchronous execution: Removes any instances of the event named eventName that had previously been activated either by a signalActivate step or by a signal command.

For full details, see signalClear: Deactivate a signal .

For details on using this action and other actions for the assert processor in analysis rules, see Analysis rules: Properties of the processor .

For details on using this action and other actions for events, see Actions on events: Definitions .
