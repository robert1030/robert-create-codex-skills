---
chunk_id: itest-help_26.2.0.zip-popups-arules-skipremainingrules.html-0af803fdbd74-19c519fb88b5-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-skipremainingrules.html-0af803fdbd74-19c519fb88b5
title: SkipRemainingRules action
heading_path:
- SkipRemainingRules action
section_titles:
- SkipRemainingRules action
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-skipremainingrules.html-0af803fdbd74-19c519fb88b5-block-0001
- itest-help_26.2.0.zip-popups-arules-skipremainingrules.html-0af803fdbd74-19c519fb88b5-block-0002
- itest-help_26.2.0.zip-popups-arules-skipremainingrules.html-0af803fdbd74-19c519fb88b5-block-0003
- itest-help_26.2.0.zip-popups-arules-skipremainingrules.html-0af803fdbd74-19c519fb88b5-block-0004
- itest-help_26.2.0.zip-popups-arules-skipremainingrules.html-0af803fdbd74-19c519fb88b5-block-0005
- itest-help_26.2.0.zip-popups-arules-skipremainingrules.html-0af803fdbd74-19c519fb88b5-block-0006
- itest-help_26.2.0.zip-popups-arules-skipremainingrules.html-0af803fdbd74-19c519fb88b5-block-0007
- itest-help_26.2.0.zip-popups-arules-skipremainingrules.html-0af803fdbd74-19c519fb88b5-block-0008
- itest-help_26.2.0.zip-popups-arules-skipremainingrules.html-0af803fdbd74-19c519fb88b5-block-0009
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 103
source_hash: 19c519fb88b58aba71a1011f2570ab789ec9d8af2f7a89863aefff2a5db7ad46
normalized_document_hash: 6e9be4d5c43ef3a864c9d96d147979d027cb37c68613703395336a1ec5e8d731
content_status: success
content_sha256: b8250279650403e36f4c5b67f1d420dc4e828f9399a515346e886e3a045eb010
---

# SkipRemainingRules action

The system does not perform any further analysis rules associated with the current step.

For example, you might set this Action so that when an analysis rule concludes that something has gone wrong and there is no point in performing additional analysis, then skip further analysis.

For details on using this action and other actions for the

assert

processor, see

Analysis rules: Properties of the processor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
