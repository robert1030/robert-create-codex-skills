# SkipRemainingRules action

The system does not perform any further analysis rules associated with the current step.

For example, you might set this Action so that when an analysis rule concludes that something has gone wrong and there is no point in performing additional analysis, then skip further analysis.

For details on using this action and other actions for the

assert

processor, see

Analysis rules: Properties of the processor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
