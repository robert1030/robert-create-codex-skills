---
chunk_id: itest-help_26.2.0.zip-popups-arules-store.html-1b3c59cd9790-7b017efff68a-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-store.html-1b3c59cd9790-7b017efff68a
title: store processor
heading_path:
- store processor
section_titles:
- store processor
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-store.html-1b3c59cd9790-7b017efff68a-block-0001
- itest-help_26.2.0.zip-popups-arules-store.html-1b3c59cd9790-7b017efff68a-block-0002
- itest-help_26.2.0.zip-popups-arules-store.html-1b3c59cd9790-7b017efff68a-block-0003
- itest-help_26.2.0.zip-popups-arules-store.html-1b3c59cd9790-7b017efff68a-block-0004
- itest-help_26.2.0.zip-popups-arules-store.html-1b3c59cd9790-7b017efff68a-block-0005
- itest-help_26.2.0.zip-popups-arules-store.html-1b3c59cd9790-7b017efff68a-block-0006
- itest-help_26.2.0.zip-popups-arules-store.html-1b3c59cd9790-7b017efff68a-block-0007
- itest-help_26.2.0.zip-popups-arules-store.html-1b3c59cd9790-7b017efff68a-block-0008
- itest-help_26.2.0.zip-popups-arules-store.html-1b3c59cd9790-7b017efff68a-block-0009
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 206
source_hash: 7b017efff68a74ade578ba24b6cf88cf89059773816ef79090b339e3bb88efc5
normalized_document_hash: 7158d8dd4dce163d4038f0da9132de0f2fe1590b47da7161ba82ad2e77044182
content_status: success
content_sha256: c4eb2103c13b0803e263f4282a9ac5b56eb6af97adb49169e2a2df23fc771421
---

# store processor

The store processor stores, into a variable, the data that is extracted while processing the rule .

- A response with zero values or multiple values is always stored in a list.
- You can specify whether to store a single extracted value in a scalar string or in a list. See the Always store data in a list property for recommendations when a single extracted value can contain whitespace.

Tip : You can store a value from the response to a step (say, step 12). In a later step (say, step 19), you can add a rule about a token in step 19 and compare its value to the value of the token extracted in step 12. So, for step 19, you can create an assertion like:

$value > $tokenStep12 * 2

For details on using this and other processor types, see

Analysis rules: Properties of the processor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
