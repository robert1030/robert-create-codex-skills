---
chunk_id: itest-help_26.2.0.zip-popups-arules-writefile.html-2dd9d4595089-fa0e6b7d928c-chunk-0001
source_id: itest-help_26.2.0.zip-popups-arules-writefile.html-2dd9d4595089-fa0e6b7d928c
title: writeFile processor
heading_path:
- writeFile processor
section_titles:
- writeFile processor
source_block_ids:
- itest-help_26.2.0.zip-popups-arules-writefile.html-2dd9d4595089-fa0e6b7d928c-block-0001
- itest-help_26.2.0.zip-popups-arules-writefile.html-2dd9d4595089-fa0e6b7d928c-block-0002
- itest-help_26.2.0.zip-popups-arules-writefile.html-2dd9d4595089-fa0e6b7d928c-block-0003
- itest-help_26.2.0.zip-popups-arules-writefile.html-2dd9d4595089-fa0e6b7d928c-block-0004
- itest-help_26.2.0.zip-popups-arules-writefile.html-2dd9d4595089-fa0e6b7d928c-block-0005
- itest-help_26.2.0.zip-popups-arules-writefile.html-2dd9d4595089-fa0e6b7d928c-block-0006
- itest-help_26.2.0.zip-popups-arules-writefile.html-2dd9d4595089-fa0e6b7d928c-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 149
source_hash: fa0e6b7d928cf44d80cebafa923e9e7b1bbc15669541e17f8eede4735264f2e0
normalized_document_hash: 11245c1b07f61a5f1c98c623f7761b44ee2c62c28565bb1210b71eb4979fa86b
content_status: success
content_sha256: 3644fb77c624929ff7e517ad4c370ed6ee8e65372dcf1d1d798198bbc6845ada
---

# writeFile processor

The writeFile processor writes information to a file. Here are some options for writeFile actions:

- You can overwrite or append to an existing file
- You can add a blank line to the end file (after the end of the data)
- When the information consists of multiple values, you can specify the delimiter character (comma, newline, and so on) to use to separate values
- For multiline data, you can specify the delimiter character to use to separate lines (cr, cr/lf and so on)

For details on using this and other processor types, see

Analysis rules: Properties of the processor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
