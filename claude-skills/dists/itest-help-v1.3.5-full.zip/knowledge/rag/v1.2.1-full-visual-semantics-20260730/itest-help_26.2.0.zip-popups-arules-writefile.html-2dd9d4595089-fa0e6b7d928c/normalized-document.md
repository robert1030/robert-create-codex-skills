# writeFile processor

The writeFile processor writes information to a file. Here are some options for writeFile actions:

- You can overwrite or append to an existing file
- You can add a blank line to the end file (after the end of the data)
- When the information consists of multiple values, you can specify the delimiter character (comma, newline, and so on) to use to separate values
- For multiline data, you can specify the delimiter character to use to separate lines (cr, cr/lf and so on)

For details on using this and other processor types, see

Analysis rules: Properties of the processor

.

Also, see: Analysis rules: Validating responses and setting Pass / Fail .
