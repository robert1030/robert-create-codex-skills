---
chunk_id: itest-help_26.2.0.zip-popups-attach.html-4ff8333703c4-38dba35ecdcf-chunk-0001
source_id: itest-help_26.2.0.zip-popups-attach.html-4ff8333703c4-38dba35ecdcf
title: attach
heading_path:
- attach
section_titles:
- attach
source_block_ids:
- itest-help_26.2.0.zip-popups-attach.html-4ff8333703c4-38dba35ecdcf-block-0001
- itest-help_26.2.0.zip-popups-attach.html-4ff8333703c4-38dba35ecdcf-block-0002
- itest-help_26.2.0.zip-popups-attach.html-4ff8333703c4-38dba35ecdcf-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 38
source_hash: 38dba35ecdcfd4c0b2049bdd0d21d89929980dc057f9dd716e3e48d6cb789513
normalized_document_hash: 0ae5796ed78af8fcfbde34ec5aa01cb70237ac69d2501c1a7b8825e51221f3bb
content_status: success
content_sha256: 4621a1ca165e2377619e19eae7fdc537bd73c178a66f4a6e560d6f7b90718f51
---

# attach

Attach the file (from the local file system) that is specified in the Description cell.

For details, see the online help: Sending email messages during test execution .
