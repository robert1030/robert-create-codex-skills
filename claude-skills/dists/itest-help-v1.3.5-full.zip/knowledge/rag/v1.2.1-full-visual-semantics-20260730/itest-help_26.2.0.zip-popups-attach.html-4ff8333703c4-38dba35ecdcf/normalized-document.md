# attach

Attach the file (from the local file system) that is specified in the Description cell.

For details, see the online help: Sending email messages during test execution .
