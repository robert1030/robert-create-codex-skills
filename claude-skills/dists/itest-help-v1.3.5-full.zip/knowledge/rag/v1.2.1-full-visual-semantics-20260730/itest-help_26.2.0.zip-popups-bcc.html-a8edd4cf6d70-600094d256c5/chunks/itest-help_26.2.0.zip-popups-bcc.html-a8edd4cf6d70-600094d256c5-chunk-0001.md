---
chunk_id: itest-help_26.2.0.zip-popups-bcc.html-a8edd4cf6d70-600094d256c5-chunk-0001
source_id: itest-help_26.2.0.zip-popups-bcc.html-a8edd4cf6d70-600094d256c5
title: bcc
heading_path:
- bcc
section_titles:
- bcc
source_block_ids:
- itest-help_26.2.0.zip-popups-bcc.html-a8edd4cf6d70-600094d256c5-block-0001
- itest-help_26.2.0.zip-popups-bcc.html-a8edd4cf6d70-600094d256c5-block-0002
- itest-help_26.2.0.zip-popups-bcc.html-a8edd4cf6d70-600094d256c5-block-0003
- itest-help_26.2.0.zip-popups-bcc.html-a8edd4cf6d70-600094d256c5-block-0004
- itest-help_26.2.0.zip-popups-bcc.html-a8edd4cf6d70-600094d256c5-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 79
source_hash: 600094d256c56f9b0971ed63cc4f7ebbb7422214f82c5bacc8923abc5c1bd9a8
normalized_document_hash: 926b9f7820eafb62ee959da7c6b56430e9315ff1b9a51ff2a6c3c05d66319117
content_status: success
content_sha256: a21316116f5a84c507da5be1581a494498896d2dd325247107f792807f95c5df
---

# bcc

"Blind copy" the message (the recipient specified in the to step does not see these addresses in the message) to the address specified in the Description cell.

In the Description cell, specify an email alias or a semicolon-separated list of email addresses.

Field replacements are supported.

For details, see the online help: Sending email messages during test execution .
