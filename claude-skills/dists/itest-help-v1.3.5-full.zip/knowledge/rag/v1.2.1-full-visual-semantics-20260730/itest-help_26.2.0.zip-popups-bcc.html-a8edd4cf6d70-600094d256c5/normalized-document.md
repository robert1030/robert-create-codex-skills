# bcc

"Blind copy" the message (the recipient specified in the to step does not see these addresses in the message) to the address specified in the Description cell.

In the Description cell, specify an email alias or a semicolon-separated list of email addresses.

Field replacements are supported.

For details, see the online help: Sending email messages during test execution .
