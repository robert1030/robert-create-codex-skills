---
chunk_id: itest-help_26.2.0.zip-popups-break_cli.html-f124c5968a83-75efa04e401e-chunk-0001
source_id: itest-help_26.2.0.zip-popups-break_cli.html-f124c5968a83-75efa04e401e
title: break (for CLI sessions)
heading_path:
- break (for CLI sessions)
section_titles:
- break (for CLI sessions)
source_block_ids:
- itest-help_26.2.0.zip-popups-break_cli.html-f124c5968a83-75efa04e401e-block-0001
- itest-help_26.2.0.zip-popups-break_cli.html-f124c5968a83-75efa04e401e-block-0002
- itest-help_26.2.0.zip-popups-break_cli.html-f124c5968a83-75efa04e401e-block-0003
- itest-help_26.2.0.zip-popups-break_cli.html-f124c5968a83-75efa04e401e-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 98
source_hash: 75efa04e401e8b4d203ee2409d480e535126346b07eff5d8b10b9885aa56bd56
normalized_document_hash: be91b79f853a2e0735abd64471c0cdf62af67757039b87915f9b4323b4b81875
content_status: success
content_sha256: 1863830945196e637c029f0483821795b923e2334805e8b531eafd2dc91b15ee
---

# break (for CLI sessions)

The break action sends the break character specified for the session profile (for example, CTRL-C). (This break action appears in the list only for CLI sessions.)

For details, see the online help: The break action .

To teach iTest about the appropriate break characters for a device, you set the Command break characters property in the session profile.  For example, here are the instructions for setting Telnet session profile properties.
