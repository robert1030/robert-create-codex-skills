# break (for CLI sessions)

The break action sends the break character specified for the session profile (for example, CTRL-C). (This break action appears in the list only for CLI sessions.)

For details, see the online help: The break action .

To teach iTest about the appropriate break characters for a device, you set the Command break characters property in the session profile.  For example, here are the instructions for setting Telnet session profile properties.
