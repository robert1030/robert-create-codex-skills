---
chunk_id: itest-help_26.2.0.zip-popups-break_exec.html-d6be29a56702-da662df48376-chunk-0001
source_id: itest-help_26.2.0.zip-popups-break_exec.html-d6be29a56702-da662df48376
title: break
heading_path:
- break
section_titles:
- break
source_block_ids:
- itest-help_26.2.0.zip-popups-break_exec.html-d6be29a56702-da662df48376-block-0001
- itest-help_26.2.0.zip-popups-break_exec.html-d6be29a56702-da662df48376-block-0002
- itest-help_26.2.0.zip-popups-break_exec.html-d6be29a56702-da662df48376-block-0004
- itest-help_26.2.0.zip-popups-break_exec.html-d6be29a56702-da662df48376-block-0005
- itest-help_26.2.0.zip-popups-break_exec.html-d6be29a56702-da662df48376-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 79
source_hash: da662df4837625ae3863ea6d2f4b98a22030ae041566edb13f2c30539253f3c7
normalized_document_hash: 88c95dad0b9cddaf460d7c767006d05df40c48ec5f6e52fae75fb65905a97a13
content_status: success
content_sha256: 83d92371019310e0f615a47a464f9d6d59b6fdc37b516a2e1bb4ad296b575c8e
---

# break

break is an EXEC action that breaks from a loop (for, foreach, while).

Important : Because the break action alters the flow of execution, it is deferred (not executed) until execution completes for all preceding steps.

Here’s an example of an EXEC break action in a for loop:

For details, see the online help: The break action .
