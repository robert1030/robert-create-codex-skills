---
chunk_id: itest-help_26.2.0.zip-popups-break_exec_python.html-25f0aa6ca8ad-0d1644eae3f9-chunk-0001
source_id: itest-help_26.2.0.zip-popups-break_exec_python.html-25f0aa6ca8ad-0d1644eae3f9
title: break
heading_path:
- break
section_titles:
- break
source_block_ids:
- itest-help_26.2.0.zip-popups-break_exec_python.html-25f0aa6ca8ad-0d1644eae3f9-block-0001
- itest-help_26.2.0.zip-popups-break_exec_python.html-25f0aa6ca8ad-0d1644eae3f9-block-0002
- itest-help_26.2.0.zip-popups-break_exec_python.html-25f0aa6ca8ad-0d1644eae3f9-block-0003
- itest-help_26.2.0.zip-popups-break_exec_python.html-25f0aa6ca8ad-0d1644eae3f9-block-0004
- itest-help_26.2.0.zip-popups-break_exec_python.html-25f0aa6ca8ad-0d1644eae3f9-block-0005
- itest-help_26.2.0.zip-popups-break_exec_python.html-25f0aa6ca8ad-0d1644eae3f9-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 84
source_hash: 0d1644eae3f997ec5df3b3a1ac6b86e5721acc3fc36d734be2569d082a5ebb0a
normalized_document_hash: 87a0ca5521fff8869f165347dd40456be3949169204ebab1bfda760e12395bb4
content_status: success
content_sha256: 03c889b4e837fecd822f10895ecc0a7a7c5d91b394a2a8620450aba6a2c110c7
---

# break

break is an EXEC action that breaks from a loop (for, while).

Important : Because the break action alters the flow of execution, it is deferred (not executed) until execution completes for all preceding steps.

Here’s an example of an EXEC break action in a for loop:

Break out of a loop

For details, see the online help: The break action .
