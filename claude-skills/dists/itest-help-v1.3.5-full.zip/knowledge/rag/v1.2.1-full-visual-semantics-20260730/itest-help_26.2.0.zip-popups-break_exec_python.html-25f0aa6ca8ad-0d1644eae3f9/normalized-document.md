# break

break is an EXEC action that breaks from a loop (for, while).

Important : Because the break action alters the flow of execution, it is deferred (not executed) until execution completes for all preceding steps.

Here’s an example of an EXEC break action in a for loop:

Break out of a loop

For details, see the online help: The break action .
