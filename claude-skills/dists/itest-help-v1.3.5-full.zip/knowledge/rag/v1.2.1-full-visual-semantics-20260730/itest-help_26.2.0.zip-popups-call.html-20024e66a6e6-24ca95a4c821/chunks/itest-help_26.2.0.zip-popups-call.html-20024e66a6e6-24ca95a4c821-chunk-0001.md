---
chunk_id: itest-help_26.2.0.zip-popups-call.html-20024e66a6e6-24ca95a4c821-chunk-0001
source_id: itest-help_26.2.0.zip-popups-call.html-20024e66a6e6-24ca95a4c821
title: About arguments to procedure calls
heading_path:
- About arguments to procedure calls
section_titles:
- call
- About arguments to procedure calls
source_block_ids:
- itest-help_26.2.0.zip-popups-call.html-20024e66a6e6-24ca95a4c821-block-0001
- itest-help_26.2.0.zip-popups-call.html-20024e66a6e6-24ca95a4c821-block-0002
- itest-help_26.2.0.zip-popups-call.html-20024e66a6e6-24ca95a4c821-block-0003
- itest-help_26.2.0.zip-popups-call.html-20024e66a6e6-24ca95a4c821-block-0004
- itest-help_26.2.0.zip-popups-call.html-20024e66a6e6-24ca95a4c821-block-0005
- itest-help_26.2.0.zip-popups-call.html-20024e66a6e6-24ca95a4c821-block-0006
- itest-help_26.2.0.zip-popups-call.html-20024e66a6e6-24ca95a4c821-block-0007
- itest-help_26.2.0.zip-popups-call.html-20024e66a6e6-24ca95a4c821-block-0008
- itest-help_26.2.0.zip-popups-call.html-20024e66a6e6-24ca95a4c821-block-0009
- itest-help_26.2.0.zip-popups-call.html-20024e66a6e6-24ca95a4c821-block-0010
- itest-help_26.2.0.zip-popups-call.html-20024e66a6e6-24ca95a4c821-block-0011
- itest-help_26.2.0.zip-popups-call.html-20024e66a6e6-24ca95a4c821-block-0012
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 236
source_hash: 24ca95a4c82190c963920848d2a5357704b03bb2fec5881b70a1b076db8b0c45
normalized_document_hash: 651ff87f044af4bccc448305e8e8fc1f5e347125d858a56564e1e891b22fb5af
content_status: success
content_sha256: a1938c27176986ad839ebdb5c74a06a4df1d49720038c2d1c738b7b84dfcb2d6
---

# call

The call action transfers execution from the current procedure (the caller) to the first step in a different procedure (the called procedure).

- The call action can pass arguments to procedures.
- When the called procedure exits, execution returns to the caller.
- Procedures can call procedures in a nested fashion.
- call creates an executed step in test reports. The step contains any response
data, and the calling step's analysis rule applies in the normal way to the returned data.

Important : Because the call action alters the flow of execution, it is deferred (not executed) until execution completes for all preceding steps.

# About arguments to procedure calls

A call action has the following content in the Description cell (all items are separated by spaces):

- The procedure name
- Optional: Any number of named arguments in the format -namedArg_1 value
- Optional: Any number of values for un-named arguments

For example:

call procedureName slot slotNumber port porttNumber numberOfRepetitions

call ExercisePorts -slot 3 -port 4 75

For details, see the online help: The call action .

Also, see the help for the write action .
