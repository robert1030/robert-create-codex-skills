---
chunk_id: itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-chunk-0001
source_id: itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4
title: About arguments to procedure calls
heading_path:
- About arguments to procedure calls
section_titles:
- call
- About arguments to procedure calls
source_block_ids:
- itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-block-0001
- itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-block-0002
- itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-block-0003
- itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-block-0004
- itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-block-0005
- itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-block-0006
- itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-block-0007
- itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-block-0008
- itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-block-0009
- itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-block-0010
- itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-block-0011
- itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-block-0012
- itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-block-0013
- itest-help_26.2.0.zip-popups-call_python.html-f7ad77b14c5b-57f3bb044aa4-block-0014
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 267
source_hash: 57f3bb044aa4b2a40ab394e89b632964c68603bbdfdd2c420fbc5295d9478372
normalized_document_hash: 536a3df311125226c777fc41276d0f665a199d12c82082eaa4d3dc0b1a707ffc
content_status: success
content_sha256: 6fcad6e284d9a2d880a1f3e7eb6df9cc3743220e4905d65b74058a216dcbd7f7
---

# call

The call action transfers execution from the current procedure (the caller) to the first step in a different procedure (the called procedure).

- The call action can pass arguments to procedures.
- When the called procedure exits, execution returns to the caller.
- Procedures can call procedures in a nested fashion.
- call creates an executed step in test reports. The step contains any response
data, and the calling step's analysis rule applies in the normal way to the returned data.

Important : Because the call action alters the flow of execution, it is deferred (not executed) until execution completes for all preceding steps.

# About arguments to procedure calls

A call action has the following content in the Description cell (all items are separated by spaces):

- The procedure name
- Optional: Any number of named arguments in the format namedArg_1 value
- Optional: Any number of values for un-named arguments

For example:

When we call a local procedure (from the same test case) the correct command is:

call local-procedure -arg1 value1 -arg2 value2

call syntax for external procedures:

call project://other_project/procedure_library.fftc#external-procedure-name -arg1 value1 -arg2 value2

For details, see the online help: The call action .

Also, see the help for the write action .
