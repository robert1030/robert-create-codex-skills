# call

The call action transfers execution from the current procedure (the caller) to the first step in a different procedure (the called procedure).

- The call action can pass arguments to procedures.
- When the called procedure exits, execution returns to the caller.
- Procedures can call procedures in a nested fashion.
- call creates an executed step in test reports. The step contains any response
data, and the calling step's analysis rule applies in the normal way to the returned data.

Important : Because the call action alters the flow of execution, it is deferred (not executed) until execution completes for all preceding steps.

# About arguments to procedure calls

A call action has the following content in the Description cell (all items are separated by spaces):

- The procedure name
- Optional: Any number of named arguments in the format namedArg_1 value
- Optional: Any number of values for un-named arguments

For example:

When we call a local procedure (from the same test case) the correct command is:

call local-procedure -arg1 value1 -arg2 value2

call syntax for external procedures:

call project://other_project/procedure_library.fftc#external-procedure-name -arg1 value1 -arg2 value2

For details, see the online help: The call action .

Also, see the help for the write action .
