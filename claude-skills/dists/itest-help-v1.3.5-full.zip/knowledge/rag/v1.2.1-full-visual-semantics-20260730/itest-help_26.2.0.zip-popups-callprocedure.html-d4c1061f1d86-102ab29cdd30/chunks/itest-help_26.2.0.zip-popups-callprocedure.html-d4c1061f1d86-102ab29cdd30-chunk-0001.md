---
chunk_id: itest-help_26.2.0.zip-popups-callprocedure.html-d4c1061f1d86-102ab29cdd30-chunk-0001
source_id: itest-help_26.2.0.zip-popups-callprocedure.html-d4c1061f1d86-102ab29cdd30
title: callProcedure
heading_path:
- callProcedure
section_titles:
- callProcedure
source_block_ids:
- itest-help_26.2.0.zip-popups-callprocedure.html-d4c1061f1d86-102ab29cdd30-block-0001
- itest-help_26.2.0.zip-popups-callprocedure.html-d4c1061f1d86-102ab29cdd30-block-0002
- itest-help_26.2.0.zip-popups-callprocedure.html-d4c1061f1d86-102ab29cdd30-block-0003
- itest-help_26.2.0.zip-popups-callprocedure.html-d4c1061f1d86-102ab29cdd30-block-0004
- itest-help_26.2.0.zip-popups-callprocedure.html-d4c1061f1d86-102ab29cdd30-block-0005
- itest-help_26.2.0.zip-popups-callprocedure.html-d4c1061f1d86-102ab29cdd30-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 138
source_hash: 102ab29cdd3013fcf17fd71f1a8d9a68f4b0d85c6f7887875f8c24a09b741e1f
normalized_document_hash: ba76178494b76b0f53c4c06817512d588f8be62350f0e598642b5cd261033fcf
content_status: success
content_sha256: 5809b6cd6eb3991cc1de962c373e1f1db80d85a77c3199977e08e8c753558e95
---

# callProcedure

You can use a call step or CallProcedure action to execute a local or foreign procedure. You cannot use the run action to execute a procedure. See Calling a procedure in a test case step or in a property setting .

See also call action definitions in The ‘call’ action: Calling a procedure .

For call steps or CallProcedure actions, the Command cell contains the target procedure name and any arguments and argument values. Procedures can call procedures in a nested fashion.

Procedure call syntax procedureName [-namedArg1 arg1Value -namedArg2 arg2Value ...] [numberedArg1 numberedArg2 ...]

- Arguments are optional
- Any named arguments must appear before any numbered arguments
