---
chunk_id: itest-help_26.2.0.zip-popups-canceldrag.html-8f0d676646f9-86388e0dfe79-chunk-0001
source_id: itest-help_26.2.0.zip-popups-canceldrag.html-8f0d676646f9-86388e0dfe79
title: cancelDrag
heading_path:
- cancelDrag
section_titles:
- cancelDrag
source_block_ids:
- itest-help_26.2.0.zip-popups-canceldrag.html-8f0d676646f9-86388e0dfe79-block-0001
- itest-help_26.2.0.zip-popups-canceldrag.html-8f0d676646f9-86388e0dfe79-block-0002
- itest-help_26.2.0.zip-popups-canceldrag.html-8f0d676646f9-86388e0dfe79-block-0003
- itest-help_26.2.0.zip-popups-canceldrag.html-8f0d676646f9-86388e0dfe79-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 179
source_hash: 86388e0dfe7917983f50fe60d649a4f47de5a453a202d31297ec1786f1d7451b
normalized_document_hash: 3339a599dcd0ec4eb05739f1ced1ef40f9c8070a36b609e26d4c57ac85d7ccc3
content_status: success
content_sha256: b3a0dcd6974f4c1223b8f0e7951d4f210b67c58dec535848231a0e35e7668e49
---

# cancelDrag

Simulates canceling a drag-and-drop action. You must execute a drag action before executing a cancelDrag action

| Target | Required |
| --- | --- |
| Controls | All containers, trees, lists, grids |
| Command | None |
| Step Properties | Step Properties Ctrl : Indicates that the Control key is pressed when executing the action Shift : Indicates that the Shift key is pressed when executing the action Alt : Indicates that the Alt key is pressed when executing the action<br>            Default: [No key selected]r Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>            Default: 15 |

For details, see the online help: Flex action reference .
