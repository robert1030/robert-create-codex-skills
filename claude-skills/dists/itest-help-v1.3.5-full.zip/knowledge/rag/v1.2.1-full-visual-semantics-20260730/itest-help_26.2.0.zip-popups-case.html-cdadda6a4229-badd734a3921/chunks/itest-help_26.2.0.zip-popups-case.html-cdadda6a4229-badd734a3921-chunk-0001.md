---
chunk_id: itest-help_26.2.0.zip-popups-case.html-cdadda6a4229-badd734a3921-chunk-0001
source_id: itest-help_26.2.0.zip-popups-case.html-cdadda6a4229-badd734a3921
title: case
heading_path:
- case
section_titles:
- case
source_block_ids:
- itest-help_26.2.0.zip-popups-case.html-cdadda6a4229-badd734a3921-block-0001
- itest-help_26.2.0.zip-popups-case.html-cdadda6a4229-badd734a3921-block-0002
- itest-help_26.2.0.zip-popups-case.html-cdadda6a4229-badd734a3921-block-0003
- itest-help_26.2.0.zip-popups-case.html-cdadda6a4229-badd734a3921-block-0004
- itest-help_26.2.0.zip-popups-case.html-cdadda6a4229-badd734a3921-block-0005
- itest-help_26.2.0.zip-popups-case.html-cdadda6a4229-badd734a3921-block-0006
- itest-help_26.2.0.zip-popups-case.html-cdadda6a4229-badd734a3921-block-0007
- itest-help_26.2.0.zip-popups-case.html-cdadda6a4229-badd734a3921-block-0008
- itest-help_26.2.0.zip-popups-case.html-cdadda6a4229-badd734a3921-block-0009
- itest-help_26.2.0.zip-popups-case.html-cdadda6a4229-badd734a3921-block-0010
- itest-help_26.2.0.zip-popups-case.html-cdadda6a4229-badd734a3921-block-0011
- itest-help_26.2.0.zip-popups-case.html-cdadda6a4229-badd734a3921-block-0012
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 113
source_hash: badd734a39215cdd153ebc5c6013ea219877ed41bcba7d734d12a5c1bfad7501
normalized_document_hash: 75d702ce8127ea95f4ab001de9ccf3642ec555f831bfcd23b82aafedff07d315
content_status: success
content_sha256: e6f94fe77af139aeabd0055b7461739ce40b42f822501400b2208e8e682be28e
---

# case

A case step is a part of a switch construct. A switch construct allows the value of an expression to determine the flow of execution.

The

Description

for each

case

step is the value of the variable or expression to compare to the control value.
When a match occurs, then execution continues with the steps that are nested under the

case

step.
When the last nested step finishes, then execution proceeds at the step after the

switch

construct.

See the online help for examples and details.
