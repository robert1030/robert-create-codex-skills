# case

A case step is a part of a switch construct. A switch construct allows the value of an expression to determine the flow of execution.

The

Description

for each

case

step is the value of the variable or expression to compare to the control value.
When a match occurs, then execution continues with the steps that are nested under the

case

step.
When the last nested step finishes, then execution proceeds at the step after the

switch

construct.

See the online help for examples and details.
