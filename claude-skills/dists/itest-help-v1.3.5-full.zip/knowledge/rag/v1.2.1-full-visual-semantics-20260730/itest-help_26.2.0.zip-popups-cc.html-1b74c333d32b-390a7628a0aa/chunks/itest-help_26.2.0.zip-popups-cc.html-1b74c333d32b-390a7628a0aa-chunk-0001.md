---
chunk_id: itest-help_26.2.0.zip-popups-cc.html-1b74c333d32b-390a7628a0aa-chunk-0001
source_id: itest-help_26.2.0.zip-popups-cc.html-1b74c333d32b-390a7628a0aa
title: cc
heading_path:
- cc
section_titles:
- cc
source_block_ids:
- itest-help_26.2.0.zip-popups-cc.html-1b74c333d32b-390a7628a0aa-block-0001
- itest-help_26.2.0.zip-popups-cc.html-1b74c333d32b-390a7628a0aa-block-0002
- itest-help_26.2.0.zip-popups-cc.html-1b74c333d32b-390a7628a0aa-block-0003
- itest-help_26.2.0.zip-popups-cc.html-1b74c333d32b-390a7628a0aa-block-0004
- itest-help_26.2.0.zip-popups-cc.html-1b74c333d32b-390a7628a0aa-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 57
source_hash: 390a7628a0aa7314f487876aaf3d4f177641f23548544a6b554d1c0f4f5b04b5
normalized_document_hash: 834856ff5aab922fe48151dff98c610e929c360b50f39766b70cfc0ef1afc064
content_status: success
content_sha256: ba9f0bb5a61c6ee303b4990856061a0b9192f8e610e375344b32f28ec97fd914
---

# cc

Copy the message to the address specified in the Description cell.

In the Description cell, specify an email alias or a semicolon-separated list of email addresses.

Field replacements are supported.

For details, see the online help: Sending email messages during test execution .
