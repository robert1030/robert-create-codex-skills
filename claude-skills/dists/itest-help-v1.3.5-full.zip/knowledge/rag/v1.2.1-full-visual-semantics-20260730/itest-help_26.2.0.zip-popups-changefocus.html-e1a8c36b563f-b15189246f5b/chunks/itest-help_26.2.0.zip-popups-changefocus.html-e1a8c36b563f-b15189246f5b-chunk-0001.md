---
chunk_id: itest-help_26.2.0.zip-popups-changefocus.html-e1a8c36b563f-b15189246f5b-chunk-0001
source_id: itest-help_26.2.0.zip-popups-changefocus.html-e1a8c36b563f-b15189246f5b
title: changeFocus
heading_path:
- changeFocus
section_titles:
- changeFocus
source_block_ids:
- itest-help_26.2.0.zip-popups-changefocus.html-e1a8c36b563f-b15189246f5b-block-0001
- itest-help_26.2.0.zip-popups-changefocus.html-e1a8c36b563f-b15189246f5b-block-0002
- itest-help_26.2.0.zip-popups-changefocus.html-e1a8c36b563f-b15189246f5b-block-0003
- itest-help_26.2.0.zip-popups-changefocus.html-e1a8c36b563f-b15189246f5b-block-0004
- itest-help_26.2.0.zip-popups-changefocus.html-e1a8c36b563f-b15189246f5b-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 176
source_hash: b15189246f5b58a075b9f3b3e5efe97c0285bfe704ee9a79b5623d7d826a6a53
normalized_document_hash: 53cf5588656357bf63eef42c287d9c1da11991f34f7a757bbb1bb22cde7212c7
content_status: success
content_sha256: 87065caa3ee0d9dd97a5c313081170374b8404da4f231f7d5c9c02f05a82fa7c
---

# changeFocus

Changes the focus out of the specified control. For example, when the cursor is in a text box, you can change the focus by pressing the TAB key.

Note: This action is not captured by iTest. You must specifically add this action in the test case if needed.

| Target | Required |
| --- | --- |
| Controls | All controls |
| Command | None |
| Step Properties | Step Properties Key that changes focus: The key that changes focus. Default: TAB Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>            Default: 15 |

For details, see the online help: Flex action reference .
