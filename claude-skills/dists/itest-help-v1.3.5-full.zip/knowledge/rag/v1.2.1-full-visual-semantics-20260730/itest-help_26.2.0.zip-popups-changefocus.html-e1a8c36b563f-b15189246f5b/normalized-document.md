# changeFocus

Changes the focus out of the specified control. For example, when the cursor is in a text box, you can change the focus by pressing the TAB key.

Note: This action is not captured by iTest. You must specifically add this action in the test case if needed.

| Target | Required |
| --- | --- |
| Controls | All controls |
| Command | None |
| Step Properties | Step Properties Key that changes focus: The key that changes focus. Default: TAB Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>            Default: 15 |

For details, see the online help: Flex action reference .
