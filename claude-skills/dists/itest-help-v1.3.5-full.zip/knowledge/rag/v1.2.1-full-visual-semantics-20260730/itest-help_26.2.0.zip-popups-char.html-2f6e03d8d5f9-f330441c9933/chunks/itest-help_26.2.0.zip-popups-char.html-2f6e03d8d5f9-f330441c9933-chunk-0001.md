---
chunk_id: itest-help_26.2.0.zip-popups-char.html-2f6e03d8d5f9-f330441c9933-chunk-0001
source_id: itest-help_26.2.0.zip-popups-char.html-2f6e03d8d5f9-f330441c9933
title: char
heading_path:
- char
section_titles:
- char
source_block_ids:
- itest-help_26.2.0.zip-popups-char.html-2f6e03d8d5f9-f330441c9933-block-0001
- itest-help_26.2.0.zip-popups-char.html-2f6e03d8d5f9-f330441c9933-block-0002
- itest-help_26.2.0.zip-popups-char.html-2f6e03d8d5f9-f330441c9933-block-0003
- itest-help_26.2.0.zip-popups-char.html-2f6e03d8d5f9-f330441c9933-block-0004
- itest-help_26.2.0.zip-popups-char.html-2f6e03d8d5f9-f330441c9933-block-0005
- itest-help_26.2.0.zip-popups-char.html-2f6e03d8d5f9-f330441c9933-block-0006
- itest-help_26.2.0.zip-popups-char.html-2f6e03d8d5f9-f330441c9933-block-0007
- itest-help_26.2.0.zip-popups-char.html-2f6e03d8d5f9-f330441c9933-block-0008
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 115
source_hash: f330441c9933f0515323d8aac91aabf492128c4e9ecfd95591387cb1eac88451
normalized_document_hash: 8d67390ceca07d28ef8b238e1fd11eba524943fb73ea9f0be22da06801e91b5c
content_status: success
content_sha256: f53e66cd9c50b30608859475a3fdae613b980a0512e4a5ffee4b5a8cd816bc0f
---

# char

char

characterCode

Inserts a character (for example, tab, Ctrl-C, Esc, or Delete) into a command or property. You can find documentation on the ASCII character set on the Internet.

To insert a char command, right-click in the field and then select Insert > Non-Printing Character .

For details, see the online help: Placing non-printing characters into commands and properties .

Also, see: Field replacements: Substituting values into properties and commands .

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .
