# char

char

characterCode

Inserts a character (for example, tab, Ctrl-C, Esc, or Delete) into a command or property. You can find documentation on the ASCII character set on the Internet.

To insert a char command, right-click in the field and then select Insert > Non-Printing Character .

For details, see the online help: Placing non-printing characters into commands and properties .

Also, see: Field replacements: Substituting values into properties and commands .

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .
