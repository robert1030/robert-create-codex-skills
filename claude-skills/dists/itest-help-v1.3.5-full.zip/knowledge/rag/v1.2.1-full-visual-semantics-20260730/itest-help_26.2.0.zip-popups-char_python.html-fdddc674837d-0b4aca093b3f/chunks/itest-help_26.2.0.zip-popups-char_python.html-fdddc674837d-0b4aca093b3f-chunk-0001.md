---
chunk_id: itest-help_26.2.0.zip-popups-char_python.html-fdddc674837d-0b4aca093b3f-chunk-0001
source_id: itest-help_26.2.0.zip-popups-char_python.html-fdddc674837d-0b4aca093b3f
title: char
heading_path:
- char
section_titles:
- char
source_block_ids:
- itest-help_26.2.0.zip-popups-char_python.html-fdddc674837d-0b4aca093b3f-block-0001
- itest-help_26.2.0.zip-popups-char_python.html-fdddc674837d-0b4aca093b3f-block-0002
- itest-help_26.2.0.zip-popups-char_python.html-fdddc674837d-0b4aca093b3f-block-0003
- itest-help_26.2.0.zip-popups-char_python.html-fdddc674837d-0b4aca093b3f-block-0004
- itest-help_26.2.0.zip-popups-char_python.html-fdddc674837d-0b4aca093b3f-block-0005
- itest-help_26.2.0.zip-popups-char_python.html-fdddc674837d-0b4aca093b3f-block-0006
- itest-help_26.2.0.zip-popups-char_python.html-fdddc674837d-0b4aca093b3f-block-0007
- itest-help_26.2.0.zip-popups-char_python.html-fdddc674837d-0b4aca093b3f-block-0008
- itest-help_26.2.0.zip-popups-char_python.html-fdddc674837d-0b4aca093b3f-block-0009
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 171
source_hash: 0b4aca093b3fcc385e473de5cb130aa6bd764af9fba54f2268b4f4706b94afac
normalized_document_hash: 560141814944a3bc53f41deef47dbc91f424c0b5e5d4f4032e8cd3487606ebd5
content_status: success
content_sha256: eed2e4bb8d99407c02c835d09489342b6fb98ef417b6823158d1e5f06ab39f53
---

# char

char

('CharacterCode')

Inserts a character (for example, tab, Ctrl-C, Esc, or Delete) into a command or property. This command can also insert standard ASCII character codes. Example:

| Character code | Python Syntax |
| --- | --- |
| backspace: Ctrl -C (and all other Control characters): Escape: Delete: Tab: | char(‘bs’) char(‘ctrl-c’)Use ctrl-a through ctrl-z and ctrl-@ through ctrl-] char(‘ESC’) char(‘del’) char(‘tab’) |

To insert a char command, right-click in the field and then select Insert > Non-Printing Character .

For details, see the online help: Placing non-printing characters into commands and properties .

Also, see: Field replacements: Substituting values into properties and commands .

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .
