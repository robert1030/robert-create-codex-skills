# char

char

('CharacterCode')

Inserts a character (for example, tab, Ctrl-C, Esc, or Delete) into a command or property. This command can also insert standard ASCII character codes. Example:

| Character code | Python Syntax |
| --- | --- |
| backspace: Ctrl -C (and all other Control characters): Escape: Delete: Tab: | char(‘bs’) char(‘ctrl-c’)Use ctrl-a through ctrl-z and ctrl-@ through ctrl-] char(‘ESC’) char(‘del’) char(‘tab’) |

To insert a char command, right-click in the field and then select Insert > Non-Printing Character .

For details, see the online help: Placing non-printing characters into commands and properties .

Also, see: Field replacements: Substituting values into properties and commands .

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .
