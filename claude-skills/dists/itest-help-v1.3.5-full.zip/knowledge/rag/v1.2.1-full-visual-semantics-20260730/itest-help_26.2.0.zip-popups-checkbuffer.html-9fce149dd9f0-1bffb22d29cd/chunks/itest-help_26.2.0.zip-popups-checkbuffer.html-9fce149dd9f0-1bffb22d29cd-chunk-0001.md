---
chunk_id: itest-help_26.2.0.zip-popups-checkbuffer.html-9fce149dd9f0-1bffb22d29cd-chunk-0001
source_id: itest-help_26.2.0.zip-popups-checkbuffer.html-9fce149dd9f0-1bffb22d29cd
title: checkbuffer
heading_path:
- checkbuffer
section_titles:
- checkbuffer
source_block_ids:
- itest-help_26.2.0.zip-popups-checkbuffer.html-9fce149dd9f0-1bffb22d29cd-block-0001
- itest-help_26.2.0.zip-popups-checkbuffer.html-9fce149dd9f0-1bffb22d29cd-block-0002
- itest-help_26.2.0.zip-popups-checkbuffer.html-9fce149dd9f0-1bffb22d29cd-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 44
source_hash: 1bffb22d29cd888083c7f64fb3744304a9dbeb9f51948645f99baea8fae49769
normalized_document_hash: fee64f00854f2e625e5ecbce1738230896422c020d365632c2523d15dca9ea48
content_status: success
content_sha256: 3a351ce77093bc4d92633c72a2d095dfbfe19b984d21d6ebddeec372631342bf
---

# checkbuffer

Checks whether there is data in the read (receive) buffer.
Returns true or false.

For details, see the online help: UDP command reference section under the topic "UDP Session Editor Concept" .
