---
chunk_id: itest-help_26.2.0.zip-popups-clear.html-e7aa4836b52d-1b8f84072e14-chunk-0001
source_id: itest-help_26.2.0.zip-popups-clear.html-e7aa4836b52d-1b8f84072e14
title: clear
heading_path:
- clear
section_titles:
- clear
source_block_ids:
- itest-help_26.2.0.zip-popups-clear.html-e7aa4836b52d-1b8f84072e14-block-0001
- itest-help_26.2.0.zip-popups-clear.html-e7aa4836b52d-1b8f84072e14-block-0002
- itest-help_26.2.0.zip-popups-clear.html-e7aa4836b52d-1b8f84072e14-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 42
source_hash: 1b8f84072e1479e39bca3d16fe75a0e0c36080d9b37428673db17cde2796e1a4
normalized_document_hash: 9d8fe9baa6521e9df3c73dab4599eeadd55cd97cbfe55755f014fd2449888543
content_status: success
content_sha256: a05b205d65c73cfb1679c5f91cf7819ea0a584c13553b41f86be3e7eefe82a0c
---

# clear

Clears the contents of the read (receive) buffer.
Returns true or false.

For details, see the online help: UDP command reference section under the topic "UDP Session Editor Concept" .
