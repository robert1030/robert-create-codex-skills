# clear

Clears the contents of the read (receive) buffer.
Returns true or false.

For details, see the online help: UDP command reference section under the topic "UDP Session Editor Concept" .
