---
chunk_id: itest-help_26.2.0.zip-popups-clearcache_web.html-0c4a108b9e39-a3e41c237437-chunk-0001
source_id: itest-help_26.2.0.zip-popups-clearcache_web.html-0c4a108b9e39-a3e41c237437
title: clearCache
heading_path:
- clearCache
section_titles:
- clearCache
source_block_ids:
- itest-help_26.2.0.zip-popups-clearcache_web.html-0c4a108b9e39-a3e41c237437-block-0001
- itest-help_26.2.0.zip-popups-clearcache_web.html-0c4a108b9e39-a3e41c237437-block-0002
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 50
source_hash: a3e41c237437849770fa55ad2ee33ce8d18512e2760736b7d52b6660792b5cd9
normalized_document_hash: 06eec7f9e3c90ea754881ba5365844098ab2ea005eca149d938fe7933766ab63
content_status: success
content_sha256: 1e619c3bbf14d97c93bc8c11ba21abcebbf1a19a38fb78213e17245676b2c79e
---

# clearCache

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| clearCache | Not Required | Not Required | Clears the browser’s cache<br>			iTest cannot capture a clearCache action during an interactive Web session. |
