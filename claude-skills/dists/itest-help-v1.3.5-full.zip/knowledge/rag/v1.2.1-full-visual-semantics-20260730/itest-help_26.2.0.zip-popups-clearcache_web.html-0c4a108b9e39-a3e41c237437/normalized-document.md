# clearCache

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| clearCache | Not Required | Not Required | Clears the browser’s cache<br>			iTest cannot capture a clearCache action during an interactive Web session. |
