---
chunk_id: itest-help_26.2.0.zip-popups-clearcookies_web.html-0d2b5dc5abc2-e452b6cd5f85-chunk-0001
source_id: itest-help_26.2.0.zip-popups-clearcookies_web.html-0d2b5dc5abc2-e452b6cd5f85
title: clearCookies
heading_path:
- clearCookies
section_titles:
- clearCookies
source_block_ids:
- itest-help_26.2.0.zip-popups-clearcookies_web.html-0d2b5dc5abc2-e452b6cd5f85-block-0001
- itest-help_26.2.0.zip-popups-clearcookies_web.html-0d2b5dc5abc2-e452b6cd5f85-block-0002
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 62
source_hash: e452b6cd5f859450f3a9080cb655ee5379a1616196c1edce361bd378d1ce8e88
normalized_document_hash: bc21876a63fa7ead02f62f04343250228a505e84a8c6ed9cfbcc070b95b3b524
content_status: success
content_sha256: 95bf44b13f03b19cc629776bfbd06be10737de39dddbcdf5e82a811ca3ca6a4f
---

# clearCookies

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| clearCookies | Not Required | Not Required | Clears the cookies associated with the web site that is identified in the open step.<br>			iTest cannot capture a clearCookies action during an interactive Web session. |
