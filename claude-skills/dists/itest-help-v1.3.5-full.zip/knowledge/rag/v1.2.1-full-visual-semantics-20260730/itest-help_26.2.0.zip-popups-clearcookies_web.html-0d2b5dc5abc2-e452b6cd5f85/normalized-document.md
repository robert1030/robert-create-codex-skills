# clearCookies

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| clearCookies | Not Required | Not Required | Clears the cookies associated with the web site that is identified in the open step.<br>			iTest cannot capture a clearCookies action during an interactive Web session. |
