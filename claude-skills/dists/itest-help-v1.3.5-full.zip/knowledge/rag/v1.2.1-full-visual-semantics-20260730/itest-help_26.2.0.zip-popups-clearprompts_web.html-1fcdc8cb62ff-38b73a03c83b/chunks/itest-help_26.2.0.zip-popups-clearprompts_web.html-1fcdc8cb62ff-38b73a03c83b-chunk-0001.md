---
chunk_id: itest-help_26.2.0.zip-popups-clearprompts_web.html-1fcdc8cb62ff-38b73a03c83b-chunk-0001
source_id: itest-help_26.2.0.zip-popups-clearprompts_web.html-1fcdc8cb62ff-38b73a03c83b
title: clearPrompts
heading_path:
- clearPrompts
section_titles:
- clearPrompts
source_block_ids:
- itest-help_26.2.0.zip-popups-clearprompts_web.html-1fcdc8cb62ff-38b73a03c83b-block-0001
- itest-help_26.2.0.zip-popups-clearprompts_web.html-1fcdc8cb62ff-38b73a03c83b-block-0002
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 88
source_hash: 38b73a03c83bab862828dfc3e732278bdd4e8f8fdce09d9c744442aa02aff3bb
normalized_document_hash: 8a0c1e3c69c872fcca9026a5a8db56c99418a0443e07bb3af8cd0d73b6062d83
content_status: success
content_sha256: aef8cd47e6d781b78843caa3fd5d739cd1c39cd85c543b5e909b33a127429454
---

# clearPrompts

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| clearPrompts | Not Required | Not Required | A prompt is the text that appears in the body of a prompt dialog box (typically an alert or confirmation dialog). For Web sessions, iTest caches (saves) the text of each prompt that appears during test case execution. The clearPrompts command removes all prompts from the cache. |
