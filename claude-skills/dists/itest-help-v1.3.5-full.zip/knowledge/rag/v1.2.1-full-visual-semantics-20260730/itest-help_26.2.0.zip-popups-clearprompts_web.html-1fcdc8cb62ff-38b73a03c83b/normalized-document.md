# clearPrompts

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| clearPrompts | Not Required | Not Required | A prompt is the text that appears in the body of a prompt dialog box (typically an alert or confirmation dialog). For Web sessions, iTest caches (saves) the text of each prompt that appears during test case execution. The clearPrompts command removes all prompts from the cache. |
