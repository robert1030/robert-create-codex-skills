---
chunk_id: itest-help_26.2.0.zip-popups-cleartext.html-9b67b751c789-9510d7ed37d2-chunk-0001
source_id: itest-help_26.2.0.zip-popups-cleartext.html-9b67b751c789-9510d7ed37d2
title: clearText
heading_path:
- clearText
section_titles:
- clearText
source_block_ids:
- itest-help_26.2.0.zip-popups-cleartext.html-9b67b751c789-9510d7ed37d2-block-0001
- itest-help_26.2.0.zip-popups-cleartext.html-9b67b751c789-9510d7ed37d2-block-0002
- itest-help_26.2.0.zip-popups-cleartext.html-9b67b751c789-9510d7ed37d2-block-0003
- itest-help_26.2.0.zip-popups-cleartext.html-9b67b751c789-9510d7ed37d2-block-0004
- itest-help_26.2.0.zip-popups-cleartext.html-9b67b751c789-9510d7ed37d2-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 62
source_hash: 9510d7ed37d2889c8661fac112c869982874535e5e20983f0a7211617dfe1c40
normalized_document_hash: a6662eeb841d3c2c0c0ebc7db6e8adb1d30950758972fee9be755e837b922647
content_status: success
content_sha256: 5d5ace8fd18f72c2fcb2d275d472145ff0b18eb25a88262921c0f19e60852efb
---

# clearText

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| clearText | Required | Not Required | Sets the value of an input field to <empty>. See setText . |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
