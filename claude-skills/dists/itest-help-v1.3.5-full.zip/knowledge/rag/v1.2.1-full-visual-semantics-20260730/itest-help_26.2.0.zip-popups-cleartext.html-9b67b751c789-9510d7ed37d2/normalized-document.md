# clearText

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| clearText | Required | Not Required | Sets the value of an input field to <empty>. See setText . |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
