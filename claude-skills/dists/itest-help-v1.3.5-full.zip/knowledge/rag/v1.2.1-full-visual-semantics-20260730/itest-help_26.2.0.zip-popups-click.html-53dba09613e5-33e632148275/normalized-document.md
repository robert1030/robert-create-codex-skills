# click

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| click | Required | Not Required | Clicks an element (HTML object) like a button, link, radio button, or check box on the current page. Note: Do not use click for combo boxes, instead, use selectAdditional . |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
