---
chunk_id: itest-help_26.2.0.zip-popups-click_web.html-a0bc01d5ab68-33e632148275-chunk-0001
source_id: itest-help_26.2.0.zip-popups-click_web.html-a0bc01d5ab68-33e632148275
title: click
heading_path:
- click
section_titles:
- click
source_block_ids:
- itest-help_26.2.0.zip-popups-click_web.html-a0bc01d5ab68-33e632148275-block-0001
- itest-help_26.2.0.zip-popups-click_web.html-a0bc01d5ab68-33e632148275-block-0002
- itest-help_26.2.0.zip-popups-click_web.html-a0bc01d5ab68-33e632148275-block-0003
- itest-help_26.2.0.zip-popups-click_web.html-a0bc01d5ab68-33e632148275-block-0004
- itest-help_26.2.0.zip-popups-click_web.html-a0bc01d5ab68-33e632148275-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 87
source_hash: 33e632148275857bf3e06ad183d8ab9485b3ed9261015f56740a5b5ab02d05cd
normalized_document_hash: a5bd9c1c79df639eae4650f62503be415783302635f2adaccbe01602c66b5f11
content_status: success
content_sha256: bc3c3638b3912bceca489d962c53a292ffabe7335f44ce1ecef617cbf9d2f059
---

# click

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| click | Required | Not Required | Clicks an element (HTML object) like a button, link, radio button, or check box on the current page. Note: Do not use click for combo boxes, instead, use selectAdditional . |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
