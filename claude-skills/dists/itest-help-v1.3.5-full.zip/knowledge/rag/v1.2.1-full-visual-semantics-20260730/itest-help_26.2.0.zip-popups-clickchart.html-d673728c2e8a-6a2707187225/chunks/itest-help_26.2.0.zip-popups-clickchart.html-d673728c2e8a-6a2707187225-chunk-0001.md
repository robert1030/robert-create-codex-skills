---
chunk_id: itest-help_26.2.0.zip-popups-clickchart.html-d673728c2e8a-6a2707187225-chunk-0001
source_id: itest-help_26.2.0.zip-popups-clickchart.html-d673728c2e8a-6a2707187225
title: clickChart
heading_path:
- clickChart
section_titles:
- clickChart
source_block_ids:
- itest-help_26.2.0.zip-popups-clickchart.html-d673728c2e8a-6a2707187225-block-0001
- itest-help_26.2.0.zip-popups-clickchart.html-d673728c2e8a-6a2707187225-block-0002
- itest-help_26.2.0.zip-popups-clickchart.html-d673728c2e8a-6a2707187225-block-0003
- itest-help_26.2.0.zip-popups-clickchart.html-d673728c2e8a-6a2707187225-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 116
source_hash: 6a2707187225cb0a9e1ee5d7cd84b92d93eabf0b33d8423f5b0aa4a0dad96aab
normalized_document_hash: f029f1a9c6a6166f7e1c0895c9099c5404cf77c727252514ccbf5945dadfad5c
content_status: success
content_sha256: f12400ee664f3a36bf8aeb3bdcd978b163abc888eadf8a6589f3ccb192964b3f
---

# clickChart

Clicks a particular data item in a chart series.

| Target | Required |
| --- | --- |
| Controls | Charts and chart series |
| Command | The index of the item in the chart series |
| Step Properties | Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>            Default: 15 |

For details, see the online help: Flex action reference .
