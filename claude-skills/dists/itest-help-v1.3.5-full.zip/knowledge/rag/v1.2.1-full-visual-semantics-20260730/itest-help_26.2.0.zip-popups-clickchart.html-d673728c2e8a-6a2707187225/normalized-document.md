# clickChart

Clicks a particular data item in a chart series.

| Target | Required |
| --- | --- |
| Controls | Charts and chart series |
| Command | The index of the item in the chart series |
| Step Properties | Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>            Default: 15 |

For details, see the online help: Flex action reference .
