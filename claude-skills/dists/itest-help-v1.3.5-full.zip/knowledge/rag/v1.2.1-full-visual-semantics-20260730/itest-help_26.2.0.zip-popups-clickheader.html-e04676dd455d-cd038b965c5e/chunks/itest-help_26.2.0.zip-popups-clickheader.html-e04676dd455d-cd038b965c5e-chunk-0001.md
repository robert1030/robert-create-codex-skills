---
chunk_id: itest-help_26.2.0.zip-popups-clickheader.html-e04676dd455d-cd038b965c5e-chunk-0001
source_id: itest-help_26.2.0.zip-popups-clickheader.html-e04676dd455d-cd038b965c5e
title: clickHeader
heading_path:
- clickHeader
section_titles:
- clickHeader
source_block_ids:
- itest-help_26.2.0.zip-popups-clickheader.html-e04676dd455d-cd038b965c5e-block-0001
- itest-help_26.2.0.zip-popups-clickheader.html-e04676dd455d-cd038b965c5e-block-0002
- itest-help_26.2.0.zip-popups-clickheader.html-e04676dd455d-cd038b965c5e-block-0003
- itest-help_26.2.0.zip-popups-clickheader.html-e04676dd455d-cd038b965c5e-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 112
source_hash: cd038b965c5e942e62cefb0143f44c063eff935db6426394984b45e7d1df57b9
normalized_document_hash: 657f691fe86d3a8d2bb77338de7978416b957d10a165c87735265ae255e4793b
content_status: success
content_sha256: 061638dfeadadbf4435822def6965f897bbaa114facb09c7c57a8f936c4b82af
---

# clickHeader

Clicks the specified column header in a grid.

| Target | Required |
| --- | --- |
| Controls | Grids (tables) |
| Command | The index of the column header to click |
| Step Properties | Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>            Default: 15 |

For details, see the online help: Flex action reference .
