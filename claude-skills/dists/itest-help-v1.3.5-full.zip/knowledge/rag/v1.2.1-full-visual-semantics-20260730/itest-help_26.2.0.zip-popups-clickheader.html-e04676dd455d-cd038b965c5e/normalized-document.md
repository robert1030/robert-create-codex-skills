# clickHeader

Clicks the specified column header in a grid.

| Target | Required |
| --- | --- |
| Controls | Grids (tables) |
| Command | The index of the column header to click |
| Step Properties | Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>            Default: 15 |

For details, see the online help: Flex action reference .
