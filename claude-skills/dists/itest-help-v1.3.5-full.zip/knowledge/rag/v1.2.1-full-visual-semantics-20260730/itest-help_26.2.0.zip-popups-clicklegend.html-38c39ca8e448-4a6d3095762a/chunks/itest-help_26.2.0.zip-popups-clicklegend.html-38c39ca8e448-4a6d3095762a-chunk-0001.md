---
chunk_id: itest-help_26.2.0.zip-popups-clicklegend.html-38c39ca8e448-4a6d3095762a-chunk-0001
source_id: itest-help_26.2.0.zip-popups-clicklegend.html-38c39ca8e448-4a6d3095762a
title: clickLegend
heading_path:
- clickLegend
section_titles:
- clickLegend
source_block_ids:
- itest-help_26.2.0.zip-popups-clicklegend.html-38c39ca8e448-4a6d3095762a-block-0001
- itest-help_26.2.0.zip-popups-clicklegend.html-38c39ca8e448-4a6d3095762a-block-0002
- itest-help_26.2.0.zip-popups-clicklegend.html-38c39ca8e448-4a6d3095762a-block-0003
- itest-help_26.2.0.zip-popups-clicklegend.html-38c39ca8e448-4a6d3095762a-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 115
source_hash: 4a6d3095762ae1ebb6c8bc1a150e40ddf54f10acae829840be088b81cb1dad9d
normalized_document_hash: 9d4e0bfbae22d753d50770f0c12e9124386ddd033a104d56ff8ccc9898ee912d
content_status: success
content_sha256: d3d23d00713b12aa7932cdd3a9d7047b734c83a5a00ee5415e92ffb281b3ba7a
---

# clickLegend

Clicks a particular legend item in the list of legends of a chart.

| Target | Required |
| --- | --- |
| Controls | Chart Legends data |
| Command | The legend item to click |
| Step Properties | Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>            Default: 15 |

For details, see the online help: Flex action reference .
