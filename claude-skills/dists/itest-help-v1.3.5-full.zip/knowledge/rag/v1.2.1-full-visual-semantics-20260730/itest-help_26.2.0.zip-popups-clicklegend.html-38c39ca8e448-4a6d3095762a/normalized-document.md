# clickLegend

Clicks a particular legend item in the list of legends of a chart.

| Target | Required |
| --- | --- |
| Controls | Chart Legends data |
| Command | The legend item to click |
| Step Properties | Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>            Default: 15 |

For details, see the online help: Flex action reference .
