---
chunk_id: itest-help_26.2.0.zip-popups-clock.html-78af5c110920-7430f60acbb1-chunk-0001
source_id: itest-help_26.2.0.zip-popups-clock.html-78af5c110920-7430f60acbb1
title: clock
heading_path:
- clock
section_titles:
- clock
source_block_ids:
- itest-help_26.2.0.zip-popups-clock.html-78af5c110920-7430f60acbb1-block-0001
- itest-help_26.2.0.zip-popups-clock.html-78af5c110920-7430f60acbb1-block-0002
- itest-help_26.2.0.zip-popups-clock.html-78af5c110920-7430f60acbb1-block-0003
- itest-help_26.2.0.zip-popups-clock.html-78af5c110920-7430f60acbb1-block-0004
- itest-help_26.2.0.zip-popups-clock.html-78af5c110920-7430f60acbb1-block-0005
- itest-help_26.2.0.zip-popups-clock.html-78af5c110920-7430f60acbb1-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 88
source_hash: 7430f60acbb1795c00288d338710f2d6220f640694593392bb845a7b3ea10640
normalized_document_hash: 4e76cf217735a4dda1d4136c0bf20a7eb72279181dae02419b65472c2b6d61c2
content_status: success
content_sha256: a5c7bb5ea4dd63afdf8e632b4d7302d19f1a023f50ea299c200d3b802c4ee589
---

# clock

clock scan dateString ? -base clockVal ? ? -gmt boolean ?

Scans dateString and converts it to the number of seconds since the epoch.

-base : The beginning date to start the clock (Default is the epoch date)

-gmt :An optional boolean variable that specifies whether or not the time is GMT

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .
