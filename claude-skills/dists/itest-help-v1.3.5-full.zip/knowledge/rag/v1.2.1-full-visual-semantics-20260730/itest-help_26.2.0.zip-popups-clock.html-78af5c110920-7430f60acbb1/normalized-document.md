# clock

clock scan dateString ? -base clockVal ? ? -gmt boolean ?

Scans dateString and converts it to the number of seconds since the epoch.

-base : The beginning date to start the clock (Default is the epoch date)

-gmt :An optional boolean variable that specifies whether or not the time is GMT

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .
