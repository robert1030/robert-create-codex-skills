---
chunk_id: itest-help_26.2.0.zip-popups-close.html-b5d13d66c2b7-f1fe2af4bfed-chunk-0001
source_id: itest-help_26.2.0.zip-popups-close.html-b5d13d66c2b7-f1fe2af4bfed
title: close
heading_path:
- close
section_titles:
- close
source_block_ids:
- itest-help_26.2.0.zip-popups-close.html-b5d13d66c2b7-f1fe2af4bfed-block-0001
- itest-help_26.2.0.zip-popups-close.html-b5d13d66c2b7-f1fe2af4bfed-block-0002
- itest-help_26.2.0.zip-popups-close.html-b5d13d66c2b7-f1fe2af4bfed-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 38
source_hash: f1fe2af4bfed6639de70b1dd9196c368ce5fbf8f84fdd4e5a23b712903f4829d
normalized_document_hash: 7d52bd45b09e673ee1b6d1cab15f02afc3ccbce5f372926c3282e5b6aff06ac4
content_status: success
content_sha256: 4d1dd1dd19b25133645eb52e04211f55e9135cf217eabd6fc853fd0487b858e3
---

# close

The close action closes the session specified by the Session property value. close takes no Command property value.

For details, see the online help: The close action .
