---
chunk_id: itest-help_26.2.0.zip-popups-close_application.html-513888d328f3-b3cfef14c219-chunk-0001
source_id: itest-help_26.2.0.zip-popups-close_application.html-513888d328f3-b3cfef14c219
title: Close Application
heading_path:
- Close Application
section_titles:
- Close Application
source_block_ids:
- itest-help_26.2.0.zip-popups-close_application.html-513888d328f3-b3cfef14c219-block-0001
- itest-help_26.2.0.zip-popups-close_application.html-513888d328f3-b3cfef14c219-block-0002
- itest-help_26.2.0.zip-popups-close_application.html-513888d328f3-b3cfef14c219-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 130
source_hash: b3cfef14c219606185133ac003e3cc778342d39f7c010eb37d771491b1e229a9
normalized_document_hash: 725e9ae2586aac4c87445e4c67ff4aea8bc6d88ff396421e308cebb9c5336225
content_status: success
content_sha256: 1875f38e6ef2268278a7f6cc6e2f48c25de3d2565dbb7e5eab7211f7991a96c0
---

# Close Application

Use action for closing applications and web sites. If the 'Close Method' is set to 'CloseWindow', the application is attempted to close.
If the parameter 'Grace Period' is set to a value greater than 0 ms, the process will be killed after the 'Grace Period', if the application fails to close.
If 'Close Method' is set to 'KillProcess' the application’s process is killed immediately, even if the value of the value of ‘Grace Period’ is > 0ms.

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
