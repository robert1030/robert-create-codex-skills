# Close Application

Use action for closing applications and web sites. If the 'Close Method' is set to 'CloseWindow', the application is attempted to close.
If the parameter 'Grace Period' is set to a value greater than 0 ms, the process will be killed after the 'Grace Period', if the application fails to close.
If 'Close Method' is set to 'KillProcess' the application’s process is killed immediately, even if the value of the value of ‘Grace Period’ is > 0ms.

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
