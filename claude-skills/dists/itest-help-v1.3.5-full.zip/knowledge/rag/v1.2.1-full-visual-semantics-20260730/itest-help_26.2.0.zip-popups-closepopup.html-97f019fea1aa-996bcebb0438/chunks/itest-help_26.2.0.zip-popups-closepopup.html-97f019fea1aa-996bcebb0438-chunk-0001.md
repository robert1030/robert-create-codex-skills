---
chunk_id: itest-help_26.2.0.zip-popups-closepopup.html-97f019fea1aa-996bcebb0438-chunk-0001
source_id: itest-help_26.2.0.zip-popups-closepopup.html-97f019fea1aa-996bcebb0438
title: closePopup
heading_path:
- closePopup
section_titles:
- closePopup
source_block_ids:
- itest-help_26.2.0.zip-popups-closepopup.html-97f019fea1aa-996bcebb0438-block-0001
- itest-help_26.2.0.zip-popups-closepopup.html-97f019fea1aa-996bcebb0438-block-0002
- itest-help_26.2.0.zip-popups-closepopup.html-97f019fea1aa-996bcebb0438-block-0003
- itest-help_26.2.0.zip-popups-closepopup.html-97f019fea1aa-996bcebb0438-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 139
source_hash: 996bcebb043847d28087ef9e3bdd79878b92e479800ff7787d69a8d744a3434b
normalized_document_hash: fdc01fae9687aaf3da14594fb8941b51435161ca061d5efb409b562cb5b440e9
content_status: success
content_sha256: c6297055e06286493495a6e997a4e472fb67b3b813cf2336eae570b42170ee4f
---

# closePopup

Closes the popup (if open).

| Target | Required |
| --- | --- |
| Controls | Controls with popup or drop-down menus, for example combo boxes or menus. |
| Command | None. |
| Step Properties | Step Properties Trigger: Mouse or Keyboard used to open or close the popup.<br>Default: Mouse Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference.
