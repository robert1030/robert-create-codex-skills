# closePopup

Closes the popup (if open).

| Target | Required |
| --- | --- |
| Controls | Controls with popup or drop-down menus, for example combo boxes or menus. |
| Command | None. |
| Step Properties | Step Properties Trigger: Mouse or Keyboard used to open or close the popup.<br>Default: Mouse Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference.
