---
chunk_id: itest-help_26.2.0.zip-popups-closewindow.html-04aa2ea43793-0143a8de9580-chunk-0001
source_id: itest-help_26.2.0.zip-popups-closewindow.html-04aa2ea43793-0143a8de9580
title: closeWindow
heading_path:
- closeWindow
section_titles:
- closeWindow
source_block_ids:
- itest-help_26.2.0.zip-popups-closewindow.html-04aa2ea43793-0143a8de9580-block-0001
- itest-help_26.2.0.zip-popups-closewindow.html-04aa2ea43793-0143a8de9580-block-0002
- itest-help_26.2.0.zip-popups-closewindow.html-04aa2ea43793-0143a8de9580-block-0003
- itest-help_26.2.0.zip-popups-closewindow.html-04aa2ea43793-0143a8de9580-block-0004
- itest-help_26.2.0.zip-popups-closewindow.html-04aa2ea43793-0143a8de9580-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 77
source_hash: 0143a8de95800f69f7d70bf134a2cfce1c72a51eebc9a226331107cb8154cc99
normalized_document_hash: a5ef405d4a87fecb757d2de6c9806157a991ee70a6f9b31d26f7eb731c07ee17
content_status: success
content_sha256: 65f60c1377738bcc74cf6576186ce879b4658d0b08106d6edd833e2494180917
---

# closeWindow

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| closeWindow | Not Required | Optional | Closes the specified window. The Command property specifies the window to close. If Command is empty, then the currently selected window is closed. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
