# closeWindow

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| closeWindow | Not Required | Optional | Closes the specified window. The Command property specifies the window to close. If Command is empty, then the currently selected window is closed. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
