---
chunk_id: itest-help_26.2.0.zip-popups-collapsenode.html-d3d55e3f1e79-45023e506acc-chunk-0001
source_id: itest-help_26.2.0.zip-popups-collapsenode.html-d3d55e3f1e79-45023e506acc
title: collapseNode
heading_path:
- collapseNode
section_titles:
- collapseNode
source_block_ids:
- itest-help_26.2.0.zip-popups-collapsenode.html-d3d55e3f1e79-45023e506acc-block-0001
- itest-help_26.2.0.zip-popups-collapsenode.html-d3d55e3f1e79-45023e506acc-block-0002
- itest-help_26.2.0.zip-popups-collapsenode.html-d3d55e3f1e79-45023e506acc-block-0003
- itest-help_26.2.0.zip-popups-collapsenode.html-d3d55e3f1e79-45023e506acc-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 183
source_hash: 45023e506acc0b5e6b848a1fed0334f54a1eec7d8e5f8123fda5007806213e77
normalized_document_hash: 029adc18e00fa29cb778a4a8a2af82db41bedc44a6a749fedc440ca46a928643
content_status: success
content_sha256: 544b360f1d6ca974f6fca3b67c2092ad3b5427e92253d57f40cba9475da7ce70
---

# collapseNode

Collapses the specified node in a tree.

| Target | Required |
| --- | --- |
| Controls | Trees |
| Command | The path to the node to collapse. Path is specified by labels or indices separated by the ‘>’ character, for example Countries>France>Paris. |
| Step Properties | Step Properties Trigger: Mouse or Keyboard used to collapse the node.<br>Default: Mouse Use index: Check the box if the command specifies the node path by indices, for example 0>1>1<br>Default: unchecked Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
