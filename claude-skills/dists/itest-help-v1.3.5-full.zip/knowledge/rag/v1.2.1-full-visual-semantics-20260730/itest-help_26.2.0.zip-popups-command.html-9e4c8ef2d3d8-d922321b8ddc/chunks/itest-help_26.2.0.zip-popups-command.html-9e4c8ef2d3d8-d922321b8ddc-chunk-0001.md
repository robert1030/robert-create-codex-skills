---
chunk_id: itest-help_26.2.0.zip-popups-command.html-9e4c8ef2d3d8-d922321b8ddc-chunk-0001
source_id: itest-help_26.2.0.zip-popups-command.html-9e4c8ef2d3d8-d922321b8ddc
title: command
heading_path:
- command
section_titles:
- command
source_block_ids:
- itest-help_26.2.0.zip-popups-command.html-9e4c8ef2d3d8-d922321b8ddc-block-0001
- itest-help_26.2.0.zip-popups-command.html-9e4c8ef2d3d8-d922321b8ddc-block-0002
- itest-help_26.2.0.zip-popups-command.html-9e4c8ef2d3d8-d922321b8ddc-block-0003
- itest-help_26.2.0.zip-popups-command.html-9e4c8ef2d3d8-d922321b8ddc-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 102
source_hash: d922321b8ddc73fd9ad4caddf7b06082793d61b82bdfe588c6cc5d4478f61295
normalized_document_hash: 0e594782f0459f654c18243e774949d3dcf05a84fdbf3b4b8aea8ae6ec310ccb
content_status: success
content_sha256: ac1f22bdeb1aa5651dc5fe31eda7926227aeb455028cacb9b4815885d5ee3774
---

# command

The command action submits the command that appears in the Description cell for the step (the Command property value).

The command action is available only for CLI (command-line interface) sessions -- the terminal-based sessions; any session type where you type commands at a prompt in a command line: Telnet, SSH, Tcl Shell, HTTP, Process, Command Prompt, and the various session types that support traffic generator devices.)

For details, see the online help: The command action .
