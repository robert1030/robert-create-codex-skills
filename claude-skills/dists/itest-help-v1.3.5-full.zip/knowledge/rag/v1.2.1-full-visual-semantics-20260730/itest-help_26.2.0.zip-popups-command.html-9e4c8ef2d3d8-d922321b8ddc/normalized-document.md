# command

The command action submits the command that appears in the Description cell for the step (the Command property value).

The command action is available only for CLI (command-line interface) sessions -- the terminal-based sessions; any session type where you type commands at a prompt in a command line: Telnet, SSH, Tcl Shell, HTTP, Process, Command Prompt, and the various session types that support traffic generator devices.)

For details, see the online help: The command action .
