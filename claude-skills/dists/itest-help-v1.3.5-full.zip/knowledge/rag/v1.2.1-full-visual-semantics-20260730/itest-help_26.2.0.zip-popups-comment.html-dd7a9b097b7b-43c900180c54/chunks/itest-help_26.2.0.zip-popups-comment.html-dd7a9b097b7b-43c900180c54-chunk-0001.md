---
chunk_id: itest-help_26.2.0.zip-popups-comment.html-dd7a9b097b7b-43c900180c54-chunk-0001
source_id: itest-help_26.2.0.zip-popups-comment.html-dd7a9b097b7b-43c900180c54
title: comment
heading_path:
- comment
section_titles:
- comment
source_block_ids:
- itest-help_26.2.0.zip-popups-comment.html-dd7a9b097b7b-43c900180c54-block-0001
- itest-help_26.2.0.zip-popups-comment.html-dd7a9b097b7b-43c900180c54-block-0002
- itest-help_26.2.0.zip-popups-comment.html-dd7a9b097b7b-43c900180c54-block-0003
- itest-help_26.2.0.zip-popups-comment.html-dd7a9b097b7b-43c900180c54-block-0004
- itest-help_26.2.0.zip-popups-comment.html-dd7a9b097b7b-43c900180c54-block-0005
- itest-help_26.2.0.zip-popups-comment.html-dd7a9b097b7b-43c900180c54-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 204
source_hash: 43c900180c541fcb45fc6cdb1e5f07032f5898683019c0b26c685ea7f6264266
normalized_document_hash: 34dcb0b1fe89fd0356fae6805b02c6490b6f82554e3b03bb6160c771d4efe437
content_status: success
content_sha256: e8c15a2c827320a64c57fe059e763ceadbbaa396678718f1bf6b4293f6aed78f
---

# comment

For the EXEC comment action, the system interprets the text in the associated Description field as a comment to the user. You have the option to specify that, at runtime, all comments in the test case should appear as execution messages in the Execution view and the test report, but no other action is performed by the step.

To use comments to "message out" to the Execution view, go to the Test Case editor General page and select Generate an execution issue for every comment step executed .

Tips:

- Comments can include field replacements. This is an easy way to send data to the Execution view.
- Comment steps are a great way to outline or pseudo-code a test case before adding actual commands. To
add Comments quickly, select a comment step and then press Ctrl-Enter. Once your outline is complete,
you can go back and insert commands.

For details, see the online help: The comment action .
