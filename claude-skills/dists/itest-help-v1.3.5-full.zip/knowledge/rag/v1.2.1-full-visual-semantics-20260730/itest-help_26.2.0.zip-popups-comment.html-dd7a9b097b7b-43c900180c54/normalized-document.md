# comment

For the EXEC comment action, the system interprets the text in the associated Description field as a comment to the user. You have the option to specify that, at runtime, all comments in the test case should appear as execution messages in the Execution view and the test report, but no other action is performed by the step.

To use comments to "message out" to the Execution view, go to the Test Case editor General page and select Generate an execution issue for every comment step executed .

Tips:

- Comments can include field replacements. This is an easy way to send data to the Execution view.
- Comment steps are a great way to outline or pseudo-code a test case before adding actual commands. To
add Comments quickly, select a comment step and then press Ctrl-Enter. Once your outline is complete,
you can go back and insert commands.

For details, see the online help: The comment action .
