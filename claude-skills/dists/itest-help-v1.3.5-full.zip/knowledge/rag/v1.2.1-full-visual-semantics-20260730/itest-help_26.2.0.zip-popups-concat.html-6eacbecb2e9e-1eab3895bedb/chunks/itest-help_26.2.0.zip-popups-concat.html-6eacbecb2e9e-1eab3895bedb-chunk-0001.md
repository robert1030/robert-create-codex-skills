---
chunk_id: itest-help_26.2.0.zip-popups-concat.html-6eacbecb2e9e-1eab3895bedb-chunk-0001
source_id: itest-help_26.2.0.zip-popups-concat.html-6eacbecb2e9e-1eab3895bedb
title: concat
heading_path:
- concat
section_titles:
- concat
source_block_ids:
- itest-help_26.2.0.zip-popups-concat.html-6eacbecb2e9e-1eab3895bedb-block-0001
- itest-help_26.2.0.zip-popups-concat.html-6eacbecb2e9e-1eab3895bedb-block-0002
- itest-help_26.2.0.zip-popups-concat.html-6eacbecb2e9e-1eab3895bedb-block-0003
- itest-help_26.2.0.zip-popups-concat.html-6eacbecb2e9e-1eab3895bedb-block-0004
- itest-help_26.2.0.zip-popups-concat.html-6eacbecb2e9e-1eab3895bedb-block-0005
- itest-help_26.2.0.zip-popups-concat.html-6eacbecb2e9e-1eab3895bedb-block-0006
- itest-help_26.2.0.zip-popups-concat.html-6eacbecb2e9e-1eab3895bedb-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 162
source_hash: 1eab3895bedbdf5f560b247b2310988b3fb945b025d367c6bc50a045853049e5
normalized_document_hash: 90118d2bb898e7cf3f6d48533c71a8dab204cbdc5567a359167fb9179a5efe6c
content_status: success
content_sha256: 19d522fd3905f4339ea7442124e2cc83ecf73352af493112a6d7a9b6570ff20b
---

# concat

concat ? arg arg ... ?

Joins each of its arguments together with spaces after trimming leading and trailing white-space from each of them. If all the arguments are lists, this has the same effect as concatenating them into a single list. It permits any number of arguments; if no args are supplied, the result is an empty string.

To insert a concat command, right-click in the field and then select Insert > Special Actions > Concatenate Strings .

The iTest concat command is compatible with its Tcl counterpart as more fully described at http://www.tcl.tk/man

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
