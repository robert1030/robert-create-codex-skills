---
chunk_id: itest-help_26.2.0.zip-popups-configure.html-2fbabc1442c8-f921ff38897c-chunk-0001
source_id: itest-help_26.2.0.zip-popups-configure.html-2fbabc1442c8-f921ff38897c
title: configure
heading_path:
- configure
section_titles:
- configure
source_block_ids:
- itest-help_26.2.0.zip-popups-configure.html-2fbabc1442c8-f921ff38897c-block-0001
- itest-help_26.2.0.zip-popups-configure.html-2fbabc1442c8-f921ff38897c-block-0002
- itest-help_26.2.0.zip-popups-configure.html-2fbabc1442c8-f921ff38897c-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 95
source_hash: f921ff38897cb44cc2baf53e0851a86ba64b0bf05b0f4ae9e07a8cb386bcdf16
normalized_document_hash: 43cee7bfc2dbdb29c3744221d22ed4c6f3f178e8c7b0222350672866e08c276a
content_status: success
content_sha256: ddc57d0e25c822d7181daa97c53cf0999002f2b6f508655d4fe925dc1d423c19
---

# configure

To enable a step in an iTest test case to configure a traffic generator to the desired state before performing the automated test, iTest submits previously saved configuration information to the device.  As a result, a configure step configures the device exactly as if you had configured it using its native management console.

For details on preparing the configuration text and adding a configure step, see the online help: The configure action .
