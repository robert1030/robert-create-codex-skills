# configure

To enable a step in an iTest test case to configure a traffic generator to the desired state before performing the automated test, iTest submits previously saved configuration information to the device.  As a result, a configure step configures the device exactly as if you had configured it using its native management console.

For details on preparing the configuration text and adding a configure step, see the online help: The configure action .
