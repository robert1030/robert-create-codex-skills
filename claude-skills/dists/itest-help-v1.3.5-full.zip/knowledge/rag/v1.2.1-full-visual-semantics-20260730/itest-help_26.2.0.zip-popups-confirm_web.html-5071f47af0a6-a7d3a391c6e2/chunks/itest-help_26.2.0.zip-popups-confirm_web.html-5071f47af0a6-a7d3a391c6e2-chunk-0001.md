---
chunk_id: itest-help_26.2.0.zip-popups-confirm_web.html-5071f47af0a6-a7d3a391c6e2-chunk-0001
source_id: itest-help_26.2.0.zip-popups-confirm_web.html-5071f47af0a6-a7d3a391c6e2
title: confirm
heading_path:
- confirm
section_titles:
- confirm
source_block_ids:
- itest-help_26.2.0.zip-popups-confirm_web.html-5071f47af0a6-a7d3a391c6e2-block-0001
- itest-help_26.2.0.zip-popups-confirm_web.html-5071f47af0a6-a7d3a391c6e2-block-0002
- itest-help_26.2.0.zip-popups-confirm_web.html-5071f47af0a6-a7d3a391c6e2-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 74
source_hash: a7d3a391c6e2bf665e84f62d7352c9ff4c9d4fc36aad169a4a408c604a2292c6
normalized_document_hash: 4f190f8cb8ff7e6d4d334ccdf00f6a75cd0ed736677a5bff6e21ac1ee80c5dd3
content_status: success
content_sha256: 48eb24253da21d885a319c91f9385d7f7dc3b955a3c17bf910b96ee763b894aa
---

# confirm

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| confirm | Required | OK or CANCEL | Typically, confirm steps are added from captured sessions. When a confirmation dialog appears, confirm clicks the OK or Cancel button. |

For details, see the online help: Creating Web test case steps and Web session action reference
