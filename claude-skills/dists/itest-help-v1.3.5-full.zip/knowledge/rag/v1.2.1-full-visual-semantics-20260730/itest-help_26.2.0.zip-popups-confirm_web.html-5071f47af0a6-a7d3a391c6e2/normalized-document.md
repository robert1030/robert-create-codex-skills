# confirm

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| confirm | Required | OK or CANCEL | Typically, confirm steps are added from captured sessions. When a confirmation dialog appears, confirm clicks the OK or Cancel button. |

For details, see the online help: Creating Web test case steps and Web session action reference
