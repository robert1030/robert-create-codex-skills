---
chunk_id: itest-help_26.2.0.zip-popups-contenttype.html-5c89c3ffeb21-27da3facaa59-chunk-0001
source_id: itest-help_26.2.0.zip-popups-contenttype.html-5c89c3ffeb21-27da3facaa59
title: Content-Type
heading_path:
- Content-Type
section_titles:
- Content-Type
source_block_ids:
- itest-help_26.2.0.zip-popups-contenttype.html-5c89c3ffeb21-27da3facaa59-block-0001
- itest-help_26.2.0.zip-popups-contenttype.html-5c89c3ffeb21-27da3facaa59-block-0002
- itest-help_26.2.0.zip-popups-contenttype.html-5c89c3ffeb21-27da3facaa59-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 56
source_hash: 27da3facaa598984c63ce8968c58eff78181264e2df27e40255a89122f0765d0
normalized_document_hash: eb7e1421b1624dc096ff370165f22fd629760b2f45716ed3f59ab2aa728adfc4
content_status: success
content_sha256: d275707d622fda53d5cffc992f522aa9258a0da27323e348d5e30874654fdca1
---

# Content-Type

The Content-Type header field is used to specify the nature of the data in the body of mail. Mail session only support 2 types: text/plain , text/html

For details, see the online help: Sending email messages during test execution .
