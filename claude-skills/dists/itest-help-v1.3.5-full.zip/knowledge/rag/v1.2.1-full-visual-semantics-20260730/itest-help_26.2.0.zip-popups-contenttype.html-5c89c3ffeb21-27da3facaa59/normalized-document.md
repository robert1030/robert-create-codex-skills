# Content-Type

The Content-Type header field is used to specify the nature of the data in the body of mail. Mail session only support 2 types: text/plain , text/html

For details, see the online help: Sending email messages during test execution .
