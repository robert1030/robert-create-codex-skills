---
chunk_id: itest-help_26.2.0.zip-popups-contextmenu.html-607c6c228cf4-39b4ab8f6109-chunk-0001
source_id: itest-help_26.2.0.zip-popups-contextmenu.html-607c6c228cf4-39b4ab8f6109
title: contextMenu
heading_path:
- contextMenu
section_titles:
- contextMenu
source_block_ids:
- itest-help_26.2.0.zip-popups-contextmenu.html-607c6c228cf4-39b4ab8f6109-block-0001
- itest-help_26.2.0.zip-popups-contextmenu.html-607c6c228cf4-39b4ab8f6109-block-0002
- itest-help_26.2.0.zip-popups-contextmenu.html-607c6c228cf4-39b4ab8f6109-block-0003
- itest-help_26.2.0.zip-popups-contextmenu.html-607c6c228cf4-39b4ab8f6109-block-0004
- itest-help_26.2.0.zip-popups-contextmenu.html-607c6c228cf4-39b4ab8f6109-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 151
source_hash: 39b4ab8f610921c9b7d47aabe85b19c42a5f3c80543c95a04ca20256d9fa2a2e
normalized_document_hash: fdcab282c9a6c25456df3d905674d458473c8a9b86aa84ce6d80b07f860d7405
content_status: success
content_sha256: 6d39f211bc4c06987d363fb67b7958c1e3328d58fdb79ac0b107d13704e1c11f
---

# contextMenu

Selects the specified item in a context menu (typically, a right-click context menu) on the specified control.

Note: Only Flex application-specific context menu items are supported. Default Adobe context menu items like Copy and Paste are not supported

| Target | Required |
| --- | --- |
| Controls | All controls |
| Command | The item to select in the context menu. |
| Step Properties | Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
