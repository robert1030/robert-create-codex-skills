# contextMenu

Selects the specified item in a context menu (typically, a right-click context menu) on the specified control.

Note: Only Flex application-specific context menu items are supported. Default Adobe context menu items like Copy and Paste are not supported

| Target | Required |
| --- | --- |
| Controls | All controls |
| Command | The item to select in the context menu. |
| Step Properties | Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
