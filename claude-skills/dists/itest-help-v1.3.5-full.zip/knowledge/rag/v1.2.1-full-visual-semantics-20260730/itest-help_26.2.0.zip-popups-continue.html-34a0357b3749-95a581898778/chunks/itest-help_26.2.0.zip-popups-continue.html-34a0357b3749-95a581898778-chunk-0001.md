---
chunk_id: itest-help_26.2.0.zip-popups-continue.html-34a0357b3749-95a581898778-chunk-0001
source_id: itest-help_26.2.0.zip-popups-continue.html-34a0357b3749-95a581898778
title: continue
heading_path:
- continue
section_titles:
- continue
source_block_ids:
- itest-help_26.2.0.zip-popups-continue.html-34a0357b3749-95a581898778-block-0001
- itest-help_26.2.0.zip-popups-continue.html-34a0357b3749-95a581898778-block-0002
- itest-help_26.2.0.zip-popups-continue.html-34a0357b3749-95a581898778-block-0003
- itest-help_26.2.0.zip-popups-continue.html-34a0357b3749-95a581898778-block-0004
- itest-help_26.2.0.zip-popups-continue.html-34a0357b3749-95a581898778-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 108
source_hash: 95a581898778f3f7fc61362b6014658d3a3bbfd55a03c0e7c2908b3291f2523c
normalized_document_hash: b2972330581c873300082087094cafa1af517ed5aab083e93a70b88e510e65d6
content_status: success
content_sha256: add234b430914297500122f4d86a4a25c255de62a5d75ad8502b18cce10e7b98
---

# continue

The continue action causes the current script to be aborted out to the innermost containing for , foreach , or while loop command. The loop then continues with the next iteration of the loop.

Use the continue action when you want to execute particular steps for some iterations of the loop, but not for other iterations.

- The asynchronous property of a continue step is ignored
- Steps nested inside a continue step are never used

For details, see the online help: The continue action .
