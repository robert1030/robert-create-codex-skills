---
chunk_id: itest-help_26.2.0.zip-popups-continue_python.html-0d2b0c10944c-f9cc0b26f1be-chunk-0001
source_id: itest-help_26.2.0.zip-popups-continue_python.html-0d2b0c10944c-f9cc0b26f1be
title: continue
heading_path:
- continue
section_titles:
- continue
source_block_ids:
- itest-help_26.2.0.zip-popups-continue_python.html-0d2b0c10944c-f9cc0b26f1be-block-0001
- itest-help_26.2.0.zip-popups-continue_python.html-0d2b0c10944c-f9cc0b26f1be-block-0002
- itest-help_26.2.0.zip-popups-continue_python.html-0d2b0c10944c-f9cc0b26f1be-block-0003
- itest-help_26.2.0.zip-popups-continue_python.html-0d2b0c10944c-f9cc0b26f1be-block-0004
- itest-help_26.2.0.zip-popups-continue_python.html-0d2b0c10944c-f9cc0b26f1be-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 106
source_hash: f9cc0b26f1be40236a1e6bab9bbd14f89153f0b473f2fce6061debbecd5a973e
normalized_document_hash: 1fde32ea3918dbdf252efb854019978a70ff8984fb382cc4d62ed30fb2ba5e34
content_status: success
content_sha256: e84a9a38fc07877b8a3e805dfcc6aae0b8c0824eadc6229f8897e894441fc40d
---

# continue

The continue action causes the current script to be aborted out to the innermost containing for , or while loop command. The loop then continues with the next iteration of the loop.

Use the continue action when you want to execute particular steps for some iterations of the loop, but not for other iterations.

- The asynchronous property of a continue step is ignored
- Steps nested inside a continue step are never used

For details, see the online help: The continue action .
