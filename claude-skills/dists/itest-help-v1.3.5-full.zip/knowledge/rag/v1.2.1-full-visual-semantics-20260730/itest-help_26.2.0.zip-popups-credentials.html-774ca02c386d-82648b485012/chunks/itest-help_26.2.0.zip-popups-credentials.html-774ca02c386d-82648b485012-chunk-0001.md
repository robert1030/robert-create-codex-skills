---
chunk_id: itest-help_26.2.0.zip-popups-credentials.html-774ca02c386d-82648b485012-chunk-0001
source_id: itest-help_26.2.0.zip-popups-credentials.html-774ca02c386d-82648b485012
title: credentials
heading_path:
- credentials
section_titles:
- credentials
source_block_ids:
- itest-help_26.2.0.zip-popups-credentials.html-774ca02c386d-82648b485012-block-0001
- itest-help_26.2.0.zip-popups-credentials.html-774ca02c386d-82648b485012-block-0002
- itest-help_26.2.0.zip-popups-credentials.html-774ca02c386d-82648b485012-block-0003
- itest-help_26.2.0.zip-popups-credentials.html-774ca02c386d-82648b485012-block-0004
- itest-help_26.2.0.zip-popups-credentials.html-774ca02c386d-82648b485012-block-0005
- itest-help_26.2.0.zip-popups-credentials.html-774ca02c386d-82648b485012-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 119
source_hash: 82648b485012fbeb07a51489db47ef2821e45ca547fdb69174efb4bdd15bb165
normalized_document_hash: c596042f2ddc9f53fe7871dddf8b54a64bdfcdb32f6f82f2884b8dd15cf6f64a
content_status: success
content_sha256: ba69891581c3e6179ac87b85e75244e95537cd90ba355f78fa6e0a6b98e85506
---

# credentials

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| credentials | Not Required | Required | Typically, credentials steps are added from captured sessions. A credentials step indicates that the user has entered new HTTP credentials. When saved as a credentials step in a test case, the credentials are configured in the step properties settings. |

Note: You should typically set credentials in the session profile and not in the test case step.

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
