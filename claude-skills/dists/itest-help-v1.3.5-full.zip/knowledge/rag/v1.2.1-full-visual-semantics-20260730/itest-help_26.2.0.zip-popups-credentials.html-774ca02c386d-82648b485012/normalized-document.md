# credentials

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| credentials | Not Required | Required | Typically, credentials steps are added from captured sessions. A credentials step indicates that the user has entered new HTTP credentials. When saved as a credentials step in a test case, the credentials are configured in the step properties settings. |

Note: You should typically set credentials in the session profile and not in the test case step.

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
