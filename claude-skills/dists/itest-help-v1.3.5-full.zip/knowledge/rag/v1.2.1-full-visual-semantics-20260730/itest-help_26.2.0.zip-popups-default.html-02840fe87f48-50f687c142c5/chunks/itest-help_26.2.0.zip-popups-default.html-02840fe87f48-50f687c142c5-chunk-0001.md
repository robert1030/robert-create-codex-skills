---
chunk_id: itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-chunk-0001
source_id: itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5
title: default
heading_path:
- default
section_titles:
- default
source_block_ids:
- itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-block-0001
- itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-block-0002
- itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-block-0003
- itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-block-0004
- itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-block-0005
- itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-block-0006
- itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-block-0007
- itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-block-0008
- itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-block-0009
- itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-block-0010
- itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-block-0011
- itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-block-0012
- itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-block-0013
- itest-help_26.2.0.zip-popups-default.html-02840fe87f48-50f687c142c5-block-0014
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 116
source_hash: 50f687c142c539e9b63427b068dae9afaac357e01c4f20645c2690980f9bbf75
normalized_document_hash: f00b68260b658d33554562eeaddfef811f475281c6052b5913d0692355da9655
content_status: success
content_sha256: b6688c41153150578207b5aaaa12af84befb21e6bf68cee0d5558377b85828fc
---

# default

A default step is a part of a switch construct. A switch construct allows the value of an expression to determine the flow of execution.

If the control value matches none of the

case

expressions, then execution switches to the steps that are nested under the

default

step. When the last nested step finishes, then execution proceeds at the step after the

switch

construct.
If there is no

default

step, then execution proceeds at the step after the

switch

construct.

See the online help for examples and details.
