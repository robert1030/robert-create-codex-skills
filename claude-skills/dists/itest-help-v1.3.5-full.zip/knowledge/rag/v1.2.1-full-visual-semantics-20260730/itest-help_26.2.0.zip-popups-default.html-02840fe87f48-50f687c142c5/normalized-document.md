# default

A default step is a part of a switch construct. A switch construct allows the value of an expression to determine the flow of execution.

If the control value matches none of the

case

expressions, then execution switches to the steps that are nested under the

default

step. When the last nested step finishes, then execution proceeds at the step after the

switch

construct.
If there is no

default

step, then execution proceeds at the step after the

switch

construct.

See the online help for examples and details.
