---
chunk_id: itest-help_26.2.0.zip-popups-delete.html-09debb77c8a3-a2542241ce3e-chunk-0001
source_id: itest-help_26.2.0.zip-popups-delete.html-09debb77c8a3-a2542241ce3e
title: DELETE
heading_path:
- DELETE
section_titles:
- DELETE
source_block_ids:
- itest-help_26.2.0.zip-popups-delete.html-09debb77c8a3-a2542241ce3e-block-0001
- itest-help_26.2.0.zip-popups-delete.html-09debb77c8a3-a2542241ce3e-block-0002
- itest-help_26.2.0.zip-popups-delete.html-09debb77c8a3-a2542241ce3e-block-0003
- itest-help_26.2.0.zip-popups-delete.html-09debb77c8a3-a2542241ce3e-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 290
source_hash: a2542241ce3e8e0eeaeab72e19d25fd3dd4013c9e28040057d4a5b673bd65ba8
normalized_document_hash: a8048d12f8d8c6f35a467ea927d6c19a3e109fbc93c2f8a6ca5a0a1c0016cd18
content_status: success
content_sha256: 22b0cbc684b2c12d590d5dc761a19dc63b3d1bad35150faea1c76e0a30e3aca3
---

# DELETE

The DELETE method is used to delete/remove a resource identified by a URI.

| Action | DELETE - use to delete/remove a resource identified by a URI. |
| --- | --- |
| Returns | Successful deletion returns:<br>- HTTP status 200 (OK) along with a response body, that is, representation of the deleted item (may take too much bandwidth), or a wrapped response<br>- HTTP status 204 (NO CONTENT) with no response body. Note: HTTP status 204 status with no body, or the JSEND-style response and HTTP status 200 are the recommended responses. Entire List: HTTP 404 (Not Found), unless you want to delete the whole collection—not often desirable. Specific Item: HTTP200 (OK). 404 (Not Found), if ID not found or invalid. |
| Method | The DELETE operation is considered idempotent. Deleting action removes a resource and repeatedly calling DELETE on that resource results with the response: as the resource does not exist.<br>Calling DELETE on a resource a second time returns a HTTP 404 (NOT FOUND) since it was already removed and cannot be found. |
| Example | DELETE http://www.example.com/customers/12345<br>DELETE http://www.example.com/customers/12345/orders<br>DELETE http://www.example.com/bucket/sample |

For details, see the online help: REST action reference .
