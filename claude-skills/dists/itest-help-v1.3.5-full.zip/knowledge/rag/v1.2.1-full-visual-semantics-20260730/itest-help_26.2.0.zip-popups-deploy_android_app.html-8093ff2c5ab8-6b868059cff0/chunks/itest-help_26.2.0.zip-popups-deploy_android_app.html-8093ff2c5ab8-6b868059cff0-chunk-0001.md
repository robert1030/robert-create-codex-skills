---
chunk_id: itest-help_26.2.0.zip-popups-deploy_android_app.html-8093ff2c5ab8-6b868059cff0-chunk-0001
source_id: itest-help_26.2.0.zip-popups-deploy_android_app.html-8093ff2c5ab8-6b868059cff0
title: Deploy Android App
heading_path:
- Deploy Android App
section_titles:
- Deploy Android App
source_block_ids:
- itest-help_26.2.0.zip-popups-deploy_android_app.html-8093ff2c5ab8-6b868059cff0-block-0001
- itest-help_26.2.0.zip-popups-deploy_android_app.html-8093ff2c5ab8-6b868059cff0-block-0002
- itest-help_26.2.0.zip-popups-deploy_android_app.html-8093ff2c5ab8-6b868059cff0-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 76
source_hash: 6b868059cff004edee3036650e75f0e4d764efcbb5dcef93ab3b107921896a22
normalized_document_hash: b6334ac3a779248765369fb17f1f27e8dd46f1d57a51accefd3a535634811366
content_status: success
content_sha256: 54fcdd36c181c7b3e0dcf100a811ba892568b68c7e94b6cbc2482e115216eec7
---

# Deploy Android App

The “Run Mobile App” action which starts the instrumented APK file on the selected device.
When using this action you can specify a 'Device' and an 'App'. For more information see Android Testing - Record your Android Test.

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
