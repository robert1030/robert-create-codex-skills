---
chunk_id: itest-help_26.2.0.zip-popups-deploy_ios_app.html-18283d3b5254-f71f7a8547ca-chunk-0001
source_id: itest-help_26.2.0.zip-popups-deploy_ios_app.html-18283d3b5254-f71f7a8547ca
title: Deploy iOS App
heading_path:
- Deploy iOS App
section_titles:
- Deploy iOS App
source_block_ids:
- itest-help_26.2.0.zip-popups-deploy_ios_app.html-18283d3b5254-f71f7a8547ca-block-0001
- itest-help_26.2.0.zip-popups-deploy_ios_app.html-18283d3b5254-f71f7a8547ca-block-0002
- itest-help_26.2.0.zip-popups-deploy_ios_app.html-18283d3b5254-f71f7a8547ca-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 74
source_hash: f71f7a8547ca2e0d228349912749ab791610f2b84d417c080efac51e1b77c5b5
normalized_document_hash: 313ae7dbb44f73b30d0a5bce2a728c74ea54a669e839c87ff467bc11cec71e28
content_status: success
content_sha256: 80b0dcbf9de555f6068d566c754012513fb4254961633d34b48d78afc51526a7
---

# Deploy iOS App

Run Mobile App” action which starts the instrumented APK file on the selected device.
When using this action you can specify a 'Device' and an 'App'. For more information see Android Testing - Record your Android Test

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
