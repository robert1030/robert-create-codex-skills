---
chunk_id: itest-help_26.2.0.zip-popups-describe.html-f7c670863708-a34e409a5e0f-chunk-0001
source_id: itest-help_26.2.0.zip-popups-describe.html-f7c670863708-a34e409a5e0f
title: describe
heading_path:
- describe
section_titles:
- describe
source_block_ids:
- itest-help_26.2.0.zip-popups-describe.html-f7c670863708-a34e409a5e0f-block-0001
- itest-help_26.2.0.zip-popups-describe.html-f7c670863708-a34e409a5e0f-block-0002
- itest-help_26.2.0.zip-popups-describe.html-f7c670863708-a34e409a5e0f-block-0003
- itest-help_26.2.0.zip-popups-describe.html-f7c670863708-a34e409a5e0f-block-0004
- itest-help_26.2.0.zip-popups-describe.html-f7c670863708-a34e409a5e0f-block-0005
- itest-help_26.2.0.zip-popups-describe.html-f7c670863708-a34e409a5e0f-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 117
source_hash: a34e409a5e0f13d2d6f3b5df7092655909443390678c3c22d3b7ef65054aa8e9
normalized_document_hash: d3d4dfe1456e41e35657a43c384c3b4f4ba4fe56fbe5343ad631dad7323f6922
content_status: success
content_sha256: 88d2e09a0b5ece451fe84c0f455e6d5b5eb29aefd54d512408cbbc409b1af5a4
---

# describe

| Action Name | Target | Command property value | Notes |
| --- | --- | --- | --- |
| describe | Required | Not Required | Returns a list of attributes for the specified target, organized into a table. Use describe to: Determine the size or content of text boxes Determine whether radio buttons or check boxes are selected |

- Use
- describe
- to:
- Determine the size or content of text boxes
- Determine whether radio buttons or check boxes are selected

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
