# describe

| Action Name | Target | Command property value | Notes |
| --- | --- | --- | --- |
| describe | Required | Not Required | Returns a list of attributes for the specified target, organized into a table. Use describe to: Determine the size or content of text boxes Determine whether radio buttons or check boxes are selected |

- Use
- describe
- to:
- Determine the size or content of text boxes
- Determine whether radio buttons or check boxes are selected

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
