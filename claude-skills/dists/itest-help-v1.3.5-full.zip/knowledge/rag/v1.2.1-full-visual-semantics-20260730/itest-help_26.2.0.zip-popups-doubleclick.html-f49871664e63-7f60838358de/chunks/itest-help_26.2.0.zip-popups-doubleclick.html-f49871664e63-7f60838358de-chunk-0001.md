---
chunk_id: itest-help_26.2.0.zip-popups-doubleclick.html-f49871664e63-7f60838358de-chunk-0001
source_id: itest-help_26.2.0.zip-popups-doubleclick.html-f49871664e63-7f60838358de
title: DoubleClick
heading_path:
- DoubleClick
section_titles:
- DoubleClick
source_block_ids:
- itest-help_26.2.0.zip-popups-doubleclick.html-f49871664e63-7f60838358de-block-0001
- itest-help_26.2.0.zip-popups-doubleclick.html-f49871664e63-7f60838358de-block-0002
- itest-help_26.2.0.zip-popups-doubleclick.html-f49871664e63-7f60838358de-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 66
source_hash: 7f60838358deb7abcae39033e71248eca50fbe204ea763c395c1710d39de702f
normalized_document_hash: 73fbb39b3b59c4ba9b2f6ee4b2e380f02833cea47497b6dc1420405ff2c8fae0
content_status: success
content_sha256: 6cd8b217914ef090296721d820afb1f283978fe211b2c56add5318628e94f412
---

# DoubleClick

This mouse action can be used for 'Up', 'Down', 'Click', 'Double-Click' and 'Move'-actions. This action is typically used for button clicks so a repository item assignment is required.

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
