---
chunk_id: itest-help_26.2.0.zip-popups-doubleclickitem.html-7041b9362eab-e19f22ed10ac-chunk-0001
source_id: itest-help_26.2.0.zip-popups-doubleclickitem.html-7041b9362eab-e19f22ed10ac
title: doubleClickItem
heading_path:
- doubleClickItem
section_titles:
- doubleClickItem
source_block_ids:
- itest-help_26.2.0.zip-popups-doubleclickitem.html-7041b9362eab-e19f22ed10ac-block-0001
- itest-help_26.2.0.zip-popups-doubleclickitem.html-7041b9362eab-e19f22ed10ac-block-0002
- itest-help_26.2.0.zip-popups-doubleclickitem.html-7041b9362eab-e19f22ed10ac-block-0003
- itest-help_26.2.0.zip-popups-doubleclickitem.html-7041b9362eab-e19f22ed10ac-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 107
source_hash: e19f22ed10acd18bfbc24e032cfd3beac526d01db7e79a9e4b297423c2f8601b
normalized_document_hash: 9d4dd1b150aed154a6d2888d8f7c4a3471ad055b7106e2b73c4883ee320533a7
content_status: success
content_sha256: 7fe228dd08358b5264bb4fc58b7c5cb604cd52ebb9a824749fcf81fb997d7df1
---

# doubleClickItem

Double-clicks an item in the list.

| Target | Required. |
| --- | --- |
| Controls | Lists, trees, grids. |
| Command | Item to double click. |
| Step Properties | Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
