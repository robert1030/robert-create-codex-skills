---
chunk_id: itest-help_26.2.0.zip-popups-down.html-fabba7224ced-345b3845913b-chunk-0001
source_id: itest-help_26.2.0.zip-popups-down.html-fabba7224ced-345b3845913b
title: Down
heading_path:
- Down
section_titles:
- Down
source_block_ids:
- itest-help_26.2.0.zip-popups-down.html-fabba7224ced-345b3845913b-block-0001
- itest-help_26.2.0.zip-popups-down.html-fabba7224ced-345b3845913b-block-0002
- itest-help_26.2.0.zip-popups-down.html-fabba7224ced-345b3845913b-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 66
source_hash: 345b3845913b37a4b5a7490ba7adcf94173043dbccb9870e1b38d4001a13e351
normalized_document_hash: 34f7ee055b51510d0dc4941adfd5c2572431234d241afe8b3c4debe74184ba9b
content_status: success
content_sha256: 18c3fb187a4c4ce25374ca15c0ec03e61830bf7898291cd758a4090d34c379c1
---

# Down

This mouse action can be used for 'Up', 'Down', 'Click', 'Double-Click' and 'Move'-actions. This action is typically used for button clicks so a repository item assignment is required.

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
