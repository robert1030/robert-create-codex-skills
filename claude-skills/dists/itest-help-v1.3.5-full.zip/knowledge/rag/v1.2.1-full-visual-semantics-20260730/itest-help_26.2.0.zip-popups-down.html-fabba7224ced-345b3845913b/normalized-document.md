# Down

This mouse action can be used for 'Up', 'Down', 'Click', 'Double-Click' and 'Move'-actions. This action is typically used for button clicks so a repository item assignment is required.

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
