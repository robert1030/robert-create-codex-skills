---
chunk_id: itest-help_26.2.0.zip-popups-drag.html-b3951249122c-a710d5ac6e11-chunk-0001
source_id: itest-help_26.2.0.zip-popups-drag.html-b3951249122c-a710d5ac6e11
title: drag
heading_path:
- drag
section_titles:
- drag
source_block_ids:
- itest-help_26.2.0.zip-popups-drag.html-b3951249122c-a710d5ac6e11-block-0001
- itest-help_26.2.0.zip-popups-drag.html-b3951249122c-a710d5ac6e11-block-0002
- itest-help_26.2.0.zip-popups-drag.html-b3951249122c-a710d5ac6e11-block-0003
- itest-help_26.2.0.zip-popups-drag.html-b3951249122c-a710d5ac6e11-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 169
source_hash: a710d5ac6e11df79ae5ee36196f1a07af058f07666e2aa0c498afa206efaf593
normalized_document_hash: e7d4b5dc8c4e2bfe5ed77b19d2a12a8b7fd58bb6004e6360b1665f832424353a
content_status: success
content_sha256: 97eb09e3f7a8bda0c62f50190a0fcffcb92a2b8a1bc6b55755c7a94e95478fc9
---

# drag

Double-clicks an item in the list.

| Target | Required. |
| --- | --- |
| Controls | Containers, lists, trees, grids. |
| Command | The item to drag. |
| Step Properties | Step Properties Ctrl: Indicates that the Control key is pressed when executing the action Shift: Indicates that the Shift key is pressed when executing the action Alt: Indicates that the Alt key is pressed when executing the action<br>Default: [No key selected] Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
