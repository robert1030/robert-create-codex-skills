---
chunk_id: itest-help_26.2.0.zip-popups-dragdivider.html-ffdc375a8438-8cdd1a004409-chunk-0001
source_id: itest-help_26.2.0.zip-popups-dragdivider.html-ffdc375a8438-8cdd1a004409
title: dragDivider
heading_path:
- dragDivider
section_titles:
- dragDivider
source_block_ids:
- itest-help_26.2.0.zip-popups-dragdivider.html-ffdc375a8438-8cdd1a004409-block-0001
- itest-help_26.2.0.zip-popups-dragdivider.html-ffdc375a8438-8cdd1a004409-block-0002
- itest-help_26.2.0.zip-popups-dragdivider.html-ffdc375a8438-8cdd1a004409-block-0003
- itest-help_26.2.0.zip-popups-dragdivider.html-ffdc375a8438-8cdd1a004409-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 146
source_hash: 8cdd1a0044093a50ceb285b398e6392f7a76fa8caf9c04285ba1f295b180df0f
normalized_document_hash: 5616bce87d7464f579a7095ab6b8c4d02a798ed6e2beb1200d6252c26b50b3e6
content_status: success
content_sha256: a80e4b696816c1dd6831f5fb0f4dc20343a27a9eca7317b36dcc63e0b57beb82
---

# dragDivider

Drags a divider up/down or left/right, based on the type of divider.

| Target | Required. |
| --- | --- |
| Controls | Divders. |
| Command | The numeric value of how much to drag a divider. |
| Step Properties | Step Properties Index of the divider: The index of the divider tab.<br>Default: 0 Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
