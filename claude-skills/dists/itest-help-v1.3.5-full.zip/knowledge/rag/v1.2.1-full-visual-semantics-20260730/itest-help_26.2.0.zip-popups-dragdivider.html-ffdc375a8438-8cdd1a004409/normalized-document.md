# dragDivider

Drags a divider up/down or left/right, based on the type of divider.

| Target | Required. |
| --- | --- |
| Controls | Divders. |
| Command | The numeric value of how much to drag a divider. |
| Step Properties | Step Properties Index of the divider: The index of the divider tab.<br>Default: 0 Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
