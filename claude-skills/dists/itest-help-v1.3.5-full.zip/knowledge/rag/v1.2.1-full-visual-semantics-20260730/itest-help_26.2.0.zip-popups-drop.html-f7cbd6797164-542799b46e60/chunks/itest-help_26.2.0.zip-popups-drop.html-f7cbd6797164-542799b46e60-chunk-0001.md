---
chunk_id: itest-help_26.2.0.zip-popups-drop.html-f7cbd6797164-542799b46e60-chunk-0001
source_id: itest-help_26.2.0.zip-popups-drop.html-f7cbd6797164-542799b46e60
title: drop
heading_path:
- drop
section_titles:
- drop
source_block_ids:
- itest-help_26.2.0.zip-popups-drop.html-f7cbd6797164-542799b46e60-block-0001
- itest-help_26.2.0.zip-popups-drop.html-f7cbd6797164-542799b46e60-block-0002
- itest-help_26.2.0.zip-popups-drop.html-f7cbd6797164-542799b46e60-block-0003
- itest-help_26.2.0.zip-popups-drop.html-f7cbd6797164-542799b46e60-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 225
source_hash: 542799b46e604708047ecd46a9cb563b59e987d5f2ea7bebd00c0b4fc9b2d990
normalized_document_hash: b01daf94cc392bac009a6f79709af331433f98ac00ccc249bfd7f7f31f08e250
content_status: success
content_sha256: d2ced9f3092cb80c8535a3073b74cc7443e4c39fcb5d554d5597b29346bd0768
---

# drop

Completes a drag-and-drop operation. You must execute a drag action before calling a drop action.

| Target | Required. |
| --- | --- |
| Controls | containers, trees, lists, grids that is the end target of the drag-and-drop operation. |
| Command | Usually none. Optionally, the item in the drop container where the drop is performed. |
| Step Properties | Step Properties Drag action: The type of drag-and-drop performed: None, Copy, Link, Move<br>Default: None Ctrl: Indicates that the Control key is pressed when executing the action Shift: Indicates that the Shift key is pressed when executing the action Alt: Indicates that the Alt key is pressed when executing the action<br>Default: [No key selected] Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
