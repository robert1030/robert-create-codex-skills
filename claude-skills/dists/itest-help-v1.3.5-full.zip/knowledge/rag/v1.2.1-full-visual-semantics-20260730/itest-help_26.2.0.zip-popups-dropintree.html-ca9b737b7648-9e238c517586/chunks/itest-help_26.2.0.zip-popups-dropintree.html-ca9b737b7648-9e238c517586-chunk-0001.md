---
chunk_id: itest-help_26.2.0.zip-popups-dropintree.html-ca9b737b7648-9e238c517586-chunk-0001
source_id: itest-help_26.2.0.zip-popups-dropintree.html-ca9b737b7648-9e238c517586
title: dropInTree
heading_path:
- dropInTree
section_titles:
- dropInTree
source_block_ids:
- itest-help_26.2.0.zip-popups-dropintree.html-ca9b737b7648-9e238c517586-block-0001
- itest-help_26.2.0.zip-popups-dropintree.html-ca9b737b7648-9e238c517586-block-0002
- itest-help_26.2.0.zip-popups-dropintree.html-ca9b737b7648-9e238c517586-block-0003
- itest-help_26.2.0.zip-popups-dropintree.html-ca9b737b7648-9e238c517586-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 208
source_hash: 9e238c517586867e381c56b8f5a407a2c435a360d326bfed754df975e51834e8
normalized_document_hash: 1214e40a08eaec8125107e9734571d161e4204aa41a0592d6c6599088bae391f
content_status: success
content_sha256: 70acf8e25d94efc43698d94775536fae518418d7c1bbfe25479b392ad263dd27
---

# dropInTree

Completes a drag-and-drop operation into a tree node. You must execute a drag action before calling a dropInTree action.

| Target | Required. |
| --- | --- |
| Controls | Trees. |
| Command | The path to the tree node where the drop happens. |
| Step Properties | Step Properties Drag action: The type of drag-and-drop performed: None, Copy, Link, Move<br>Default: None Ctrl: Indicates that the Control key is pressed when executing the action Shift: Indicates that the Shift key is pressed when executing the action Alt: Indicates that the Alt key is pressed when executing the action<br>Default: [No key selected] Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
