# dropInTree

Completes a drag-and-drop operation into a tree node. You must execute a drag action before calling a dropInTree action.

| Target | Required. |
| --- | --- |
| Controls | Trees. |
| Command | The path to the tree node where the drop happens. |
| Step Properties | Step Properties Drag action: The type of drag-and-drop performed: None, Copy, Link, Move<br>Default: None Ctrl: Indicates that the Control key is pressed when executing the action Shift: Indicates that the Shift key is pressed when executing the action Alt: Indicates that the Alt key is pressed when executing the action<br>Default: [No key selected] Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
