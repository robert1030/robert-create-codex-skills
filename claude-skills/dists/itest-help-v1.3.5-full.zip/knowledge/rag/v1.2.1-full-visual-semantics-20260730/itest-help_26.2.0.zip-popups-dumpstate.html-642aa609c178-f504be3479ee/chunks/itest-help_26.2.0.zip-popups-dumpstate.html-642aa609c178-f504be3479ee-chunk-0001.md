---
chunk_id: itest-help_26.2.0.zip-popups-dumpstate.html-642aa609c178-f504be3479ee-chunk-0001
source_id: itest-help_26.2.0.zip-popups-dumpstate.html-642aa609c178-f504be3479ee
title: dumpState
heading_path:
- dumpState
section_titles:
- dumpState
source_block_ids:
- itest-help_26.2.0.zip-popups-dumpstate.html-642aa609c178-f504be3479ee-block-0001
- itest-help_26.2.0.zip-popups-dumpstate.html-642aa609c178-f504be3479ee-block-0002
- itest-help_26.2.0.zip-popups-dumpstate.html-642aa609c178-f504be3479ee-block-0003
- itest-help_26.2.0.zip-popups-dumpstate.html-642aa609c178-f504be3479ee-block-0004
- itest-help_26.2.0.zip-popups-dumpstate.html-642aa609c178-f504be3479ee-block-0005
- itest-help_26.2.0.zip-popups-dumpstate.html-642aa609c178-f504be3479ee-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 174
source_hash: f504be3479ee2dbde45f44970a115d9b47358c3c03eeb3681a123f5cb5300162
normalized_document_hash: d42e7623b244ad029bb2063ad1018ed4258d047c5bb7c9d0e524c84ae2cc5aea
content_status: success
content_sha256: a11cd735a288f8d3918d58a029423dab15957c818bd2f57b8c0269165ea27e2d
---

# dumpState

The response to a dumpState step (commonly used for troubleshooting) can include any or all of the following information:

- Execution thread information (the data that would currently be displayed in the Threads view)
- The data that would currently be displayed in the Data view
- The identical content as is returned by a summarize step
- The response to a dumpState step appears in the Response view.
- The response is automatically mapped, so you do not have to create a response map.

The Description cell (the value of the Command property) for a dumpState step is blank.

Tip: Use a mail session and a response field replacement .
to write the response to the dumpState step into the body of an email message.

For details and restrictions, see the online help: The dumpState action .
