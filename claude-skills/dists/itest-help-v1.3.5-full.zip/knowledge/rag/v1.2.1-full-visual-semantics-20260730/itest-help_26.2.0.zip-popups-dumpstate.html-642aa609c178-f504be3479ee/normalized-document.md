# dumpState

The response to a dumpState step (commonly used for troubleshooting) can include any or all of the following information:

- Execution thread information (the data that would currently be displayed in the Threads view)
- The data that would currently be displayed in the Data view
- The identical content as is returned by a summarize step
- The response to a dumpState step appears in the Response view.
- The response is automatically mapped, so you do not have to create a response map.

The Description cell (the value of the Command property) for a dumpState step is blank.

Tip: Use a mail session and a response field replacement .
to write the response to the dumpState step into the body of an email message.

For details and restrictions, see the online help: The dumpState action .
