---
chunk_id: itest-help_26.2.0.zip-popups-elif.html-1acaa79ee6ab-766a1a51e652-chunk-0001
source_id: itest-help_26.2.0.zip-popups-elif.html-1acaa79ee6ab-766a1a51e652
title: elif
heading_path:
- elif
section_titles:
- elif
source_block_ids:
- itest-help_26.2.0.zip-popups-elif.html-1acaa79ee6ab-766a1a51e652-block-0001
- itest-help_26.2.0.zip-popups-elif.html-1acaa79ee6ab-766a1a51e652-block-0002
- itest-help_26.2.0.zip-popups-elif.html-1acaa79ee6ab-766a1a51e652-block-0003
- itest-help_26.2.0.zip-popups-elif.html-1acaa79ee6ab-766a1a51e652-block-0005
- itest-help_26.2.0.zip-popups-elif.html-1acaa79ee6ab-766a1a51e652-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 118
source_hash: 766a1a51e652a0eef96df337d580563097af1b4602e8175286eb2c17d9ddabd8
normalized_document_hash: 70b197d96d410defa653a35867b3b0b5c1f752f71a2b42a9b104263c7aa711aa
content_status: success
content_sha256: bab03e664fe51537422e250ddf5a66d18f8521b13ec808ce95154f5fbc14bdde
---

# elif

An optional EXEC elseif step is a part of an if-elif-else construct.

An EXEC elif step is legal only when it immediately follows an if statement or another elif statement. The command for elif contains an assertion. If no previous if or elif step that is associated with the elif was True and the elif assertion is True, then its nested steps will be executed.

If a previous if or elif assertion was True, then the elif assertion not tested.

See the online help for tips on adding if-then constructs .
