---
chunk_id: itest-help_26.2.0.zip-popups-elif_python.html-da1510b25672-3cfc6516cb9a-chunk-0001
source_id: itest-help_26.2.0.zip-popups-elif_python.html-da1510b25672-3cfc6516cb9a
title: elif
heading_path:
- elif
section_titles:
- elif
source_block_ids:
- itest-help_26.2.0.zip-popups-elif_python.html-da1510b25672-3cfc6516cb9a-block-0001
- itest-help_26.2.0.zip-popups-elif_python.html-da1510b25672-3cfc6516cb9a-block-0002
- itest-help_26.2.0.zip-popups-elif_python.html-da1510b25672-3cfc6516cb9a-block-0003
- itest-help_26.2.0.zip-popups-elif_python.html-da1510b25672-3cfc6516cb9a-block-0005
- itest-help_26.2.0.zip-popups-elif_python.html-da1510b25672-3cfc6516cb9a-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 119
source_hash: 3cfc6516cb9a934b38174188af8ed2b15bb0f40688a5dedd8d6e99777a12d543
normalized_document_hash: 3bc73569bed2c88dd59b08bc0601722910723353b396f5aae165a276a825b33b
content_status: success
content_sha256: 59a56c884976e46a34d733e47bc313fc520ac02f1664115b23738c4ea5cc2585
---

# elif

An optional EXEC elif step is a part of an if-elif-else construct.

An EXEC elif step is legal only when it immediately follows an if statement or another elif statement. The command for elif contains an assertion. If no previous if or elif step that is associated with the elif was True and the elif assertion is True, then its nested steps will be executed.

If a previous if or elif assertion was True, then the elif will not be tested.

See the online help for tips on adding if-then constructs .
