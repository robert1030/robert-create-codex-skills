# elif

An optional EXEC elif step is a part of an if-elif-else construct.

An EXEC elif step is legal only when it immediately follows an if statement or another elif statement. The command for elif contains an assertion. If no previous if or elif step that is associated with the elif was True and the elif assertion is True, then its nested steps will be executed.

If a previous if or elif assertion was True, then the elif will not be tested.

See the online help for tips on adding if-then constructs .
