---
chunk_id: itest-help_26.2.0.zip-popups-else.html-f712576086b1-88451792732f-chunk-0001
source_id: itest-help_26.2.0.zip-popups-else.html-f712576086b1-88451792732f
title: else
heading_path:
- else
section_titles:
- else
source_block_ids:
- itest-help_26.2.0.zip-popups-else.html-f712576086b1-88451792732f-block-0001
- itest-help_26.2.0.zip-popups-else.html-f712576086b1-88451792732f-block-0002
- itest-help_26.2.0.zip-popups-else.html-f712576086b1-88451792732f-block-0003
- itest-help_26.2.0.zip-popups-else.html-f712576086b1-88451792732f-block-0004
- itest-help_26.2.0.zip-popups-else.html-f712576086b1-88451792732f-block-0006
- itest-help_26.2.0.zip-popups-else.html-f712576086b1-88451792732f-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 166
source_hash: 88451792732f69da3355a69d52b62a5d718379c3cfdd843900ebdbf7b13cac96
normalized_document_hash: 831a755f02410c6430a7c6252d93c7bcf71dc9695965586170c982c9f1321bad
content_status: success
content_sha256: 6f3cbb967c05ed591609b0c666f51bde1a495a3f3c78333392e4d90eb4115c60
---

# else

An optional EXEC else step is a part of an if-then-elseif-else construct.

An else step is similar to elseif , but it must come last in the sequence of steps associated with the if construct.

If the assertion associated with the else is True, then its nested steps will be executed as long as no previous associated if or elseif has been actioned

Note: A legal contiguous sequence of if , then , elseif , and else steps will have one if step, followed by one then step, followed by zero or more elseif steps followed by zero or one else step.
Any other sequence is illegal. No other types of steps within the scope can be interleaved in these sequences.

See the online help for tips on adding if-then constructs .
