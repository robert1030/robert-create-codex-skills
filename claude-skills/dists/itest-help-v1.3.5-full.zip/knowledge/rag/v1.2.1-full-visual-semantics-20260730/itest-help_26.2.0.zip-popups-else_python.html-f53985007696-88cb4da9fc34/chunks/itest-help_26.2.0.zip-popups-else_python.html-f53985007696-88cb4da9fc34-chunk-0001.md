---
chunk_id: itest-help_26.2.0.zip-popups-else_python.html-f53985007696-88cb4da9fc34-chunk-0001
source_id: itest-help_26.2.0.zip-popups-else_python.html-f53985007696-88cb4da9fc34
title: else
heading_path:
- else
section_titles:
- else
source_block_ids:
- itest-help_26.2.0.zip-popups-else_python.html-f53985007696-88cb4da9fc34-block-0001
- itest-help_26.2.0.zip-popups-else_python.html-f53985007696-88cb4da9fc34-block-0002
- itest-help_26.2.0.zip-popups-else_python.html-f53985007696-88cb4da9fc34-block-0003
- itest-help_26.2.0.zip-popups-else_python.html-f53985007696-88cb4da9fc34-block-0004
- itest-help_26.2.0.zip-popups-else_python.html-f53985007696-88cb4da9fc34-block-0006
- itest-help_26.2.0.zip-popups-else_python.html-f53985007696-88cb4da9fc34-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 158
source_hash: 88cb4da9fc34912d51b6676f0813695a61759fd80660334e37b5db274c86e456
normalized_document_hash: 30861468a57a69da091173dfdb9c869b8d12e6291eedf0f5fb744896663b4f0b
content_status: success
content_sha256: 3cf7d1148f9c9a30efcf68d43ddd70d8d73b71ec9e56926527c1b01d4314df85
---

# else

An optional EXEC else step is a part of an if-elif-else construct.

An else step is similar to elif , but it must come last in the sequence of steps associated with the if construct.

If the assertion associated with the else is True, then its nested steps will be executed as long as no previous associated if or elif has been actioned.

Note: A legal contiguous sequence of if , elif , and else steps will have one if step, followed by zero or more elif steps followed by zero or one else step.
Any other sequence is illegal. No other types of steps within the scope can be interleaved in these sequences.

See the online help for tips on adding if constructs .
