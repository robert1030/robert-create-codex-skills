# else

An optional EXEC else step is a part of an if-elif-else construct.

An else step is similar to elif , but it must come last in the sequence of steps associated with the if construct.

If the assertion associated with the else is True, then its nested steps will be executed as long as no previous associated if or elif has been actioned.

Note: A legal contiguous sequence of if , elif , and else steps will have one if step, followed by zero or more elif steps followed by zero or one else step.
Any other sequence is illegal. No other types of steps within the scope can be interleaved in these sequences.

See the online help for tips on adding if constructs .
