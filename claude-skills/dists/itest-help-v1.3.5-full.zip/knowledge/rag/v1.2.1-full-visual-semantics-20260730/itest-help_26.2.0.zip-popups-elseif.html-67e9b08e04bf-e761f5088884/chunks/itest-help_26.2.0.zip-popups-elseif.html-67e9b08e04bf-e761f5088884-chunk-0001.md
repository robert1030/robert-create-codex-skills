---
chunk_id: itest-help_26.2.0.zip-popups-elseif.html-67e9b08e04bf-e761f5088884-chunk-0001
source_id: itest-help_26.2.0.zip-popups-elseif.html-67e9b08e04bf-e761f5088884
title: elseif
heading_path:
- elseif
section_titles:
- elseif
source_block_ids:
- itest-help_26.2.0.zip-popups-elseif.html-67e9b08e04bf-e761f5088884-block-0001
- itest-help_26.2.0.zip-popups-elseif.html-67e9b08e04bf-e761f5088884-block-0002
- itest-help_26.2.0.zip-popups-elseif.html-67e9b08e04bf-e761f5088884-block-0003
- itest-help_26.2.0.zip-popups-elseif.html-67e9b08e04bf-e761f5088884-block-0005
- itest-help_26.2.0.zip-popups-elseif.html-67e9b08e04bf-e761f5088884-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 118
source_hash: e761f50888840b7b0c4bd4365643b2af94f138dc578ed3e3587ff12ca281e807
normalized_document_hash: 9ab31e26081aa24c0fb31985b24a2a5129fd5e2f16a341adb2d41e9261bca132
content_status: success
content_sha256: 7cc83e1d5cafd9a23d457f0662f6b25318a9ea48af1fb4862f92cd72ea4ba103
---

# elseif

An optional EXEC elseif step is a part of an if-then-elseif-else construct.

An EXEC elseif step is legal only when it immediately follows an if statement or another elseif statement. The command for elseif contains an assertion. If no previous if or elseif step that is associated with the elseif was True and the elseif assertion is True, then its nested steps will be executed.

If a previous if or elseif assertion was True, then the elseif assertion not tested.

See the online help for tips on adding if-then constructs .
