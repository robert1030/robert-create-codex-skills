---
chunk_id: itest-help_26.2.0.zip-popups-eval_exec.html-9334b343c64f-afafef136f64-chunk-0001
source_id: itest-help_26.2.0.zip-popups-eval_exec.html-9334b343c64f-afafef136f64
title: eval
heading_path:
- eval
section_titles:
- eval
source_block_ids:
- itest-help_26.2.0.zip-popups-eval_exec.html-9334b343c64f-afafef136f64-block-0001
- itest-help_26.2.0.zip-popups-eval_exec.html-9334b343c64f-afafef136f64-block-0002
- itest-help_26.2.0.zip-popups-eval_exec.html-9334b343c64f-afafef136f64-block-0003
- itest-help_26.2.0.zip-popups-eval_exec.html-9334b343c64f-afafef136f64-block-0004
- itest-help_26.2.0.zip-popups-eval_exec.html-9334b343c64f-afafef136f64-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 131
source_hash: afafef136f649cf20dfa2db10432cef766d8b8e74edffd6b4656adc9c290786b
normalized_document_hash: 109b8c122d5877bffbf27f4de3c9e7230e944435e4118cb9ee8530712e26bc94
content_status: success
content_sha256: a9e8f4637b2fe31711958cef68e6ccf7e7a99f29b507b6408637730f30a16910
---

# eval

The eval action evaluates the statements specified in the Description cell (the value of the Command property). (The statements must use iTest command syntax, as described in Command syntax for test case steps .)

For example, the eval action with a Command of set port 4 sets the value of a local variable named port to the value 4 .

- Because eval operates on the whole command text (which can be multi-line), you can
execute multiple statements with a single eval statement.
- There is no Session associated with an eval Action.

For details, see the online help: The eval action .
