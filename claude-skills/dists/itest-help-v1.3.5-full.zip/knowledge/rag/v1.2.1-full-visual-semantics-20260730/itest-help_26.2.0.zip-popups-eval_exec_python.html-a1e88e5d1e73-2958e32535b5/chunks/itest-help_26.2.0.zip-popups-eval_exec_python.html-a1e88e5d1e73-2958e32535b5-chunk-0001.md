---
chunk_id: itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-chunk-0001
source_id: itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5
title: eval
heading_path:
- eval
section_titles:
- eval
source_block_ids:
- itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-block-0001
- itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-block-0002
- itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-block-0003
- itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-block-0004
- itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-block-0005
- itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-block-0006
- itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-block-0007
- itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-block-0008
- itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-block-0009
- itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-block-0010
- itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-block-0011
- itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-block-0012
- itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-block-0013
- itest-help_26.2.0.zip-popups-eval_exec_python.html-a1e88e5d1e73-2958e32535b5-block-0014
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 142
source_hash: 2958e32535b57c8662e0d39df2aa355d1d7dcc2e3cecb5293387acaf49372fc8
normalized_document_hash: 4d5f458e1d0e38c6f588e9538d7c1b7b89bcae7fe91aa5324022afc7b3d7d3d9
content_status: success
content_sha256: 91edaf11f9cb3571cd3a7cf83e344910c6b41edb64266b3b071ddad640f7143c
---

# eval

eval (any valid Python command)

The

eval

action evaluates the statements specified in the

Description

cell (the value of the

Command

property). (The statements must use Python command syntax, as described in

Command syntax for test case steps

.)

For example, the eval action with a Command of port = 4 sets the value of a local variable named port to the value 4 . Syntax: port = 4

- Because eval operates on the whole command text (which can be multi-line), you can
execute multiple statements with a single eval statement.
- There is no Session associated with an eval Action.

For details, see the online help: The eval action .
