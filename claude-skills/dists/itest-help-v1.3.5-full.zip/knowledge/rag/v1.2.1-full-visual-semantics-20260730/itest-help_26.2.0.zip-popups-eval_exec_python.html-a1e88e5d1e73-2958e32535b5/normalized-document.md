# eval

eval (any valid Python command)

The

eval

action evaluates the statements specified in the

Description

cell (the value of the

Command

property). (The statements must use Python command syntax, as described in

Command syntax for test case steps

.)

For example, the eval action with a Command of port = 4 sets the value of a local variable named port to the value 4 . Syntax: port = 4

- Because eval operates on the whole command text (which can be multi-line), you can
execute multiple statements with a single eval statement.
- There is no Session associated with an eval Action.

For details, see the online help: The eval action .
