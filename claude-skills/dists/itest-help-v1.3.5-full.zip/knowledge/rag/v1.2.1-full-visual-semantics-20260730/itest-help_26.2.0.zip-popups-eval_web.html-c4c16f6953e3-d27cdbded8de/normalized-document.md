# eval

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| eval | Not Required | Required | Executes the specified JavaScript in the context of the selected window. The Command property specifies the JavaScript code to evaluate. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
