---
chunk_id: itest-help_26.2.0.zip-popups-execute.html-e5cbb3a81321-5e12e0aecfe3-chunk-0001
source_id: itest-help_26.2.0.zip-popups-execute.html-e5cbb3a81321-5e12e0aecfe3
title: execute
heading_path:
- execute
section_titles:
- execute
source_block_ids:
- itest-help_26.2.0.zip-popups-execute.html-e5cbb3a81321-5e12e0aecfe3-block-0001
- itest-help_26.2.0.zip-popups-execute.html-e5cbb3a81321-5e12e0aecfe3-block-0002
- itest-help_26.2.0.zip-popups-execute.html-e5cbb3a81321-5e12e0aecfe3-block-0003
- itest-help_26.2.0.zip-popups-execute.html-e5cbb3a81321-5e12e0aecfe3-block-0004
- itest-help_26.2.0.zip-popups-execute.html-e5cbb3a81321-5e12e0aecfe3-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 109
source_hash: 5e12e0aecfe31ffa6e377d5063e99c285e421a3ff2c707d5673b824adffb9687
normalized_document_hash: 22e675654c196024d42a4cf75322eb0cd9c53566bcca9715cf95639a23dcc8a9
content_status: success
content_sha256: 88497db8729bdc83272b1760a702035979460e3015aaa7eee09aa616e62b5027
---

# execute

The execute command executes the SQL statement that you specify in the Command property ( Description cell ) for the step.

For statements that return records, the command returns the first record or first page of records, depending on the setting for the Fetch single record at a time property in the session profile.

In an interactive session, when you click the Execute button, iTest captures an execute action.

For details on using this and other iTest interpreter commands, see Database Client command set .
