---
chunk_id: itest-help_26.2.0.zip-popups-exit_exec.html-d08ec26118ce-d2b5d5416a9b-chunk-0001
source_id: itest-help_26.2.0.zip-popups-exit_exec.html-d08ec26118ce-d2b5d5416a9b
title: exit
heading_path:
- exit
section_titles:
- exit
source_block_ids:
- itest-help_26.2.0.zip-popups-exit_exec.html-d08ec26118ce-d2b5d5416a9b-block-0001
- itest-help_26.2.0.zip-popups-exit_exec.html-d08ec26118ce-d2b5d5416a9b-block-0002
- itest-help_26.2.0.zip-popups-exit_exec.html-d08ec26118ce-d2b5d5416a9b-block-0003
- itest-help_26.2.0.zip-popups-exit_exec.html-d08ec26118ce-d2b5d5416a9b-block-0004
- itest-help_26.2.0.zip-popups-exit_exec.html-d08ec26118ce-d2b5d5416a9b-block-0005
- itest-help_26.2.0.zip-popups-exit_exec.html-d08ec26118ce-d2b5d5416a9b-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 88
source_hash: d2b5d5416a9b184624e7c6467b6d04eae8555372b2319c189739cbf8e27e2ee4
normalized_document_hash: a778f04a3bbabb6e5e1c2fea466f2220a99c7b8fd1b1778c051e5329d1be4700
content_status: success
content_sha256: fbc80fc605bace63fc0cb32f00267fc93c5bf33e904d1ea2a8634bc8c30f33e2
---

# exit

An exit action immediately stops executing the current procedure and all threads to end test case execution.

An exit step does not change the existing execution status of the test case (Pass, Fail, or Indeterminate).

An appropriate execution message appears in the Execution view, in the Step Issues view, and in test reports.

No configurable properties.

For details, see the online help: The exit action .
