---
chunk_id: itest-help_26.2.0.zip-popups-exitexecution.html-a55e81b326fb-41560b82f064-chunk-0001
source_id: itest-help_26.2.0.zip-popups-exitexecution.html-a55e81b326fb-41560b82f064
title: ExitExecution
heading_path:
- ExitExecution
section_titles:
- ExitExecution
source_block_ids:
- itest-help_26.2.0.zip-popups-exitexecution.html-a55e81b326fb-41560b82f064-block-0001
- itest-help_26.2.0.zip-popups-exitexecution.html-a55e81b326fb-41560b82f064-block-0002
- itest-help_26.2.0.zip-popups-exitexecution.html-a55e81b326fb-41560b82f064-block-0003
- itest-help_26.2.0.zip-popups-exitexecution.html-a55e81b326fb-41560b82f064-block-0004
- itest-help_26.2.0.zip-popups-exitexecution.html-a55e81b326fb-41560b82f064-block-0005
- itest-help_26.2.0.zip-popups-exitexecution.html-a55e81b326fb-41560b82f064-block-0006
- itest-help_26.2.0.zip-popups-exitexecution.html-a55e81b326fb-41560b82f064-block-0007
- itest-help_26.2.0.zip-popups-exitexecution.html-a55e81b326fb-41560b82f064-block-0008
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 92
source_hash: 41560b82f0648e97c93774c0daf974dffbf366767e6d46b215970495357073c1
normalized_document_hash: b7ed4ee65007be34c51747d055849727931dafa621940fb5102ee071280601cf
content_status: success
content_sha256: 9eec11e6b067767f1bfa20c2e974f3f6f53624acbde16367ee606a9b05682838
---

# ExitExecution

An ExitExecution action immediately stops executing the current procedure and all threads to end test case execution.

Does not change the existing execution status of the test case (Pass, Fail, or Indeterminate).

An appropriate execution message appears in the Execution view, in the Step Issues view,  and in test reports.

No configurable properties.

For details, see the online help:

Global Events page

Analysis rules: Properties of the processor
