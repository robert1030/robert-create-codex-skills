# ExitExecution

An ExitExecution action immediately stops executing the current procedure and all threads to end test case execution.

Does not change the existing execution status of the test case (Pass, Fail, or Indeterminate).

An appropriate execution message appears in the Execution view, in the Step Issues view,  and in test reports.

No configurable properties.

For details, see the online help:

Global Events page

Analysis rules: Properties of the processor
