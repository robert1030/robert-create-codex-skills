---
chunk_id: itest-help_26.2.0.zip-popups-exitprocedure.html-d6c9529e695c-333e28056ad9-chunk-0001
source_id: itest-help_26.2.0.zip-popups-exitprocedure.html-d6c9529e695c-333e28056ad9
title: Properties
heading_path:
- Properties
section_titles:
- ExitProcedure
- Properties
source_block_ids:
- itest-help_26.2.0.zip-popups-exitprocedure.html-d6c9529e695c-333e28056ad9-block-0001
- itest-help_26.2.0.zip-popups-exitprocedure.html-d6c9529e695c-333e28056ad9-block-0002
- itest-help_26.2.0.zip-popups-exitprocedure.html-d6c9529e695c-333e28056ad9-block-0003
- itest-help_26.2.0.zip-popups-exitprocedure.html-d6c9529e695c-333e28056ad9-block-0004
- itest-help_26.2.0.zip-popups-exitprocedure.html-d6c9529e695c-333e28056ad9-block-0005
- itest-help_26.2.0.zip-popups-exitprocedure.html-d6c9529e695c-333e28056ad9-block-0006
- itest-help_26.2.0.zip-popups-exitprocedure.html-d6c9529e695c-333e28056ad9-block-0007
- itest-help_26.2.0.zip-popups-exitprocedure.html-d6c9529e695c-333e28056ad9-block-0008
- itest-help_26.2.0.zip-popups-exitprocedure.html-d6c9529e695c-333e28056ad9-block-0009
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 199
source_hash: 333e28056ad9f098456221de39dcbe97a413daeede1e8c1fd4d369ca62af6ec5
normalized_document_hash: 044b30abaa89790c9e466801539053f1d2c5f3f2e24d3b1c232fb9e71a2c2dcf
content_status: success
content_sha256: dfa359a92a3ee927749c220f7250170882b91a7824ccb819a0250176af2b9f56
---

# ExitProcedure

Stop executing the current procedure and return execution from the current procedure to the caller.

Important: Because this action alters the flow of execution, it is deferred (not executed) until all other actions for the step are executed. This is true even if this action appears before other actions in the list of actions for the event and if there are additional analysis rules listed after the current rule for the step. For example, even if a FailTest action appears last in the list after an ExitProcedure action, the ExitProcedure action does not execute until the FailTest action is finished executing.

An appropriate execution message appears in the Execution view and in test reports.

# Properties

Return value : Specify the value to return for the procedure. The text string can contain field replacements (for example, [response var_name] ).

For details, see the online help:

Global Events page

Analysis rules: Properties of the processor
