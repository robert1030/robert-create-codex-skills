---
chunk_id: itest-help_26.2.0.zip-popups-expandnode.html-f9ff80f0c0f8-2cec9a4cdd8a-chunk-0001
source_id: itest-help_26.2.0.zip-popups-expandnode.html-f9ff80f0c0f8-2cec9a4cdd8a
title: expandNode
heading_path:
- expandNode
section_titles:
- expandNode
source_block_ids:
- itest-help_26.2.0.zip-popups-expandnode.html-f9ff80f0c0f8-2cec9a4cdd8a-block-0001
- itest-help_26.2.0.zip-popups-expandnode.html-f9ff80f0c0f8-2cec9a4cdd8a-block-0002
- itest-help_26.2.0.zip-popups-expandnode.html-f9ff80f0c0f8-2cec9a4cdd8a-block-0003
- itest-help_26.2.0.zip-popups-expandnode.html-f9ff80f0c0f8-2cec9a4cdd8a-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 184
source_hash: 2cec9a4cdd8afdfcfe9677ed7dad7a892a9caf965cdbb360c9733877c2d9ca0f
normalized_document_hash: 0e645ba04e2e518c601c9833061a908e3afcd8a77f17c862c340b9b95e45b55a
content_status: success
content_sha256: 374027aea13a440162a6532a32d960b6b1cfdfb67e5f82d9572550c6e446495b
---

# expandNode

Expands the specified node in a tree.

| Target | Required. |
| --- | --- |
| Controls | Trees. |
| Command | The path to the node to expand. Path is specified by labels or indices separated by the ‘>’ character, for example Countries>France>Paris. |
| Step Properties | Step Properties Trigger: Mouse or Keyboard used to perform the action.<br>Default: Mouse Use index: Check the box if the command specifies the node path by indices, for example 0>1>1<br>Default: unchecked Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
