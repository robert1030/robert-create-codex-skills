# expandNode

Expands the specified node in a tree.

| Target | Required. |
| --- | --- |
| Controls | Trees. |
| Command | The path to the node to expand. Path is specified by labels or indices separated by the ‘>’ character, for example Countries>France>Paris. |
| Step Properties | Step Properties Trigger: Mouse or Keyboard used to perform the action.<br>Default: Mouse Use index: Check the box if the command specifies the node path by indices, for example 0>1>1<br>Default: unchecked Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
