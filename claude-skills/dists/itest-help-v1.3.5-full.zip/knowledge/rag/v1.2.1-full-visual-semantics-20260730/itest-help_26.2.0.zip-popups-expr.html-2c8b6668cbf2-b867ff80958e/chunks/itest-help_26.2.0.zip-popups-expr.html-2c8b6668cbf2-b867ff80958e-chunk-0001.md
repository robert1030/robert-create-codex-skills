---
chunk_id: itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-chunk-0001
source_id: itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e
title: Examples
heading_path:
- Examples
section_titles:
- expr
- Examples
source_block_ids:
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0001
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0002
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0003
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0004
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0005
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0006
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0007
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0008
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0009
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0010
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0011
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0012
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0013
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0014
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0015
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0016
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0017
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0018
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0019
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0020
- itest-help_26.2.0.zip-popups-expr.html-2c8b6668cbf2-b867ff80958e-block-0021
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 143
source_hash: b867ff80958eef871df8c3bd41e8dac438ae27edfcf42a897fe4b807e308aef1
normalized_document_hash: fdb05fd584b8328185114ab48def9c2fede069df427a9d593650276999c71fe0
content_status: success
content_sha256: 231f74021f28e7df8e5d691a2f470a97e6232d94ccf449bcb5d82ce8bc80ec4a
---

# expr

expr

mathematicalExpression

Evaluates the specified expression (typically into the text of a command or a property). The result of the query is converted into a string and inserted in place of this command.

# Examples

[expr 5 + 5]

: replaced by

10

[expr $i + 1]

:

$i

is first substituted. If

i

has value

10

, then the result of this command is

11

.

For details and more examples, see the online help: Placing non-printing characters into commands and properties .

Also: Field replacements: Substituting values into properties and commands .

For details on using this and other iTest interpreter commands, see the online help: Command syntax for test case steps .
