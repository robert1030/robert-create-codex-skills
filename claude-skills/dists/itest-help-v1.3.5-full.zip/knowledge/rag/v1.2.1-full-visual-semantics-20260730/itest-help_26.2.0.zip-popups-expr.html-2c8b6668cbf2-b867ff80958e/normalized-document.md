# expr

expr

mathematicalExpression

Evaluates the specified expression (typically into the text of a command or a property). The result of the query is converted into a string and inserted in place of this command.

# Examples

[expr 5 + 5]

: replaced by

10

[expr $i + 1]

:

$i

is first substituted. If

i

has value

10

, then the result of this command is

11

.

For details and more examples, see the online help: Placing non-printing characters into commands and properties .

Also: Field replacements: Substituting values into properties and commands .

For details on using this and other iTest interpreter commands, see the online help: Command syntax for test case steps .
