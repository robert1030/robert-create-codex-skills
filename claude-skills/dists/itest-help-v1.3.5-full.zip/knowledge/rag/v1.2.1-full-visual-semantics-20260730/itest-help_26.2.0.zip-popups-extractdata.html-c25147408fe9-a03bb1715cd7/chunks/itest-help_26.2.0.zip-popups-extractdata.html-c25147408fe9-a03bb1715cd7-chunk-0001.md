---
chunk_id: itest-help_26.2.0.zip-popups-extractdata.html-c25147408fe9-a03bb1715cd7-chunk-0001
source_id: itest-help_26.2.0.zip-popups-extractdata.html-c25147408fe9-a03bb1715cd7
title: extractData
heading_path:
- extractData
section_titles:
- extractData
source_block_ids:
- itest-help_26.2.0.zip-popups-extractdata.html-c25147408fe9-a03bb1715cd7-block-0001
- itest-help_26.2.0.zip-popups-extractdata.html-c25147408fe9-a03bb1715cd7-block-0002
- itest-help_26.2.0.zip-popups-extractdata.html-c25147408fe9-a03bb1715cd7-block-0003
- itest-help_26.2.0.zip-popups-extractdata.html-c25147408fe9-a03bb1715cd7-block-0004
- itest-help_26.2.0.zip-popups-extractdata.html-c25147408fe9-a03bb1715cd7-block-0005
- itest-help_26.2.0.zip-popups-extractdata.html-c25147408fe9-a03bb1715cd7-block-0006
- itest-help_26.2.0.zip-popups-extractdata.html-c25147408fe9-a03bb1715cd7-block-0007
- itest-help_26.2.0.zip-popups-extractdata.html-c25147408fe9-a03bb1715cd7-block-0008
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 96
source_hash: a03bb1715cd7695fa44d1147005a9acb1709b9ba6ae1aa2c6c0e5f2c4bbc676a
normalized_document_hash: 2960f3d2a59aebde1ad84eb3e6f52380f680269a44817232b796fd7c7d5af620
content_status: success
content_sha256: 1464c0ae7bf3728bac69e6270c3bf3def8e23f0c3a42d2988652bc8a822e370e
---

# extractData

extractData allows you to specify a data tag/value pair in the associated Description field, which is extracted and reported.

Tcl Syntax: tag_name :  $ tag_value

Python Syntax: tag_name : tag_value

The extractData action requires these two arguments.

Tag: (Field substitution disabled) Define the data tag to extract.

Value: (Field substitution enabled) Define the value of the tag to be extracted and stored.

For details, see the online help: The extractData action .
