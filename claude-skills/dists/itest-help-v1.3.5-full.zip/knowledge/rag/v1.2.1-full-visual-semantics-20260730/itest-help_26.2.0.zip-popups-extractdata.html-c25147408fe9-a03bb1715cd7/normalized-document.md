# extractData

extractData allows you to specify a data tag/value pair in the associated Description field, which is extracted and reported.

Tcl Syntax: tag_name :  $ tag_value

Python Syntax: tag_name : tag_value

The extractData action requires these two arguments.

Tag: (Field substitution disabled) Define the data tag to extract.

Value: (Field substitution enabled) Define the value of the tag to be extracted and stored.

For details, see the online help: The extractData action .
