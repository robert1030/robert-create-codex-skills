---
chunk_id: itest-help_26.2.0.zip-popups-extractdata_python.html-bd4c272f4fd3-ee2675d429b9-chunk-0001
source_id: itest-help_26.2.0.zip-popups-extractdata_python.html-bd4c272f4fd3-ee2675d429b9
title: extractData
heading_path:
- extractData
section_titles:
- extractData
source_block_ids:
- itest-help_26.2.0.zip-popups-extractdata_python.html-bd4c272f4fd3-ee2675d429b9-block-0001
- itest-help_26.2.0.zip-popups-extractdata_python.html-bd4c272f4fd3-ee2675d429b9-block-0002
- itest-help_26.2.0.zip-popups-extractdata_python.html-bd4c272f4fd3-ee2675d429b9-block-0003
- itest-help_26.2.0.zip-popups-extractdata_python.html-bd4c272f4fd3-ee2675d429b9-block-0004
- itest-help_26.2.0.zip-popups-extractdata_python.html-bd4c272f4fd3-ee2675d429b9-block-0005
- itest-help_26.2.0.zip-popups-extractdata_python.html-bd4c272f4fd3-ee2675d429b9-block-0006
- itest-help_26.2.0.zip-popups-extractdata_python.html-bd4c272f4fd3-ee2675d429b9-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 90
source_hash: ee2675d429b9f1045ba465b786015bda78759c073d0bd0afff4a67d14fbcef4b
normalized_document_hash: aab32cf8cbd7b5c7ca7d0b441b17753e0456b14ffab1cd7b7a02974f856a4f82
content_status: success
content_sha256: 530ed1816cb2e06852b8642dc9a8da591794f1bc9ddbfbc3752b94dc59b0ccff
---

# extractData

extractData allows you to specify a data tag/value pair in the associated Description field, which is extracted and reported.

Python Syntax: tag_name : tag_value

The extractData action requires these two arguments.

Tag: (Field substitution disabled) Define the data tag to extract.

Value: (Field substitution enabled) Define the value of the tag to be extracted and stored.

For details, see the online help: The extractData action .
