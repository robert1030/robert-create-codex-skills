---
chunk_id: itest-help_26.2.0.zip-popups-file.html-9f9d5f3fb767-7af5acae91a0-chunk-0001
source_id: itest-help_26.2.0.zip-popups-file.html-9f9d5f3fb767-7af5acae91a0
title: file
heading_path:
- file
section_titles:
- file
source_block_ids:
- itest-help_26.2.0.zip-popups-file.html-9f9d5f3fb767-7af5acae91a0-block-0001
- itest-help_26.2.0.zip-popups-file.html-9f9d5f3fb767-7af5acae91a0-block-0002
- itest-help_26.2.0.zip-popups-file.html-9f9d5f3fb767-7af5acae91a0-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 352
source_hash: 7af5acae91a00668c731dc8b1fe6e5c3a8e7c22b335a39b3ca5e164f20060528
normalized_document_hash: 4160e46d9e9306fb0a224f4d0d6ddc95fd803ae466b6aeb7dc4b29d3b727ea41
content_status: success
content_sha256: d3833b79678c0de9b1831ce5a5f6fa5d5ca03f6b1e5753a5d5af7da842d3790c
---

# file

The file commands operate on the file system. You can use an eval action with a file command or can use the command in a field replacement.

- file copy
- [
- -y
- ]
- sourceURI
- destinationURI
- Copies files from the specified source directory or file URI to the specified destination. Creates destination directories as needed.
- file delete
- [
- -r
- ]
- URI
- Deletes files from the specified directory or file URI.
- file exists
- URI
- Returns True (1) if the file or directory exists, else returns False (0).
- file isDirectory
- URI
- Returns True (1) if the URI is a directory, otherwise returns False (0).
- file isFile
- URI
- Returns True (1) if the URI is a filename, otherwise returns False (0).
- file list
- [
- -r
- ] [
- -p
- ] [
- -nolimit
- ]
- URI
- Lists all files and subdirectories for the specified directory or file URI.
- file mkdir
- URI
- Creates the specified directory.
- file mkTempDir
- [
- -k
- ] [
- prefix
- ] [
- suffix
- ] 	Creates a temporary directory.
- file mkTempFile
- [
- -k
- ] [
- prefix
- ] [
- suffix
- ]
- Creates a temporary file.
- file move
- [
- -y
- ]
- sourceURI
- destinationURI
- Moves files from the specified source directory or file URI to the specified destination. Creates destination directories as needed. The move command can rename individual files and directories.
- file pathToUri
- path
- Returns the URI for the specified directory or file path.
- file rmdir
- uri
- Deletes the specified directory.
- file uriToPath
- URI
- Returns the full operating system path for the specified URI (using appropriate path syntax).
- For details on each file subcommand, see the online help: Commands for managing files and directories .
