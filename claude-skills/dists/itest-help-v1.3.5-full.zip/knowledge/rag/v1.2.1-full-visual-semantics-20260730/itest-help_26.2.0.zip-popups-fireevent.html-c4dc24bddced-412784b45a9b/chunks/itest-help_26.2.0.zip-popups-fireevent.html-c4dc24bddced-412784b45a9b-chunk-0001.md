---
chunk_id: itest-help_26.2.0.zip-popups-fireevent.html-c4dc24bddced-412784b45a9b-chunk-0001
source_id: itest-help_26.2.0.zip-popups-fireevent.html-c4dc24bddced-412784b45a9b
title: fireEvent
heading_path:
- fireEvent
section_titles:
- fireEvent
source_block_ids:
- itest-help_26.2.0.zip-popups-fireevent.html-c4dc24bddced-412784b45a9b-block-0001
- itest-help_26.2.0.zip-popups-fireevent.html-c4dc24bddced-412784b45a9b-block-0002
- itest-help_26.2.0.zip-popups-fireevent.html-c4dc24bddced-412784b45a9b-block-0003
- itest-help_26.2.0.zip-popups-fireevent.html-c4dc24bddced-412784b45a9b-block-0004
- itest-help_26.2.0.zip-popups-fireevent.html-c4dc24bddced-412784b45a9b-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 87
source_hash: 412784b45a9b4e6e9f2896da48b989ca6ca9d65bc3bb0386b777f4f76e70975c
normalized_document_hash: 851acfb8d0a24648e9bc0a0f1fcfa8e5a58740bdc12d5fff1c96021924194954
content_status: success
content_sha256: 60c3228add70c29494f8d9c20c3f2b792d5a067b99ebedb0513620077be02a88
---

# fireEvent

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| fireEvent | Required | Not Required | For the specified element, simulates the specified JavaScript event. (Specify the event name to trigger the corresponding "onevent" handler.) For fireEvent actions, you must specify a non-zero Idle Time. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
