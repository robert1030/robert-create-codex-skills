# fireEvent

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| fireEvent | Required | Not Required | For the specified element, simulates the specified JavaScript event. (Specify the event name to trigger the corresponding "onevent" handler.) For fireEvent actions, you must specify a non-zero Idle Time. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
