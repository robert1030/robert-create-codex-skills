---
chunk_id: itest-help_26.2.0.zip-popups-for.html-c9928228d972-5ea558967eba-chunk-0001
source_id: itest-help_26.2.0.zip-popups-for.html-c9928228d972-5ea558967eba
title: for
heading_path:
- for
section_titles:
- for
source_block_ids:
- itest-help_26.2.0.zip-popups-for.html-c9928228d972-5ea558967eba-block-0001
- itest-help_26.2.0.zip-popups-for.html-c9928228d972-5ea558967eba-block-0002
- itest-help_26.2.0.zip-popups-for.html-c9928228d972-5ea558967eba-block-0003
- itest-help_26.2.0.zip-popups-for.html-c9928228d972-5ea558967eba-block-0004
- itest-help_26.2.0.zip-popups-for.html-c9928228d972-5ea558967eba-block-0005
- itest-help_26.2.0.zip-popups-for.html-c9928228d972-5ea558967eba-block-0007
- itest-help_26.2.0.zip-popups-for.html-c9928228d972-5ea558967eba-block-0008
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 127
source_hash: 5ea558967eba1fac34ba247ee05e3331ab4b022e33aa5ea608feba2c0234aec5
normalized_document_hash: bc7182fe2f1ff12e0077518e44ef7f211aa6790ad9296b40a4faadf3c85f8339
content_status: success
content_sha256: 707d3f4af9fa89e525d554196fbbfddd53335b0f7e6015807f4d9715ecec19c8
---

# for

A for loop executes a group of steps a specified number of times.

In this example, the for loop repeats the steps within the loop 10 times.

A for loop is composed of all of the steps that are indented under the for step.

The Command of the for statement takes three clauses enclosed in { and } characters -- {set i 0} {$i < 10} {incr i} in this example.

Nested loops ( if , for , foreach , and while ) are supported.

For details and tips on adding a for loop, see the online help: The for action .
