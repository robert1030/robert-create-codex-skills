# for

A for loop executes a group of steps a specified number of times.

In this example, the for loop repeats the steps within the loop 10 times.

A for loop is composed of all of the steps that are indented under the for step.

The Command of the for statement takes three clauses enclosed in { and } characters -- {set i 0} {$i < 10} {incr i} in this example.

Nested loops ( if , for , foreach , and while ) are supported.

For details and tips on adding a for loop, see the online help: The for action .
