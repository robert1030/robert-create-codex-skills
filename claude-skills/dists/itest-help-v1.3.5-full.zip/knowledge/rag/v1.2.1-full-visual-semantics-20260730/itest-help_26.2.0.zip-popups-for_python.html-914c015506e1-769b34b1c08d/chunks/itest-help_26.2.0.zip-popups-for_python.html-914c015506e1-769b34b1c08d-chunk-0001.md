---
chunk_id: itest-help_26.2.0.zip-popups-for_python.html-914c015506e1-769b34b1c08d-chunk-0001
source_id: itest-help_26.2.0.zip-popups-for_python.html-914c015506e1-769b34b1c08d
title: for
heading_path:
- for
section_titles:
- for
source_block_ids:
- itest-help_26.2.0.zip-popups-for_python.html-914c015506e1-769b34b1c08d-block-0001
- itest-help_26.2.0.zip-popups-for_python.html-914c015506e1-769b34b1c08d-block-0002
- itest-help_26.2.0.zip-popups-for_python.html-914c015506e1-769b34b1c08d-block-0003
- itest-help_26.2.0.zip-popups-for_python.html-914c015506e1-769b34b1c08d-block-0004
- itest-help_26.2.0.zip-popups-for_python.html-914c015506e1-769b34b1c08d-block-0006
- itest-help_26.2.0.zip-popups-for_python.html-914c015506e1-769b34b1c08d-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 92
source_hash: 769b34b1c08d8f424f34d805ed4e3774967f28ba2534b2c19900d5a202106326
normalized_document_hash: 63f891865b928d44e12a5fe481d4534d400dbe125a5c7d172400ab2135956a83
content_status: success
content_sha256: 6982dff28dd1c3390bdc2406edab7df8e4239a799024458b1eb219dbf6debb3f
---

# for

A for loop executes a group of steps a specified number of times.

In this example, the for loop repeats the steps within the loop 10 times.

A for loop is composed of all of the steps that are indented under the for step.

Nested loops ( if , for , and while ) are supported.

For details and tips on adding a for loop, see the online help: The for action .
