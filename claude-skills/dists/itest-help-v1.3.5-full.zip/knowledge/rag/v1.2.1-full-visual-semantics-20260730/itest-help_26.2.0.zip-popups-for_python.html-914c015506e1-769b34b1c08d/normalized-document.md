# for

A for loop executes a group of steps a specified number of times.

In this example, the for loop repeats the steps within the loop 10 times.

A for loop is composed of all of the steps that are indented under the for step.

Nested loops ( if , for , and while ) are supported.

For details and tips on adding a for loop, see the online help: The for action .
