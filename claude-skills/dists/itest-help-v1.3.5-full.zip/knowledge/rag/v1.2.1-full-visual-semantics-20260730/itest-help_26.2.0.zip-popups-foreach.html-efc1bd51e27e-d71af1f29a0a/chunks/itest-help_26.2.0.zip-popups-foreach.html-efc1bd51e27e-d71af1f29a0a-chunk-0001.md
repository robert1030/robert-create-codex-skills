---
chunk_id: itest-help_26.2.0.zip-popups-foreach.html-efc1bd51e27e-d71af1f29a0a-chunk-0001
source_id: itest-help_26.2.0.zip-popups-foreach.html-efc1bd51e27e-d71af1f29a0a
title: foreach
heading_path:
- foreach
section_titles:
- foreach
source_block_ids:
- itest-help_26.2.0.zip-popups-foreach.html-efc1bd51e27e-d71af1f29a0a-block-0001
- itest-help_26.2.0.zip-popups-foreach.html-efc1bd51e27e-d71af1f29a0a-block-0002
- itest-help_26.2.0.zip-popups-foreach.html-efc1bd51e27e-d71af1f29a0a-block-0003
- itest-help_26.2.0.zip-popups-foreach.html-efc1bd51e27e-d71af1f29a0a-block-0004
- itest-help_26.2.0.zip-popups-foreach.html-efc1bd51e27e-d71af1f29a0a-block-0005
- itest-help_26.2.0.zip-popups-foreach.html-efc1bd51e27e-d71af1f29a0a-block-0006
- itest-help_26.2.0.zip-popups-foreach.html-efc1bd51e27e-d71af1f29a0a-block-0007
- itest-help_26.2.0.zip-popups-foreach.html-efc1bd51e27e-d71af1f29a0a-block-0008
- itest-help_26.2.0.zip-popups-foreach.html-efc1bd51e27e-d71af1f29a0a-block-0009
- itest-help_26.2.0.zip-popups-foreach.html-efc1bd51e27e-d71af1f29a0a-block-0010
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 357
source_hash: d71af1f29a0a2e8d2fcfa7adad2e7f681d0c85d6829ec652ce6acd7519f74806
normalized_document_hash: 586df2caea4ed0b1f59e2387a11c8dd18fc063da88443cd1fe5e326d761412eb
content_status: success
content_sha256: b047db05f208fafc286221550297d455031a6a5660af3ad704560acd55ca78f6
---

# foreach

A foreach loop performs the steps within the loop for each value in a specified set of values.

The statement in the Description cell (the value of the Command property) of a foreach step follows Tcl foreach syntax. The simplest usage takes two lists. The first is a list of variables and the second is the list of values that the variables take on.

A foreach loop is composed of all of the steps that are indented under the foreach clause.

Example 1:  foreach A {1 3 5} In this example, the first list has a single member, A. The loop will execute 3 times with:
A = 1, A = 3, and A = 5

foreach also supports updating multiple variables in the same way as Tcl does, as shown in the following examples:

Example 2:  foreach {A B C} {a1 b1 c1 a2 b2 c2 a3 b3} Notice that the second list "runs out" in the last round, so C will be equal to an empty string on the last round.
The loop executes for 3 iterations where A, B, C equals a1, b1, c1  ---   a2, b2, c2  ---  a3, b3

Example 3:  foreach A {1 3 5} B {2 4 6 8 10} The loop will execute for the number of iterations based on the largest value pair specified The example loop executes for 5 iterations where A, B equals:
1, 2 --- 3, 4 --- 5, 6 --- <no A value>, 8 --- <no A value>, 10

Nested loops ( if , for , foreach , and while ) are supported.

For details, see the online help: The foreach action .
