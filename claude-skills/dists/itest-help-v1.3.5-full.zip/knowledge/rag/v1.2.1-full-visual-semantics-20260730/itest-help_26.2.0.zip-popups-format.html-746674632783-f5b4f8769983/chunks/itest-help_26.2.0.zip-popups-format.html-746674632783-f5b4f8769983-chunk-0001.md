---
chunk_id: itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-chunk-0001
source_id: itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983
title: '[format formatString ? arg arg ... ?]'
heading_path:
- '[format formatString ? arg arg ... ?]'
section_titles:
- '[format formatString ? arg arg ... ?]'
source_block_ids:
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0001
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0002
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0003
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0004
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0005
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0006
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0007
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0008
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0009
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0010
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0011
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0012
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0013
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0014
- itest-help_26.2.0.zip-popups-format.html-746674632783-f5b4f8769983-block-0015
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 124
source_hash: f5b4f87699836a7cfa12357843d7329f8db0a27286cebedad1a4d095ea762d29
normalized_document_hash: 14d954541b30ed07e5059dd17155f130a736097c9c8db8ffb8826a8940e9c4bb
content_status: success
content_sha256: 8c29cd0e06c1f144bc2a7e74f4900c2727c3fbddd6954217b79b3425d7e8bf0a
---

# [format formatString ? arg arg ... ?]

The

format

command generates a formatted string in a fashion similar to the ANSI C

sprintf

procedure.

formatString

indicates how to format the result, using % conversion specifiers as in

sprint

. The additional arguments, if any, provide values to be substituted into the result. The return value from format is the formatted string..

The

format

command is compatible with its Tcl counterpart as more fully described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
