# [format formatString ? arg arg ... ?]

The

format

command generates a formatted string in a fashion similar to the ANSI C

sprintf

procedure.

formatString

indicates how to format the result, using % conversion specifiers as in

sprint

. The additional arguments, if any, provide values to be substituted into the result. The return value from format is the formatted string..

The

format

command is compatible with its Tcl counterpart as more fully described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
