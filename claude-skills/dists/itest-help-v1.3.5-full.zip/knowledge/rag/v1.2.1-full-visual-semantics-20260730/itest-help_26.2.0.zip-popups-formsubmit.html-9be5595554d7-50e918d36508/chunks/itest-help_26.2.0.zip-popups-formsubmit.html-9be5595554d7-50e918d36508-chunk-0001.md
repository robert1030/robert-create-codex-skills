---
chunk_id: itest-help_26.2.0.zip-popups-formsubmit.html-9be5595554d7-50e918d36508-chunk-0001
source_id: itest-help_26.2.0.zip-popups-formsubmit.html-9be5595554d7-50e918d36508
title: formSubmit
heading_path:
- formSubmit
section_titles:
- formSubmit
source_block_ids:
- itest-help_26.2.0.zip-popups-formsubmit.html-9be5595554d7-50e918d36508-block-0001
- itest-help_26.2.0.zip-popups-formsubmit.html-9be5595554d7-50e918d36508-block-0002
- itest-help_26.2.0.zip-popups-formsubmit.html-9be5595554d7-50e918d36508-block-0003
- itest-help_26.2.0.zip-popups-formsubmit.html-9be5595554d7-50e918d36508-block-0004
- itest-help_26.2.0.zip-popups-formsubmit.html-9be5595554d7-50e918d36508-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 100
source_hash: 50e918d365083103cc28583875270f3fd60b0622b6a4d3800dc5c3344afe3b20
normalized_document_hash: cf6c88e03dddce2c362c2d033e5b6fd65b64382f0f479d1fb920612bf3839431
content_status: success
content_sha256: 276b4d62066d2759fe24a4ca512d9eb49d8ae676abb3ec800626abb5be46073c
---

# formSubmit

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| formSubmit | Required | Not Required | Rarely, you must submit a form that does not have a Submit button. You submit the form by pressing the Enter key in some field in the form. Use formSubmit for such cases. The Target is the FORM element to submit. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
