# formSubmit

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| formSubmit | Required | Not Required | Rarely, you must submit a form that does not have a Submit button. You submit the form by pressing the Enter key in some field in the form. Use formSubmit for such cases. The Target is the FORM element to submit. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
