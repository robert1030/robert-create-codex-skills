---
chunk_id: itest-help_26.2.0.zip-popups-from.html-860e4f60fac2-ec4227bb1c29-chunk-0001
source_id: itest-help_26.2.0.zip-popups-from.html-860e4f60fac2-ec4227bb1c29
title: from
heading_path:
- from
section_titles:
- from
source_block_ids:
- itest-help_26.2.0.zip-popups-from.html-860e4f60fac2-ec4227bb1c29-block-0001
- itest-help_26.2.0.zip-popups-from.html-860e4f60fac2-ec4227bb1c29-block-0002
- itest-help_26.2.0.zip-popups-from.html-860e4f60fac2-ec4227bb1c29-block-0003
- itest-help_26.2.0.zip-popups-from.html-860e4f60fac2-ec4227bb1c29-block-0004
- itest-help_26.2.0.zip-popups-from.html-860e4f60fac2-ec4227bb1c29-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 59
source_hash: ec4227bb1c298a00f3910ca1a568d4116cb75ef93fbad74e4edcbff084edfd93
normalized_document_hash: 3bf967093cae31295257d57e5514aeb091fe040de71cc87fb5bff225af380cd9
content_status: success
content_sha256: 25ff666128b76825f2834cf692bd9062ab1f3dc874129485adcc17b1f9f3bd6c
---

# from

Specifies the sender of the email message. Required for each mail session in a test case.

In the Description cell, specify the email address of the sender.

Field replacements are supported.

For details, see the online help: Sending email messages during test execution .
