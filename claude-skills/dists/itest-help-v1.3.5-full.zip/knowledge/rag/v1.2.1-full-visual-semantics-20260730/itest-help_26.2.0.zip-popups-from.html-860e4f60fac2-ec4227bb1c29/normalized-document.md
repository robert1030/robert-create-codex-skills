# from

Specifies the sender of the email message. Required for each mail session in a test case.

In the Description cell, specify the email address of the sender.

Field replacements are supported.

For details, see the online help: Sending email messages during test execution .
