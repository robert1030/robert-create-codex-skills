---
chunk_id: itest-help_26.2.0.zip-popups-get.html-297700fa933a-3e860400dd5a-chunk-0001
source_id: itest-help_26.2.0.zip-popups-get.html-297700fa933a-3e860400dd5a
title: GET
heading_path:
- GET
section_titles:
- GET
source_block_ids:
- itest-help_26.2.0.zip-popups-get.html-297700fa933a-3e860400dd5a-block-0001
- itest-help_26.2.0.zip-popups-get.html-297700fa933a-3e860400dd5a-block-0002
- itest-help_26.2.0.zip-popups-get.html-297700fa933a-3e860400dd5a-block-0003
- itest-help_26.2.0.zip-popups-get.html-297700fa933a-3e860400dd5a-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 253
source_hash: 3e860400dd5a7593a33f80b0189881cf22980903c9a3f72093d9f85e785133e0
normalized_document_hash: b421fdb2916f1df022e9eb4f90a8dcb4589caf9fc0be6bd9d4144fc8336cd8be
content_status: success
content_sha256: 7cb25a627605ece4b95f4ad34d7b0628db443b20b898be897520de52cf6681b6
---

# GET

The GET method is used to read (or retrieve) a representation of a resource

| Action | GET- read (or retrieve) a representation of a resource |
| --- | --- |
| Returns | GET returns a representation in XML or JSON and an HTTP response code of 200 (OK). Entire List: HTTP 200 (OK), list of customers. Use pagination, sorting and filtering to navigate big lists. Specific Item: HTTP 200 (OK), single customer. 404 (Not Found), if ID not found or invalid. Error: HTTP 404 (NOT FOUND) or 400 (BAD REQUEST) |
| Method | GET (along with HEAD) requests when used to only read data this way, they are considered safe. Calling GET once has the same effect as calling it 10 times, or none at al.<br>Additionally, GET (and HEAD) is idempotent, which means that making multiple identical requests ends up having the same result as a single request. |
| Example | GET http://www.example.com/customers/12345<br>GET http://www.example.com/customers/12345/orders<br>GET http://www.example.com/buckets/sample |

For details, see the online help: REST action reference .
