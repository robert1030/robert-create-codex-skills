---
chunk_id: itest-help_26.2.0.zip-popups-get_attribute.html-8204078caf06-f2957f8c266d-chunk-0001
source_id: itest-help_26.2.0.zip-popups-get_attribute.html-8204078caf06-f2957f8c266d
title: Get Attrribute
heading_path:
- Get Attrribute
section_titles:
- Get Attrribute
source_block_ids:
- itest-help_26.2.0.zip-popups-get_attribute.html-8204078caf06-f2957f8c266d-block-0001
- itest-help_26.2.0.zip-popups-get_attribute.html-8204078caf06-f2957f8c266d-block-0002
- itest-help_26.2.0.zip-popups-get_attribute.html-8204078caf06-f2957f8c266d-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 110
source_hash: f2957f8c266d9b55eca827109e532e9c04f23ccc71b2e73b686a8118d3b45ab3
normalized_document_hash: acf07954e00abbf704bdd7b1f206ea410254c59f2901b3384192fc73135316b9
content_status: success
content_sha256: ac8d52267d85aae033e3ff799033d3062bee7af1a5c584515dd622dd164165a1
---

# Get Attrribute

Used action for getting values from repository items. Depending on the assigned repository item, the available attributes can be different. The value obtained can be assigned to a module variable. Depending on the available adapters for the assigned repository item, the attributes are divided into several sections.
After recording, use action to write back an attribute value of a control to a variable for further processing.

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
