# Get Attrribute

Used action for getting values from repository items. Depending on the assigned repository item, the available attributes can be different. The value obtained can be assigned to a module variable. Depending on the available adapters for the assigned repository item, the attributes are divided into several sections.
After recording, use action to write back an attribute value of a control to a variable for further processing.

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
