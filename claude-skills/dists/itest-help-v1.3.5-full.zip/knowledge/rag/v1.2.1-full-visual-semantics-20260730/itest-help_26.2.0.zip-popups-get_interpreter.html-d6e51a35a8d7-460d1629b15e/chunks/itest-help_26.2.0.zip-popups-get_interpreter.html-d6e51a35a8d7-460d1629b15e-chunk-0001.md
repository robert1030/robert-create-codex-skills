---
chunk_id: itest-help_26.2.0.zip-popups-get_interpreter.html-d6e51a35a8d7-460d1629b15e-chunk-0001
source_id: itest-help_26.2.0.zip-popups-get_interpreter.html-d6e51a35a8d7-460d1629b15e
title: get
heading_path:
- get
section_titles:
- get
source_block_ids:
- itest-help_26.2.0.zip-popups-get_interpreter.html-d6e51a35a8d7-460d1629b15e-block-0001
- itest-help_26.2.0.zip-popups-get_interpreter.html-d6e51a35a8d7-460d1629b15e-block-0002
- itest-help_26.2.0.zip-popups-get_interpreter.html-d6e51a35a8d7-460d1629b15e-block-0003
- itest-help_26.2.0.zip-popups-get_interpreter.html-d6e51a35a8d7-460d1629b15e-block-0004
- itest-help_26.2.0.zip-popups-get_interpreter.html-d6e51a35a8d7-460d1629b15e-block-0005
- itest-help_26.2.0.zip-popups-get_interpreter.html-d6e51a35a8d7-460d1629b15e-block-0006
- itest-help_26.2.0.zip-popups-get_interpreter.html-d6e51a35a8d7-460d1629b15e-block-0007
- itest-help_26.2.0.zip-popups-get_interpreter.html-d6e51a35a8d7-460d1629b15e-block-0008
- itest-help_26.2.0.zip-popups-get_interpreter.html-d6e51a35a8d7-460d1629b15e-block-0009
- itest-help_26.2.0.zip-popups-get_interpreter.html-d6e51a35a8d7-460d1629b15e-block-0010
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 98
source_hash: 460d1629b15e25fe09df2375e7eebc998e4a513c2a7a7402aa3c585dad32fb74
normalized_document_hash: b2fd0122d5fa079e641be909486d5e033e7f9302486ab1b609a0bb3e905c2444
content_status: success
content_sha256: 201f3e99da8cda8622cf70cbd2495f1bcb1f838075498e34361c3b311c911d62
---

# get

get

varName

?

defaultValue

?

Returns the value of the specified local variable. If the specified variable is not found, then the command returns the default value if specified.

To insert a get command, right-click in the field and then select Insert > Local Variable > Get using command .

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
