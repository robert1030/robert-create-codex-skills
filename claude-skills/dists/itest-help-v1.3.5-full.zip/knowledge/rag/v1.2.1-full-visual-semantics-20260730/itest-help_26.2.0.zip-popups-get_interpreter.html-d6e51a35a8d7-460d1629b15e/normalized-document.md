# get

get

varName

?

defaultValue

?

Returns the value of the specified local variable. If the specified variable is not found, then the command returns the default value if specified.

To insert a get command, right-click in the field and then select Insert > Local Variable > Get using command .

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
