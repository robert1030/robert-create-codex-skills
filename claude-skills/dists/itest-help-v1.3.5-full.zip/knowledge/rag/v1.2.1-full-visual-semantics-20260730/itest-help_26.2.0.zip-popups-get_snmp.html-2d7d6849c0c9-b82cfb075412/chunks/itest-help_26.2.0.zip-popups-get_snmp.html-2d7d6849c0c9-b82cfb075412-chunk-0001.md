---
chunk_id: itest-help_26.2.0.zip-popups-get_snmp.html-2d7d6849c0c9-b82cfb075412-chunk-0001
source_id: itest-help_26.2.0.zip-popups-get_snmp.html-2d7d6849c0c9-b82cfb075412
title: get
heading_path:
- get
section_titles:
- get
source_block_ids:
- itest-help_26.2.0.zip-popups-get_snmp.html-2d7d6849c0c9-b82cfb075412-block-0001
- itest-help_26.2.0.zip-popups-get_snmp.html-2d7d6849c0c9-b82cfb075412-block-0002
- itest-help_26.2.0.zip-popups-get_snmp.html-2d7d6849c0c9-b82cfb075412-block-0003
- itest-help_26.2.0.zip-popups-get_snmp.html-2d7d6849c0c9-b82cfb075412-block-0004
- itest-help_26.2.0.zip-popups-get_snmp.html-2d7d6849c0c9-b82cfb075412-block-0005
- itest-help_26.2.0.zip-popups-get_snmp.html-2d7d6849c0c9-b82cfb075412-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 129
source_hash: b82cfb075412b69221f851c01a653917b688e4b1c0d47f3ff8550b90272b2207
normalized_document_hash: 751fb1f1e045868683e9669901511910426949ec5cbbb33b8ee471397ffab29c
content_status: success
content_sha256: 33619b69fc784ad09328a07187d6fdf0574fb53328af870a57eb932a523063e4
---

# get

Returns the OID and Value of a single MIB variable. The system uses the Get PDU to get values for scalar MIBs.

The response contains the printable value of the specified MIB variable.

For octet strings, the result is displayed as a string of 2-digit hex values for each byte, separated by colons (typical MAC address format).

For strings, non-printable characters (except for CR/LF) are converted into printable versions using the standard iTest field replacement syntax (for example, [char CTRL-C] or [char \t] ).

For details, see the online help: Creating SNMP test case steps .
