# get

Returns the OID and Value of a single MIB variable. The system uses the Get PDU to get values for scalar MIBs.

The response contains the printable value of the specified MIB variable.

For octet strings, the result is displayed as a string of 2-digit hex values for each byte, separated by colons (typical MAC address format).

For strings, non-printable characters (except for CR/LF) are converted into printable versions using the standard iTest field replacement syntax (for example, [char CTRL-C] or [char \t] ).

For details, see the online help: Creating SNMP test case steps .
