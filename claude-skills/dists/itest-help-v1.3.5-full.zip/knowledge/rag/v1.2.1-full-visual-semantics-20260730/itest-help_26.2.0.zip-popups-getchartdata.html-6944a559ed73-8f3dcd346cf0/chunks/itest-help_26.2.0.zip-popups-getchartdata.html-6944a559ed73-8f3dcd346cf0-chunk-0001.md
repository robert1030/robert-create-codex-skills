---
chunk_id: itest-help_26.2.0.zip-popups-getchartdata.html-6944a559ed73-8f3dcd346cf0-chunk-0001
source_id: itest-help_26.2.0.zip-popups-getchartdata.html-6944a559ed73-8f3dcd346cf0
title: getChartData
heading_path:
- getChartData
section_titles:
- getChartData
source_block_ids:
- itest-help_26.2.0.zip-popups-getchartdata.html-6944a559ed73-8f3dcd346cf0-block-0001
- itest-help_26.2.0.zip-popups-getchartdata.html-6944a559ed73-8f3dcd346cf0-block-0002
- itest-help_26.2.0.zip-popups-getchartdata.html-6944a559ed73-8f3dcd346cf0-block-0003
- itest-help_26.2.0.zip-popups-getchartdata.html-6944a559ed73-8f3dcd346cf0-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 126
source_hash: 8f3dcd346cf0c08681e2ce43a093d22f1a34ed901602f18a0321b5fafca63918
normalized_document_hash: 47a2699f3a9dc034b07035bdc77e52a47af433eb960c656fe0925451d61d5a0e
content_status: success
content_sha256: 1b9974dfa84c9cb6578f364cb1d4cdcab8de7e5e942435f9c07460a2cfc611c2
---

# getChartData

Extracts the information from a chart and represents it in structured tabular text form. getChartData also captures an image of the chart.

| Target | Required. |
| --- | --- |
| Controls | chart or chart series. |
| Command | None. |
| Step Properties | Step Properties Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
