# getChartData

Extracts the information from a chart and represents it in structured tabular text form. getChartData also captures an image of the chart.

| Target | Required. |
| --- | --- |
| Controls | chart or chart series. |
| Command | None. |
| Step Properties | Step Properties Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
