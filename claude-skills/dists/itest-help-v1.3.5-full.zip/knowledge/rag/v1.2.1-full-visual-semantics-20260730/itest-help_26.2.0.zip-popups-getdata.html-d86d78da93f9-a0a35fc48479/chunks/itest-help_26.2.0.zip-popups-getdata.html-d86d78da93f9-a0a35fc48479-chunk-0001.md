---
chunk_id: itest-help_26.2.0.zip-popups-getdata.html-d86d78da93f9-a0a35fc48479-chunk-0001
source_id: itest-help_26.2.0.zip-popups-getdata.html-d86d78da93f9-a0a35fc48479
title: getData
heading_path:
- getData
section_titles:
- getData
source_block_ids:
- itest-help_26.2.0.zip-popups-getdata.html-d86d78da93f9-a0a35fc48479-block-0001
- itest-help_26.2.0.zip-popups-getdata.html-d86d78da93f9-a0a35fc48479-block-0002
- itest-help_26.2.0.zip-popups-getdata.html-d86d78da93f9-a0a35fc48479-block-0003
- itest-help_26.2.0.zip-popups-getdata.html-d86d78da93f9-a0a35fc48479-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 143
source_hash: a0a35fc48479f6f54900ab568aea35c096be71975d5e038a114f1a1378261176
normalized_document_hash: 1f3f52723ea63f8faf25299c8931a18d8486798ec703abb1b40d009458f2815b
content_status: success
content_sha256: 2cbe9cab91a3c6d216e2b408653ba3c21aac94b48761199fec74adb5683e8eb9
---

# getData

Extracts the items present in the target. For grids, the response is a table. For lists, the response is a list of all possible values. In addition, captures the image of the control.

| Target | Required. |
| --- | --- |
| Controls | Lists, grids, all containers. |
| Command | None. |
| Step Properties | Step Properties Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
