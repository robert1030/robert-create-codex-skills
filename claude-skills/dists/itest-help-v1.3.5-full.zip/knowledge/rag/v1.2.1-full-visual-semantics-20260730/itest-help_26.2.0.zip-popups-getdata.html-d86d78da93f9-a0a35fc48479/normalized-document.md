# getData

Extracts the items present in the target. For grids, the response is a table. For lists, the response is a list of all possible values. In addition, captures the image of the control.

| Target | Required. |
| --- | --- |
| Controls | Lists, grids, all containers. |
| Command | None. |
| Step Properties | Step Properties Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
