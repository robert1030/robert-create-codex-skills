---
chunk_id: itest-help_26.2.0.zip-popups-getinnertext.html-fb21661bc73f-e245d31631af-chunk-0001
source_id: itest-help_26.2.0.zip-popups-getinnertext.html-fb21661bc73f-e245d31631af
title: getInnerText
heading_path:
- getInnerText
section_titles:
- getInnerText
source_block_ids:
- itest-help_26.2.0.zip-popups-getinnertext.html-fb21661bc73f-e245d31631af-block-0001
- itest-help_26.2.0.zip-popups-getinnertext.html-fb21661bc73f-e245d31631af-block-0002
- itest-help_26.2.0.zip-popups-getinnertext.html-fb21661bc73f-e245d31631af-block-0003
- itest-help_26.2.0.zip-popups-getinnertext.html-fb21661bc73f-e245d31631af-block-0004
- itest-help_26.2.0.zip-popups-getinnertext.html-fb21661bc73f-e245d31631af-block-0005
- itest-help_26.2.0.zip-popups-getinnertext.html-fb21661bc73f-e245d31631af-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 145
source_hash: e245d31631af4e39f41844791bb8de03374f1eb68605632d55c66c8cc2c19a96
normalized_document_hash: 62356b1a555663522374bee918bb183f09c5e2f0388090a2dd73752bf341b2d9
content_status: success
content_sha256: b68fad73d07a9df2e7ef7c9ec270bb15593772f1de363de127faebf0d0016680
---

# getInnerText

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| getInnerText | Required | Not Required | Extracts the text from within the HTML structure for the specified node (Target). <nb> tags appear as whitespace The system adds newlines to improve the appearance of the response. The system adds newlines for <br>, <nl>, and any tag that causes newlines. |

- <nb> tags appear as whitespace
- The system adds newlines to improve the appearance of the response.
- The system adds newlines for <br>, <nl>, and any tag that causes newlines.

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
