---
chunk_id: itest-help_26.2.0.zip-popups-getnext.html-5d98da92e069-7aff52cfe3fe-chunk-0001
source_id: itest-help_26.2.0.zip-popups-getnext.html-5d98da92e069-7aff52cfe3fe
title: getNext
heading_path:
- getNext
section_titles:
- getNext
source_block_ids:
- itest-help_26.2.0.zip-popups-getnext.html-5d98da92e069-7aff52cfe3fe-block-0001
- itest-help_26.2.0.zip-popups-getnext.html-5d98da92e069-7aff52cfe3fe-block-0002
- itest-help_26.2.0.zip-popups-getnext.html-5d98da92e069-7aff52cfe3fe-block-0003
- itest-help_26.2.0.zip-popups-getnext.html-5d98da92e069-7aff52cfe3fe-block-0004
- itest-help_26.2.0.zip-popups-getnext.html-5d98da92e069-7aff52cfe3fe-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 120
source_hash: 7aff52cfe3fe5231308fe56dfd63cba3f118bd8122cff491b30113e85dab4556
normalized_document_hash: cb12379c9b48e92fcd044060b54a5cc2085be943baaa7398a89b0a6853f70121
content_status: success
content_sha256: 26920140b9eceb5a92145baa124d0100b124964d8ea04b3e0a7808014824103f
---

# getNext

Returns the value of the single MIB variable that follows the specified OID. The system uses the Get PDU to get values for scalar MIBs.

The structured data includes the OID value and iTest generates queries for OID and RAW_OID.

Tip: To use getNext in a loop for returning multiple values, the device's agent must implement a variable (the “next” variable) for loop control. If you intend to get values for all variables in a MIB, use walk instead.

For details, see the online help: Creating SNMP test case steps .
