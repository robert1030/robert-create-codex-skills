---
chunk_id: itest-help_26.2.0.zip-popups-getstate.html-f9384dbce1a1-1a22cf7ca441-chunk-0001
source_id: itest-help_26.2.0.zip-popups-getstate.html-f9384dbce1a1-1a22cf7ca441
title: getstate
heading_path:
- getstate
section_titles:
- getstate
source_block_ids:
- itest-help_26.2.0.zip-popups-getstate.html-f9384dbce1a1-1a22cf7ca441-block-0001
- itest-help_26.2.0.zip-popups-getstate.html-f9384dbce1a1-1a22cf7ca441-block-0002
- itest-help_26.2.0.zip-popups-getstate.html-f9384dbce1a1-1a22cf7ca441-block-0003
- itest-help_26.2.0.zip-popups-getstate.html-f9384dbce1a1-1a22cf7ca441-block-0004
- itest-help_26.2.0.zip-popups-getstate.html-f9384dbce1a1-1a22cf7ca441-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 70
source_hash: 1a22cf7ca4412891f94cd7e097af97a9c236e4ea1a1c24c8047da9018713fa50
normalized_document_hash: 7ce519dc42226f492eac3ec8869abc2eb9642bdda3d2e4e6f2b549f4fe2a6641
content_status: success
content_sha256: 3d816200b3cab4b396443226ce53fe21323ac8eb06db67da3f0933815936c400
---

# getstate

The getstate action returns:

- The current state of the processors in structured data (for querying and analysis) (as displayed in the Structure view)
- A human-readable table in the response (as displayed in the Response view)

For details, see the online help: The getstate action .

Also, see the HA command reference .
