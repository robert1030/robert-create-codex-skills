# getstate

The getstate action returns:

- The current state of the processors in structured data (for querying and analysis) (as displayed in the Structure view)
- A human-readable table in the response (as displayed in the Response view)

For details, see the online help: The getstate action .

Also, see the HA command reference .
