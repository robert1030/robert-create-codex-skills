---
chunk_id: itest-help_26.2.0.zip-popups-gettable.html-b8d6d8c49bb4-9add9e94a73a-chunk-0001
source_id: itest-help_26.2.0.zip-popups-gettable.html-b8d6d8c49bb4-9add9e94a73a
title: getTable
heading_path:
- getTable
section_titles:
- getTable
source_block_ids:
- itest-help_26.2.0.zip-popups-gettable.html-b8d6d8c49bb4-9add9e94a73a-block-0001
- itest-help_26.2.0.zip-popups-gettable.html-b8d6d8c49bb4-9add9e94a73a-block-0002
- itest-help_26.2.0.zip-popups-gettable.html-b8d6d8c49bb4-9add9e94a73a-block-0003
- itest-help_26.2.0.zip-popups-gettable.html-b8d6d8c49bb4-9add9e94a73a-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 52
source_hash: 9add9e94a73aa5768fb052c708235eb310cb3de74f5821ba1edc3830ab48fa70
normalized_document_hash: 8aab2138ae6f035fba342cd096533527d7d5ee6e70bbcde3766e36de76486f79
content_status: success
content_sha256: e9e6511d99207ee2f24c586151e71af262723efc1b4ce6732918d7e02a870f8a
---

# getTable

Returns all OIDs, Types, and Values of variables in the table.

The system uses a Get PDU with multiple OIDs to read the values for each row.

For details, see the online help: Creating SNMP test case steps .
