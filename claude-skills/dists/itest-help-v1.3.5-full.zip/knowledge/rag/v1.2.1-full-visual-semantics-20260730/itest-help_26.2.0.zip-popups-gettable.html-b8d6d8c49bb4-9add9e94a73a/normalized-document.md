# getTable

Returns all OIDs, Types, and Values of variables in the table.

The system uses a Get PDU with multiple OIDs to read the values for each row.

For details, see the online help: Creating SNMP test case steps .
