---
chunk_id: itest-help_26.2.0.zip-popups-gettext.html-2bc44bcb8f30-86c9bb9b1c4f-chunk-0001
source_id: itest-help_26.2.0.zip-popups-gettext.html-2bc44bcb8f30-86c9bb9b1c4f
title: getText
heading_path:
- getText
section_titles:
- getText
source_block_ids:
- itest-help_26.2.0.zip-popups-gettext.html-2bc44bcb8f30-86c9bb9b1c4f-block-0001
- itest-help_26.2.0.zip-popups-gettext.html-2bc44bcb8f30-86c9bb9b1c4f-block-0002
- itest-help_26.2.0.zip-popups-gettext.html-2bc44bcb8f30-86c9bb9b1c4f-block-0003
- itest-help_26.2.0.zip-popups-gettext.html-2bc44bcb8f30-86c9bb9b1c4f-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 101
source_hash: 86c9bb9b1c4f1fb9db3b08f0c7ef0fd649347355761a0ba1bd8f260f6803ed6b
normalized_document_hash: 81bbc70119f2432f877ed67c9ec35b1ad92917fa96e02b9407f22fe2a9986abd
content_status: success
content_sha256: 4a1192a6adffb09831588c1f8d4a514348dbfc20417e1830ecb88baf864d2b41
---

# getText

Returns the structured representation of the tree..

| Target | Required. |
| --- | --- |
| Controls | Trees. |
| Command | None. |
| Step Properties | Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
