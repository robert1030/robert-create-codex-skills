---
chunk_id: itest-help_26.2.0.zip-popups-gget.html-a8e1d142e080-3f8ef11bcb44-chunk-0001
source_id: itest-help_26.2.0.zip-popups-gget.html-a8e1d142e080-3f8ef11bcb44
title: gget
heading_path:
- gget
section_titles:
- gget
source_block_ids:
- itest-help_26.2.0.zip-popups-gget.html-a8e1d142e080-3f8ef11bcb44-block-0001
- itest-help_26.2.0.zip-popups-gget.html-a8e1d142e080-3f8ef11bcb44-block-0002
- itest-help_26.2.0.zip-popups-gget.html-a8e1d142e080-3f8ef11bcb44-block-0003
- itest-help_26.2.0.zip-popups-gget.html-a8e1d142e080-3f8ef11bcb44-block-0004
- itest-help_26.2.0.zip-popups-gget.html-a8e1d142e080-3f8ef11bcb44-block-0005
- itest-help_26.2.0.zip-popups-gget.html-a8e1d142e080-3f8ef11bcb44-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 95
source_hash: 3f8ef11bcb448e57204b600aadb19b37f857df33abe0cfff7941c172490b7a31
normalized_document_hash: d1c91e2d966c59c81bb84bcd47def07bb602a3d9bde6783ed2057bd65e2d77fe
content_status: success
content_sha256: 59d8594f8770e292ecad0001659609f11130aa5002e9d3f5b0e15b352522cbfa
---

# gget

gget variableName ? defaultValue ?

Returns the value of the specified global variable. If the specified variable is not found, then the command returns the default value if specified.

To insert a gget command, right-click in the field and then select Insert > Global Variable > Get .

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
