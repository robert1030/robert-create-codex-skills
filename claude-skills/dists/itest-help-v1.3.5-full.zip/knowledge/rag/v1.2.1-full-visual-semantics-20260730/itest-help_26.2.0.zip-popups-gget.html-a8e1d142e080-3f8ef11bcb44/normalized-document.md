# gget

gget variableName ? defaultValue ?

Returns the value of the specified global variable. If the specified variable is not found, then the command returns the default value if specified.

To insert a gget command, right-click in the field and then select Insert > Global Variable > Get .

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
