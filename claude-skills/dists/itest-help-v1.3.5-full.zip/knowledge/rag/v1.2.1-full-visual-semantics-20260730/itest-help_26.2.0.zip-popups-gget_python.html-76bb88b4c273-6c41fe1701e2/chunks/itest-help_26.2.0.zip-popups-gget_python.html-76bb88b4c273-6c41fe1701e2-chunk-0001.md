---
chunk_id: itest-help_26.2.0.zip-popups-gget_python.html-76bb88b4c273-6c41fe1701e2-chunk-0001
source_id: itest-help_26.2.0.zip-popups-gget_python.html-76bb88b4c273-6c41fe1701e2
title: gget
heading_path:
- gget
section_titles:
- gget
source_block_ids:
- itest-help_26.2.0.zip-popups-gget_python.html-76bb88b4c273-6c41fe1701e2-block-0001
- itest-help_26.2.0.zip-popups-gget_python.html-76bb88b4c273-6c41fe1701e2-block-0002
- itest-help_26.2.0.zip-popups-gget_python.html-76bb88b4c273-6c41fe1701e2-block-0003
- itest-help_26.2.0.zip-popups-gget_python.html-76bb88b4c273-6c41fe1701e2-block-0004
- itest-help_26.2.0.zip-popups-gget_python.html-76bb88b4c273-6c41fe1701e2-block-0005
- itest-help_26.2.0.zip-popups-gget_python.html-76bb88b4c273-6c41fe1701e2-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 120
source_hash: 6c41fe1701e267b67aa1c7e318cd4216a265e6f379006e9a3be0953ad856819f
normalized_document_hash: fdf41bd27c139b9754e684bd9cc7191e4e2ff0125cf8c13297dcc3e54d0820e4
content_status: success
content_sha256: 53129807e2b3a9046240ed06aad3ca5c28ce553c483b2e5f98e7e075ee16364a
---

# gget

gget ('variableName', 'defaultValue')

Returns the value of the specified global variable. If the specified variable is not found, then the command returns the default value if specified. Example: gget ('varName', param('my_param')) ping -c [gget('ping_count')] 10.155.0.1

To insert a gget command, right-click in the field and then select Insert > Global Variable > Get .

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
