---
chunk_id: itest-help_26.2.0.zip-popups-go.html-71606c22f04c-acc0921a67e0-chunk-0001
source_id: itest-help_26.2.0.zip-popups-go.html-71606c22f04c-acc0921a67e0
title: go
heading_path:
- go
section_titles:
- go
source_block_ids:
- itest-help_26.2.0.zip-popups-go.html-71606c22f04c-acc0921a67e0-block-0001
- itest-help_26.2.0.zip-popups-go.html-71606c22f04c-acc0921a67e0-block-0002
- itest-help_26.2.0.zip-popups-go.html-71606c22f04c-acc0921a67e0-block-0004
- itest-help_26.2.0.zip-popups-go.html-71606c22f04c-acc0921a67e0-block-0005
- itest-help_26.2.0.zip-popups-go.html-71606c22f04c-acc0921a67e0-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 98
source_hash: acc0921a67e070f49de25ec361218ba1eb255ac9598e2a734caac597d44e5c5d
normalized_document_hash: 35cdfdf2ebf2535b872d1122a5e4d07f39eb78afc523910b4fb1bc49dcf8a7b7
content_status: success
content_sha256: 00c4f93ced8db1a1d9be847ae414a3e6c0edb2f07e95957aadd9a0992375a9e6
---

# go

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| go | Required | Not Required | A go step navigates to the URL specified in the Command property. During an interactive session, if you type a new address in the address bar and press Enter or the Go button , it is captured as a go step. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
