# go

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| go | Required | Not Required | A go step navigates to the URL specified in the Command property. During an interactive session, if you type a new address in the address bar and press Enter or the Go button , it is captured as a go step. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
