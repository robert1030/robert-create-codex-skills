---
chunk_id: itest-help_26.2.0.zip-popups-goback.html-c78547f2e0b4-2af2485ccfca-chunk-0001
source_id: itest-help_26.2.0.zip-popups-goback.html-c78547f2e0b4-2af2485ccfca
title: goBack
heading_path:
- goBack
section_titles:
- goBack
source_block_ids:
- itest-help_26.2.0.zip-popups-goback.html-c78547f2e0b4-2af2485ccfca-block-0001
- itest-help_26.2.0.zip-popups-goback.html-c78547f2e0b4-2af2485ccfca-block-0002
- itest-help_26.2.0.zip-popups-goback.html-c78547f2e0b4-2af2485ccfca-block-0003
- itest-help_26.2.0.zip-popups-goback.html-c78547f2e0b4-2af2485ccfca-block-0004
- itest-help_26.2.0.zip-popups-goback.html-c78547f2e0b4-2af2485ccfca-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 77
source_hash: 2af2485ccfca5acadc9512c124df8e4ed765e5f76ddd69d5c849a0185f261306
normalized_document_hash: b86a8198257a0061691d8e8a1a8d70fa5d6256eccd3ff385ca1d172349c9c55e
content_status: success
content_sha256: 3b35c175423a49535fe7fadd51814d44703eb41b042677d635adfc9099705bb9
---

# goBack

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| goBack | Not Required | Not Required | Simulates clicking the browser's Back button. Note: If the preceding action did not change the URL, then this action does not occur. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
