---
chunk_id: itest-help_26.2.0.zip-popups-goforward.html-944402a5891d-f59493709b37-chunk-0001
source_id: itest-help_26.2.0.zip-popups-goforward.html-944402a5891d-f59493709b37
title: goForward
heading_path:
- goForward
section_titles:
- goForward
source_block_ids:
- itest-help_26.2.0.zip-popups-goforward.html-944402a5891d-f59493709b37-block-0001
- itest-help_26.2.0.zip-popups-goforward.html-944402a5891d-f59493709b37-block-0002
- itest-help_26.2.0.zip-popups-goforward.html-944402a5891d-f59493709b37-block-0003
- itest-help_26.2.0.zip-popups-goforward.html-944402a5891d-f59493709b37-block-0004
- itest-help_26.2.0.zip-popups-goforward.html-944402a5891d-f59493709b37-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 77
source_hash: f59493709b372f060e80038f3ac70964081a4398f342129f78cac25a7177981d
normalized_document_hash: 2f0d90633fd81a8b7471349cdfddcc653ad9f1c4420148fa27363d5899b0e633
content_status: success
content_sha256: cd00e335acffcb7fe93846609d4bff91bbc8063d9f9841b8685ed007a0d0ea6d
---

# goForward

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| goForward | Not Required | Not Required | Simulates clicking the browser's Forward button. Note: If the preceding action did not change the URL, then this action does not occur. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
