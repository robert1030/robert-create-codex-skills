# goForward

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| goForward | Not Required | Not Required | Simulates clicking the browser's Forward button. Note: If the preceding action did not change the URL, then this action does not occur. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
