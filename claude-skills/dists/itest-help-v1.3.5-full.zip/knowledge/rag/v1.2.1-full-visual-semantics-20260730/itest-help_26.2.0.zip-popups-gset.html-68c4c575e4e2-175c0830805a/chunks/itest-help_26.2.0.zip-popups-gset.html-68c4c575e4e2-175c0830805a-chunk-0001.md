---
chunk_id: itest-help_26.2.0.zip-popups-gset.html-68c4c575e4e2-175c0830805a-chunk-0001
source_id: itest-help_26.2.0.zip-popups-gset.html-68c4c575e4e2-175c0830805a
title: gset
heading_path:
- gset
section_titles:
- gset
source_block_ids:
- itest-help_26.2.0.zip-popups-gset.html-68c4c575e4e2-175c0830805a-block-0001
- itest-help_26.2.0.zip-popups-gset.html-68c4c575e4e2-175c0830805a-block-0002
- itest-help_26.2.0.zip-popups-gset.html-68c4c575e4e2-175c0830805a-block-0003
- itest-help_26.2.0.zip-popups-gset.html-68c4c575e4e2-175c0830805a-block-0004
- itest-help_26.2.0.zip-popups-gset.html-68c4c575e4e2-175c0830805a-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 53
source_hash: 175c0830805a20e1bba2b30da9365eab34d6016aeab7eef0cb8eac042de5e616
normalized_document_hash: c2e8532f73d4099ac2ffe187ec7f09182ab50c67272717ee9cc4a226ad1b98bc
content_status: success
content_sha256: e47fdaf496710fe01502593f5a8f0de883602ef6730c88e23cdf90fac922fea8
---

# gset

gset variableName ? defaultValue ?

Set the value of the specified global variable.

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
