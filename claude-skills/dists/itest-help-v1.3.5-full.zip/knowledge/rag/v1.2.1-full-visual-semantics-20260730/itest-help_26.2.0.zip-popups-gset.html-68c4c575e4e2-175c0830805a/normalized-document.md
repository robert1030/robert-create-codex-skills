# gset

gset variableName ? defaultValue ?

Set the value of the specified global variable.

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
