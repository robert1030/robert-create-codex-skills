---
chunk_id: itest-help_26.2.0.zip-popups-gset_python.html-93025294fb1d-183c424ddf18-chunk-0001
source_id: itest-help_26.2.0.zip-popups-gset_python.html-93025294fb1d-183c424ddf18
title: gset
heading_path:
- gset
section_titles:
- gset
source_block_ids:
- itest-help_26.2.0.zip-popups-gset_python.html-93025294fb1d-183c424ddf18-block-0001
- itest-help_26.2.0.zip-popups-gset_python.html-93025294fb1d-183c424ddf18-block-0002
- itest-help_26.2.0.zip-popups-gset_python.html-93025294fb1d-183c424ddf18-block-0003
- itest-help_26.2.0.zip-popups-gset_python.html-93025294fb1d-183c424ddf18-block-0004
- itest-help_26.2.0.zip-popups-gset_python.html-93025294fb1d-183c424ddf18-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 62
source_hash: 183c424ddf18ca4244c43c4284ae8790186855a02c57951f31be19c39c53830e
normalized_document_hash: 0b085336ae14e0ec1e75afea861aa2720c9e30676fff370708449c15e7a28d47
content_status: success
content_sha256: 8234a5185fc789f879ddbde4bdce7bf1151e2216b2f66dc073af6afb763072e0
---

# gset

gset ('variableName', 'Value')

Set the value of the specified global variable. Example: gset('ping_count', 42)

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
