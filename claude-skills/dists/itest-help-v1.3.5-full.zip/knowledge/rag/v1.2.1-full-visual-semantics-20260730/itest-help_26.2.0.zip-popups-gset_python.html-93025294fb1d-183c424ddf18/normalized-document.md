# gset

gset ('variableName', 'Value')

Set the value of the specified global variable. Example: gset('ping_count', 42)

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
