---
chunk_id: itest-help_26.2.0.zip-popups-gunset.html-0283a4f5709d-f63db31cd299-chunk-0001
source_id: itest-help_26.2.0.zip-popups-gunset.html-0283a4f5709d-f63db31cd299
title: gunset
heading_path:
- gunset
section_titles:
- gunset
source_block_ids:
- itest-help_26.2.0.zip-popups-gunset.html-0283a4f5709d-f63db31cd299-block-0001
- itest-help_26.2.0.zip-popups-gunset.html-0283a4f5709d-f63db31cd299-block-0002
- itest-help_26.2.0.zip-popups-gunset.html-0283a4f5709d-f63db31cd299-block-0003
- itest-help_26.2.0.zip-popups-gunset.html-0283a4f5709d-f63db31cd299-block-0004
- itest-help_26.2.0.zip-popups-gunset.html-0283a4f5709d-f63db31cd299-block-0005
- itest-help_26.2.0.zip-popups-gunset.html-0283a4f5709d-f63db31cd299-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 85
source_hash: f63db31cd29912aec63b58fca9165d48e3e9887fb0185ded2e1271fddb5eebc8
normalized_document_hash: c0fb473f83bd36bd9e698cfe6788f894751025cad08bead9473a179c234aac74
content_status: success
content_sha256: 70a6b54819672d64dac75f1f1875d4c7db0df41bdd8dcf3c2602aee6fd69315e
---

# gunset

gunset

varName

The iTest gunset command removes one global variable. Limitation : No additional arguments are allowed. The command is otherwise compatible with its Tcl counterpart as more fully described at: http://www.tcl.tk/man

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
