---
chunk_id: itest-help_26.2.0.zip-popups-head.html-3f8d6f2f4130-8b9bc4b3c543-chunk-0001
source_id: itest-help_26.2.0.zip-popups-head.html-3f8d6f2f4130-8b9bc4b3c543
title: HEAD
heading_path:
- HEAD
section_titles:
- HEAD
source_block_ids:
- itest-help_26.2.0.zip-popups-head.html-3f8d6f2f4130-8b9bc4b3c543-block-0001
- itest-help_26.2.0.zip-popups-head.html-3f8d6f2f4130-8b9bc4b3c543-block-0002
- itest-help_26.2.0.zip-popups-head.html-3f8d6f2f4130-8b9bc4b3c543-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 120
source_hash: 8b9bc4b3c5436a4851baca886b9de954ca55900641bbd059e26f176ef58be382
normalized_document_hash: 7886d3f8a070bb4684b2b1992060ec5c2daa464413a4daabefe0afccfff09b8f
content_status: success
content_sha256: 55830f1b16a652c99ba76c6f59d84d634d085319faf5d81249812bc1aed7bc95
---

# HEAD

The HEAD method may be used for obtaining meta information about the entity implied by the request without transferring the entity-body itself. This method is often used for testing hypertext links for validity, accessibility, and recent modification.
The HEAD method is identical to "GET" . except that the server does not return a message-body in the response. The meta information contained in the HTTP headers in response to a HEAD request is identical to the information sent in response to a GET request.

For details, see the online help: REST action reference .
