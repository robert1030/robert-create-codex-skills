# HEAD

The HEAD method may be used for obtaining meta information about the entity implied by the request without transferring the entity-body itself. This method is often used for testing hypertext links for validity, accessibility, and recent modification.
The HEAD method is identical to "GET" . except that the server does not return a message-body in the response. The meta information contained in the HTTP headers in response to a HEAD request is identical to the information sent in response to a GET request.

For details, see the online help: REST action reference .
