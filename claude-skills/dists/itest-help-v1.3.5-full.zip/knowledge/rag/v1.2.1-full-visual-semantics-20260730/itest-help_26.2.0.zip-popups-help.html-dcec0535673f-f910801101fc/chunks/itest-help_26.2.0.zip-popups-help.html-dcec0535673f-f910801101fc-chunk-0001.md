---
chunk_id: itest-help_26.2.0.zip-popups-help.html-dcec0535673f-f910801101fc-chunk-0001
source_id: itest-help_26.2.0.zip-popups-help.html-dcec0535673f-f910801101fc
title: help
heading_path:
- help
section_titles:
- help
source_block_ids:
- itest-help_26.2.0.zip-popups-help.html-dcec0535673f-f910801101fc-block-0001
- itest-help_26.2.0.zip-popups-help.html-dcec0535673f-f910801101fc-block-0002
- itest-help_26.2.0.zip-popups-help.html-dcec0535673f-f910801101fc-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 52
source_hash: f910801101fcf5ca06594bd6f1acba11165f8fed15270db7652493cc8a3bb04a
normalized_document_hash: 59157e23636a154a3f8a0fab8ccba3563bb9f5f9f0a0434803440fd222a56758
content_status: success
content_sha256: 55b616bef574d3fd0ef4df1f57f6b4984851fd35a20684ed4c99e899af628e8d
---

# help

Returns the list of commands and the description of each command.
iTest does not map the response to the help command.

For details, see the online help: UDP command reference section under the topic "UDP Session Editor Concept" .
