# help

Returns the list of commands and the description of each command.
iTest does not map the response to the help command.

For details, see the online help: UDP command reference section under the topic "UDP Session Editor Concept" .
