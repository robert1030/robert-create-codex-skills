---
chunk_id: itest-help_26.2.0.zip-popups-hidemenu.html-8aa7ebb49329-cdca108ca0e9-chunk-0001
source_id: itest-help_26.2.0.zip-popups-hidemenu.html-8aa7ebb49329-cdca108ca0e9
title: hideMenu
heading_path:
- hideMenu
section_titles:
- hideMenu
source_block_ids:
- itest-help_26.2.0.zip-popups-hidemenu.html-8aa7ebb49329-cdca108ca0e9-block-0001
- itest-help_26.2.0.zip-popups-hidemenu.html-8aa7ebb49329-cdca108ca0e9-block-0002
- itest-help_26.2.0.zip-popups-hidemenu.html-8aa7ebb49329-cdca108ca0e9-block-0003
- itest-help_26.2.0.zip-popups-hidemenu.html-8aa7ebb49329-cdca108ca0e9-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 103
source_hash: cdca108ca0e9388f21a08d1e72bf9f80bf846e12b0ee36a0a7d825804f3c1621
normalized_document_hash: bb2ba0352f4ae3c611a4e92a387f52d21cd06183c7d9b42c1a841a83d41628bc
content_status: success
content_sha256: 6b1fef1191b85cdc437215f5a7d827beacb5cd16ae8de667db91cc2294f50e76
---

# hideMenu

Returns the structured representation of the tree..

| Target | Required. |
| --- | --- |
| Controls | Menu objects. |
| Command | Menu name. |
| Step Properties | Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
