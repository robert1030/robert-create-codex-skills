---
chunk_id: itest-help_26.2.0.zip-popups-if.html-4e4162b1d0a1-e3e1e58009cb-chunk-0001
source_id: itest-help_26.2.0.zip-popups-if.html-4e4162b1d0a1-e3e1e58009cb
title: if
heading_path:
- if
section_titles:
- if
source_block_ids:
- itest-help_26.2.0.zip-popups-if.html-4e4162b1d0a1-e3e1e58009cb-block-0001
- itest-help_26.2.0.zip-popups-if.html-4e4162b1d0a1-e3e1e58009cb-block-0002
- itest-help_26.2.0.zip-popups-if.html-4e4162b1d0a1-e3e1e58009cb-block-0003
- itest-help_26.2.0.zip-popups-if.html-4e4162b1d0a1-e3e1e58009cb-block-0004
- itest-help_26.2.0.zip-popups-if.html-4e4162b1d0a1-e3e1e58009cb-block-0006
- itest-help_26.2.0.zip-popups-if.html-4e4162b1d0a1-e3e1e58009cb-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 231
source_hash: e3e1e58009cb503823cb607f757ee7a18665969d7134b7c795fca58365c4637b
normalized_document_hash: 48df66951f5d0e6f29ea3b6487338e98835a99c39b462df14b2f05e11b004002
content_status: success
content_sha256: 4f485e293e73de522be06ecb1e616a06026dc03f7ddd84746f697a5b9045c363
---

# if

An if step evaluates the expression that appears in the Description cell (the value of the Command property).

- If the expression is True, then continue execution at the immediately following step.
- If the expression is False, then continue execution at the associated elseif action. If there is no elseif action, or if
the elseif action evaluates to False, then continue execution at the associated else action.
- When the steps indented under the else are complete, then continue execution at the immediately following step (that is,
after the last step in the if construct).

Nested loops ( if , for , foreach , and while ) are supported.

Note: A legal contiguous sequence of if , then , elseif , and else steps will have one if step, followed by one then step, followed by zero or more elseif steps followed by zero or one else step.
Any other sequence is illegal. No other types of steps within the scope can be interleaved in these sequences.

See the online help for tips on adding if-then constructs and help on the if action .
