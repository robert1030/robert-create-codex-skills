# if

An if step evaluates the expression that appears in the Description cell (the value of the Command property).

- If the expression is True, then continue execution at the immediately following step.
- If the expression is False, then continue execution at the associated elseif action. If there is no elseif action, or if
the elseif action evaluates to False, then continue execution at the associated else action.
- When the steps indented under the else are complete, then continue execution at the immediately following step (that is,
after the last step in the if construct).

Nested loops ( if , for , foreach , and while ) are supported.

Note: A legal contiguous sequence of if , then , elseif , and else steps will have one if step, followed by one then step, followed by zero or more elseif steps followed by zero or one else step.
Any other sequence is illegal. No other types of steps within the scope can be interleaved in these sequences.

See the online help for tips on adding if-then constructs and help on the if action .
