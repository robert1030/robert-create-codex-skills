---
chunk_id: itest-help_26.2.0.zip-popups-if_python.html-4d1fbce1ba88-be9bbec92d7d-chunk-0001
source_id: itest-help_26.2.0.zip-popups-if_python.html-4d1fbce1ba88-be9bbec92d7d
title: if
heading_path:
- if
section_titles:
- if
source_block_ids:
- itest-help_26.2.0.zip-popups-if_python.html-4d1fbce1ba88-be9bbec92d7d-block-0001
- itest-help_26.2.0.zip-popups-if_python.html-4d1fbce1ba88-be9bbec92d7d-block-0002
- itest-help_26.2.0.zip-popups-if_python.html-4d1fbce1ba88-be9bbec92d7d-block-0003
- itest-help_26.2.0.zip-popups-if_python.html-4d1fbce1ba88-be9bbec92d7d-block-0004
- itest-help_26.2.0.zip-popups-if_python.html-4d1fbce1ba88-be9bbec92d7d-block-0006
- itest-help_26.2.0.zip-popups-if_python.html-4d1fbce1ba88-be9bbec92d7d-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 221
source_hash: be9bbec92d7d894f7fb35613af9ee995d9538a5767ab2acae990f9f3287cfa0b
normalized_document_hash: f5ab71a8b8e6a4602c33898edc9976d3691af00490fcbe0ca19d52fbb3dcf22b
content_status: success
content_sha256: 603c11c2c8c4b12c52a0adac75ac738531eaa3502285fc507dc3fb032af2d969
---

# if

An if step evaluates the expression that appears in the Description cell (the value of the Command property).

- If the expression is True, then continue execution at the immediately following step.
- If the expression is False, then continue execution at the associated elif action. If there is no elif action, or if
the elif action evaluates to False, then continue execution at the associated else action.
- When the steps indented under the else are complete, then continue execution at the immediately following step (that is,
after the last step in the if construct).

Nested loops ( if , for , and while ) are supported.

Note: A legal contiguous sequence of if , elif , and else steps will have one if step, followed by zero or more elif steps followed by zero or one else step.
Any other sequence is illegal. No other types of steps within the scope can be interleaved in these sequences.

See the online help for tips on adding if constructs and help on the if action .
