# if

An if step evaluates the expression that appears in the Description cell (the value of the Command property).

- If the expression is True, then continue execution at the immediately following step.
- If the expression is False, then continue execution at the associated elif action. If there is no elif action, or if
the elif action evaluates to False, then continue execution at the associated else action.
- When the steps indented under the else are complete, then continue execution at the immediately following step (that is,
after the last step in the if construct).

Nested loops ( if , for , and while ) are supported.

Note: A legal contiguous sequence of if , elif , and else steps will have one if step, followed by zero or more elif steps followed by zero or one else step.
Any other sequence is illegal. No other types of steps within the scope can be interleaved in these sequences.

See the online help for tips on adding if constructs and help on the if action .
