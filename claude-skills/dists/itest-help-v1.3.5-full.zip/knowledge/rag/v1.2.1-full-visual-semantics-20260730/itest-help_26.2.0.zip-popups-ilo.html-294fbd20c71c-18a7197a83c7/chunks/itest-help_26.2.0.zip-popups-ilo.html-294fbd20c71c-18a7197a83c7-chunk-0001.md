---
chunk_id: itest-help_26.2.0.zip-popups-ilo.html-294fbd20c71c-18a7197a83c7-chunk-0001
source_id: itest-help_26.2.0.zip-popups-ilo.html-294fbd20c71c-18a7197a83c7
title: ilo
heading_path:
- ilo
section_titles:
- ilo
source_block_ids:
- itest-help_26.2.0.zip-popups-ilo.html-294fbd20c71c-18a7197a83c7-block-0001
- itest-help_26.2.0.zip-popups-ilo.html-294fbd20c71c-18a7197a83c7-block-0002
- itest-help_26.2.0.zip-popups-ilo.html-294fbd20c71c-18a7197a83c7-block-0003
- itest-help_26.2.0.zip-popups-ilo.html-294fbd20c71c-18a7197a83c7-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 215
source_hash: 18a7197a83c793ce9fc5f5555243256eb7043cbd2f2b2a7cc6ef5c82fa4250ae
normalized_document_hash: b7f84c3ec4d5763d5e3b68d46037ffb990a12a1334eb802af0de1e7cc72fff5a
content_status: success
content_sha256: b3174bf197cf4e4c774e53b124a1a87e221bc0300f39b0536e0c36d194922dd4
---

# ilo

To run a test case associated with a Velocity topology (using the ilo command to retrieve information about the active topology), specify the following parameters:

| ---iloLogin userName ---iloPassword password: | Specify the username/password credentials to use to access the Velocity server. |
| --- | --- |
| --iloServer URI /ilo: | URI is the hostname or IP address of the Velocity virtual appliance. The URI is followed by “/velocity” Example: --velocityServer http://velocity.acme.com/ilo --reservationId reservationId: If there is more than one active reservation for the topology associated with the test case, then you must specify a value for the --reservationId option. When there is only one active reservation of the topology, then you do not need to specify a value for --reservationId |

Example: itestrt --licenseServer lshost.acme.com:27000 --iloServer http://ilo.acme.com/ilo --iloLogin Apurba --iloPassword yikes --reservationId 1e4371d0-e8f2-4ecb-91e2-b1e67535b867 --itar C:\itars --test project://my_project/test_cases/telnet3.fftc
