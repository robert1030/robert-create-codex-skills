---
chunk_id: itest-help_26.2.0.zip-popups-incr.html-f6fcd762a2e8-855f35a45dae-chunk-0001
source_id: itest-help_26.2.0.zip-popups-incr.html-f6fcd762a2e8-855f35a45dae
title: incr
heading_path:
- incr
section_titles:
- incr
source_block_ids:
- itest-help_26.2.0.zip-popups-incr.html-f6fcd762a2e8-855f35a45dae-block-0001
- itest-help_26.2.0.zip-popups-incr.html-f6fcd762a2e8-855f35a45dae-block-0002
- itest-help_26.2.0.zip-popups-incr.html-f6fcd762a2e8-855f35a45dae-block-0003
- itest-help_26.2.0.zip-popups-incr.html-f6fcd762a2e8-855f35a45dae-block-0004
- itest-help_26.2.0.zip-popups-incr.html-f6fcd762a2e8-855f35a45dae-block-0005
- itest-help_26.2.0.zip-popups-incr.html-f6fcd762a2e8-855f35a45dae-block-0006
- itest-help_26.2.0.zip-popups-incr.html-f6fcd762a2e8-855f35a45dae-block-0007
- itest-help_26.2.0.zip-popups-incr.html-f6fcd762a2e8-855f35a45dae-block-0008
- itest-help_26.2.0.zip-popups-incr.html-f6fcd762a2e8-855f35a45dae-block-0009
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 84
source_hash: 855f35a45daeaec4a06bb77f22a9ab1c40fb7a7518d0f88769aa1247cdb02e0c
normalized_document_hash: 690a31b85b148588f6af4b8c4eb595a059e33234abd7391b0a615130ea2d62b8
content_status: success
content_sha256: 4194846af6ea1b8618b20b39dcc81220b923c0bc142a53f89874e7b7ea5025e4
---

# incr

incr varName

Increments the specified variable.

To insert an incr command, right-click in the field and then select either of the following:

Insert > Special Actions > Increment Local Variable

or

Insert > Special Actions > Increment Global Variable

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
