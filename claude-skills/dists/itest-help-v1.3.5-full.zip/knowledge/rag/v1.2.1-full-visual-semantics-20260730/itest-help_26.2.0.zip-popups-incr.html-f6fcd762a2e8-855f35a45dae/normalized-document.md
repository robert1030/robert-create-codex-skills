# incr

incr varName

Increments the specified variable.

To insert an incr command, right-click in the field and then select either of the following:

Insert > Special Actions > Increment Local Variable

or

Insert > Special Actions > Increment Global Variable

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
