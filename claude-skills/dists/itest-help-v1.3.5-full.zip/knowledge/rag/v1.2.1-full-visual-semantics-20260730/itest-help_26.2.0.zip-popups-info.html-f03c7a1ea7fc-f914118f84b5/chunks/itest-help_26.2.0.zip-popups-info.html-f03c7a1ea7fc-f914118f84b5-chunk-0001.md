---
chunk_id: itest-help_26.2.0.zip-popups-info.html-f03c7a1ea7fc-f914118f84b5-chunk-0001
source_id: itest-help_26.2.0.zip-popups-info.html-f03c7a1ea7fc-f914118f84b5
title: info
heading_path:
- info
section_titles:
- info
source_block_ids:
- itest-help_26.2.0.zip-popups-info.html-f03c7a1ea7fc-f914118f84b5-block-0001
- itest-help_26.2.0.zip-popups-info.html-f03c7a1ea7fc-f914118f84b5-block-0002
- itest-help_26.2.0.zip-popups-info.html-f03c7a1ea7fc-f914118f84b5-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 1138
source_hash: f914118f84b55ff2b900246c01b53d78b5c0e183b31c89fada0481fe13345ce5
normalized_document_hash: 8ebef3aaa4ec8332bb11d2137ddf90243e15aa838c5e52cb99ff4706906c5ff2
content_status: success
content_sha256: fa7c56d9d4b4b138221e2063f7a56570e73be809abcaba428da048bf9ecf867c
---

# info

The info commands return information about execution, about the current instance of iTest, and about the local computer. You can use an eval action with an info command or can use the command in a field replacement.

- [info env varName ] Returns the contents of the  environment variable specified by varName
- [info exists { local | global | param } varName/paramName ] Returns existence (0: False, 1: True) of the local or global variable specified by varName or parameter specified by paramName . Similar to the Tcl info exists command.
- [info homeDir] Returns the path to the home directory of the current user. The format of the path is appropriate for the operating system.
- [info hostIp] Returns the IP address of the computer that is currently running iTest
- [info hostName] Returns the hostname of the computer that is currently running iTest
- [info issueCount { ok|information|warning|error|all } ] Returns, for this moment in the current execution, the current number of execution issues of the specified severity
- [info paramFile ? path ? ] Returns the fully-qualified URL of the current parameter file. (For example, project://my_ project/parameter_files/file_name.ffpt)
If you use the optional path argument, then the URL is not returned. Instead, the command returns the path to the file in the format appropriate for the operating system.
- [info platform] Returns the current operating system (windows, linux, or solaris)
- [info procedure] Returns the name of the procedure that contains the currently executing step
- [info profile ? path ? ] Returns the fully-qualified URL of the session profile (if any) associated with the currently executing step. (For example, project://my_ project/session_profiles/file_name.ffsp)
If you use the optional path argument, then the URL is not returned. Instead, the command returns the path to the file in the format appropriate for the operating system.
- [info project { current | main } ] Returns the fully-qualified URL of the project that contains the currently executing test case or the URL of the main test case (the test case for which you clicked the Execute button).
- [info status] Returns the current status of the test case being executed: Pass, Fail, or Indeterminate.  If no test case is running, returns Indeterminate.
- [info step testCase] Returns the step ID (for example, 2.5.3) of the currently executing step
- [info step report] Returns the step ID (for example, 2.3.1.5) of the step from the Test report currently being executed
- [info tempDir] Returns the path to the temporary directory of the current user. The format of the path is appropriate for the operating system
- [info testbedFile ? path ? ] Returns the fully-qualified URL of the current testbed (if any). (For example, project://my_ project/testbeds/file_name.fftb)
If you use the optional path argument, then the URL is not returned. Instead, the command returns the path to the file in the format appropriate for the operating system.
- [info testCaseFile { current | main } ? path ? ] If you use the current argument, then the command returns the fully-qualified URL of the test case that contains the currently executing step. (For example, project://proj_name/dir_name/file_name.fftc)
If you use the main argument, then the command returns the fully-qualified URL of the test case for which you clicked the Execute button.
If you use the optional path argument, then the URL is not returned. Instead, the command returns the path to the file specified by either main or current. The format of the path is appropriate for the operating system.
- [info testCaseProject { current | main } ] If you use the current argument, then the command returns the name of the project for the test case that contains the currently executing step.
If you use the main argument, then the command returns the name of the project for the main test case (the test case for which you clicked the Execute button).
- [info testCaseProjectPath { current | main } ] If you use the current argument, then the command returns the path to the project of the test case that contains the currently executing step. The format of the path is appropriate for the operating system.
If you use the main argument, then the command returns the path to the project of the test case for which you clicked the Execute button.
- [info threadId] Returns the ID of the current thread
- [info time] Returns the number of seconds (floating point) since execution of the current test case started, excluding pauses.  If not currently executing, returns 0.
- [info timestamp ? formatString ? ] Returns a timestamp of current local time. If you do not specify the optional format string, then the command uses Java's localized full timestamp format. An example formatString is yyyy-MM-dd HH:mm:ss.SSS .   Format strings are based on Java's SimpleDateFormat.  See http://java.sun.com/j2se/1.5.0/docs/api/java/text/SimpleDateFormat.html
- [info user] Returns the username of the current user.
- [info version] Returns the full version number (for example, 5.0.1) of the current iTest instance
- [info workspacePath] Returns the full path of the current workspace.
- For details on each iTest command, see the online help: Command syntax for test case steps .
