---
chunk_id: itest-help_26.2.0.zip-popups-info_python.html-83693a1d07c0-bd7e3e520122-chunk-0001
source_id: itest-help_26.2.0.zip-popups-info_python.html-83693a1d07c0-bd7e3e520122
title: info
heading_path:
- info
section_titles:
- info
source_block_ids:
- itest-help_26.2.0.zip-popups-info_python.html-83693a1d07c0-bd7e3e520122-block-0001
- itest-help_26.2.0.zip-popups-info_python.html-83693a1d07c0-bd7e3e520122-block-0002
- itest-help_26.2.0.zip-popups-info_python.html-83693a1d07c0-bd7e3e520122-block-0003
- itest-help_26.2.0.zip-popups-info_python.html-83693a1d07c0-bd7e3e520122-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 95
source_hash: bd7e3e520122efc6053b2affecdf7ea27991804fc3a9255c3f57166cc8faec23
normalized_document_hash: 4d6a3e4b40bb34e885a2ca0acc06a1f22c5226538c2c0c04d7ec4a55497a2f6e
content_status: success
content_sha256: 58bb292c27b9751fe68c6d5a5744d46a08091bac31ecc08ed412a777c794d25a
---

# info

info ('subcommand') #*arguments The info commands return information about execution, about the current instance of iTest, and about the local computer. You can use an eval action with an info command or can use the command in a field replacement.

Example: info('env' , 'varName' ) Returns the contents of the  environment variable specified by varName

For details on each iTest command, see the online help: Commands for returning information .
