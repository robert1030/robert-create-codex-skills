# info

info ('subcommand') #*arguments The info commands return information about execution, about the current instance of iTest, and about the local computer. You can use an eval action with an info command or can use the command in a field replacement.

Example: info('env' , 'varName' ) Returns the contents of the  environment variable specified by varName

For details on each iTest command, see the online help: Commands for returning information .
