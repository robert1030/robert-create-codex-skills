---
chunk_id: itest-help_26.2.0.zip-popups-insertimage.html-ebe29b911750-275cc534122a-chunk-0001
source_id: itest-help_26.2.0.zip-popups-insertimage.html-ebe29b911750-275cc534122a
title: insertImage
heading_path:
- insertImage
section_titles:
- insertImage
source_block_ids:
- itest-help_26.2.0.zip-popups-insertimage.html-ebe29b911750-275cc534122a-block-0001
- itest-help_26.2.0.zip-popups-insertimage.html-ebe29b911750-275cc534122a-block-0002
- itest-help_26.2.0.zip-popups-insertimage.html-ebe29b911750-275cc534122a-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 41
source_hash: 275cc534122ac65627f39b73fddeb20d016bb838411b8811d8cf8ca19c24bd44
normalized_document_hash: e89c51b958526696e6b6f3f860984fbcb6178a3c2ce173898c4cc9ee9d8347f5
content_status: success
content_sha256: 97887580f8f6b2a0fd83c854fcea3d0b3b1eeed894fa22e5878f8fb0d1c23b90
---

# insertImage

Add image to message body (from the local file system) that is specified in the Description cell.

For details, see the online help: Sending email messages during test execution .
