---
chunk_id: itest-help_26.2.0.zip-popups-java.html-5f35b1d2a998-22f8e54c2e71-chunk-0001
source_id: itest-help_26.2.0.zip-popups-java.html-5f35b1d2a998-22f8e54c2e71
title: '[java {statement}]'
heading_path:
- '[java {statement}]'
section_titles:
- '[java {statement}]'
source_block_ids:
- itest-help_26.2.0.zip-popups-java.html-5f35b1d2a998-22f8e54c2e71-block-0001
- itest-help_26.2.0.zip-popups-java.html-5f35b1d2a998-22f8e54c2e71-block-0002
- itest-help_26.2.0.zip-popups-java.html-5f35b1d2a998-22f8e54c2e71-block-0003
- itest-help_26.2.0.zip-popups-java.html-5f35b1d2a998-22f8e54c2e71-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 91
source_hash: 22f8e54c2e71d7de1706179706b580f62be80d3c891856012eafcb90cd33387d
normalized_document_hash: 6665f3097eaa624f052a4f477b3f74e460ada0a715e7f1ac53cc350577d8f3d4
content_status: success
content_sha256: 1971297da9d36b136ebad77b6a9899c49ce5bad64a1502a49b91277de648dfe5
---

# [java {statement}]

The iTest interpreter java command calls on the execution kernel's java interpreter (implemented using BeanShell), concatenates all arguments into a single string and evaluates it as a Java statement (or BeanShell statement), and then returns the result of that evaluation.

For details on using this and other iTest interpreter commands, see iTest interpreter command syntax .

Also, see: Field replacements: Substituting values into properties and commands .
