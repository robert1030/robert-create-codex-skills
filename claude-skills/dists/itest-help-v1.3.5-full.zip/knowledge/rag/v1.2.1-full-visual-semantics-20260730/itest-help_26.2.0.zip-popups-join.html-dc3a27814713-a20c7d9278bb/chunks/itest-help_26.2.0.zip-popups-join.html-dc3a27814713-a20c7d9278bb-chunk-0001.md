---
chunk_id: itest-help_26.2.0.zip-popups-join.html-dc3a27814713-a20c7d9278bb-chunk-0001
source_id: itest-help_26.2.0.zip-popups-join.html-dc3a27814713-a20c7d9278bb
title: join
heading_path:
- join
section_titles:
- join
source_block_ids:
- itest-help_26.2.0.zip-popups-join.html-dc3a27814713-a20c7d9278bb-block-0001
- itest-help_26.2.0.zip-popups-join.html-dc3a27814713-a20c7d9278bb-block-0002
- itest-help_26.2.0.zip-popups-join.html-dc3a27814713-a20c7d9278bb-block-0003
- itest-help_26.2.0.zip-popups-join.html-dc3a27814713-a20c7d9278bb-block-0004
- itest-help_26.2.0.zip-popups-join.html-dc3a27814713-a20c7d9278bb-block-0005
- itest-help_26.2.0.zip-popups-join.html-dc3a27814713-a20c7d9278bb-block-0006
- itest-help_26.2.0.zip-popups-join.html-dc3a27814713-a20c7d9278bb-block-0007
- itest-help_26.2.0.zip-popups-join.html-dc3a27814713-a20c7d9278bb-block-0008
- itest-help_26.2.0.zip-popups-join.html-dc3a27814713-a20c7d9278bb-block-0009
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 119
source_hash: a20c7d9278bb3611dee5647dd13445f3607a013bf069a282eb4e018658b44b40
normalized_document_hash: 251ce785e4e4896fc245927608e112dc30ea89f1358f1201a61c3e702bca4f7e
content_status: success
content_sha256: 4eec9d2314e5a827cdf5c4f4941bff0ab59e30ad73a85ee4e05af7319e6ec9eb
---

# join

join list ? joinString ?

The join command creates a string by joining together list elements.

The list argument must be a valid Tcl list. The command returns the string formed by joining all of the elements of list together with joinString separating each adjacent pair of elements. The joinString argument defaults to a space character.

The

join

command is compatible with its Tcl counterpart as more fully described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
