# join

join list ? joinString ?

The join command creates a string by joining together list elements.

The list argument must be a valid Tcl list. The command returns the string formed by joining all of the elements of list together with joinString separating each adjacent pair of elements. The joinString argument defaults to a space character.

The

join

command is compatible with its Tcl counterpart as more fully described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
