---
chunk_id: itest-help_26.2.0.zip-popups-json_exec.html-1854771b873a-5420b434b4ac-chunk-0001
source_id: itest-help_26.2.0.zip-popups-json_exec.html-1854771b873a-5420b434b4ac
title: json
heading_path:
- json
section_titles:
- json
source_block_ids:
- itest-help_26.2.0.zip-popups-json_exec.html-1854771b873a-5420b434b4ac-block-0001
- itest-help_26.2.0.zip-popups-json_exec.html-1854771b873a-5420b434b4ac-block-0002
- itest-help_26.2.0.zip-popups-json_exec.html-1854771b873a-5420b434b4ac-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 50
source_hash: 5420b434b4ac33d2177932537a6271123e60e04e8ef56e9f296173e916e84a7e
normalized_document_hash: 886e5c2a41d2122f915bbc1d2ee63c47880f932f36511b7d1e9997efc57b03a0
content_status: success
content_sha256: b3c78b81fe0f44483641ea46a2ca732a2e6caaa048125523dbd0bbacd131b6ef
---

# json

Use a json step to perform CREATE, READ, UPDATE, DELETE operations on nodes in a JSON document.

For details on preparing the configuration text and adding a JSON step, see the online help: The JSON action .
