# json

Use a json step to perform CREATE, READ, UPDATE, DELETE operations on nodes in a JSON document.

For details on preparing the configuration text and adding a JSON step, see the online help: The JSON action .
