---
chunk_id: itest-help_26.2.0.zip-popups-jsonselect.html-948cb91a1490-cf1130987132-chunk-0001
source_id: itest-help_26.2.0.zip-popups-jsonselect.html-948cb91a1490-cf1130987132
title: jsonSelect
heading_path:
- jsonSelect
section_titles:
- jsonSelect
source_block_ids:
- itest-help_26.2.0.zip-popups-jsonselect.html-948cb91a1490-cf1130987132-block-0001
- itest-help_26.2.0.zip-popups-jsonselect.html-948cb91a1490-cf1130987132-block-0002
- itest-help_26.2.0.zip-popups-jsonselect.html-948cb91a1490-cf1130987132-block-0003
- itest-help_26.2.0.zip-popups-jsonselect.html-948cb91a1490-cf1130987132-block-0004
- itest-help_26.2.0.zip-popups-jsonselect.html-948cb91a1490-cf1130987132-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 170
source_hash: cf1130987132ece56418a4c7a25b934e1ffb72a96cff60f247c216c24d2d3830
normalized_document_hash: 54b79821b3ac489ef44b0f2fdae876635e9df814f04ec7bb69eb6b4aea16e5bc
content_status: success
content_sha256: dc0c24074d8a0c0fdc4d1e7a216a7a8c76e1ddff6fe95f7ed999d6bf262ef5fa
---

# jsonSelect

Use jsonSelect command to get the node value from the json_string, based on the provided query_xpath. The command returns the value of the specific node based on the provided xpath.

Note: The xpath should be a valid xpath for XML (not the JsonPath - http://goessner.net/articles/JsonPath/), otherwise no value is returned. The provided json string will be converted to xml first, and then evaluated using the xpath and gets the specific value.

Syntax: jsonSelect json_string query_xpath json_string is the valid json string. Query_xpath is the valid xpath for xml. Note: If the xpath location is not a single value, then an assembled version of sub values will be retrieved.

For details on Get the node value from json string, see the online help: jsonSelect command .
