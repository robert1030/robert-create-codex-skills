---
chunk_id: itest-help_26.2.0.zip-popups-jsonselect_python.html-4295dd17e6e0-f579cf1e2863-chunk-0001
source_id: itest-help_26.2.0.zip-popups-jsonselect_python.html-4295dd17e6e0-f579cf1e2863
title: jsonSelect
heading_path:
- jsonSelect
section_titles:
- jsonSelect
source_block_ids:
- itest-help_26.2.0.zip-popups-jsonselect_python.html-4295dd17e6e0-f579cf1e2863-block-0001
- itest-help_26.2.0.zip-popups-jsonselect_python.html-4295dd17e6e0-f579cf1e2863-block-0002
- itest-help_26.2.0.zip-popups-jsonselect_python.html-4295dd17e6e0-f579cf1e2863-block-0003
- itest-help_26.2.0.zip-popups-jsonselect_python.html-4295dd17e6e0-f579cf1e2863-block-0004
- itest-help_26.2.0.zip-popups-jsonselect_python.html-4295dd17e6e0-f579cf1e2863-block-0005
- itest-help_26.2.0.zip-popups-jsonselect_python.html-4295dd17e6e0-f579cf1e2863-block-0006
- itest-help_26.2.0.zip-popups-jsonselect_python.html-4295dd17e6e0-f579cf1e2863-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 180
source_hash: f579cf1e2863366647a4550fcb300c982ac0802b8a56d7b287057fc367fa2b8e
normalized_document_hash: 37f143cf34799d988a503c3c11f9fe41464a550d5d97c1ef00a338e9d749d882
content_status: success
content_sha256: 6f2a67b4dd910b766255b549877b97e33938df64fa413bc807bbafbb6ec642c0
---

# jsonSelect

jsonSelect ('jsonString', 'queryXpath')

The jsonSelect command takes two arguments. The first argument is the json string. The second argument is the xpath query, and returns the extracted value(typically a single string).

Syntax: jsonSelect('jsonString', 'queryXpath') json_str is the valid json string. xpath is the valid xpath for xml. Example: eval jsonSelect("{'key1':'value1'}", "key1")

Note: The xpath should be a valid xpath for XML (not the JsonPath - http://goessner.net/articles/JsonPath/), otherwise no value is returned. The provided json string will be converted to xml first, and then evaluated using the xpath and gets the specific value.

Note: If the xpath location is not a single value, then an assembled version of sub values will be retrieved.

See also the online help: jsonSelect command .
