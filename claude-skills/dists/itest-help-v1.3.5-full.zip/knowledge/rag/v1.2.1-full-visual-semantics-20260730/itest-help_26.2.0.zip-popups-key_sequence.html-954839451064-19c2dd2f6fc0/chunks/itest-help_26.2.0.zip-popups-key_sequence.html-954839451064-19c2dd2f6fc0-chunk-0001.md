---
chunk_id: itest-help_26.2.0.zip-popups-key_sequence.html-954839451064-19c2dd2f6fc0-chunk-0001
source_id: itest-help_26.2.0.zip-popups-key_sequence.html-954839451064-19c2dd2f6fc0
title: Key Sequence
heading_path:
- Key Sequence
section_titles:
- Key Sequence
source_block_ids:
- itest-help_26.2.0.zip-popups-key_sequence.html-954839451064-19c2dd2f6fc0-block-0001
- itest-help_26.2.0.zip-popups-key_sequence.html-954839451064-19c2dd2f6fc0-block-0002
- itest-help_26.2.0.zip-popups-key_sequence.html-954839451064-19c2dd2f6fc0-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 78
source_hash: 19c2dd2f6fc045354c16ea0af7f6f620c9cfe378e2e55ee567ccda6c8aec9c5d
normalized_document_hash: 78b00a072e8a897e800a61a604ab33624167e378dc9413b820d2afb3729922e8
content_status: success
content_sha256: b8d35538f031a2d6157926224519f7b63adaa7ab8b4e23a8f79185686dbc0ef8
---

# Key Sequence

Use action to execute or to simulate a key sequence on a specified repository item. This action is typically recorded in a form filling scenario (e.g., username field in login process). Note: This action requires a repository item assignment.

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
