# Key Sequence

Use action to execute or to simulate a key sequence on a specified repository item. This action is typically recorded in a form filling scenario (e.g., username field in login process). Note: This action requires a repository item assignment.

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
