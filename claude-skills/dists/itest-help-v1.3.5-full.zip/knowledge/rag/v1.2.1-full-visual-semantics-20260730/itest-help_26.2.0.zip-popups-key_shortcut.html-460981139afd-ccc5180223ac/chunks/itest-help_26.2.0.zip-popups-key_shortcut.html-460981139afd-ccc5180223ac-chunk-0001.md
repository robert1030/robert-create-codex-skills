---
chunk_id: itest-help_26.2.0.zip-popups-key_shortcut.html-460981139afd-ccc5180223ac-chunk-0001
source_id: itest-help_26.2.0.zip-popups-key_shortcut.html-460981139afd-ccc5180223ac
title: Key Shortcut
heading_path:
- Key Shortcut
section_titles:
- Key Shortcut
source_block_ids:
- itest-help_26.2.0.zip-popups-key_shortcut.html-460981139afd-ccc5180223ac-block-0001
- itest-help_26.2.0.zip-popups-key_shortcut.html-460981139afd-ccc5180223ac-block-0002
- itest-help_26.2.0.zip-popups-key_shortcut.html-460981139afd-ccc5180223ac-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 67
source_hash: ccc5180223ac4573df9d74afd4d603897d13efed2db4dbd79a969bdc3d650f6a
normalized_document_hash: 981bee5c636d7b9f72b72ff696050662b4c864df55d3a26c75a6d91decba4315
content_status: success
content_sha256: 429486a9eadb35ff0cb08c9def1c1390f0b71a812571cc8280af4217485b6949
---

# Key Shortcut

Use sction for executing key shortcut actions. In addition to the shortcut actions, you may also specify the key codes Press, Up and Down. Note: This action requires a repository item assignment.

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
