# Key Shortcut

Use sction for executing key shortcut actions. In addition to the shortcut actions, you may also specify the key codes Press, Up and Down. Note: This action requires a repository item assignment.

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
