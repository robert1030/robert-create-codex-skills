---
chunk_id: itest-help_26.2.0.zip-popups-killthread.html-706b691be9ed-ee1764001a8a-chunk-0001
source_id: itest-help_26.2.0.zip-popups-killthread.html-706b691be9ed-ee1764001a8a
title: killthread
heading_path:
- killthread
section_titles:
- killthread
source_block_ids:
- itest-help_26.2.0.zip-popups-killthread.html-706b691be9ed-ee1764001a8a-block-0001
- itest-help_26.2.0.zip-popups-killthread.html-706b691be9ed-ee1764001a8a-block-0002
- itest-help_26.2.0.zip-popups-killthread.html-706b691be9ed-ee1764001a8a-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 33
source_hash: ee1764001a8a817fdc4fd54d2938e25e415ca221b5a6ea39c36154834788e3a8
normalized_document_hash: 8deae1f78c54c912371cc935a360fcda1f203a8212cfafe2e5a28da8656971bb
content_status: success
content_sha256: a94fb3aa08564bb241faf5b2ea571dfba16883cdc3f74f0d9fceca2e1f1b9ee0
---

# killthread

Use a killThread step to immediately stop execution of the specified thread.

For details, see the online help: killThread: Kill the specified threads .
