# killthread

Use a killThread step to immediately stop execution of the specified thread.

For details, see the online help: killThread: Kill the specified threads .
