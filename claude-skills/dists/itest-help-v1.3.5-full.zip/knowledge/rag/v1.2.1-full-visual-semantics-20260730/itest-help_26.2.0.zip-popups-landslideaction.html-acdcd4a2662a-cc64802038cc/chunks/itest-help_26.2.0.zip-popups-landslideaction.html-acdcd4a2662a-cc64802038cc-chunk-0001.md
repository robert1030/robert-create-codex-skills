---
chunk_id: itest-help_26.2.0.zip-popups-landslideaction.html-acdcd4a2662a-cc64802038cc-chunk-0001
source_id: itest-help_26.2.0.zip-popups-landslideaction.html-acdcd4a2662a-cc64802038cc
title: Landslide Actions
heading_path:
- Landslide Actions
section_titles:
- Landslide Actions
source_block_ids:
- itest-help_26.2.0.zip-popups-landslideaction.html-acdcd4a2662a-cc64802038cc-block-0001
- itest-help_26.2.0.zip-popups-landslideaction.html-acdcd4a2662a-cc64802038cc-block-0002
- itest-help_26.2.0.zip-popups-landslideaction.html-acdcd4a2662a-cc64802038cc-block-0003
- itest-help_26.2.0.zip-popups-landslideaction.html-acdcd4a2662a-cc64802038cc-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 107
source_hash: cc64802038ccc5141803632c8b720ce5680ec24da0b8249666f4577e5e53033e
normalized_document_hash: d35ffd7861ecab7b3efb15bb265d7d1517f2d43c71dba93d749486f87c433b6e
content_status: success
content_sha256: ff052b644db68ae6e5e111f68a01b31fcb5558a9ba17bcf4979b704c81fd4a2e
---

# Landslide Actions

The name of each Spirent iTest action corresponds directly to the name of the Landslide Tcl API function (ls:: action) that it executes. See the Landslide Tcl API Object and Perform Function Reference for details on operation and usage.

If the Landslide Tcl command associated with the Spirent iTest step/action requires arguments, then you can view and set the argument values in the Step Properties section.

Each Spirent iTest action returns the same values as the corresponding Landslide command.
