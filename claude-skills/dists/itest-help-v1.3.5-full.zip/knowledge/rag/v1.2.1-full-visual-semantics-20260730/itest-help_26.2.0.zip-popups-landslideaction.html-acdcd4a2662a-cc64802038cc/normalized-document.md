# Landslide Actions

The name of each Spirent iTest action corresponds directly to the name of the Landslide Tcl API function (ls:: action) that it executes. See the Landslide Tcl API Object and Perform Function Reference for details on operation and usage.

If the Landslide Tcl command associated with the Spirent iTest step/action requires arguments, then you can view and set the argument values in the Step Properties section.

Each Spirent iTest action returns the same values as the corresponding Landslide command.
