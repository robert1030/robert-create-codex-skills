---
chunk_id: itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-chunk-0001
source_id: itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873
title: lappend
heading_path:
- lappend
section_titles:
- lappend
source_block_ids:
- itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-block-0001
- itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-block-0002
- itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-block-0003
- itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-block-0004
- itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-block-0005
- itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-block-0006
- itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-block-0007
- itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-block-0008
- itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-block-0009
- itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-block-0010
- itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-block-0011
- itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-block-0012
- itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-block-0013
- itest-help_26.2.0.zip-popups-lappend.html-932bd61e6fa7-0ab5a0f53873-block-0014
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 94
source_hash: 0ab5a0f5387341c25cdb9d89bf7580b34d90d27e664ac58a10c5bf9d2aeecb01
normalized_document_hash: f0ceebe9783d1e0b2ef8e66d4025894e7527f7d18221f9cb8e89998cec15be9c
content_status: success
content_sha256: a49d816a8cec9c795e0d395b606b7dd985a060090f6e258afbeedd01c39e6e65
---

# lappend

lappend varName ? value value value ... ?

The

lappend

command treats the variable given by

varName

as a list and appends each of the

value

arguments to the list as a separate element, with spaces between elements.

The

lappend

command is compatible with its Tcl counterpart as described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
