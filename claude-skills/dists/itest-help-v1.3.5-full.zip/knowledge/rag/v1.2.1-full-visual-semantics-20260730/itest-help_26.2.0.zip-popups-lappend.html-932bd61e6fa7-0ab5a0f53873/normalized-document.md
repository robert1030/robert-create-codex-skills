# lappend

lappend varName ? value value value ... ?

The

lappend

command treats the variable given by

varName

as a list and appends each of the

value

arguments to the list as a separate element, with spaces between elements.

The

lappend

command is compatible with its Tcl counterpart as described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
