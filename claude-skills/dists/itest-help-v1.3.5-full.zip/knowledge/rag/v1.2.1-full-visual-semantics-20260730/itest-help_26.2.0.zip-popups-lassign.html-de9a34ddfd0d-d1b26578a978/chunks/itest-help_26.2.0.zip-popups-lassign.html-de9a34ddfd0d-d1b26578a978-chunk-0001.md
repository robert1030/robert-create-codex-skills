---
chunk_id: itest-help_26.2.0.zip-popups-lassign.html-de9a34ddfd0d-d1b26578a978-chunk-0001
source_id: itest-help_26.2.0.zip-popups-lassign.html-de9a34ddfd0d-d1b26578a978
title: lassign
heading_path:
- lassign
section_titles:
- lassign
source_block_ids:
- itest-help_26.2.0.zip-popups-lassign.html-de9a34ddfd0d-d1b26578a978-block-0001
- itest-help_26.2.0.zip-popups-lassign.html-de9a34ddfd0d-d1b26578a978-block-0002
- itest-help_26.2.0.zip-popups-lassign.html-de9a34ddfd0d-d1b26578a978-block-0003
- itest-help_26.2.0.zip-popups-lassign.html-de9a34ddfd0d-d1b26578a978-block-0004
- itest-help_26.2.0.zip-popups-lassign.html-de9a34ddfd0d-d1b26578a978-block-0005
- itest-help_26.2.0.zip-popups-lassign.html-de9a34ddfd0d-d1b26578a978-block-0006
- itest-help_26.2.0.zip-popups-lassign.html-de9a34ddfd0d-d1b26578a978-block-0007
- itest-help_26.2.0.zip-popups-lassign.html-de9a34ddfd0d-d1b26578a978-block-0008
- itest-help_26.2.0.zip-popups-lassign.html-de9a34ddfd0d-d1b26578a978-block-0009
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 142
source_hash: d1b26578a9781d84788ca3282928a23b0f542e382c69ceada6dd67b0b46503df
normalized_document_hash: f250745c3b5b9c4f4b0ed6d04e19fb80bb962998f767a4770a041ed76865874c
content_status: success
content_sha256: 3cc07727917e23f03d6c2db0a559542be590f63a1cd5b784e4058cc1216ed311
---

# lassign

lassign list varName ? varName ... ?

The lassign command assigns list elements to variables.

The command treats the value list as a list and assigns successive elements from that list to the variables given by the varName arguments in order. If there are more variable names than list elements, the remaining variables are set to the empty string. If there are more list elements than variables, a list of unassigned elements is returned.

The

lassign

command is compatible with its Tcl counterpart as more fully described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
