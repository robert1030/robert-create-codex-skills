---
chunk_id: itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-chunk-0001
source_id: itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec
title: lcompare
heading_path:
- lcompare
section_titles:
- lcompare
source_block_ids:
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0001
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0002
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0003
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0004
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0005
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0006
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0007
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0008
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0009
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0010
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0011
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0012
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0013
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0014
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0015
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0016
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0017
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0018
- itest-help_26.2.0.zip-popups-lcompare.html-845f8b3c6e17-fefb74233fec-block-0019
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 72
source_hash: fefb74233fecd68fb35f0cbb7f4d6a434912099fcbe81227a21e280c260bf2b5
normalized_document_hash: 121b9b898afa88eddb71472758cfbc71cf0f9602e23008416d2893a77581d642
content_status: success
content_sha256: 210fb239e7873baf03ae73b8aebe3844ee6a7b0fdf82212bed45f5e3563f69cb
---

# lcompare

lcompare list1 list2

The

lcompare

command compares two lists and:

Returns -1 if

list1

is less than

list2

Returns 0 if

list1

is equal to

list2

Returns 1 if

list1

is bigger than

list2

Lists are compared recursively.

For details on each iTest command, see the online help: Command syntax for test case steps .
