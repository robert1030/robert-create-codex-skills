# lcompare

lcompare list1 list2

The

lcompare

command compares two lists and:

Returns -1 if

list1

is less than

list2

Returns 0 if

list1

is equal to

list2

Returns 1 if

list1

is bigger than

list2

Lists are compared recursively.

For details on each iTest command, see the online help: Command syntax for test case steps .
