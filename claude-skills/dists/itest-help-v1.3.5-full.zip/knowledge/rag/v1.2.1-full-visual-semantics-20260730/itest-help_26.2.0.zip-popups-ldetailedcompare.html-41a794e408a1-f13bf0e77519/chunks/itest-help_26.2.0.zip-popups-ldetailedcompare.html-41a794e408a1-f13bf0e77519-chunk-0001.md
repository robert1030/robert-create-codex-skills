---
chunk_id: itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-chunk-0001
source_id: itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519
title: PLACEHOLDER
heading_path:
- PLACEHOLDER
section_titles:
- ldetailedcompare
- PLACEHOLDER
source_block_ids:
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0001
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0002
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0003
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0004
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0005
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0006
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0007
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0008
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0009
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0010
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0011
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0012
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0013
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0014
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0015
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0016
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0017
- itest-help_26.2.0.zip-popups-ldetailedcompare.html-41a794e408a1-f13bf0e77519-block-0018
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 70
source_hash: f13bf0e775190e392e7fa201749712d47c64a9c81a004422791151caaf585cae
normalized_document_hash: 3f571a3bcad8c214f2b2f460ddfe135274d8cab24e1468b4b2318542a97841f9
content_status: success
content_sha256: 63fa38d07017030f300d955e62a2dbd75e416daf233a3d051005d56716c728fd
---

# ldetailedcompare

# PLACEHOLDER

ldetailedcompare list1 list2

Compares two lists and:

Returns -1 if

list1

is less than

list2

Returns 0 if

list1

is equal to

list2

Returns 1 if

list1

is bigger than

list2

Lists are compared recursively.

For details on each iTest command, see the online help: Command syntax for test case steps .
