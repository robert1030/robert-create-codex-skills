---
chunk_id: itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-chunk-0001
source_id: itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa
title: lindex
heading_path:
- lindex
section_titles:
- lindex
source_block_ids:
- itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-block-0001
- itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-block-0002
- itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-block-0003
- itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-block-0004
- itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-block-0005
- itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-block-0006
- itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-block-0007
- itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-block-0008
- itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-block-0009
- itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-block-0010
- itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-block-0011
- itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-block-0012
- itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-block-0013
- itest-help_26.2.0.zip-popups-lindex.html-3f5b355982ec-330354f517aa-block-0014
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 169
source_hash: 330354f517aaa1cff5d7cf737672dbd5aa6f48fa515884f5138e753c2b4c5510
normalized_document_hash: 33955a8a82b4752236f6cb3665fefbf94a38bfacebfd8e28b62eb10d3b772265
content_status: success
content_sha256: 3d838bc769d440842820c30864394fd9f1afb6623fe087c69a1f749445d2a913
---

# lindex

lindex list ? index ?

The

lindex

command accepts a parameter,

list

, which it treats as a Tcl list. It also accepts zero or more indexes into the list. The indexes may be presented either consecutively on the command line, or grouped in a Tcl list and presented as a single argument.

You can specify end?-n? as an index: lindex {a b c} end will return c lindex {a b c} end-1 will return b

If no indexes are present, then the return value of lindex is the value of the list parameter.

The

lindex

command is compatible with its Tcl counterpart as described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
