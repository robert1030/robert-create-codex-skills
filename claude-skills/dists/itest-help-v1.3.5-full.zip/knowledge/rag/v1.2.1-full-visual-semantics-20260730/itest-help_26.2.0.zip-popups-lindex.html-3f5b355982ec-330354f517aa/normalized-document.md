# lindex

lindex list ? index ?

The

lindex

command accepts a parameter,

list

, which it treats as a Tcl list. It also accepts zero or more indexes into the list. The indexes may be presented either consecutively on the command line, or grouped in a Tcl list and presented as a single argument.

You can specify end?-n? as an index: lindex {a b c} end will return c lindex {a b c} end-1 will return b

If no indexes are present, then the return value of lindex is the value of the list parameter.

The

lindex

command is compatible with its Tcl counterpart as described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
