---
chunk_id: itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-chunk-0001
source_id: itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39
title: linsert
heading_path:
- linsert
section_titles:
- linsert
source_block_ids:
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0001
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0002
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0003
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0004
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0005
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0006
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0007
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0008
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0009
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0010
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0011
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0012
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0013
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0014
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0015
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0016
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0017
- itest-help_26.2.0.zip-popups-linsert.html-4d119a770103-9c1cf8364f39-block-0018
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 174
source_hash: 9c1cf8364f3957a56adf7b2cc6111a895d9c4be0670bc7891110520a4355dda6
normalized_document_hash: 8f925f4ed89829e9c34342a3aaa79ea8269eb23a01a031318a1ae946181399df
content_status: success
content_sha256: 3a32ef497d95ac99e2f792f12ed46dbee7bf660270e59ab52fb478ad960c5ada
---

# linsert

linsert list index element ? element element ... ?

The

linsert

command inserts elements into a list. The command produces a new list from

list

by inserting all of the element arguments just before the

index

'th element of list. Each element argument will become a separate element of the new list. If

index

is less than or equal to zero, then the new elements are inserted at the beginning of the list. The interpretation of the

index

value is the same as for the command string index, supporting simple index arithmetic and indexes relative to the end of the list.

The

linsert

command is compatible with its Tcl counterpart as described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
