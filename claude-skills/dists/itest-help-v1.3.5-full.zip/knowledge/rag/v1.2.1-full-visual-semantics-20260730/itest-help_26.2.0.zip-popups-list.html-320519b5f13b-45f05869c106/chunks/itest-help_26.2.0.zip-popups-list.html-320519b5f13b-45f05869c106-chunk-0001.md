---
chunk_id: itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-chunk-0001
source_id: itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106
title: list
heading_path:
- list
section_titles:
- list
source_block_ids:
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0001
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0002
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0003
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0004
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0005
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0006
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0007
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0008
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0009
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0010
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0011
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0012
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0013
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0014
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0015
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0016
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0017
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0018
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0019
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0020
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0021
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0022
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0023
- itest-help_26.2.0.zip-popups-list.html-320519b5f13b-45f05869c106-block-0024
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 173
source_hash: 45f05869c106067129daabbf2c621744b59a1145499d67a6c82871b6c7f66d67
normalized_document_hash: f36e1487e78644ac2793f262b9ca36521924841ba524b859183f7ca1aa9f46a0
content_status: success
content_sha256: 5ea947c8b92d983044ce75662a48e008bc24b8f372adab10bc82b818a7ffed8c
---

# list

list ? arg arg ... ?

The

list

command returns a list comprised of all the args, or an empty string if no args are specified. Braces and backslashes get added as necessary, so that the

lindex

command may be used on the result to re-extract the original arguments, and also so that

eval

may be used to execute the resulting list, with

arg1

comprising the command's name and the other args comprising its arguments.

list

produces slightly different results than

concat

:

concat

removes one level of grouping before forming the list, while

list

works directly from the original arguments.

The

list

command is compatible with its Tcl counterpart as described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
