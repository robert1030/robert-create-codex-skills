# list

list ? arg arg ... ?

The

list

command returns a list comprised of all the args, or an empty string if no args are specified. Braces and backslashes get added as necessary, so that the

lindex

command may be used on the result to re-extract the original arguments, and also so that

eval

may be used to execute the resulting list, with

arg1

comprising the command's name and the other args comprising its arguments.

list

produces slightly different results than

concat

:

concat

removes one level of grouping before forming the list, while

list

works directly from the original arguments.

The

list

command is compatible with its Tcl counterpart as described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
