---
chunk_id: itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-chunk-0001
source_id: itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6
title: list commands
heading_path:
- list commands
section_titles:
- list commands
- 'The following functions are supported:'
source_block_ids:
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0001
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0002
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0003
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0004
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0005
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0006
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0007
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0008
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0009
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0010
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0011
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0012
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0013
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0014
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0015
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0016
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0017
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0018
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0019
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0020
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0021
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0022
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0023
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0024
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0025
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0026
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0027
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0028
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0029
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0030
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0031
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0032
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0033
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0034
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0035
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0036
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0037
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0038
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0039
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0040
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0041
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0042
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0043
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0044
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0045
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0046
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0047
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0048
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0049
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0050
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0051
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0052
- itest-help_26.2.0.zip-popups-list_functions.html-db79d3067e72-a5f4486f17c6-block-0053
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 124
source_hash: a5f4486f17c63503f85c2f6d8f47ae6f96c3201ec95127a8507c9d2c96101d1f
normalized_document_hash: 8d612b32078de298dce067b1dc2e8cb010cf52d46aece32b338b56abead931cb
content_status: success
content_sha256: b97083544f84c99088613156718ebed32fadde6b80be853b221acc1eb0cd5bb2
---

# list commands

Each of the iTest list function commands is compatible with its Tcl counterpart as described at:

http://www.tcl.tk/man

##### The following functions are supported:

[

lappend

varName

?value value value ...?]

[

lcompare

list1 list2

]

[

lindex

list index

]

[

linsert

list index element

?

element element ...

?]

[

list

arg ... arg

]

[

llength

list

]

[

lrange

list first last

]

[

lreplace

list first last

?

element element ...

?]

[

lsearch

list pattern

]

[

lset

varName

?

index...

?

newValue

]

For details for each function, see the online help: Command syntax for test case steps .
