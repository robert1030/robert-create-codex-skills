# list commands

Each of the iTest list function commands is compatible with its Tcl counterpart as described at:

http://www.tcl.tk/man

##### The following functions are supported:

[

lappend

varName

?value value value ...?]

[

lcompare

list1 list2

]

[

lindex

list index

]

[

linsert

list index element

?

element element ...

?]

[

list

arg ... arg

]

[

llength

list

]

[

lrange

list first last

]

[

lreplace

list first last

?

element element ...

?]

[

lsearch

list pattern

]

[

lset

varName

?

index...

?

newValue

]

For details for each function, see the online help: Command syntax for test case steps .
