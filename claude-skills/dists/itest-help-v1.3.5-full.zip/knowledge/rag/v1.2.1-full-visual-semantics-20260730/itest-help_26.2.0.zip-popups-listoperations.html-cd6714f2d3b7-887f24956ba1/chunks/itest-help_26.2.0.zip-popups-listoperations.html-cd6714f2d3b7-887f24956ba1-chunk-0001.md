---
chunk_id: itest-help_26.2.0.zip-popups-listoperations.html-cd6714f2d3b7-887f24956ba1-chunk-0001
source_id: itest-help_26.2.0.zip-popups-listoperations.html-cd6714f2d3b7-887f24956ba1
title: listOperations
heading_path:
- listOperations
section_titles:
- listOperations
source_block_ids:
- itest-help_26.2.0.zip-popups-listoperations.html-cd6714f2d3b7-887f24956ba1-block-0001
- itest-help_26.2.0.zip-popups-listoperations.html-cd6714f2d3b7-887f24956ba1-block-0002
- itest-help_26.2.0.zip-popups-listoperations.html-cd6714f2d3b7-887f24956ba1-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 52
source_hash: 887f24956ba145dfb6f2e848035cbb0f474831b3bec496e8647283479031e10a
normalized_document_hash: 6057af69e116c87ef0d7dce6bff07a7c2467b710c095fdf3943be4c0dc18561c
content_status: success
content_sha256: 8b096ff06527b8f4f76988a72a167a6f4a20df2329a7b2f78b7f0a1e88790ecd
---

# listOperations

When we start the session, iTest opens the Web Services Client session window, obtains the endpoint from the WSDL, and then displays all available operations in the Operations list.

For details, see the online help: Web Services Session .
