# listOperations

When we start the session, iTest opens the Web Services Client session window, obtains the endpoint from the WSDL, and then displays all available operations in the Operations list.

For details, see the online help: Web Services Session .
