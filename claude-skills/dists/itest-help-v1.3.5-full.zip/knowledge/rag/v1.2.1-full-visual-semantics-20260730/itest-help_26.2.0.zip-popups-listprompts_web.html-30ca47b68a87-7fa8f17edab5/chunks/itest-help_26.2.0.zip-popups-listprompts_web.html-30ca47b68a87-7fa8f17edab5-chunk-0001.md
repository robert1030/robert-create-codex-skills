---
chunk_id: itest-help_26.2.0.zip-popups-listprompts_web.html-30ca47b68a87-7fa8f17edab5-chunk-0001
source_id: itest-help_26.2.0.zip-popups-listprompts_web.html-30ca47b68a87-7fa8f17edab5
title: listPrompts
heading_path:
- listPrompts
section_titles:
- listPrompts
source_block_ids:
- itest-help_26.2.0.zip-popups-listprompts_web.html-30ca47b68a87-7fa8f17edab5-block-0001
- itest-help_26.2.0.zip-popups-listprompts_web.html-30ca47b68a87-7fa8f17edab5-block-0002
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 125
source_hash: 7fa8f17edab53dbc9b2da9edb811f3dc3c2955cd5afc2c2cf23441aaf0ed232c
normalized_document_hash: 282d72bdb599efa2dd0b0b7e7c2c8040e28ee3efa321ddf84a52e21e27c03cce
content_status: success
content_sha256: a21879a27376ae248f16b300fdc3e4539c4bfbf8b4089f888100cb2e13d28a22
---

# listPrompts

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| listPrompts | Not Required | Not Required | A prompt is the text that appears in the body of a prompt dialog box (typically an alert or confirmation dialog). For Web sessions, iTest caches (saves) the text of each prompt that appears during test case execution. A listPrompts step returns the text of all prompts that have appeared since the Web session started or since the last clearPrompts command. The response is structured and iTest auto-generates queries that enable you to extract the text. |
