# listPrompts

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| listPrompts | Not Required | Not Required | A prompt is the text that appears in the body of a prompt dialog box (typically an alert or confirmation dialog). For Web sessions, iTest caches (saves) the text of each prompt that appears during test case execution. A listPrompts step returns the text of all prompts that have appeared since the Web session started or since the last clearPrompts command. The response is structured and iTest auto-generates queries that enable you to extract the text. |
