---
chunk_id: itest-help_26.2.0.zip-popups-listtraps.html-43c36b4167f8-4a018389b813-chunk-0001
source_id: itest-help_26.2.0.zip-popups-listtraps.html-43c36b4167f8-4a018389b813
title: listTraps
heading_path:
- listTraps
section_titles:
- listTraps
source_block_ids:
- itest-help_26.2.0.zip-popups-listtraps.html-43c36b4167f8-4a018389b813-block-0001
- itest-help_26.2.0.zip-popups-listtraps.html-43c36b4167f8-4a018389b813-block-0002
- itest-help_26.2.0.zip-popups-listtraps.html-43c36b4167f8-4a018389b813-block-0003
- itest-help_26.2.0.zip-popups-listtraps.html-43c36b4167f8-4a018389b813-block-0004
- itest-help_26.2.0.zip-popups-listtraps.html-43c36b4167f8-4a018389b813-block-0005
- itest-help_26.2.0.zip-popups-listtraps.html-43c36b4167f8-4a018389b813-block-0006
- itest-help_26.2.0.zip-popups-listtraps.html-43c36b4167f8-4a018389b813-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 106
source_hash: 4a018389b813a077e222a03248ffd8f7e67a2639b96bced1cd0d114d515262bf
normalized_document_hash: 82e29a98a582bfd6f0aa86c7d2d7dc6a8f7f2d48aa200653fdb2091ebc812078
content_status: success
content_sha256: ca56bb1775bfc7f4b75c76816fc819251376aa530db88dae9222f0703e41d972
---

# listTraps

Lists all traps that have been received since executing the first SNMP step or previous ListTraps calls.

ListTraps steps do not send commands to the device.

Depending on the Clear Traps After List property setting in the session profile, the system either leaves the queue unchanged or clears it after ListTraps steps.

The response body contains an XML document listing the following elements for each trap:

- Timestamp
- Trap objects

For details, see the online help: Creating SNMP test case steps .
