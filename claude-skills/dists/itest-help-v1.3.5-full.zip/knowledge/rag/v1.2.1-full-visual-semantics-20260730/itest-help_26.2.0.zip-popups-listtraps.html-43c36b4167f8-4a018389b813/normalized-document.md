# listTraps

Lists all traps that have been received since executing the first SNMP step or previous ListTraps calls.

ListTraps steps do not send commands to the device.

Depending on the Clear Traps After List property setting in the session profile, the system either leaves the queue unchanged or clears it after ListTraps steps.

The response body contains an XML document listing the following elements for each trap:

- Timestamp
- Trap objects

For details, see the online help: Creating SNMP test case steps .
