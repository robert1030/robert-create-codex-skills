---
chunk_id: itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-chunk-0001
source_id: itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167
title: Example response
heading_path:
- Example response
section_titles:
- listWindows
- Example response
source_block_ids:
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0001
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0002
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0003
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0004
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0005
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0006
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0007
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0008
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0009
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0010
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0011
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0012
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0013
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0014
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0015
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0016
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0017
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0018
- itest-help_26.2.0.zip-popups-listwindows.html-11f76c6a8827-96793abc5167-block-0019
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 141
source_hash: 96793abc51675ad7d11cf2076e5bb277688f85e5eb6f4e31f02f1590b8f6c50f
normalized_document_hash: 74a2e179fe318aa39aa750a76f0154991c14af9545b8b66197a8388c6868852c
content_status: success
content_sha256: 9e3a84d9c39c4ad29f6c86d2d2b7e73a765c38258d5b1b7df73e33d78271a909
---

# listWindows

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| listWindows | Not Required | Not Required | Lists all active windows--main window and popup windows--that Web session steps launched. Identifies the currently selected window. Displays the frame structure for each window, including nested windows. |

# Example response

Current Window: MainWindow

There are 2 windows open:

Window 1: configWin

Window 2: MainWindow

Frame structure of windows:

configWin:

No frames present in this window

MainWindow:

MainWindow -> gral_toolbar

MainWindow -> navigation

MainWindow -> ctxt

ctxt -> ctxt_nav

ctxt -> ctxt_view

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
