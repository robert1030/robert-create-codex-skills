# listWindows

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| listWindows | Not Required | Not Required | Lists all active windows--main window and popup windows--that Web session steps launched. Identifies the currently selected window. Displays the frame structure for each window, including nested windows. |

# Example response

Current Window: MainWindow

There are 2 windows open:

Window 1: configWin

Window 2: MainWindow

Frame structure of windows:

configWin:

No frames present in this window

MainWindow:

MainWindow -> gral_toolbar

MainWindow -> navigation

MainWindow -> ctxt

ctxt -> ctxt_nav

ctxt -> ctxt_view

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
