---
chunk_id: itest-help_26.2.0.zip-popups-llength.html-fa35c734e706-b63fe4a38571-chunk-0001
source_id: itest-help_26.2.0.zip-popups-llength.html-fa35c734e706-b63fe4a38571
title: llength
heading_path:
- llength
section_titles:
- llength
source_block_ids:
- itest-help_26.2.0.zip-popups-llength.html-fa35c734e706-b63fe4a38571-block-0001
- itest-help_26.2.0.zip-popups-llength.html-fa35c734e706-b63fe4a38571-block-0002
- itest-help_26.2.0.zip-popups-llength.html-fa35c734e706-b63fe4a38571-block-0003
- itest-help_26.2.0.zip-popups-llength.html-fa35c734e706-b63fe4a38571-block-0004
- itest-help_26.2.0.zip-popups-llength.html-fa35c734e706-b63fe4a38571-block-0005
- itest-help_26.2.0.zip-popups-llength.html-fa35c734e706-b63fe4a38571-block-0006
- itest-help_26.2.0.zip-popups-llength.html-fa35c734e706-b63fe4a38571-block-0007
- itest-help_26.2.0.zip-popups-llength.html-fa35c734e706-b63fe4a38571-block-0008
- itest-help_26.2.0.zip-popups-llength.html-fa35c734e706-b63fe4a38571-block-0009
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 93
source_hash: b63fe4a38571c19d68a9dc2085ee30c2faf83fe502a3bad07e504a005513a494
normalized_document_hash: bc328aa3a72adebbcf0cfb70f5007209a220a7bd2e74c53b59747c9d51662ceb
content_status: success
content_sha256: 1e5438cfb7e9db1ac2f30e3fde76738e40e3029b93be1d3b8f085553c6954457
---

# llength

llength list

The

llength

command counts the number of elements in a list. The command treats the

list

argument as a list and returns a decimal string giving the number of elements in it.

The llength command is compatible with its Tcl counterpart as more fully described at: http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
