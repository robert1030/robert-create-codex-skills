# llength

llength list

The

llength

command counts the number of elements in a list. The command treats the

list

argument as a list and returns a decimal string giving the number of elements in it.

The llength command is compatible with its Tcl counterpart as more fully described at: http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
