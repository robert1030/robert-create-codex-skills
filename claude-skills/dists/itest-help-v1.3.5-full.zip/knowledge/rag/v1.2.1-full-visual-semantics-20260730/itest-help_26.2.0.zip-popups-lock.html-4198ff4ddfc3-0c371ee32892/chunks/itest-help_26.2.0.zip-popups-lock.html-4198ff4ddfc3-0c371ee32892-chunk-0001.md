---
chunk_id: itest-help_26.2.0.zip-popups-lock.html-4198ff4ddfc3-0c371ee32892-chunk-0001
source_id: itest-help_26.2.0.zip-popups-lock.html-4198ff4ddfc3-0c371ee32892
title: lock
heading_path:
- lock
section_titles:
- lock
source_block_ids:
- itest-help_26.2.0.zip-popups-lock.html-4198ff4ddfc3-0c371ee32892-block-0001
- itest-help_26.2.0.zip-popups-lock.html-4198ff4ddfc3-0c371ee32892-block-0002
- itest-help_26.2.0.zip-popups-lock.html-4198ff4ddfc3-0c371ee32892-block-0003
- itest-help_26.2.0.zip-popups-lock.html-4198ff4ddfc3-0c371ee32892-block-0004
- itest-help_26.2.0.zip-popups-lock.html-4198ff4ddfc3-0c371ee32892-block-0005
- itest-help_26.2.0.zip-popups-lock.html-4198ff4ddfc3-0c371ee32892-block-0006
- itest-help_26.2.0.zip-popups-lock.html-4198ff4ddfc3-0c371ee32892-block-0007
- itest-help_26.2.0.zip-popups-lock.html-4198ff4ddfc3-0c371ee32892-block-0008
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 66
source_hash: 0c371ee32892de1ac02c5218a68834ac9cfbdd8accc2de877dfcdae9c16ad106
normalized_document_hash: 612b75912d5917b2d33e2bbbb2fe53011715590491ca20a56362bf084618a899
content_status: success
content_sha256: 69109cbbb212cff8eadd7ef3dcb0296c04c1e1bd84a77a7dcd2063b979f59baa
---

# lock

lock lockName

The

lock

action ensures that only one thread at a time is working inside the set of steps that is locked on the

lockName

that is specified for the lock step.

For details, see the online help: lock: Ensure one thread for a specified block of code .
