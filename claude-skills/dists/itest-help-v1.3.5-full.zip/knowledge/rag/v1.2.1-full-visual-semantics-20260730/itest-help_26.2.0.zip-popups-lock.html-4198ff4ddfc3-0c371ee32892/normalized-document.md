# lock

lock lockName

The

lock

action ensures that only one thread at a time is working inside the set of steps that is locked on the

lockName

that is specified for the lock step.

For details, see the online help: lock: Ensure one thread for a specified block of code .
