---
chunk_id: itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-chunk-0001
source_id: itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936
title: lrange
heading_path:
- lrange
section_titles:
- lrange
source_block_ids:
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0001
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0002
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0003
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0004
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0005
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0006
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0007
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0008
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0009
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0010
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0011
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0012
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0013
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0014
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0015
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0016
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0017
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0018
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0019
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0020
- itest-help_26.2.0.zip-popups-lrange.html-845c99d2c0a0-ceea9306c936-block-0021
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 136
source_hash: ceea9306c93627ed25265736bb3a928df96cacccfead77a939ffefc31dc603da
normalized_document_hash: cada397a500ea08f2be44706cf7055f1bc9d177a666af396b5d4e6a16a7c58e3
content_status: success
content_sha256: e778e386738a51e2d3242b1097374fc01f8ba71133015ca08a54d4ecaf2e2704
---

y

# lrange

lrange list first last

The

lrange

command returns one or more adjacent elements from a list.

list

must be a valid Tcl list. The command returns a new list consisting of elements

first

through

last

, inclusive. The index values

first

and

last

are interpreted the same as index values for the command string index, supporting simple index arithmetic and indexes relative to the end of the list.

The

lrange

command is compatible with its Tcl counterpart as more fully described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
