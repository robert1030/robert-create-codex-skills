y

# lrange

lrange list first last

The

lrange

command returns one or more adjacent elements from a list.

list

must be a valid Tcl list. The command returns a new list consisting of elements

first

through

last

, inclusive. The index values

first

and

last

are interpreted the same as index values for the command string index, supporting simple index arithmetic and indexes relative to the end of the list.

The

lrange

command is compatible with its Tcl counterpart as more fully described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
