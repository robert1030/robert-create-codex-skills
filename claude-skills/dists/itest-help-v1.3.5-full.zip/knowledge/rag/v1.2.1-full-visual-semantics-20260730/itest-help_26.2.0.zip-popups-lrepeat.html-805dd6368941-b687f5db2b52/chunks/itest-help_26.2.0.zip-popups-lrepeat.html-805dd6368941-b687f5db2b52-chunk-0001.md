---
chunk_id: itest-help_26.2.0.zip-popups-lrepeat.html-805dd6368941-b687f5db2b52-chunk-0001
source_id: itest-help_26.2.0.zip-popups-lrepeat.html-805dd6368941-b687f5db2b52
title: lrepeat
heading_path:
- lrepeat
section_titles:
- lrepeat
source_block_ids:
- itest-help_26.2.0.zip-popups-lrepeat.html-805dd6368941-b687f5db2b52-block-0001
- itest-help_26.2.0.zip-popups-lrepeat.html-805dd6368941-b687f5db2b52-block-0002
- itest-help_26.2.0.zip-popups-lrepeat.html-805dd6368941-b687f5db2b52-block-0003
- itest-help_26.2.0.zip-popups-lrepeat.html-805dd6368941-b687f5db2b52-block-0004
- itest-help_26.2.0.zip-popups-lrepeat.html-805dd6368941-b687f5db2b52-block-0005
- itest-help_26.2.0.zip-popups-lrepeat.html-805dd6368941-b687f5db2b52-block-0006
- itest-help_26.2.0.zip-popups-lrepeat.html-805dd6368941-b687f5db2b52-block-0007
- itest-help_26.2.0.zip-popups-lrepeat.html-805dd6368941-b687f5db2b52-block-0008
- itest-help_26.2.0.zip-popups-lrepeat.html-805dd6368941-b687f5db2b52-block-0009
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 138
source_hash: b687f5db2b52493f5647a9614df4dc8fd74597e67836c3a172f9fb2c1cc1ae45
normalized_document_hash: 92f3a551173073c4aa7a6117c51acc45c833a1feabaed377c0ceb64091bb5c50
content_status: success
content_sha256: 32d60ab7229475433db55ea62a1531c403d57200bac457f552215da11f9d43e8
---

# lrepeat

lrepeat number element1 ? element2 element3 ... ?

The lrepeat command builds a list by repeating elements.

The command creates a list of size number * number of elements by repeating number times the sequence of elements element1 element2 ... . number must be a positive integer, elementn can be any Tcl value. Note that [lrepeat 1 arg ...] is identical to [list arg ...] , though the arg is required with lrepeat .

The

lrepeat

command is compatible with its Tcl counterpart as more fully described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
