# lrepeat

lrepeat number element1 ? element2 element3 ... ?

The lrepeat command builds a list by repeating elements.

The command creates a list of size number * number of elements by repeating number times the sequence of elements element1 element2 ... . number must be a positive integer, elementn can be any Tcl value. Note that [lrepeat 1 arg ...] is identical to [list arg ...] , though the arg is required with lrepeat .

The

lrepeat

command is compatible with its Tcl counterpart as more fully described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
