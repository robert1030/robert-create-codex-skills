---
chunk_id: itest-help_26.2.0.zip-popups-lreplace.html-dce1c16e73b6-5a7aae6c2630-chunk-0001
source_id: itest-help_26.2.0.zip-popups-lreplace.html-dce1c16e73b6-5a7aae6c2630
title: lreplace
heading_path:
- lreplace
section_titles:
- lreplace
source_block_ids:
- itest-help_26.2.0.zip-popups-lreplace.html-dce1c16e73b6-5a7aae6c2630-block-0001
- itest-help_26.2.0.zip-popups-lreplace.html-dce1c16e73b6-5a7aae6c2630-block-0002
- itest-help_26.2.0.zip-popups-lreplace.html-dce1c16e73b6-5a7aae6c2630-block-0003
- itest-help_26.2.0.zip-popups-lreplace.html-dce1c16e73b6-5a7aae6c2630-block-0004
- itest-help_26.2.0.zip-popups-lreplace.html-dce1c16e73b6-5a7aae6c2630-block-0005
- itest-help_26.2.0.zip-popups-lreplace.html-dce1c16e73b6-5a7aae6c2630-block-0006
- itest-help_26.2.0.zip-popups-lreplace.html-dce1c16e73b6-5a7aae6c2630-block-0007
- itest-help_26.2.0.zip-popups-lreplace.html-dce1c16e73b6-5a7aae6c2630-block-0008
- itest-help_26.2.0.zip-popups-lreplace.html-dce1c16e73b6-5a7aae6c2630-block-0009
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 276
source_hash: 5a7aae6c26309c1249c3d308ccbb5574566a92263035f8f1f710fb10a2ecff1b
normalized_document_hash: 71eef2a68bf7d2e1576c137b9a48f60f79b4b27b9aac53a76db44fe37ba3dc22
content_status: success
content_sha256: 643968508d859492ec13007a498e990f3e7ca509570b2a529987b43988e77156
---

# lreplace

lreplace list first last ? element element ... ?

The

lreplace

command replaces elements in a list with new elements.

lreplace returns a new list formed by replacing one or more elements of list with the element arguments. first and last are index values specifying the first and last elements of the range to replace. The index values first and last are interpreted the same as index values for the command string index, supporting simple index arithmetic and indices relative to the end of the list. 0 refers to the first element of the list, and end refers to the last element of the list. If list is empty, then first and last are ignored.

The element arguments specify zero or more new arguments to be added to the list in place of those that were deleted. Each element argument will become a separate element of the list. If no element arguments are specified, then the elements between first and last are simply deleted. If list is empty, any element arguments are added to the end of the list.

The lrange command is compatible with its Tcl counterpart as more fully described at: http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
