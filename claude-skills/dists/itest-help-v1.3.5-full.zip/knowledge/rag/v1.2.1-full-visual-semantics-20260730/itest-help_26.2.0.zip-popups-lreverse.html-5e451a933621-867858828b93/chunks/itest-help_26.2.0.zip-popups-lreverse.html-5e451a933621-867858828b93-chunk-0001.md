---
chunk_id: itest-help_26.2.0.zip-popups-lreverse.html-5e451a933621-867858828b93-chunk-0001
source_id: itest-help_26.2.0.zip-popups-lreverse.html-5e451a933621-867858828b93
title: lreverse
heading_path:
- lreverse
section_titles:
- lreverse
source_block_ids:
- itest-help_26.2.0.zip-popups-lreverse.html-5e451a933621-867858828b93-block-0001
- itest-help_26.2.0.zip-popups-lreverse.html-5e451a933621-867858828b93-block-0002
- itest-help_26.2.0.zip-popups-lreverse.html-5e451a933621-867858828b93-block-0003
- itest-help_26.2.0.zip-popups-lreverse.html-5e451a933621-867858828b93-block-0004
- itest-help_26.2.0.zip-popups-lreverse.html-5e451a933621-867858828b93-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 67
source_hash: 867858828b936b337973ab9a2220a23196f31693d062d0d2f20c53610edb10e8
normalized_document_hash: 0ccbbfae1a3fa178a1e619d0ab99a1706166d09c88cd96ad33435b65a8112e44
content_status: success
content_sha256: 9cff1f557d7ca7131088728d66e452d08c3e58ef757d2a4a94dd5c9df0976447
---

# lreverse

lreverse list

The lreverse command reverses the order of a list.

The command returns a list that has the same elements as its input list, list , except with the elements in the reverse order.

For details on each iTest command, see the online help: Command syntax for test case steps .
