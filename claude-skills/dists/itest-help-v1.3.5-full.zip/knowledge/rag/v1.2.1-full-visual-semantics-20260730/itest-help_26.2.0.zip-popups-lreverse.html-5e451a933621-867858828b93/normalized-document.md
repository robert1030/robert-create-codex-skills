# lreverse

lreverse list

The lreverse command reverses the order of a list.

The command returns a list that has the same elements as its input list, list , except with the elements in the reverse order.

For details on each iTest command, see the online help: Command syntax for test case steps .
