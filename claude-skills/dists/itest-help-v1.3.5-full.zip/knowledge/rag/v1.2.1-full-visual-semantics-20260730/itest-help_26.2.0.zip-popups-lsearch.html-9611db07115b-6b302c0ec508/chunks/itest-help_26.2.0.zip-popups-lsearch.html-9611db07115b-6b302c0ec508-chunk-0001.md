---
chunk_id: itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-chunk-0001
source_id: itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508
title: lsearch
heading_path:
- lsearch
section_titles:
- lsearch
source_block_ids:
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0001
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0002
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0003
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0004
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0005
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0006
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0007
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0008
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0009
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0010
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0011
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0012
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0013
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0014
- itest-help_26.2.0.zip-popups-lsearch.html-9611db07115b-6b302c0ec508-block-0015
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 143
source_hash: 6b302c0ec508c3bc1b84ac6255c53f5642eb22d1a8d54f93bd6e7ba331133ff0
normalized_document_hash: 78f6ba94ffc8d97c350224278f0613f283f807053ad71b3116bbb36e57a06d9f
content_status: success
content_sha256: db8833e8b1ef23911489e3f1a3f7913803929eca8c5c6dfc3d542cc35380c245
---

# lsearch

lsearch ? switches ? list pattern

lsearch determines whether a list contains a specified element.

If found, returns the zero-based index of the matching item. If you provide the optional

-inline

switch, then returns the matching item.

If not found, returns -1.

pattern

supports regex matching, exact matching, and wildcard (glob-style) matching (using  the * and ? wildcard characters)). The

[chars]

and

\x

options are not supported.

The lsearch command is compatible with its Tcl counterpart.  The command and optional switches are more fully described at: http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
