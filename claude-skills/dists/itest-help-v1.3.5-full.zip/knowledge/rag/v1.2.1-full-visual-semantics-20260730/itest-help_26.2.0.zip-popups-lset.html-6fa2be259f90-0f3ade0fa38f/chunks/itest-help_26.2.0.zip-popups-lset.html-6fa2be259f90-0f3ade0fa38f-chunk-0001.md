---
chunk_id: itest-help_26.2.0.zip-popups-lset.html-6fa2be259f90-0f3ade0fa38f-chunk-0001
source_id: itest-help_26.2.0.zip-popups-lset.html-6fa2be259f90-0f3ade0fa38f
title: lset
heading_path:
- lset
section_titles:
- lset
source_block_ids:
- itest-help_26.2.0.zip-popups-lset.html-6fa2be259f90-0f3ade0fa38f-block-0001
- itest-help_26.2.0.zip-popups-lset.html-6fa2be259f90-0f3ade0fa38f-block-0002
- itest-help_26.2.0.zip-popups-lset.html-6fa2be259f90-0f3ade0fa38f-block-0003
- itest-help_26.2.0.zip-popups-lset.html-6fa2be259f90-0f3ade0fa38f-block-0004
- itest-help_26.2.0.zip-popups-lset.html-6fa2be259f90-0f3ade0fa38f-block-0005
- itest-help_26.2.0.zip-popups-lset.html-6fa2be259f90-0f3ade0fa38f-block-0006
- itest-help_26.2.0.zip-popups-lset.html-6fa2be259f90-0f3ade0fa38f-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 134
source_hash: 0f3ade0fa38f91f35e12e40fef9dcf4537f77efda43d9f91a4d5cf4dc380290a
normalized_document_hash: d29c80dd7007b5667a630232adc04a8dc6c7555ece9abaec1d96fd1a93b751be
content_status: success
content_sha256: 4dc94f0599ccb3fb2e930f72f9fbc497cd9d9bddd5a375f3b6a7dba4d1d37483
---

# lset

lset varName ? index ...? newValue

The lset command accepts a parameter, varName, which it interprets as the name of a variable containing a Tcl list.

The  command also accepts zero or more indices into the list. The indices may be presented either consecutively on the command line, or grouped in a Tcl list and presented as a single argument.

Finally, the command accepts a new value for an element of varName.

For additional detail, see the fuller description at: http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
