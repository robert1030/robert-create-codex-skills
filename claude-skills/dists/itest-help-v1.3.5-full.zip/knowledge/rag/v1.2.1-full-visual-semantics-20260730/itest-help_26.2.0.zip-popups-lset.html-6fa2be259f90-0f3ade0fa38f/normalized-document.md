# lset

lset varName ? index ...? newValue

The lset command accepts a parameter, varName, which it interprets as the name of a variable containing a Tcl list.

The  command also accepts zero or more indices into the list. The indices may be presented either consecutively on the command line, or grouped in a Tcl list and presented as a single argument.

Finally, the command accepts a new value for an element of varName.

For additional detail, see the fuller description at: http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
