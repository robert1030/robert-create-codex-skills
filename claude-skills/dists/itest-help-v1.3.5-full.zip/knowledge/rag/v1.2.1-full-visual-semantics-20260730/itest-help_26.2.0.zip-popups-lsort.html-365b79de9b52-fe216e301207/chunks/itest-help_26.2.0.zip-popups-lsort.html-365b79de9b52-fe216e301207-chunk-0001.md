---
chunk_id: itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207-chunk-0001
source_id: itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207
title: lsort
heading_path:
- lsort
section_titles:
- lsort
source_block_ids:
- itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207-block-0001
- itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207-block-0002
- itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207-block-0003
- itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207-block-0004
- itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207-block-0005
- itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207-block-0006
- itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207-block-0007
- itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207-block-0008
- itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207-block-0009
- itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207-block-0010
- itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207-block-0011
- itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207-block-0012
- itest-help_26.2.0.zip-popups-lsort.html-365b79de9b52-fe216e301207-block-0013
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 154
source_hash: fe216e30120709a87bf62370fc70d4a6d10ec62852e184f97e2c616487c575d6
normalized_document_hash: 6031ead6b0a26c0d74e8d6eb1ef38e3b8247e50549e5a0d7e9a91dab43b7b777
content_status: success
content_sha256: eaa7605c7cac86b809979cf7ac4b316b6dd0231690c3c4a7a2745ae34db8aa6e
---

# lsort

lsort ? options ? list

The lsort command sorts the elements of list , returning a new list in sorted order. The implementation of the lsort command uses the merge-sort algorithm which is a stable sort that has O(n log n) performance characteristics.

ASCII sorting is used by default, with the result returned in increasing order. However, any of several options may be specified to control the sorting process.

Limitation

: The

-command

option is not supported.

Aside from the stated limitation, the

lsort

command is compatible with its Tcl counterpart as more fully described at:

http://www.tcl.tk/man

For details on each iTest command, see the online help: Command syntax for test case steps .
