---
chunk_id: itest-help_26.2.0.zip-popups-math.html-e358aad5c884-d9919cc2863e-chunk-0001
source_id: itest-help_26.2.0.zip-popups-math.html-e358aad5c884-d9919cc2863e
title: math functions
heading_path:
- math functions
section_titles:
- math functions
source_block_ids:
- itest-help_26.2.0.zip-popups-math.html-e358aad5c884-d9919cc2863e-block-0001
- itest-help_26.2.0.zip-popups-math.html-e358aad5c884-d9919cc2863e-block-0002
- itest-help_26.2.0.zip-popups-math.html-e358aad5c884-d9919cc2863e-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 57
source_hash: d9919cc2863e9008b80cfc4a1e4d75e38485f192968229921a206bbf8d903b3b
normalized_document_hash: cc5b3247d40e5d1bb294a2df7e7e4c3dc82241402c9bada6847d0c09c4cede6c
content_status: success
content_sha256: f093cdb993d8a181cd533944d04441123541f14a48742debe456b3cf550d6560
---

# math functions

Each of the iTest math function commands is compatible with its Tcl counterpart as more fully described at: http://www.tcl.tk/man

For details on using any iTest command, see the online help: Command syntax for test case steps .
