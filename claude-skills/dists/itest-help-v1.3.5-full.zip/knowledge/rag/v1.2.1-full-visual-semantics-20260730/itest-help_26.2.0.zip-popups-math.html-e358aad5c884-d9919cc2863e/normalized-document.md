# math functions

Each of the iTest math function commands is compatible with its Tcl counterpart as more fully described at: http://www.tcl.tk/man

For details on using any iTest command, see the online help: Command syntax for test case steps .
