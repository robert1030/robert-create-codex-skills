---
chunk_id: itest-help_26.2.0.zip-popups-message.html-02546da849ef-48a17fd8754e-chunk-0001
source_id: itest-help_26.2.0.zip-popups-message.html-02546da849ef-48a17fd8754e
title: message
heading_path:
- message
section_titles:
- message
source_block_ids:
- itest-help_26.2.0.zip-popups-message.html-02546da849ef-48a17fd8754e-block-0001
- itest-help_26.2.0.zip-popups-message.html-02546da849ef-48a17fd8754e-block-0002
- itest-help_26.2.0.zip-popups-message.html-02546da849ef-48a17fd8754e-block-0003
- itest-help_26.2.0.zip-popups-message.html-02546da849ef-48a17fd8754e-block-0004
- itest-help_26.2.0.zip-popups-message.html-02546da849ef-48a17fd8754e-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 74
source_hash: 48a17fd8754e13b5e388a3b8bcdae2f8f47287dcb9d7b10cc3fd1c426b136d52
normalized_document_hash: 4a6a25d5c0ee39c508414b9b7cdfd3c9b8f2d74e662931f98c6cfbe162f6b3c0
content_status: success
content_sha256: 4348e5efa66d40f3eff73612689a7841af88777a835f1086f66ffbb0fc58a5fe
---

# message

Adds content to the body of the email message.

Type the message into the Description cell. To supply multiple lines of text, click the Advanced button for the Command property and type the text into the Command text box.

Field replacements are supported.

For details, see the online help: Sending email messages during test execution .
