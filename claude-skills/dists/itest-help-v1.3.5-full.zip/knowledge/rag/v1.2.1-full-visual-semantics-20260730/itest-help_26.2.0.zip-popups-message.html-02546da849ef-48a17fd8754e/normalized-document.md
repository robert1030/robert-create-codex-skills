# message

Adds content to the body of the email message.

Type the message into the Description cell. To supply multiple lines of text, click the Advanced button for the Command property and type the text into the Command text box.

Field replacements are supported.

For details, see the online help: Sending email messages during test execution .
