# message

For the message action, iTest interprets the text in the associated Description field as a message with severity type. At runtime, all messages in the test case appear as execution issue messages in the Execution view and test report. The message actions supports severity levels: OK, Error, Information, and Warning . You may either enter the severity type and message manually or select from the Step Properties > EXEC message Properties > Message Step Properties page.

Note: Message can include field replacements. This is an easy way to send data to the Execution view.

For details, see the online help: The message action .
