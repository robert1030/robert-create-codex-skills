---
chunk_id: itest-help_26.2.0.zip-popups-messageexec_python.html-b45d2de139ef-7617f7603a84-chunk-0001
source_id: itest-help_26.2.0.zip-popups-messageexec_python.html-b45d2de139ef-7617f7603a84
title: message
heading_path:
- message
section_titles:
- message
source_block_ids:
- itest-help_26.2.0.zip-popups-messageexec_python.html-b45d2de139ef-7617f7603a84-block-0001
- itest-help_26.2.0.zip-popups-messageexec_python.html-b45d2de139ef-7617f7603a84-block-0002
- itest-help_26.2.0.zip-popups-messageexec_python.html-b45d2de139ef-7617f7603a84-block-0003
- itest-help_26.2.0.zip-popups-messageexec_python.html-b45d2de139ef-7617f7603a84-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 134
source_hash: 7617f7603a849add8c350a801a4afcaa40e5889b66f963a720a97c0cf5a9b640
normalized_document_hash: c82ff2946aa29923b1681f9fb7c69e25d47347131c55c6c10306b4bb92f7271a
content_status: success
content_sha256: a3a0401e6a213bc5042c68c2737decaf78599196dd11ebb68b8fdcbc2551481a
---

# message

For the message action, iTest interprets the text in the associated Description field as a message with severity type. At runtime, all messages in the test case appear as execution issue messages in the Execution view and test report. The message actions supports severity levels: OK, Error, Information, and Warning . You may either enter the severity type and message manually or select from the Step Properties > EXEC message Properties > Message Step Properties page.

Note: Message can include field replacements. This is an easy way to send data to the Execution view.

For details, see the online help: The message action .
