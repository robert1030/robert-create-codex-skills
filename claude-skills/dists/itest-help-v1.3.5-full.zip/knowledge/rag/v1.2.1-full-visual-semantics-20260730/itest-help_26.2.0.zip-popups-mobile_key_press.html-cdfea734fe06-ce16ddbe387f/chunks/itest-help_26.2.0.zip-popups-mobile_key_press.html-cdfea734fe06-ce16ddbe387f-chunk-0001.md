---
chunk_id: itest-help_26.2.0.zip-popups-mobile_key_press.html-cdfea734fe06-ce16ddbe387f-chunk-0001
source_id: itest-help_26.2.0.zip-popups-mobile_key_press.html-cdfea734fe06-ce16ddbe387f
title: Mobile Key Press
heading_path:
- Mobile Key Press
section_titles:
- Mobile Key Press
source_block_ids:
- itest-help_26.2.0.zip-popups-mobile_key_press.html-cdfea734fe06-ce16ddbe387f-block-0001
- itest-help_26.2.0.zip-popups-mobile_key_press.html-cdfea734fe06-ce16ddbe387f-block-0002
- itest-help_26.2.0.zip-popups-mobile_key_press.html-cdfea734fe06-ce16ddbe387f-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 45
source_hash: ce16ddbe387ffb8cdd54ed3cb5487e2fe0909656065b4e5612f250a0ae13b190
normalized_document_hash: 991b0bf07015cfc172fc58aaf65fb51a0a9b60ccd6e410b719144b3ee81fb4a9
content_status: success
content_sha256: 5908bda15f40eafa583de3c46b6863c448a2205a04b9c6fc2bc123d04b203260
---

# Mobile Key Press

Adds a new mobile key press action (e.g. \{BACK\}, \{MENU\}).

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
