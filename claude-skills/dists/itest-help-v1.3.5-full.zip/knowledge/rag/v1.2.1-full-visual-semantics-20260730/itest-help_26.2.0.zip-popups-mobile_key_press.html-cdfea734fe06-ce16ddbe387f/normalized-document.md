# Mobile Key Press

Adds a new mobile key press action (e.g. \{BACK\}, \{MENU\}).

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
