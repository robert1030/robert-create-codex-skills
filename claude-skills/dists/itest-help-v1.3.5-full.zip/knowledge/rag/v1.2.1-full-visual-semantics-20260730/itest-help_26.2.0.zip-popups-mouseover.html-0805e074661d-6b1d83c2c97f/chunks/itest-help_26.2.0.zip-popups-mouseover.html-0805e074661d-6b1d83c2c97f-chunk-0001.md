---
chunk_id: itest-help_26.2.0.zip-popups-mouseover.html-0805e074661d-6b1d83c2c97f-chunk-0001
source_id: itest-help_26.2.0.zip-popups-mouseover.html-0805e074661d-6b1d83c2c97f
title: mouseOver
heading_path:
- mouseOver
section_titles:
- mouseOver
source_block_ids:
- itest-help_26.2.0.zip-popups-mouseover.html-0805e074661d-6b1d83c2c97f-block-0001
- itest-help_26.2.0.zip-popups-mouseover.html-0805e074661d-6b1d83c2c97f-block-0002
- itest-help_26.2.0.zip-popups-mouseover.html-0805e074661d-6b1d83c2c97f-block-0003
- itest-help_26.2.0.zip-popups-mouseover.html-0805e074661d-6b1d83c2c97f-block-0004
- itest-help_26.2.0.zip-popups-mouseover.html-0805e074661d-6b1d83c2c97f-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 98
source_hash: 6b1d83c2c97fea60dfb572656a2905747b17354634830428b59af1014360dfd3
normalized_document_hash: a750e8d495670614541ddfa8f7d7f8f9c28bf55c4143dfcf47a41ba0a856ea40
content_status: success
content_sha256: 892cdd95791046682cb706335b41eaf4b459f77d386ff2cb9cd56f6a2cde2fd4
---

# mouseOver

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| mouseOver | Required | Not Required | A mouseOver step simulates a mouse-over event on the specified Target. If the target has mouseover handlers, the handlers are invoked. mouseOver steps are captured during interactive sessions if the Capture mouse-over events property is set in the session profile. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
