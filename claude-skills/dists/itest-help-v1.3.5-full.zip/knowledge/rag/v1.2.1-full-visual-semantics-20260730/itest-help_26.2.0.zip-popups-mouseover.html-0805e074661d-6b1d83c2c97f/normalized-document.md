# mouseOver

| Action Name | Target | Command property value | Description |
| --- | --- | --- | --- |
| mouseOver | Required | Not Required | A mouseOver step simulates a mouse-over event on the specified Target. If the target has mouseover handlers, the handlers are invoked. mouseOver steps are captured during interactive sessions if the Capture mouse-over events property is set in the session profile. |

For details, see the online help: Creating Web test case steps .

Also:

Web session action reference
