---
chunk_id: itest-help_26.2.0.zip-popups-mousewheel.html-15230c89a2fc-efbfe91ed81f-chunk-0001
source_id: itest-help_26.2.0.zip-popups-mousewheel.html-15230c89a2fc-efbfe91ed81f
title: Mousewheel
heading_path:
- Mousewheel
section_titles:
- Mousewheel
source_block_ids:
- itest-help_26.2.0.zip-popups-mousewheel.html-15230c89a2fc-efbfe91ed81f-block-0001
- itest-help_26.2.0.zip-popups-mousewheel.html-15230c89a2fc-efbfe91ed81f-block-0002
- itest-help_26.2.0.zip-popups-mousewheel.html-15230c89a2fc-efbfe91ed81f-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 62
source_hash: efbfe91ed81fc5385b2163781b1409953c2b97abf89d2ae0fd0808ecb0f3abe6
normalized_document_hash: 17f3970dd55797f57e2adaaf1eac4b1eccebda80831f6b11a43b3e5a2f00f04e
content_status: success
content_sha256: ac26b5f0883aa4893e61454d08901dcb4f176a7d9445296fca2875c0d32269ad
---

# Mousewheel

Adds a new mouse wheel action item.
Use the mousewheel action to specify as Vertical or Horizontal direction. You may also specify a wheel-delta, which is 120 by default.

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
