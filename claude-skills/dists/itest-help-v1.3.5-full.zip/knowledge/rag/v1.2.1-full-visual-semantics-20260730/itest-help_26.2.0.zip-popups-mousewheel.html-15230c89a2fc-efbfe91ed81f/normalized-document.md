# Mousewheel

Adds a new mouse wheel action item.
Use the mousewheel action to specify as Vertical or Horizontal direction. You may also specify a wheel-delta, which is 120 by default.

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
