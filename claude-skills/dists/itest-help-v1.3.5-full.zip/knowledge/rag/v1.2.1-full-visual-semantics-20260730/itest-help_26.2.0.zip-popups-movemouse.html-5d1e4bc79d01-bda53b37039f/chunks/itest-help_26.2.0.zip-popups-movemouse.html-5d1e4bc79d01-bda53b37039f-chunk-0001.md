---
chunk_id: itest-help_26.2.0.zip-popups-movemouse.html-5d1e4bc79d01-bda53b37039f-chunk-0001
source_id: itest-help_26.2.0.zip-popups-movemouse.html-5d1e4bc79d01-bda53b37039f
title: moveMouse
heading_path:
- moveMouse
section_titles:
- moveMouse
source_block_ids:
- itest-help_26.2.0.zip-popups-movemouse.html-5d1e4bc79d01-bda53b37039f-block-0001
- itest-help_26.2.0.zip-popups-movemouse.html-5d1e4bc79d01-bda53b37039f-block-0002
- itest-help_26.2.0.zip-popups-movemouse.html-5d1e4bc79d01-bda53b37039f-block-0003
- itest-help_26.2.0.zip-popups-movemouse.html-5d1e4bc79d01-bda53b37039f-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 198
source_hash: bda53b37039f03a227f7207d37bf1e194ff29ae8069ff1b65d4541cfc9dabfe0
normalized_document_hash: 67c81664e8b885be9274dabc8f5f77b6b19a32bf90e2a4ea07577c171798528f
content_status: success
content_sha256: 254f598ede910529be690cd35c7ae336960f4489b64c93326350c29f15e2074f
---

# moveMouse

Simulates a mouse move over a control. Note: This action is never captured and must be manually added to the test case by the user.

| Target | Required. |
| --- | --- |
| Controls | All controls. |
| Command | Optional. X, Y coordinates in pixels relative to the control. |
| Step Properties | Step Properties Ctrl: Indicates that the Control key is pressed when executing the action Shift: Indicates that the Shift key is pressed when executing the action Alt: Indicates that the Alt key is pressed when executing the action<br>Default: [No key selected] Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
