# moveMouse

Simulates a mouse move over a control. Note: This action is never captured and must be manually added to the test case by the user.

| Target | Required. |
| --- | --- |
| Controls | All controls. |
| Command | Optional. X, Y coordinates in pixels relative to the control. |
| Step Properties | Step Properties Ctrl: Indicates that the Control key is pressed when executing the action Shift: Indicates that the Shift key is pressed when executing the action Alt: Indicates that the Alt key is pressed when executing the action<br>Default: [No key selected] Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
