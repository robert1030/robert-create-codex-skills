---
chunk_id: itest-help_26.2.0.zip-popups-next.html-55cda837e05d-252260c44820-chunk-0001
source_id: itest-help_26.2.0.zip-popups-next.html-55cda837e05d-252260c44820
title: next
heading_path:
- next
section_titles:
- next
source_block_ids:
- itest-help_26.2.0.zip-popups-next.html-55cda837e05d-252260c44820-block-0001
- itest-help_26.2.0.zip-popups-next.html-55cda837e05d-252260c44820-block-0002
- itest-help_26.2.0.zip-popups-next.html-55cda837e05d-252260c44820-block-0003
- itest-help_26.2.0.zip-popups-next.html-55cda837e05d-252260c44820-block-0004
- itest-help_26.2.0.zip-popups-next.html-55cda837e05d-252260c44820-block-0005
- itest-help_26.2.0.zip-popups-next.html-55cda837e05d-252260c44820-block-0006
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 124
source_hash: 252260c4482085c0b7114b81fde349f3ba5bc7e6090c8a4c8aef068a8c5db945
normalized_document_hash: 2ff5520b1ca172f3235a2be22556dcfbca40ea4ee46c93b90f49223c2ef3f69c
content_status: success
content_sha256: ff137c78d7aebaf7e7373db39cda014b72f7038d32b1fc5552068161f0f8e205
---

# next

The next command fetches the next page of records or the next record, depending on the setting for the Fetch single record at a time property in the session profile.

To fetch the first record or first page of records, perform the execute command.

You can specify the number of records per page using the Records per page property in the session profile.

In an interactive session, when you click Fetch Additional Records , iTest captures a next<\b> action.

For details on using this and other iTest interpreter commands, see Database Client command set .
