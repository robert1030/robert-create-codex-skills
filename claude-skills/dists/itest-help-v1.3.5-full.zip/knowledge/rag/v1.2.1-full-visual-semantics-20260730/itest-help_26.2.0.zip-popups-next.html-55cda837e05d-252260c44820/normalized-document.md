# next

The next command fetches the next page of records or the next record, depending on the setting for the Fetch single record at a time property in the session profile.

To fetch the first record or first page of records, perform the execute command.

You can specify the number of records per page using the Records per page property in the session profile.

In an interactive session, when you click Fetch Additional Records , iTest captures a next<\b> action.

For details on using this and other iTest interpreter commands, see Database Client command set .
