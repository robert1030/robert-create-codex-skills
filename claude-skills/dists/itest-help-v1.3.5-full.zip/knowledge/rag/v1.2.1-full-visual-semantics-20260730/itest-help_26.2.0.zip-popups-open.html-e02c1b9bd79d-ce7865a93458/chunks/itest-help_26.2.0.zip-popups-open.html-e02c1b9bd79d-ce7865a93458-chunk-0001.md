---
chunk_id: itest-help_26.2.0.zip-popups-open.html-e02c1b9bd79d-ce7865a93458-chunk-0001
source_id: itest-help_26.2.0.zip-popups-open.html-e02c1b9bd79d-ce7865a93458
title: open
heading_path:
- open
section_titles:
- open
source_block_ids:
- itest-help_26.2.0.zip-popups-open.html-e02c1b9bd79d-ce7865a93458-block-0001
- itest-help_26.2.0.zip-popups-open.html-e02c1b9bd79d-ce7865a93458-block-0002
- itest-help_26.2.0.zip-popups-open.html-e02c1b9bd79d-ce7865a93458-block-0003
- itest-help_26.2.0.zip-popups-open.html-e02c1b9bd79d-ce7865a93458-block-0004
- itest-help_26.2.0.zip-popups-open.html-e02c1b9bd79d-ce7865a93458-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 227
source_hash: ce7865a9345813f63eff30bf24b388360c48a008e0a32a86d9b15f22bd1e9290
normalized_document_hash: 3ceef2349c6d5f45d8e62ff48e4d56635b768d188867f97dcc527120d924313a
content_status: success
content_sha256: b0a849c18f130f6fffb8f76e030234038b8c5fc323d9070729c89c6531199ac6
---

# open

An open step in a test case starts a session using one of the following:

- Topology or testbed device: The box displays each device associated with the current test case (either a global topology or testbed or the topology or testbed specified for the test case). Select the device from the list and then click OK .
- Session profile or reference session profile: The box displays a tree of all projects in the current workspace. Navigate to the session profile and then click OK .
- iTest default session type: This is a powerful option that you can use when generalizing a test case. You can use a parameter value in the Session or Description cells for a step so that the session ID, device, or session profile can be determined at runtime. With this option, you must specify a Default session for the step or procedure.

The easiest way to add an open step is to save a captured session or step into a test case.

For details, see the online help: The open action .
