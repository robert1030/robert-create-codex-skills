# open

An open step in a test case starts a session using one of the following:

- Topology or testbed device: The box displays each device associated with the current test case (either a global topology or testbed or the topology or testbed specified for the test case). Select the device from the list and then click OK .
- Session profile or reference session profile: The box displays a tree of all projects in the current workspace. Navigate to the session profile and then click OK .
- iTest default session type: This is a powerful option that you can use when generalizing a test case. You can use a parameter value in the Session or Description cells for a step so that the session ID, device, or session profile can be determined at runtime. With this option, you must specify a Default session for the step or procedure.

The easiest way to add an open step is to save a captured session or step into a test case.

For details, see the online help: The open action .
