---
chunk_id: itest-help_26.2.0.zip-popups-open_browser.html-547b20e0cd74-40c8808a43b0-chunk-0001
source_id: itest-help_26.2.0.zip-popups-open_browser.html-547b20e0cd74-40c8808a43b0
title: Open Browser
heading_path:
- Open Browser
section_titles:
- Open Browser
source_block_ids:
- itest-help_26.2.0.zip-popups-open_browser.html-547b20e0cd74-40c8808a43b0-block-0001
- itest-help_26.2.0.zip-popups-open_browser.html-547b20e0cd74-40c8808a43b0-block-0002
- itest-help_26.2.0.zip-popups-open_browser.html-547b20e0cd74-40c8808a43b0-block-0003
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 58
source_hash: 40c8808a43b02bf01bff89fa2048f51c00b28bb0cd7c4bf13907c79389eb8b51
normalized_document_hash: 1b62cd815710081679ac222b0536e46938bf0b858f061d1ac92b44925d2efedb
content_status: success
content_sha256: b4c2ad769afb58235086bf0257ac750186d9a6cc446df4b452c78f994627b0a7
---

# Open Browser

Opens a browser and navigates to the given URL. User the parameter browser for choosing a browser (e.g. IE, Chrome, Safari, or Firefox).

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
