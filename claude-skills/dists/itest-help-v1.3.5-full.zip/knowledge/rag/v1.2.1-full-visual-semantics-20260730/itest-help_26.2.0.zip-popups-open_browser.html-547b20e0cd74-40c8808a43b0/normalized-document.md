# Open Browser

Opens a browser and navigates to the given URL. User the parameter browser for choosing a browser (e.g. IE, Chrome, Safari, or Firefox).

For details, see the online help: "Ranorex action commands" section under the "Ranorex Sessions" topic .
