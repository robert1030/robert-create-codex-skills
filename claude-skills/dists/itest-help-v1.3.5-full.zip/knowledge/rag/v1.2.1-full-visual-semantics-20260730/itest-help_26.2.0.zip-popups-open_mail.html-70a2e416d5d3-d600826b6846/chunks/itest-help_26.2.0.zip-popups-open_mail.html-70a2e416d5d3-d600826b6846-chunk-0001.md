---
chunk_id: itest-help_26.2.0.zip-popups-open_mail.html-70a2e416d5d3-d600826b6846-chunk-0001
source_id: itest-help_26.2.0.zip-popups-open_mail.html-70a2e416d5d3-d600826b6846
title: open
heading_path:
- open
section_titles:
- open
source_block_ids:
- itest-help_26.2.0.zip-popups-open_mail.html-70a2e416d5d3-d600826b6846-block-0001
- itest-help_26.2.0.zip-popups-open_mail.html-70a2e416d5d3-d600826b6846-block-0002
- itest-help_26.2.0.zip-popups-open_mail.html-70a2e416d5d3-d600826b6846-block-0003
- itest-help_26.2.0.zip-popups-open_mail.html-70a2e416d5d3-d600826b6846-block-0004
- itest-help_26.2.0.zip-popups-open_mail.html-70a2e416d5d3-d600826b6846-block-0005
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 66
source_hash: d600826b68467f9a192468773b083bf712faab3d92bbb07f0dd59745672eaf46
normalized_document_hash: 88feeb4390b8f4f66008856d5c0a586b52e0886b600584591119939240db878a
content_status: success
content_sha256: 6c231fcd176976cc197481398dcd71e216977c2261597456eb9e7ff67814c53e
---

# open

Opens a new mail message for building and sending.

Added automatically when you save a mail session as a procedure. (See the send action.)

In the Description cell, select application://com.fnfr.svt.applications.mail

For details, see the online help: Sending email messages during test execution .
