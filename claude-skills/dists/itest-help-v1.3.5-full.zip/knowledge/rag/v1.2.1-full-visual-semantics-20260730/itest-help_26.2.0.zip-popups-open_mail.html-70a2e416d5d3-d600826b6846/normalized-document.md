# open

Opens a new mail message for building and sending.

Added automatically when you save a mail session as a procedure. (See the send action.)

In the Description cell, select application://com.fnfr.svt.applications.mail

For details, see the online help: Sending email messages during test execution .
