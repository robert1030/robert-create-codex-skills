---
chunk_id: itest-help_26.2.0.zip-popups-openpopup.html-7ddfafc01eab-d70f096fc5b7-chunk-0001
source_id: itest-help_26.2.0.zip-popups-openpopup.html-7ddfafc01eab-d70f096fc5b7
title: openPopup
heading_path:
- openPopup
section_titles:
- openPopup
source_block_ids:
- itest-help_26.2.0.zip-popups-openpopup.html-7ddfafc01eab-d70f096fc5b7-block-0001
- itest-help_26.2.0.zip-popups-openpopup.html-7ddfafc01eab-d70f096fc5b7-block-0002
- itest-help_26.2.0.zip-popups-openpopup.html-7ddfafc01eab-d70f096fc5b7-block-0003
- itest-help_26.2.0.zip-popups-openpopup.html-7ddfafc01eab-d70f096fc5b7-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 136
source_hash: d70f096fc5b7eb39937a7964be77e80e628ddf7c18320ce80c0e0b69682d160a
normalized_document_hash: 3173dd71d6c5f838f4fed86e5c6d925e18b302b9ba105143bf04f6cc84919d97
content_status: success
content_sha256: 457d39759e81ff0906b968f83fc32de90039e4164c4d64304ad1a32004f0aa91
---

# openPopup

Opens the popup or drop-down list.

| Target | Required. |
| --- | --- |
| Controls | Controls with popup or drop-down menus, for example combo boxes, menus. |
| Command | None. |
| Step Properties | Step Properties Trigger: Mouse or Keyboard used to open the popup.<br>Default: Mouse Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
