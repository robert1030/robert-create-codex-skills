---
chunk_id: itest-help_26.2.0.zip-popups-options.html-3f09e70e2545-15cfd559d933-chunk-0001
source_id: itest-help_26.2.0.zip-popups-options.html-3f09e70e2545-15cfd559d933
title: OPTIONS
heading_path:
- OPTIONS
section_titles:
- OPTIONS
source_block_ids:
- itest-help_26.2.0.zip-popups-options.html-3f09e70e2545-15cfd559d933-block-0001
- itest-help_26.2.0.zip-popups-options.html-3f09e70e2545-15cfd559d933-block-0002
- itest-help_26.2.0.zip-popups-options.html-3f09e70e2545-15cfd559d933-block-0003
- itest-help_26.2.0.zip-popups-options.html-3f09e70e2545-15cfd559d933-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 219
source_hash: 15cfd559d93302ec259da92e8b3f14d85e21b825256eec290d93833ae7bc08e6
normalized_document_hash: a17bfe515503c316beda60f53da2a37426270f70d764c44622caeac33734305e
content_status: success
content_sha256: 668955dbb6956d383de6947c31f6325e99830fe659607565bb5e013468823a53
---

# OPTIONS

The OPTIONS method represents allows the client to determine the options and/or requirements associated with a resource, or the capabilities of a server, without implying a resource action or initiating a resource retrieval.

| Action | OPTIONS - determines the options and/or requirements associated with a resource, or the capabilities of a server.<br>- If the Request-URI is an asterisk (*), the OPTIONS request applies to the server in general rather than to a specific resource.<br>- If the Request-URI is not an asterisk (*), the OPTIONS request applies only to the options that are available when communicating with that resource. |
| --- | --- |
| Returns | HTTP200 response includes any header fields that indicate optional features implemented by the server and applicable to that resource (e.g., Allow). |
| Method | Is inherently idempotent as it has no side effects. |
| Example | OPTIONS /users/me returns:<br>200 OK<br>Allow: HEAD,GET,PUT,DELETE,OPTIONS |

For details, see the online help: REST action reference .
