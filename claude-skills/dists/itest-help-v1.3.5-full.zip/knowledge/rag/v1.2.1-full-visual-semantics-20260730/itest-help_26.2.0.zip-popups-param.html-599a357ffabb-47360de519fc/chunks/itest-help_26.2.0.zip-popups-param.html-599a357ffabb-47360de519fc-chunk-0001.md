---
chunk_id: itest-help_26.2.0.zip-popups-param.html-599a357ffabb-47360de519fc-chunk-0001
source_id: itest-help_26.2.0.zip-popups-param.html-599a357ffabb-47360de519fc
title: param
heading_path:
- param
section_titles:
- param
source_block_ids:
- itest-help_26.2.0.zip-popups-param.html-599a357ffabb-47360de519fc-block-0001
- itest-help_26.2.0.zip-popups-param.html-599a357ffabb-47360de519fc-block-0002
- itest-help_26.2.0.zip-popups-param.html-599a357ffabb-47360de519fc-block-0003
- itest-help_26.2.0.zip-popups-param.html-599a357ffabb-47360de519fc-block-0004
- itest-help_26.2.0.zip-popups-param.html-599a357ffabb-47360de519fc-block-0005
- itest-help_26.2.0.zip-popups-param.html-599a357ffabb-47360de519fc-block-0006
- itest-help_26.2.0.zip-popups-param.html-599a357ffabb-47360de519fc-block-0008
- itest-help_26.2.0.zip-popups-param.html-599a357ffabb-47360de519fc-block-0009
- itest-help_26.2.0.zip-popups-param.html-599a357ffabb-47360de519fc-block-0010
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 150
source_hash: 47360de519fc1c98326a32485b859832c6aab6834203624494ceae539df0f189
normalized_document_hash: d31466d211c85b941ace8f66ca144b59ab5d9875eaab7b1f4b1bd405894eca59
content_status: success
content_sha256: ef5527a1f3e08a2f3b0fc5e92c9447b7be12cd5feb71d4d45d4fb088dc62d81b
---

# param

param

paramName_or_query

?defaultValue?

The param command inserts the value of a parameter into a test case step or property.

In this example, [param ping_count] is a field replacement that is replaced at runtime by the value of the ping_count parameter.

Parameters can be defined in the test case, in the testbed, in another test case that loaded as a result of a foreign procedure, or in the session profile associated with the step. To access a parameter defined in the session profile associated with a step, use the profile command.

For details, see the online help: Accessing parameter values: The param command .

Also, see: Field replacements: Substituting values into properties and commands .
