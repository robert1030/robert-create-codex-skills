# param

param

paramName_or_query

?defaultValue?

The param command inserts the value of a parameter into a test case step or property.

In this example, [param ping_count] is a field replacement that is replaced at runtime by the value of the ping_count parameter.

Parameters can be defined in the test case, in the testbed, in another test case that loaded as a result of a foreign procedure, or in the session profile associated with the step. To access a parameter defined in the session profile associated with a step, use the profile command.

For details, see the online help: Accessing parameter values: The param command .

Also, see: Field replacements: Substituting values into properties and commands .
