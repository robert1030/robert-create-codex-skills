---
chunk_id: itest-help_26.2.0.zip-popups-param_python.html-246d99a6dd6d-e9398e9c6dcc-chunk-0001
source_id: itest-help_26.2.0.zip-popups-param_python.html-246d99a6dd6d-e9398e9c6dcc
title: param
heading_path:
- param
section_titles:
- param
source_block_ids:
- itest-help_26.2.0.zip-popups-param_python.html-246d99a6dd6d-e9398e9c6dcc-block-0001
- itest-help_26.2.0.zip-popups-param_python.html-246d99a6dd6d-e9398e9c6dcc-block-0002
- itest-help_26.2.0.zip-popups-param_python.html-246d99a6dd6d-e9398e9c6dcc-block-0003
- itest-help_26.2.0.zip-popups-param_python.html-246d99a6dd6d-e9398e9c6dcc-block-0004
- itest-help_26.2.0.zip-popups-param_python.html-246d99a6dd6d-e9398e9c6dcc-block-0006
- itest-help_26.2.0.zip-popups-param_python.html-246d99a6dd6d-e9398e9c6dcc-block-0007
- itest-help_26.2.0.zip-popups-param_python.html-246d99a6dd6d-e9398e9c6dcc-block-0008
- itest-help_26.2.0.zip-popups-param_python.html-246d99a6dd6d-e9398e9c6dcc-block-0009
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 196
source_hash: e9398e9c6dccc7d2a0319350004d3ef083eeadd7e2461f02904d1a39d8f47d80
normalized_document_hash: 28cd5649686f285ed24711f2e755491d9e8b38e57476c74ccb9ff51f79399f5f
content_status: success
content_sha256: 7ad7cbcbd66913d65f597b84bb5edb911b0fce5d56fcf153ada2cebbde026364
---

# param

param ('parameter_name_or_query', 'default')

The param command inserts the value of a parameter into a test case step or property.

In this example, [param('ping_count')] is a field replacement that is replaced at runtime by the value of the ping_count parameter.

Example: eval count = param('ping_count', 5) #ping_count will have default value eval device = param('device_name') #device_name parameter will be defined in the parameter file command ping -c [count] [device]

Parameters can be defined in the test case, in the testbed, in another test case that loaded as a result of a foreign procedure, or in the session profile associated with the step. To access a parameter defined in the session profile associated with a step, use the profile command.

For details, see the online help: Accessing parameter values: The param command .

Also, see: Field replacements: Substituting values into properties and commands .
