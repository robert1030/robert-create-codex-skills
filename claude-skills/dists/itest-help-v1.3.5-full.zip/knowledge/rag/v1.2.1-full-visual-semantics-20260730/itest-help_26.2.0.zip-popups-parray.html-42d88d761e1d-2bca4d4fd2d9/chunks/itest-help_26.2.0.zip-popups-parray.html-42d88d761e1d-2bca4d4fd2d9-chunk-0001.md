---
chunk_id: itest-help_26.2.0.zip-popups-parray.html-42d88d761e1d-2bca4d4fd2d9-chunk-0001
source_id: itest-help_26.2.0.zip-popups-parray.html-42d88d761e1d-2bca4d4fd2d9
title: parray
heading_path:
- parray
section_titles:
- parray
source_block_ids:
- itest-help_26.2.0.zip-popups-parray.html-42d88d761e1d-2bca4d4fd2d9-block-0001
- itest-help_26.2.0.zip-popups-parray.html-42d88d761e1d-2bca4d4fd2d9-block-0002
- itest-help_26.2.0.zip-popups-parray.html-42d88d761e1d-2bca4d4fd2d9-block-0003
- itest-help_26.2.0.zip-popups-parray.html-42d88d761e1d-2bca4d4fd2d9-block-0004
- itest-help_26.2.0.zip-popups-parray.html-42d88d761e1d-2bca4d4fd2d9-block-0005
- itest-help_26.2.0.zip-popups-parray.html-42d88d761e1d-2bca4d4fd2d9-block-0006
- itest-help_26.2.0.zip-popups-parray.html-42d88d761e1d-2bca4d4fd2d9-block-0007
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 130
source_hash: 2bca4d4fd2d9b72db6f9ce6e60d0ec67412e34568d2dfb443462687891342f27
normalized_document_hash: 027e83a89763492fc381569aea574a9505ddfa154356e5e1ebf9a97e604167f7
content_status: success
content_sha256: fdab3b7a4e6801f4743dfbd1d76d612c4ab74c9955cd6c2e6e2955969ae8b4a1
---

# parray

parray ? -g ? arrayName ? pattern ?

The parray command returns an array's keys and values. In the optional pattern , only the * and ? wildcard characters are supported. The [chars] and \x options are not supported.

Example response: fruit(best) = peach fruit(2nd) = apple fruit(ok) = banana fruit(worst) = fly

The iTest parray command is compatible with its Tcl counterpart as described at: http://wiki.tcl.tk/man

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
