# parray

parray ? -g ? arrayName ? pattern ?

The parray command returns an array's keys and values. In the optional pattern , only the * and ? wildcard characters are supported. The [chars] and \x options are not supported.

Example response: fruit(best) = peach fruit(2nd) = apple fruit(ok) = banana fruit(worst) = fly

The iTest parray command is compatible with its Tcl counterpart as described at: http://wiki.tcl.tk/man

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also, see: Field replacements: Substituting values into properties and commands .
