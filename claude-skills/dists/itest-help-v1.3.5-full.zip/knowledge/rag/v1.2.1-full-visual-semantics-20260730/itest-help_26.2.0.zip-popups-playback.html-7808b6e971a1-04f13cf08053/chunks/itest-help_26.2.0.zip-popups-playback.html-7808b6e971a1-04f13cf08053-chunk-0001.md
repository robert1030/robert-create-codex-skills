---
chunk_id: itest-help_26.2.0.zip-popups-playback.html-7808b6e971a1-04f13cf08053-chunk-0001
source_id: itest-help_26.2.0.zip-popups-playback.html-7808b6e971a1-04f13cf08053
title: Playback
heading_path:
- Playback
section_titles:
- Playback
source_block_ids:
- itest-help_26.2.0.zip-popups-playback.html-7808b6e971a1-04f13cf08053-block-0001
- itest-help_26.2.0.zip-popups-playback.html-7808b6e971a1-04f13cf08053-block-0002
- itest-help_26.2.0.zip-popups-playback.html-7808b6e971a1-04f13cf08053-block-0003
- itest-help_26.2.0.zip-popups-playback.html-7808b6e971a1-04f13cf08053-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 61
source_hash: 04f13cf080539f3ebede9b7e9b6a568cecd70a673a78b8a8ebe76f85c86a8042
normalized_document_hash: fbc4a67ebff99311b85256873102acede19c3226765ae08d03446a91700e4775
content_status: success
content_sha256: c281c2a3ada15cb24e1d54d6f1c6f66266325aeb29b2bd79a9d4bd62859d5b9b
---

# Playback

The playback action executes the script whose path is specified in the Description cell.

Note: Spirent iTest captures your commands to execute scripts so you can automate the execution and the analysis of responses.

For details, see Creating a test case that includes RFT sessions .
