# Playback

The playback action executes the script whose path is specified in the Description cell.

Note: Spirent iTest captures your commands to execute scripts so you can automate the execution and the analysis of responses.

For details, see Creating a test case that includes RFT sessions .
