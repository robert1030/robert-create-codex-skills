---
chunk_id: itest-help_26.2.0.zip-popups-post.html-79108359be96-b0dc7478bfda-chunk-0001
source_id: itest-help_26.2.0.zip-popups-post.html-79108359be96-b0dc7478bfda
title: POST
heading_path:
- POST
section_titles:
- POST
source_block_ids:
- itest-help_26.2.0.zip-popups-post.html-79108359be96-b0dc7478bfda-block-0001
- itest-help_26.2.0.zip-popups-post.html-79108359be96-b0dc7478bfda-block-0002
- itest-help_26.2.0.zip-popups-post.html-79108359be96-b0dc7478bfda-block-0003
- itest-help_26.2.0.zip-popups-post.html-79108359be96-b0dc7478bfda-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 216
source_hash: b0dc7478bfdaa7913932a30e6a607945b1414a1ef5ba3f1e53390984cbaeb9c4
normalized_document_hash: d937ddaebc5d6d040a432b8f12f2e3619cc47f7ec853cdc4b81ef445e77439a1
content_status: success
content_sha256: 26dc56c9b76c6cf10fe0e50eb7f01463f3ba073a9a78f4b0f057c5b09644cdf6
---

# POST

The POST method is used to create new resources. When creating a new resource, POST action to the parent and the service takes care of associating the new resource with the parent and assigns an ID (new resource URI).

| Action | POST - Create new resources. |
| --- | --- |
| Returns | On successful creation, POST returns HTTP status 201, returning a Location header with a link to the newly-created resource with the 201 HTTP status: Entire List: HTTP 201 (Created), 'Location' header with link to /customers/{id} containing new ID. Specific Item: HTTP 404 (Not Found), 409 (Conflict) if resource already exists. |
| Method | POST is neither safe nor idempotent. It is therefore recommended for non-idempotent resource requests. Making two identical POST requests will most-likely result in two resources containing the same information. |
| Example | POST http://www.example.com/customers<br>POST http://www.example.com/customers/12345/orders |

For details, see the online help: REST action reference .
