---
chunk_id: itest-help_26.2.0.zip-popups-pressdivider.html-3c40d736ed47-895b3b313284-chunk-0001
source_id: itest-help_26.2.0.zip-popups-pressdivider.html-3c40d736ed47-895b3b313284
title: pressDivider
heading_path:
- pressDivider
section_titles:
- pressDivider
source_block_ids:
- itest-help_26.2.0.zip-popups-pressdivider.html-3c40d736ed47-895b3b313284-block-0001
- itest-help_26.2.0.zip-popups-pressdivider.html-3c40d736ed47-895b3b313284-block-0002
- itest-help_26.2.0.zip-popups-pressdivider.html-3c40d736ed47-895b3b313284-block-0003
- itest-help_26.2.0.zip-popups-pressdivider.html-3c40d736ed47-895b3b313284-block-0004
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 153
source_hash: 895b3b313284d2fd192b7ee53b88dc65bacb4f3f733221c33e0caa8ba48178fb
normalized_document_hash: 451e6b3eac6e3a4237860c57feba03292c12488b1ba179fe173ea4c88c334126
content_status: success
content_sha256: 0fe17b047902101f595972958a4c841655a29124183e1b8cc8e3023737f108d2
---

# pressDivider

Simulates clicking the divider tab but not dragging it. Note: This action is never captured and must be manually added to the test case by the user.

| Target | Required. |
| --- | --- |
| Controls | Dividers. |
| Command | None. |
| Step Properties | Step Properties Index of the divider: The index of the divider to press.<br>Default: 0 Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
