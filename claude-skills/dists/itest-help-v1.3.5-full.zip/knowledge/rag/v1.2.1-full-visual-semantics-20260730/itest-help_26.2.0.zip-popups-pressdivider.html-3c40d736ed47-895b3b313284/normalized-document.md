# pressDivider

Simulates clicking the divider tab but not dragging it. Note: This action is never captured and must be manually added to the test case by the user.

| Target | Required. |
| --- | --- |
| Controls | Dividers. |
| Command | None. |
| Step Properties | Step Properties Index of the divider: The index of the divider to press.<br>Default: 0 Step Properties > Target Maximum time to wait for target : Specify the maximum number of seconds to wait for the target to appear before performing an action on it. If the time is exceeded, iTest declares an execution issue for the step and then continues executing.<br>Default: 15 |

For details, see the online help: Flex action reference .
