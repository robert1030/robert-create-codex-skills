---
chunk_id: itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-chunk-0001
source_id: itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623
title: profile
heading_path:
- profile
section_titles:
- profile
source_block_ids:
- itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-block-0001
- itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-block-0002
- itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-block-0003
- itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-block-0004
- itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-block-0005
- itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-block-0006
- itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-block-0007
- itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-block-0008
- itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-block-0009
- itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-block-0010
- itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-block-0011
- itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-block-0012
- itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-block-0013
- itest-help_26.2.0.zip-popups-profile.html-5c984db78739-1663f1195623-block-0014
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 141
source_hash: 1663f11956233472a353c7de68355c0115b1363ecdf38bcea5d50ecd02560849
normalized_document_hash: e9b0cdaa5ecbeccfe294b76da2012b9758d696281b2ca08386dc3565d6646303
content_status: success
content_sha256: 4eca56b08bc2a7a394034afcb8c9770dc05b544c1f8a9f1eb256717b0286e3d9
---

# profile

[ profile sessionID parameterNameOrQuery ? defaultValue ?]

Use the profile command to access the value of a parameter that is defined in the session profile associated with a particular session.

Tip:

In any field that supports field replacements, the fastest way to insert a

profile

command is to right-click where the command should appear and then select

Insert Parameter

. See

Inserting a parameter into a property or test case step

.

For details, see the online help: Accessing parameter values: The profile command .

Also, see: Field replacements: Substituting values into properties and commands .

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .
