---
chunk_id: itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-chunk-0001
source_id: itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136
title: profile
heading_path:
- profile
section_titles:
- profile
source_block_ids:
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0001
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0002
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0003
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0004
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0005
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0006
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0007
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0008
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0009
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0010
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0011
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0012
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0013
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0014
- itest-help_26.2.0.zip-popups-profile_python.html-58db86f3c071-4e9037c2b136-block-0015
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 206
source_hash: 4e9037c2b1363859e0ef4235775afb84074586c5a97a5157cce044e5eb6674f3
normalized_document_hash: e587b7e5344e06ef3dae8a104f62dbc459342d0ec61c38f29f5e43edc8ab492a
content_status: success
content_sha256: f6319318e369e2830fea14dc6b5643c8d8da1b5c20dc89df6020578f04245675
---

# profile

profile ('session', 'parameter_name_or_query', 'defaultValue')

Use the profile command to access the value of a parameter that is defined in the session profile associated with a particular session. Returns a profile parameter value.

Example: profile(in eval step): print(profile('s2','ip')) - Eval must be called while session is still open profile(in session command): ping [profile('.','ip')] - In session profile, add the 'ip' parameter in the 'Parameters' tab

Tip:

In any field that supports field replacements, the fastest way to insert a

profile

command is to right-click where the command should appear and then select

Insert Parameter

. See

Inserting a parameter into a property or test case step

.

For details, see the online help: Accessing parameter values: The profile command .

Also, see: Field replacements: Substituting values into properties and commands .

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .
