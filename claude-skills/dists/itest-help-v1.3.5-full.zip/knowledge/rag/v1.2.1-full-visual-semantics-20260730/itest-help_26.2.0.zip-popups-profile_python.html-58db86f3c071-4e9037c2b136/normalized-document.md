# profile

profile ('session', 'parameter_name_or_query', 'defaultValue')

Use the profile command to access the value of a parameter that is defined in the session profile associated with a particular session. Returns a profile parameter value.

Example: profile(in eval step): print(profile('s2','ip')) - Eval must be called while session is still open profile(in session command): ping [profile('.','ip')] - In session profile, add the 'ip' parameter in the 'Parameters' tab

Tip:

In any field that supports field replacements, the fastest way to insert a

profile

command is to right-click where the command should appear and then select

Insert Parameter

. See

Inserting a parameter into a property or test case step

.

For details, see the online help: Accessing parameter values: The profile command .

Also, see: Field replacements: Substituting values into properties and commands .

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .
