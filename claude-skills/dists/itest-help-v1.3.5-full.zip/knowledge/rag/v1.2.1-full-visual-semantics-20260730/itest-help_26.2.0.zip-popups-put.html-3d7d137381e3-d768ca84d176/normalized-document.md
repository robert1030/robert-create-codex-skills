# PUT

The PUT method is used to update (PUT to) a known resource URI with the request body containing the newly-updated representation of the original resource. PUT may also be used to create a resource where the resource ID is chosen by the client instead of by the server. If a new resource is created, see “POST” ( REST action reference ) for details. caution: .Use the PUT method for create purposes with caution

| Action | PUT - update (PUT to) a known resource URI with the request body containing the newly-updated representation of the original resource. |
| --- | --- |
| Returns | On successful update, return 200 (or 204 if not returning any content in the body). Note: If using PUT for create, return HTTP status 201 on successful creation. A body in the response is optional—providing one consumes more bandwidth. It is not necessary to return a link via a Location header in the creation case since the client already set the resource ID. Entire List: HTTP 404 (Not Found), unless you want to update/replace every resource in the entire collection. Specific Item: HTTP 200 (OK) or 204 (No Content). 404 (Not Found), if ID not found or invalid. |
| Method | PUT is not a safe operation as it modifies (or creates) state on the server, but it is idempotent. That is, creating or updating a resource using PUT multiple times does not change the resource state, it remains the same as the first PUT action. |
| Example | PUT http://www.example.com/customers/12345<br>PUT http://www.example.com/customers/12345/orders/98765<br>PUT http://www.example.com/buckets/secret_stuff |

For details, see the online help: REST action reference .
