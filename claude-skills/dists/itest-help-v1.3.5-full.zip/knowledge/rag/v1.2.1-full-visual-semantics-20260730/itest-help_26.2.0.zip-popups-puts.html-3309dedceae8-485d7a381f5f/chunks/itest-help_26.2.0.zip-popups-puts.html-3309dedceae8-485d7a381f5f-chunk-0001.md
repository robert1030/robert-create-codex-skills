---
chunk_id: itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-chunk-0001
source_id: itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f
title: puts
heading_path:
- puts
section_titles:
- puts
source_block_ids:
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0001
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0002
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0003
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0004
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0005
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0006
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0007
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0008
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0009
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0010
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0011
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0012
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0013
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0014
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0015
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0016
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0017
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0018
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0019
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0020
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0021
- itest-help_26.2.0.zip-popups-puts.html-3309dedceae8-485d7a381f5f-block-0022
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 131
source_hash: 485d7a381f5f7d0456e2da6ff5f72cb5a58d2c479455de5d3982e193d5c10660
normalized_document_hash: fef3c6a5f391c8cdc4a04856c89d7e946dbf544c86cf8a690a9b3b3fddeef73c
content_status: success
content_sha256: c5ac11093f7c01ec66a534145ebd384aed4459fad80283793e2371bff0cdfbaf
---

# puts

[ puts ? -nonewline ? { string }]

The

puts

command writes the characters given by

string

to stdout.

The command normally adds a newline character after

string

, but you can suppress the newline using the

-nonewline

switch.

Tip:

puts

returns the string into the response. Using a

get

or

gget

field substitution in the string itself is a convenient way to display a variable value.

Right-click shortcut: Insert > Special Actions > Write string into step response

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also:

Field replacements: Substituting values into properties and commands
