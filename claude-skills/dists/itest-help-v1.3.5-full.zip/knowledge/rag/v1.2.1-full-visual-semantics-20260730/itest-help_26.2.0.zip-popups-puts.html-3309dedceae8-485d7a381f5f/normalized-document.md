# puts

[ puts ? -nonewline ? { string }]

The

puts

command writes the characters given by

string

to stdout.

The command normally adds a newline character after

string

, but you can suppress the newline using the

-nonewline

switch.

Tip:

puts

returns the string into the response. Using a

get

or

gget

field substitution in the string itself is a convenient way to display a variable value.

Right-click shortcut: Insert > Special Actions > Write string into step response

For details on using this and other iTest interpreter commands, see Command syntax for test case steps .

Also:

Field replacements: Substituting values into properties and commands
