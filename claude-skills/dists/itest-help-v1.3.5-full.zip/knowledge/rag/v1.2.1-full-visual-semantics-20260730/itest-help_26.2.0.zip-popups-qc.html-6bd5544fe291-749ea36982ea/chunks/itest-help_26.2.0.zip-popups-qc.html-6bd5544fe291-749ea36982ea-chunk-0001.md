---
chunk_id: itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea-chunk-0001
source_id: itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea
title: qc
heading_path:
- qc
section_titles:
- qc
source_block_ids:
- itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea-block-0001
- itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea-block-0002
- itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea-block-0003
- itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea-block-0004
- itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea-block-0005
- itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea-block-0006
- itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea-block-0007
- itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea-block-0008
- itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea-block-0009
- itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea-block-0010
- itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea-block-0011
- itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea-block-0012
- itest-help_26.2.0.zip-popups-qc.html-6bd5544fe291-749ea36982ea-block-0013
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 111
source_hash: 749ea36982ea5ddd3b7629bd1fe1fc08b1083b69e7bdaac6dfbc6d740ab6cb8b
normalized_document_hash: 8711b0c1f0079e595a568f18f1f5c3b1d3402ebf541ec951bad532a45d5e88dc
content_status: success
content_sha256: c0eae5997b791a805a6dce4f8f8f8666a05884019731fbbd9962fac1eba1f66c
---

# qc

qc ? arg arg ... ?

qc setArtifactsLocation URI

Sets the artifactsLocation property in the QualityCenterInfo section of the test report. When excution finishes, iTest zips the artifacts and saves the zipped file to the specified loaction.

Note:

You can also set the value using the

Artifacts folder

property on the

Quality Center

page in the Test Case editor.

qc getArtifactsLocation

Returns the value of the artifactsLocation property in the QualityCenterInfo section of the test report.

Also, see: Field replacements: Substituting values into properties and commands .
