# qc

qc ? arg arg ... ?

qc setArtifactsLocation URI

Sets the artifactsLocation property in the QualityCenterInfo section of the test report. When excution finishes, iTest zips the artifacts and saves the zipped file to the specified loaction.

Note:

You can also set the value using the

Artifacts folder

property on the

Quality Center

page in the Test Case editor.

qc getArtifactsLocation

Returns the value of the artifactsLocation property in the QualityCenterInfo section of the test report.

Also, see: Field replacements: Substituting values into properties and commands .
