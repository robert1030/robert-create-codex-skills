---
chunk_id: itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-chunk-0001
source_id: itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703
title: qc
heading_path:
- qc
section_titles:
- qc
source_block_ids:
- itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-block-0001
- itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-block-0002
- itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-block-0003
- itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-block-0004
- itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-block-0005
- itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-block-0006
- itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-block-0007
- itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-block-0008
- itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-block-0009
- itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-block-0010
- itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-block-0011
- itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-block-0012
- itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-block-0013
- itest-help_26.2.0.zip-popups-qc_python.html-b23af1520281-7995e9e5f703-block-0014
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 156
source_hash: 7995e9e5f7030f2ba82011b07002653dff00495fead1297ab762f34727f72a24
normalized_document_hash: d7cb34ebca9a3d98256bcf4c80724d017e67cb76351e9940309ce1d78fb15ee4
content_status: success
content_sha256: 4c71be4303402b777b8449a88d7d361d537e15a9dac1bf4fb21bc60490994a65
---

# qc

qc ('option', 'arg', 'arg', '...')

qc ('setArtifactsLocation', 'URI')

Sets the artifactsLocation property in the QualityCenterInfo section of the test report. When excution finishes, iTest zips the artifacts and saves the zipped file to the specified loaction.

Note:

You can also set the value using the

Artifacts folder

property on the

Quality Center

page in the Test Case editor.

qc ('getArtifactsLocation', 'URI')

Returns the value of the artifactsLocation property in the QualityCenterInfo section of the test report.

Example: eval qc("setArtifactsLocation", "file:/C:/Program%20Files%20(x86)/Spirent%20Communications/iTest%207.1.0/") eval qc("getArtifactsLocation")

Also, see: Field replacements: Substituting values into properties and commands .
