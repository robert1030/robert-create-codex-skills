---
chunk_id: itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-chunk-0001
source_id: itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8
title: query
heading_path:
- query
section_titles:
- query
source_block_ids:
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0001
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0002
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0003
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0004
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0005
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0006
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0007
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0008
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0009
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0010
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0011
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0012
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0013
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0014
- itest-help_26.2.0.zip-popups-query.html-1e9a48cf9055-e5e243423ec8-block-0015
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 306
source_hash: e5e243423ec81daaa68fa99e6aea620dd0e34ba74e29a271a79912313f0b21e5
normalized_document_hash: 1f28c8228345596ea7d6e355830fa8431321e1abeed59ae0ba35b35c91675cf2
content_status: success
content_sha256: 100baa59a3b4ed6ea7a132e2dac90d63916302028b4025b0cbc1be19b5d37ea4
---

# query

query

?

-alwayslist

?

varName

mapperQuery

Use the query command to insert the result of a query into a command or property.

varName is a variable that stores the response content. (Responses are stored using the Store response in property for a step). You can use "." to indicate the response for the current step.

mapperQuery is a mapping query that will be applied to the structured data in that response object. Either an XPath query or a query from a response map, as defined in the response map for the step. If query includes whitespace, it must be surrounded by double-quotes.

The optional -alwaysList flag causes a single extracted value to be stored in a list with a single element, rather than in a scalar string. (A response with zero values or multiple values is always stored in a list.) This setting is important when you're using the response as the argument to a foreach statement and a single extracted value can contain whitespace. When you use the -alwaysList flag, a foreach statement that iterates over the stored variable will loop once for the match (rather than once for each word in the match).

For details, see the online help: Inserting the results of a query

Here's a tip for the quickest way to insert a field replacement for a query command applied to a stored response

Also:

Field replacements: Substituting values into properties and commands
