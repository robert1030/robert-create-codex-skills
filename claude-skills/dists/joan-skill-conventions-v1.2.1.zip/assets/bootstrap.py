#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""相依自動安裝器（唯一正本，房規六）。

原則：
  1. 分顆粒 ensure_*：偵測缺哪個裝哪個，裝過秒跳過（冪等）。
  2. 透明不等於隱瞞：每次實際安裝必留 log 訊息，使用者不動手但看得見。
  3. ensure_* 必須在對應的 import 之前呼叫。
  4. pip 一律帶 --break-system-packages。

各包複製到自己的 scripts/bootstrap.py 後，依相依裁剪 ensure_* 顆粒。
"""
import importlib.util
import os
import subprocess
import sys


def _have_py(module_name):
    return importlib.util.find_spec(module_name) is not None


def _have_npm(pkg):
    return os.path.isdir(os.path.join(os.getcwd(), "node_modules", pkg))


def _pip(*pkgs):
    subprocess.run([sys.executable, "-m", "pip", "install",
                    "--break-system-packages", "-q", *pkgs], check=True)


def _npm(*pkgs):
    subprocess.run(["npm", "install", "--silent", *pkgs], check=True)


def ensure_export(log=print):
    """HTML 轉 PDF／PNG 匯出鏈：playwright＋chromium＋pillow。"""
    if not _have_py("playwright"):
        log("[bootstrap] 安裝 playwright…")
        _pip("playwright")
        log("[bootstrap] 安裝 chromium…")
        subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"],
                       check=True)
    if not _have_py("PIL"):
        log("[bootstrap] 安裝 pillow…")
        _pip("pillow")


def ensure_katex(log=print):
    """KaTeX 伺服端預渲染。"""
    if not _have_npm("katex"):
        log("[bootstrap] 安裝 katex…")
        _npm("katex")


def ensure_math(log=print):
    """數理驗證（SymPy 重算）。"""
    if not _have_py("sympy"):
        log("[bootstrap] 安裝 sympy…")
        _pip("sympy")


def ensure_font_tools(log=print):
    """字型子集化為 woff2 內嵌。"""
    need = []
    if not _have_py("fontTools"):
        need.append("fonttools")
    if not _have_py("brotli"):
        need.append("brotli")
    if need:
        log(f"[bootstrap] 安裝 {' '.join(need)}…")
        _pip(*need)


def ensure_chem(log=print):
    """化學結構繪製與驗證。"""
    if not _have_py("rdkit"):
        log("[bootstrap] 安裝 rdkit…")
        _pip("rdkit")
