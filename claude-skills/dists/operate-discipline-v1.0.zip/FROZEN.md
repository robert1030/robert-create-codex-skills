# 凍結紀錄

## v1.0 ｜ 2026-07-09 ｜ 已鎖定

- 鎖了什麼：八節準則全文（節名、程序、例子、防止的失敗）與五題自測全文（題目文字與章節路由）。
- 觸發條件清單（數字、法條、程式、開發、科學、科技、電腦、研究、決策）為單一事實來源，存放於 SKILL.md frontmatter 的 description；自測適用段引用之。
- 定版檔：`SKILL.md`（已通過 `scripts/validate_punct.py` 與 `tests/test_discipline.py`）。

要調整八節內容或五題題目 → 另開新版本（minor 或 major 依變更幅度），不動本版；擴充觸發條件清單屬 minor，只改 description 一處。
