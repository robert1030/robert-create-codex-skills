#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""operate-discipline 回歸測試（房規二：驗證即閘門，不豁免自己）。

守四道門：
  1) validate_punct 對 SKILL.md 綠燈（全形標點＋零破折號）。
  2) 結構凍結：八節標題齊全、五題自測齊全（含章節路由）。
  3) 無交接殘留詞（前任／接替／交接／手冊）。
  4) 單一事實來源：description 觸發清單與自測適用段的清單一致。
改動 SKILL.md 後必跑，全 PASS 才算沒踩到凍結契約。
用法: python tests/test_discipline.py
"""
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKILL = ROOT / "SKILL.md"

SECTION_TITLES = [
    "一、讀出請求真正在問什麼",
    "二、把難題拆成可獨立驗證的片段",
    "三、判斷風險住在哪裡",
    "四、用重新推導取代「聽起來對」",
    "五、分開已知與猜測，並且說出口",
    "六、交付前先攻擊自己的結論",
    "七、先答案、再推理、最後講風險",
    "八、看起來像能力、其實不是的錯誤",
]

SELFTEST_ROUTES = ["回第一節", "回第四節", "回第五節", "回第六節", "回第七節"]

TRIGGER_TERMS = ["數字", "法條", "程式", "開發", "科學", "科技", "電腦", "研究", "決策"]

FORBIDDEN_WORDS = ["前任", "接替", "交接", "手冊"]

FAILED = []


def check(name, cond, detail=""):
    if cond:
        print(f"  PASS  {name}")
    else:
        print(f"  FAIL  {name}  {detail}")
        FAILED.append(name)


def main():
    text = SKILL.read_text(encoding="utf-8")

    print("[1] validate_punct 閘門")
    r = subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "validate_punct.py"), str(SKILL)],
        capture_output=True, text=True,
    )
    check("validate_punct 退出碼 0", r.returncode == 0, r.stdout.strip()[:200])

    print("[2] 結構凍結")
    for title in SECTION_TITLES:
        check(f"章節存在：{title[:12]}", title in text)
    check("八節標題數量恰為 8", sum(1 for t in SECTION_TITLES if t in text) == 8)
    selftest_count = len(re.findall(r"（否→回第[一四五六七]節）", text))
    check("五題自測恰為 5 題", selftest_count == 5, f"實得 {selftest_count}")
    for route in SELFTEST_ROUTES:
        check(f"自測路由存在：{route}", route in text)

    print("[3] 交接殘留清潔度")
    for word in FORBIDDEN_WORDS:
        hits = [ln for ln, line in enumerate(text.splitlines(), 1) if word in line]
        check(f"無殘留詞「{word}」", not hits, f"出現於行 {hits}")

    print("[4] 單一事實來源一致性")
    m = re.search(r'^description:\s*"(.*?)"\s*$', text, re.MULTILINE | re.DOTALL)
    check("frontmatter description 可解析", m is not None)
    if m:
        desc = m.group(1)
        for term in TRIGGER_TERMS:
            check(f"description 含觸發詞「{term}」", term in desc)
    scope = re.search(r"適用範圍（單一事實來源）：(.*?)。", text, re.DOTALL)
    check("自測適用段存在", scope is not None)
    if scope:
        body = scope.group(1)
        for term in TRIGGER_TERMS:
            check(f"適用段含觸發詞「{term}」", term in body)

    print()
    if FAILED:
        print(f"❌ {len(FAILED)} 項未過：{FAILED}")
        return 1
    print("✅ 全部通過，凍結契約完好。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
