#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""operate-discipline 回歸測試（房規二：驗證即閘門，不豁免自己）。

守七道門：
  1) validate_punct 對 SKILL.md 綠燈（全形標點＋零破折號）。
  2) 結構凍結：八節標題齊全、五題自測齊全（含章節路由）。
  3) 無交接殘留詞（前任／接替／交接／手冊）。
  4) 單一事實來源：description 觸發清單與自測適用段的清單一致。
  5) 第九節結構（v1.1）：清單九點齊全、三項情境加問的觸發條件在、禁止刻意反駁的約束逐字在、銜接註記在第 5 題之後。
  6) 凍結雜湊：八節全文與五題自測（節標題到第 5 題止）的 SHA-256 摘要等於 v1.0 定版值，改一個字即紅燈。
  7) 篇幅上限：SKILL.md 不得超過 MAX_BYTES，超過就得把例子外移到 references/。
改動 SKILL.md 後必跑，全 PASS 才算沒踩到凍結契約。
用法: python tests/test_discipline.py
"""
import hashlib
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKILL = ROOT / "SKILL.md"

SECTION_TITLES = [
    "一、讀出請求真正在問什麼",
    "二、把難題拆成可獨立驗證的片段",
    "三、判斷風險住在哪裡",
    "四、用重新推導取代「聽起來對」",
    "五、分開已知與猜測，並且說出口",
    "六、交付前先攻擊自己的結論",
    "七、先答案、再推理、最後講風險",
    "八、看起來像能力、其實不是的錯誤",
]

SELFTEST_ROUTES = ["回第一節", "回第四節", "回第五節", "回第六節", "回第七節"]

TRIGGER_TERMS = ["數字", "法條", "程式", "開發", "科學", "科技", "電腦", "研究", "決策"]

FORBIDDEN_WORDS = ["前任", "接替", "交接", "手冊"]

# ---- v1.1 新增：第九節「交付前的論證體質審查」 ----
NEW_SECTION_TITLE = "九、交付前的論證體質審查"

CHECKLIST_ITEMS = [
    "主要主張是否有足夠證據支持",
    "結論是否超出當前證據範圍",
    "是否存在未說明的假設",
    "重要名詞的定義是否一致",
    "因果關係與相關關係是否混淆",
    "是否存在資訊缺口、適用限制或可能的反例",
    "（改動既有系統時）是否破壞原有的架構、設計、工作紀錄、平台相容性",
    "（交付物有多個變體時）修正是否涵蓋全部變體",
    "（改動涉及程式時）當前與修正後的程式是否存在安全風險",
]

# 這條是第九節的靈魂，逐字守門，不准被改寫成軟話
ANTI_CONTRARIAN = "不得為了顯示批判性而刻意反駁；沒有明顯問題時，應明確說明未發現重大矛盾。"

BRIDGE_NOTE = "見第九節「交付前的論證體質審查」"

# ---- 凍結雜湊（房規一）：v1.0 定版值，改任何一個字都會變 ----
FROZEN_SECTIONS_DIGEST = "312e2257a9c5c4cf"   # 八節全文
FROZEN_SELFTEST_DIGEST = "e492ec9f57030ce3"   # 五題自測（節標題到第 5 題止）

MAX_BYTES = 16000   # 注意力預算上限；超過就把例子外移到 references/，不要放任長大

FAILED = []


def frozen_sections_digest(text):
    """八節全文摘要。依 `\\n## ` 切塊、只取八節、去掉尾端分隔線，故插入新節不影響取樣。"""
    blocks = []
    for block in text.split("\n## "):
        for title in SECTION_TITLES:
            if block.startswith(title):
                body = block.rstrip()
                while body.endswith("---"):
                    body = body[:-3].rstrip()
                blocks.append("## " + body)
    if len(blocks) != 8:
        return f"blocks={len(blocks)}"
    return hashlib.sha256("\n\n".join(blocks).encode("utf-8")).hexdigest()[:16]


def frozen_selftest_digest(text):
    """五題自測摘要：節標題到第 5 題結尾止。其後新增的銜接註記不進摘要，屬 v1.1 擴充。"""
    m = re.search(r"## 出手前的五題自測.*?（否→回第七節）", text, re.DOTALL)
    if not m:
        return "not-found"
    return hashlib.sha256(m.group(0).encode("utf-8")).hexdigest()[:16]


def check(name, cond, detail=""):
    if cond:
        print(f"  PASS  {name}")
    else:
        print(f"  FAIL  {name}  {detail}")
        FAILED.append(name)


def main():
    text = SKILL.read_text(encoding="utf-8")

    print("[1] validate_punct 閘門")
    r = subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "validate_punct.py"), str(SKILL)],
        capture_output=True, text=True,
    )
    check("validate_punct 退出碼 0", r.returncode == 0, r.stdout.strip()[:200])

    print("[2] 結構凍結")
    for title in SECTION_TITLES:
        check(f"章節存在：{title[:12]}", title in text)
    check("八節標題數量恰為 8", sum(1 for t in SECTION_TITLES if t in text) == 8)
    selftest_count = len(re.findall(r"（否→回第[一四五六七]節）", text))
    check("五題自測恰為 5 題", selftest_count == 5, f"實得 {selftest_count}")
    for route in SELFTEST_ROUTES:
        check(f"自測路由存在：{route}", route in text)

    print("[3] 交接殘留清潔度")
    for word in FORBIDDEN_WORDS:
        hits = [ln for ln, line in enumerate(text.splitlines(), 1) if word in line]
        check(f"無殘留詞「{word}」", not hits, f"出現於行 {hits}")

    print("[4] 單一事實來源一致性")
    m = re.search(r'^description:\s*"(.*?)"\s*$', text, re.MULTILINE | re.DOTALL)
    check("frontmatter description 可解析", m is not None)
    if m:
        desc = m.group(1)
        for term in TRIGGER_TERMS:
            check(f"description 含觸發詞「{term}」", term in desc)
    scope = re.search(r"適用範圍（單一事實來源）：(.*?)。", text, re.DOTALL)
    check("自測適用段存在", scope is not None)
    if scope:
        body = scope.group(1)
        for term in TRIGGER_TERMS:
            check(f"適用段含觸發詞「{term}」", term in body)

    print("[5] 第九節結構（v1.1）")
    check(f"章節存在：{NEW_SECTION_TITLE}", NEW_SECTION_TITLE in text)
    sec9 = ""
    m9 = re.search(r"## 九、交付前的論證體質審查\n(.*?)\n---\n", text, re.DOTALL)
    check("第九節可擷取", m9 is not None)
    if m9:
        sec9 = m9.group(1)
    check("節首說明與第六節的分工", "與第六節的分工" in sec9)
    for item in CHECKLIST_ITEMS:
        check(f"清單項存在：{item[:14]}", item in sec9)
    item_count = len(re.findall(r"^\d\. \*\*", sec9, re.MULTILINE))
    check("清單恰為 9 點", item_count == 9, f"實得 {item_count}")
    check("禁止刻意反駁的約束逐字存在", ANTI_CONTRARIAN in sec9)
    check("銜接註記存在", BRIDGE_NOTE in text)
    q5 = text.find("（否→回第七節）")
    bridge = text.find(BRIDGE_NOTE)
    check("銜接註記在第 5 題之後", q5 != -1 and bridge > q5)

    print("[6] 凍結雜湊守門")
    got_sections = frozen_sections_digest(text)
    check("八節全文未被動到", got_sections == FROZEN_SECTIONS_DIGEST,
          f"實得 {got_sections} ≠ 定版 {FROZEN_SECTIONS_DIGEST}")
    got_selftest = frozen_selftest_digest(text)
    check("五題自測未被動到", got_selftest == FROZEN_SELFTEST_DIGEST,
          f"實得 {got_selftest} ≠ 定版 {FROZEN_SELFTEST_DIGEST}")

    print("[7] 篇幅上限")
    size = len(text.encode("utf-8"))
    check(f"SKILL.md ≦ {MAX_BYTES} bytes", size <= MAX_BYTES, f"實得 {size}")

    print()
    if FAILED:
        print(f"❌ {len(FAILED)} 項未過：{FAILED}")
        return 1
    print("✅ 全部通過，凍結契約完好。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
