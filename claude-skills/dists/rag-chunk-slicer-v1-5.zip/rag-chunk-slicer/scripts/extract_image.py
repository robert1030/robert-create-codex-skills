#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""extract_image.py：圖片 OCR（PNG／JPG／HEIC／HEIF）。
能力邊界（先講清楚，別硬做）：
  - 用 Tesseract 做傳統 OCR，吃文字型圖片（截圖、掃描頁、含文字的圖表標籤）效果好；
    對純視覺內容（照片、無文字的示意圖、手繪圖）OCR 不出東西是預期行為，不是錯誤。
  - v1.5 起：小尺寸圖片（長邊低於門檻）會先放大再辨識，並自動比較多種版面切割模式
    （PSM）取信心分數最高者，大幅改善小字截圖（如流程圖、對話框、表格截圖）的準確度，
    但仍是傳統 OCR，遇到藝術字體、極低解析度、傾斜角度、複雜疊字排版時準確度仍有限，
    正式用於 RAG 索引前建議抽樣人工核對；不確定的辨識結果不會被美化或腦補成看似合理
    的文字。
  - 圖片含旋轉／浮水印疊字等複雜排版不做版面還原，純粹整段文字輸出。
  - HEIC／HEIF（iPhone 常見拍照格式）額外仰賴 pillow-heif 解碼，環境無法安裝時
    會明確拋出例外，由呼叫端降級告知，不嘗試用其他方式硬讀。
"""
import os

_HEIC_EXTS = {'.heic', '.heif'}

# 小圖放大門檻：長邊低於此值才觸發放大（已經夠大的圖片不做多餘處理，避免浪費時間）。
_UPSCALE_TARGET_LONG_SIDE = 1400
# 放大倍率上限：避免對極小的裝飾性圖示做無意義的暴力放大。
_UPSCALE_MAX_SCALE = 6

# 依序嘗試的 Tesseract 版面切割模式（PSM）：
#   6 = 假設整張圖是一塊排版一致的文字（截圖、表格、對話框最常見的情況）
#   3 = 全自動版面分析（預設值，適合複雜排版的完整頁面）
#   4 = 假設是單欄、不同行高可變的文字（部分表格／清單類截圖適用）
# 三種都跑一次，取「詞辨識信心分數平均」最高的一組當最終結果。
_PSM_CANDIDATES = (6, 3, 4)


def _upscale_if_small(img):
    """長邊低於 `_UPSCALE_TARGET_LONG_SIDE` 才放大，用 LANCZOS 內插；
    已經夠大的圖片原樣返回，不做多餘運算。放大倍率上限 `_UPSCALE_MAX_SCALE`。
    """
    from PIL import Image

    long_side = max(img.width, img.height)
    if long_side >= _UPSCALE_TARGET_LONG_SIDE:
        return img
    scale = min(_UPSCALE_MAX_SCALE, _UPSCALE_TARGET_LONG_SIDE / long_side)
    if scale <= 1:
        return img
    new_size = (max(1, round(img.width * scale)), max(1, round(img.height * scale)))
    return img.resize(new_size, Image.LANCZOS)


def _preprocess_for_ocr(img):
    """OCR 前處理：正規化色彩模式 → 小圖放大 → 灰階 → 自動對比。
    這一路操作會產生新的 PIL Image 物件（`.format` 屬性會變成 None），
    pytesseract 遇到 `.format` 是 None 時會預設當成 PNG 處理，這同時
    也順便解決了 HEIC／HEIF 解碼後格式標記不被 pytesseract 辨識的問題，
    不需要再另外繞路轉存暫存檔。
    """
    from PIL import ImageOps

    img = img.convert('RGB')
    img = _upscale_if_small(img)
    gray = ImageOps.grayscale(img)
    gray = ImageOps.autocontrast(gray)
    return gray


def _ocr_best_effort(img, lang):
    """依序嘗試 `_PSM_CANDIDATES` 幾種版面切割模式，取詞辨識信心分數平均
    最高的一組文字。信心分數來自 Tesseract 自己回報的每個詞辨識信心
    （0～100），不是用文字長短或外觀猜的，符合「驗證即閘門、不靠肉眼」。
    全部模式都辨識不出任何文字時，退回最基本的預設模式再試一次，
    確保至少嘗試過，不會因為前面幾種模式失敗就直接放棄。
    """
    import pytesseract

    best_text, best_conf = '', -1.0
    for psm in _PSM_CANDIDATES:
        config = f'--psm {psm}'
        try:
            data = pytesseract.image_to_data(img, lang=lang, config=config, output_type=pytesseract.Output.DICT)
        except pytesseract.TesseractError:
            continue
        confs = [int(c) for c in data.get('conf', []) if str(c) not in ('-1', '')]
        mean_conf = sum(confs) / len(confs) if confs else -1.0
        has_text = any(w.strip() for w in data.get('text', []))
        if has_text and mean_conf > best_conf:
            best_conf = mean_conf
            best_text = pytesseract.image_to_string(img, lang=lang, config=config)

    if not best_text:
        best_text = pytesseract.image_to_string(img, lang=lang)
    return best_text.strip()


def ocr_image(path: str, lang: str = 'chi_tra+eng') -> str:
    """對單張圖片做 OCR，回傳辨識出的文字（去頭尾空白）。
    讀取失敗或辨識不出文字時，回傳空字串，由呼叫端決定如何降級顯示。

    v1.5 起會先做前處理（小圖放大、灰階、自動對比），再比較多種 PSM
    版面切割模式取信心分數最高者，藉此改善小字截圖的辨識準確度；
    HEIC／HEIF 檔案在開圖前會先確保 pillow-heif 已安裝並註冊為 Pillow 的
    解碼外掛。
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(path)

    ext = os.path.splitext(path)[1].lower()
    if ext in _HEIC_EXTS:
        import bootstrap
        if not bootstrap.ensure_heic():
            raise RuntimeError('此環境缺少可用的 HEIC／HEIF 解碼器（pillow-heif 安裝失敗）')
        import pillow_heif
        pillow_heif.register_heif_opener()

    from PIL import Image

    with Image.open(path) as img:
        processed = _preprocess_for_ocr(img)
    return _ocr_best_effort(processed, lang)
