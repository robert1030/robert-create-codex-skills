---
name: rag-chunk-slicer
description: "把 PDF、DOCX、DOC、HTML、XML、CSV、Markdown、MP4、HEIC／HEIF 切成高細緻度的 RAG 切片，交付成單一 Markdown 檔或 JSONL（每片附 chunk_id／section_path／頁碼或時間戳等 metadata）。支援批次模式（整個資料夾一次處理）與 HTML／HTM 內嵌的 PNG／JPG／HEIC 圖片（含子目錄相對路徑）OCR 切片。當使用者要做『RAG 切片』『chunking』『文件切塊』『向量化前處理』『建立知識庫切片』，或提到要把文件／影片／照片轉成適合餵給向量資料庫或檢索增強生成（RAG）系統的格式時，立即使用本 skill。即使使用者只說『幫我把這份文件切一切準備做 RAG』也應觸發。"
---

# RAG 切片產生器（rag-chunk-slicer）

> **v1.6｜2026-07-02**：疊加兩道以信心分數為依據的 OCR 強化，仍是純本地 Tesseract，不接視覺模型（已對焦定案，見下方「對焦記錄」）。① 圖示區域遮罩：依尺寸與信心分數啟發式判斷「圖示污染候選」框體（框體很小、近似方形、信心分數偏低），OCR 前塗成局部背景色再重跑，避免圖示像素跟旁邊真實文字的字元邊界黏在一起造成整詞誤判。② 局部裁切放大：對信心分數仍偏低的個別詞，裁切該詞所在區域用更高倍率單獨放大重辨識，新信心分數要比原本高出一定幅度（`_CROP_MIN_IMPROVEMENT`）才採用，不是「有比較高就換」。**同版也修正一個實作缺陷**：版面重建原本用自製的 top 座標分行啟發式，多欄並排介面（左側樹狀清單＋右側屬性面板）容易被錯誤打散重排；改用 Tesseract 自己回傳的 `block_num`／`par_num`／`line_num` 分行與原始閱讀順序，此問題已修正並有回歸測試鎖住。**實測結果誠實記錄（不美化）**：用三張真實問題截圖（`loops_6.1.jpg`、`array_param_PythonSplit.png`、`test_case_editor_2.19.jpg`）比對 v1.5 與 v1.6，圖示遮罩與局部裁切放大對「圖示與文字已經是分開框體」的情況（本次測試集的實際狀況）效果有限，因為問題根源多半是字元本身在小尺寸下被誤讀（例如 else 讀成 cke／cbse 這類字母層級混淆），不是圖示像素與文字融合。局部裁切放大偶爾會把一個錯誤猜測換成另一個信心分數更高、但依然錯誤的猜測（confidence 不等於正確性），已加最小改善門檻但無法完全排除，這是傳統 OCR 以信心分數為依據做校正的固有限制，不是這次實作的 bug。這道強化對「圖示與文字確實融合成單一框體」的其他圖片仍有意義，且不會讓已經正確的內容變差（多欄版面順序修正後與 v1.5 高度一致）。新增 `tests/test_extract_image_v16.py`（二十一個測試：圖示候選判斷、背景色取樣、遮罩、版面重建、局部裁切放大信心分數門檻），回歸測試全綠。`ocr_image()` 新增可選參數 `enhance`（預設 `True`），設 `enhance=False` 完全等同 v1.5 行為，供除錯或效能比較之用。
> **v1.5｜2026-07-02**：強化圖片 OCR 準確度＋補齊獨立圖片輸入格式。① OCR 前處理：小尺寸圖片（長邊低於一四〇〇像素）自動放大（LANCZOS 內插，最高六倍）並轉灰階、自動對比，改善小字截圖（流程圖、對話框、表格截圖）的辨識率；已經夠大的圖片不做多餘處理。② 多 PSM 信心分數挑選：同一張圖依序嘗試三種 Tesseract 版面切割模式（PSM 6／3／4），比較 Tesseract 回報的逐詞信心分數，取平均分數最高者，不是憑文字長短猜。③ 補齊 png／jpg／jpeg 的「頂層獨立輸入格式」入口（`python scripts/run.py 截圖.jpg`），之前只有 HEIC／HEIF 有這個入口，一般截圖只能透過 HTML 內嵌才能 OCR，此版起與 HEIC 共用同一套 `extract_image_standalone()`。**非向下相容說明**：`extract.py` 的 `extract_heic()` 函式已改名為 `extract_image_standalone()`（若有外部程式直接 import 舊函式名需要更新）；OCR 文字輸出本身也會因為準確度改善而與 v1.4 以前的結果不同（這是預期的品質提升，不是錯誤），若下游有依賴舊版 OCR 文字做精確比對，重新切片前請留意。新增 `tests/test_extract_image_ocr.py`（前處理幾何與信心分數挑選邏輯）與擴充後的 `tests/test_extract_image_standalone.py`（涵蓋全部五種副檔名），回歸測試全綠。
> **v1.4｜2026-07-01**：新增 HEIC／HEIF 圖片支援，兩個入口都支援：① 當成獨立頂層輸入格式（`python scripts/run.py photo.heic`，與 pdf／docx 同層級，整張圖 OCR 文字強制獨立成一塊，行為與既有 png／jpg 圖片 OCR 一致，不依語意細切）；② HTML／HTM 內嵌 `<img src="x.heic">` 一併處理（沿用既有內嵌圖片 OCR 邏輯，無需額外參數）。新增 `bootstrap.ensure_heic()` 自動安裝 `pillow-heif`（純 Python wheel，不需要系統套件），與既有 `ensure_ocr()`（Tesseract）互相獨立、缺一不影響另一格式。既有格式與既有內嵌圖片（png／jpg）行為完全不變，回歸測試全綠（`tests/test_chunker.py`／`test_run_batch.py`／`test_extract_heic.py`）。
> **v1.3｜2026-07-01**：新增批次模式（輸入改給資料夾即自動切換，逐檔輸出、單檔失敗不中斷整批，結尾印出成功／失敗清單；預設不遞迴，`--recursive` 可連子資料夾一併掃描）；新增 `chunk_id` 雜湊模式（`--id-mode hash`，同內容重新切片時 `chunk_id` 保持穩定，方便向量資料庫增量索引）。預設 `--id-mode sequential`，行為與 v1.2 以前完全相同（四位數連號），向下相容；單檔模式的呼叫方式與輸出檔名規則也完全不變。`build_chunks()` 新增可選參數 `id_mode`，不傳則沿用舊版行為。
> **v1.2｜2026-06-30**：新增 JSONL 輸出選項（與 Markdown 並存，`--format md/jsonl/both`），免去下游自己解析 frontmatter；PDF 標題判斷改為書籤（TOC）優先，沒有書籤才退回原本的字級啟發式（既有無書籤文件行為不變）；新增可選精確 token 計數（`--tokenizer tiktoken`），預設仍是免安裝的粗估（`heuristic`），向下相容。`build_chunks()` 新增可選參數 `token_fn`，不傳則行為與舊版完全一致。
> **v1.1｜2026-06-30**：新增 HTML／HTM 內嵌圖片（PNG／JPG，含子目錄相對路徑）OCR 切片支援。圖片走 Tesseract（繁中＋英文語言包），每張圖強制獨立成塊並帶 `image_path` 欄位回溯來源；外部連結圖片與找不到的圖片走明確降級訊息，不靜默略過、不假裝辨識成功。既有格式（pdf／docx／doc／xml／csv／md／txt／mp4）行為不變，回歸測試全綠（見 `tests/test_chunker.py`）。
> **v1.0｜2026-06-30**：初版，支援 pdf／docx／doc／html／xml／csv／md／txt／mp4 八種格式的混合策略切片。

把任意支援格式的來源文件，依「標題優先分區、區內語意細切」的混合策略，產出高細緻度的 RAG 切片，交付成單一 Markdown 檔或 JSONL（可批次處理整個資料夾）。

## 支援格式與處理方式

| 格式 | 解析方式 | 備註 |
|---|---|---|
| Markdown（.md） | `#`～`######` 標題階層＋空行分段落 | 原生支援 |
| 純文字（.txt） | 空行分段落，無標題層級 | 全文視為單一區（無標題區） |
| HTML（.html/.htm） | `h1`～`h6` 為標題，`p/li/td` 為段落；`<img>` 內嵌圖片另走 OCR 切片 | 去除 `script/style`；圖片相對路徑支援子目錄（如 `assets/sub/a.png`），支援 png／jpg／jpeg／heic／heif |
| XML（.xml） | 標籤階層前兩層當虛擬標題路徑 | 啟發式，見下方能力邊界 |
| CSV（.csv） | 每一列強制獨立成一塊 | 列是天生原子單位，不與其他列合併 |
| Word（.docx） | 段落樣式 `Heading 1~6` 為標題 | 用 `python-docx` |
| 舊版 Word（.doc） | 先用系統 LibreOffice 轉成 .docx 再解析 | 環境無 LibreOffice 時明確降級 |
| PDF（.pdf） | 優先讀取書籤（TOC）當標題階層；無書籤才退回字級中位數啟發式，逐頁記錄頁碼 | 掃描影像版（無文字層）不含 OCR，會明確告知 |
| 影片（.mp4） | ffmpeg 抽音軌 → faster-whisper 語音轉文字 → 依時間戳切片 | 需要可連網下載模型權重，見下方能力邊界 |
| 圖片（.png/.jpg/.jpeg/.heic/.heif） | 整張圖走 Tesseract OCR，文字強制獨立成一塊；v1.5 起先做放大＋灰階＋對比前處理，再比較多種 PSM 模式取信心分數最高者；v1.6 起再疊加圖示區域遮罩與局部裁切放大 | HEIC／HEIF 額外需 `pillow-heif` 解碼，見下方能力邊界 |

## 切片策略（已與使用者對焦定案）

**混合策略：標題優先分區，區內再依語意細切，最高細緻度。**

1. 先依文件結構（標題階層／CSV 列／影片時間戳）切出「區段」，每個區段帶完整的 `section_path`（例如「第一章 > 1.2 背景」）。
2. 區段內的內容再依句界（。！？；換行）細切，逼近目標字元區間（預設 150～400 字元，可用 `--min`／`--max` 調整），絕不在句子中間硬斷。
3. 單一句子若已超過上限，整句保留、不強制截斷，以保護語意完整性。
4. CSV 的每一列固定獨立成一塊（資料列本身就是最高細緻度的原子單位）。
5. HTML／HTM 內嵌的 `<img>` 圖片（PNG／JPG／JPEG／HEIC／HEIF，支援子目錄相對路徑），會依出現順序原地插入結構區塊，繼承當下所在的標題路徑，並用 Tesseract OCR 取出圖片裡的文字，強制獨立成一塊（不與前後文字段落合併），切片帶 `image_path` 欄位回溯來源檔案。v1.5 起，OCR 前會先做放大＋灰階＋自動對比前處理，並比較多種 PSM 版面切割模式取信心分數最高者，改善小字截圖的準確度。
6. HEIC／HEIF 當成頂層獨立輸入時，同一份原則：整張圖的 OCR 文字強制獨立成一塊，不論長短都不再依語意細切（跟內嵌圖片行為一致，這是已與使用者對焦的決定，見「對焦記錄」）。

## 使用方式

單檔模式（與 v1.2 以前完全相同）：

```bash
python scripts/run.py <輸入檔路徑> [--out 輸出路徑前綴] [--min 150] [--max 400] \
    [--format md|jsonl|both] [--tokenizer heuristic|tiktoken] [--id-mode sequential|hash]
```

批次模式（輸入改給資料夾即自動切換）：

```bash
python scripts/run.py <輸入資料夾> [--recursive] [--out 輸出資料夾] \
    [--min 150] [--max 400] [--format md|jsonl|both] [--tokenizer heuristic|tiktoken] \
    [--id-mode sequential|hash]
```

- `--format`：預設 `md`（單一 Markdown，與 v1.0／v1.1 行為一致，向下相容）。`jsonl` 產出每行一筆切片的 JSONL，方便直接餵向量資料庫／embedding pipeline，不需要再自己解析 Markdown frontmatter。`both` 兩者都產出。
- `--tokenizer`：預設 `heuristic`（免安裝、免網路的粗估，向下相容）。`tiktoken` 改用精確分詞器計數，需要安裝 `tiktoken` 套件並下載編碼檔；若此環境的網路白名單擋下編碼檔下載，會自動降級回 `heuristic` 並印出明確警告，不會讓整支程式中斷。
- `--id-mode`：預設 `sequential`（四位數連號 `"0001"`，與 v1.2 以前完全相同，向下相容）。`hash` 改用內容雜湊（來源檔名＋標題路徑＋正文算 sha1，取前十二碼十六進位），只要某片內容不變，重新切片時 `chunk_id` 就不會變，方便向量資料庫做增量索引。兩種模式互不相容、不能混用同一批索引。
- `--recursive`：僅批次模式（輸入為資料夾）有效，連子資料夾一併掃描；預設只掃輸入資料夾本身（不遞迴）。

批次模式支援的格式與單檔模式相同（見上表）；掃到不支援的副檔名會直接略過，不當作失敗。單檔處理失敗（例如檔案損毀）不會中斷整批，會記錄在結尾的失敗清單並印出原因，成功的檔案仍會正常產出。輸出檔名規則與單檔模式相同（`<原檔名去副檔名>.chunks.md`／`.jsonl`），批次模式預設輸出到輸入資料夾本身，可用 `--out` 指定另一個輸出資料夾。

預設輸出路徑前綴為去除副檔名的輸入檔名，例如 `--format both` 會產出 `<輸入檔名>.chunks.md` 與 `<輸入檔名>.chunks.jsonl`。執行流程：

1. `extract.py` 依副檔名分派到對應解析器，產出結構區塊（`Block`）清單。PDF 會優先讀取書籤（TOC）當標題階層，沒有書籤才退回字級啟發式判斷；HEIC／HEIF 走單張圖片 OCR。
2. 重相依套件（pymupdf／python-docx／beautifulsoup4／faster-whisper／tesseract／tiktoken／pillow-heif 等）由 `bootstrap.py` 的 `ensure_*` 在 import 前自動偵測安裝，裝過就跳過（`pip` 一律帶 `--break-system-packages`）。
3. `chunker.py` 的 `build_chunks()` 執行混合切片，產出 `Chunk` 清單；token 計數策略由 `token_counter.py` 的 `get_token_counter()` 選擇，`chunk_id` 產生方式由 `id_mode` 選擇。
4. `build_markdown.py` 與／或 `build_jsonl.py` 依 `--format` 組成交付檔。批次模式下對資料夾內每個支援格式的檔案重複步驟 1 至 4，單檔失敗記錄後繼續下一檔。

## 輸出格式

### Markdown（`--format md`，預設）

檔首是一份文件層級總覽，之後每個切片各自一份 frontmatter＋正文，彼此用 `---` 分隔：

```markdown
---
doc_source_file: "員工手冊.docx"
doc_source_type: docx
chunk_strategy: hybrid-heading-then-semantic
total_chunks: 42
generated_at: 2026-06-30T10:00:00
---

---
chunk_id: "0001"
source_file: "員工手冊.docx"
source_type: docx
section_path: "第一章 > 請假規定"
section_level: 2
char_count: 187
token_estimate: 142
page_range: "3-3"
---
（切片正文……）
```

人讀、稽核友善，但要餵進向量資料庫前，下游通常得自己寫一段解析 frontmatter 的程式。

### JSONL（`--format jsonl`）

每行一筆切片，機器可直接讀取，免去自己解析 Markdown frontmatter：

```jsonl
{"chunk_id": "0001", "source_file": "員工手冊.docx", "source_type": "docx", "chunk_strategy": "hybrid-heading-then-semantic", "section_path": "第一章 > 請假規定", "section_level": 2, "char_count": 187, "token_estimate": 142, "page_range": "3-3", "text": "（切片正文……）"}
```

`page_range` 只在 PDF 有值，`timestamp_range`（格式如 `00:01:23-00:01:45`）只在 MP4 有值，`image_path` 在 HTML 內嵌圖片切片與 HEIC／HEIF 頂層輸入切片都有值。兩種格式欄位定義詳見 `references/chunk-schema.md`。

## 能力邊界（先講清楚，別硬做）

- **掃描影像版 PDF**：本引擎不含 OCR，偵測不到文字層時會回傳一則明確的能力邊界說明，不會假裝抽到完整內容。需要 OCR 的話，建議先用其他工具把 PDF 轉成可選取文字版再餵進來。
- **.doc 舊版二進位格式**：仰賴系統有 LibreOffice（`soffice`）才能安全轉檔。沒有就明確告知，不嘗試用猜測性方式硬讀二進位內容，避免內容失真。
- **.xml 章節推測**：沒有固定 schema 時，以標籤階層前兩層當虛擬標題路徑，是啟發式推測，不保證對應到真正語意章節，正式用於 RAG 索引前建議使用者抽樣確認。
- **.mp4 語音轉文字**：依賴本機 ffmpeg＋faster-whisper 模型權重下載。若執行環境離線或網路白名單擋下模型下載，會降級為只保留檔案中繼資料（檔名／大小），並在輸出中明確標示降級原因，不編造逐字稿內容。轉錄準確度也會受口音、背景雜音、術語影響，正式使用前建議人工抽查。
- **圖片 OCR（PNG／JPG／JPEG／HEIC／HEIF，含 HTML 內嵌與頂層獨立輸入）**：用 Tesseract（繁中＋英文語言包）做傳統 OCR。v1.5 起，小尺寸圖片（長邊低於一四〇〇像素）會先放大＋灰階＋自動對比前處理，並比較三種 PSM 版面切割模式取信心分數最高者，對小字截圖（流程圖、表格、對話框）的準確度有明顯改善。v1.6 起再疊加圖示區域遮罩（把小型、近似方形、低信心分數的框體視為圖示污染候選，OCR 前塗成局部背景色再重跑）與局部裁切放大（對信心分數仍偏低的個別詞，裁切後單獨放大重辨識，新信心分數要明顯高於原本才採用）。**實測誠實補充**：這兩道強化對「圖示像素與文字融合成單一框體」的情況才有效，若 Tesseract 本身已經把圖示與文字分成不同框體（實測中較常見的狀況），遮罩不會改變結果；局部裁切放大偶爾會把一個錯誤猜測換成另一個信心分數更高、但依然錯誤的猜測，因為信心分數只反映 Tesseract 對自己這次猜測的把握，不保證猜對，這是以信心分數為依據做校正的固有限制，已加最小改善門檻降低此風險但無法完全排除。整體而言，仍是傳統 OCR，對純視覺內容（照片、無文字的示意圖）辨識不出文字是預期行為，遇到藝術字體、極低解析度、傾斜角度、原始筆畫本身已缺失時準確度仍有限，這是原始圖片本身的限制而非管線缺陷，正式用於 RAG 索引前建議抽樣人工核對，不會被腦補成看似合理的文字。多 PSM 比較＋v1.6 兩道強化會讓每張圖的處理時間比 v1.4 以前明顯增加，對批次模式的整體耗時有影響。HTML 外部連結（`http(s)://`）與內嵌 `data:` URI 的圖片不會下載／解碼處理，會明確標示已略過；找不到的圖片檔案也會明確告知路徑，不靜默跳過。
- **HEIC／HEIF 解碼**：仰賴 `pillow-heif`（純 Python wheel，不需系統套件，安裝門檻低於 ffmpeg／LibreOffice 這類系統相依），安裝失敗時會明確拋出能力邊界訊息並略過該圖片，不嘗試用其他方式硬讀；解碼成功與否跟 OCR 辨不辨得出文字是兩件事，兩者的降級訊息不同，前者是「圖片處理失敗」，後者是「辨識不到文字」。
- **token 估算**：預設 `token_estimate` 是粗估（中日韓文字逐字計、英數依空白斷詞），非特定模型分詞器的精確 token 數，僅供切片大小參考。改用 `--tokenizer tiktoken` 可換成精確分詞器，但 tiktoken 首次使用需要下載編碼檔（`openaipublic.blob.core.windows.net`），若執行環境網路白名單未開放該網域，會自動降級回粗估並印出明確警告，不會讓整支程式中斷，但 token 數會回到粗估而非精確值。
- **PDF 書籤優先**：文件有做書籤（TOC）時，標題階層直接採用書籤，準確度遠高於字級啟發式；沒有書籤的文件仍退回字級中位數啟發式（與 v1.0／v1.1 行為相同），對標題字級不明顯或版面複雜的文件，準確度有限，正式用於 RAG 索引前建議抽樣確認 `section_path` 是否合理。
- **chunk_id 雜湊模式**：`--id-mode hash` 只保證「同一片的來源檔名、所屬標題路徑、正文三者都沒變」時 chunk_id 不變；只要其中任何一項改了（含標題文字調整、正文因 `--min`／`--max` 不同而重新斷句），該片的雜湊值就會跟著變，不是「這份文件永遠不變」的保證，增量索引前建議仍對變動片重新 embedding 而非只信任 chunk_id 是否存在。雜湊碰撞機率極低但非零，未做碰撞偵測。
- **批次模式**：目前是單機依序處理，不做平行化，檔案數量大時耗時會隨檔案數線性增加；單檔失敗會被記錄並跳過，不會嘗試重試或修復損毀檔案；掃描規則只認副檔名，副檔名錯誤或偽裝的檔案仍可能被送進對應解析器而解析失敗（會反映在失敗清單裡，不會靜默產出錯誤內容）。

## 對焦記錄（本次已與使用者確認，無需重問）

- 切片粒度策略：混合策略（標題優先分區，區內語意細切，最高細緻度）。
- MP4 處理方式：本地語音轉文字（Whisper／faster-whisper），轉成逐字稿再切片。
- 交付形式：單一 Markdown 檔，所有切片用 frontmatter 分隔串接。
- HTML／HTM 內嵌圖片（PNG／JPG，含子目錄）：一併切片，OCR 引擎用本地開源 Tesseract（離線、免費，未特別要求視覺理解模型時的預設選擇）。
- 輸出格式擴充：新增 JSONL 選項，與 Markdown 並存、不取代。
- 文件判斷品質優先順序：PDF 書籤（TOC）優先於字級啟發式；token 計數可選接 tiktoken（預設仍是免安裝粗估）。
- 規模擴充：CLI 支援批次模式（輸入給資料夾自動切換），預設不遞迴、`--recursive` 可連子資料夾。
- 索引穩定性：`chunk_id` 新增雜湊模式（`--id-mode hash`），預設仍是連號（`sequential`），向下相容。
- HEIC／HEIF 圖片：頂層獨立輸入格式與 HTML 內嵌圖片兩個入口都要支援；切片細緻度維持「整張圖一塊」，與既有 png／jpg 內嵌圖片 OCR 行為一致，不因文字長短而再依語意細切。
- OCR 強化範圍：維持本地開源 Tesseract 引擎不換（沿用最初的對焦結論），只強化前處理與版面切割模式挑選，不引入需要網路／API 金鑰的視覺模型方案；png／jpg／jpeg 補齊頂層獨立輸入格式，跟 HEIC 共用同一套邏輯。
- v1.6 強化方向：在不引入視覺模型的前提下，經評估後選定圖示區域遮罩與局部裁切放大兩個方向（另有領域詞彙表校正方向，屬於內容層而非引擎層，尚未排入本版，留待後續視需求另立版本）。實測後如實記錄：對本次測試集效果有限，因主要誤差來源是字元本身在小尺寸下被誤讀，不是圖示與文字框體融合；此強化保留是因為對「圖示與文字確實融合」的其他圖片仍有意義，且不會讓已經正確的內容變差。

若之後使用者要切換策略（例如改固定 token 數、改多檔輸出、真的要接視覺模型做 OCR），視為新的對焦結果，更新此區塊並調整 `run.py` 參數或 `build_markdown.py` 輸出邏輯，不需整支重寫。

## 回歸測試

```bash
python tests/test_chunker.py -v
python tests/test_run_batch.py -v
python tests/test_extract_image_standalone.py -v
python tests/test_extract_image_ocr.py -v
python tests/test_extract_image_v16.py -v
```

`test_chunker.py` 涵蓋句界切分、token 估算、語意細切（不破句、不丟資料）、標題階層堆疊、chunk_id 連號與雜湊兩種模式（含內容不變時跨重切片穩定性）、頁碼範圍追蹤。`test_run_batch.py` 涵蓋批次模式的檔案篩選（遞迴／不遞迴）與端到端流程（多檔輸出、單檔失敗不中斷整批）。`test_extract_image_standalone.py` 涵蓋 png／jpg／jpeg／heic／heif 五種副檔名的分派表註冊、單張圖片強制獨立成塊、OCR／解碼失敗時的能力邊界訊息（用 mock 隔離重相依套件，不需真的安裝 pillow-heif／Tesseract 也能跑）。`test_extract_image_ocr.py` 涵蓋 v1.5 的前處理幾何邏輯（小圖放大、大圖不動、放大倍率上限）與多 PSM 信心分數挑選邏輯（用 mock 隔離 Tesseract 本體呼叫，驗證「有沒有真的照信心分數挑」）。`test_extract_image_v16.py` 涵蓋圖示候選判斷（尺寸與信心分數雙條件，避免誤傷小型真實文字）、背景色取樣與遮罩（用真的 PIL 圖片測像素結果）、版面重建（改用 Tesseract 原生 `block_num`／`par_num`／`line_num` 分行，含多欄並排情境的回歸測試）、局部裁切放大的信心分數門檻與最小改善幅度（用 mock 隔離 Tesseract 本體，驗證「有沒有真的照門檻決定要不要採用」）。真實解碼＋辨識效果已在裝好相依套件的環境人工端到端驗證過，v1.6 兩道強化也已用三張真實問題截圖實測比對 v1.5／v1.6 差異（結果誠實記錄於上方版號戳記，效果有限但不會讓已正確內容變差）。改動 `chunker.py`／`run.py`／`extract.py`／`extract_image.py` 後務必重跑，全綠才算沒踩到既有契約。

## 交付前檢查清單

1. [ ] `tests/test_chunker.py`／`test_run_batch.py`／`test_extract_image_standalone.py`／`test_extract_image_ocr.py`／`test_extract_image_v16.py` 全綠。
2. [ ] 對實際輸入檔跑過 `run.py`，確認 `section_path` 與頁碼／時間戳合理。
3. [ ] 確認沒有切片在句子中間被硬切斷。
4. [ ] 若輸入含掃描版 PDF／.doc／.mp4／圖片，確認能力邊界訊息有正確顯示而非靜默失敗。
5. [ ] 含圖片 OCR 的輸入，建議抽樣比對原圖與辨識結果，確認可讀性符合預期。
6. [ ] 輸出檔已用 `present_files` 交給使用者。
7. [ ] 交付後問使用者是否滿意，粒度需要更細或更粗都可以調整 `--min`／`--max` 重跑。
