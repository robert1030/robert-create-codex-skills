# 切片 frontmatter／JSONL 欄位定義

Markdown（`--format md`）與 JSONL（`--format jsonl`）共用同一套欄位，只是承載方式不同：Markdown 是每片一份 YAML frontmatter，JSONL 是每行一個扁平 JSON 物件（額外多帶 `chunk_strategy` 欄位，方便單看一行就知道切片策略，不用回頭翻文件層級總覽）。

## 文件層級（檔首，僅 Markdown 有）

| 欄位 | 說明 |
|---|---|
| `doc_source_file` | 來源檔名 |
| `doc_source_type` | 來源格式（pdf／docx／doc／html／xml／csv／md／txt／mp4） |
| `chunk_strategy` | 切片策略代號，固定為 `hybrid-heading-then-semantic` |
| `total_chunks` | 本檔總切片數 |
| `generated_at` | 產生時間（ISO 8601） |

## 切片層級（每片）

| 欄位 | 說明 |
|---|---|
| `chunk_id` | 四位數連號，例如 `"0001"` |
| `source_file` | 來源檔名（與文件層級一致） |
| `source_type` | 來源格式 |
| `section_path` | 標題階層路徑，以 ` > ` 串接，例如 `"第一章 > 1.2 背景"` |
| `section_level` | 該切片所屬最深標題的階層數（1 為最高階） |
| `char_count` | 切片正文字元數 |
| `token_estimate` | 粗估 token 數（中日韓逐字計＋英數空白斷詞，非精確分詞器計數） |
| `page_range` | 僅 PDF 有值，格式 `"起始頁-結束頁"` |
| `timestamp_range` | 僅 MP4 有值，格式 `"HH:MM:SS-HH:MM:SS"` |
| `image_path` | HTML 內嵌圖片切片、或圖片頂層獨立輸入切片才有值。前者為圖片相對於來源 HTML 檔案的路徑（保留原始 `src` 寫法，含子目錄，例如 `"assets/sub/diagram1.png"`）；後者為來源圖片檔案本身的檔名（例如 `"photo.heic"`、`"screenshot.jpg"`） |

## 設計考量

- 每片都自帶 `section_path`，即使切片被單獨抽出（例如塞進向量資料庫後只取出單片），仍能還原它在原文件中的脈絡位置，不需要回查整份原文。
- `page_range`／`timestamp_range` 是回溯原始來源（翻到第幾頁、影片第幾分幾秒）的依據，方便做引用標註或人工覆核。
- CSV 的每一列固定獨立成一塊，`section_path` 會是欄位清單（例如 `"資料表（欄位：姓名、部門、到職日）"`），方便辨識來源表格結構。
