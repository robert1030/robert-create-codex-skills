#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""bootstrap.py：透明自動安裝相依套件（房規六）。
每個 ensure_* 只在對應格式真的被用到時才呼叫，裝過就跳過，
失敗時不靜默吞掉，會往外拋出讓上層做「能力邊界」降級處理。
務必在對應 import 之前呼叫 ensure_*。
"""
import importlib
import shutil
import subprocess
import sys


def _pip(*pkgs):
    subprocess.run(
        [sys.executable, '-m', 'pip', 'install', '--break-system-packages', '-q', *pkgs],
        check=True,
    )


def _have(mod: str) -> bool:
    try:
        importlib.import_module(mod)
        return True
    except ImportError:
        return False


def ensure_pdf():
    if not _have('fitz'):
        _pip('pymupdf')


def ensure_docx():
    if not _have('docx'):
        _pip('python-docx')


def ensure_html():
    if not _have('bs4'):
        _pip('beautifulsoup4', 'lxml')


def ensure_csv():
    if not _have('pandas'):
        _pip('pandas')


def ensure_doc_legacy():
    """.doc 舊版二進位格式：優先找系統 LibreOffice（soffice）做轉檔。
    這裡不裝 LibreOffice（屬系統套件、體積大），只偵測是否存在。
    """
    return shutil.which('soffice') is not None or shutil.which('libreoffice') is not None


def ensure_audio_tools():
    """MP4 語音轉文字所需：ffmpeg（系統指令）＋ faster-whisper（Python 套件）。
    回傳 (ffmpeg_ok, whisper_ok)；任一為 False 時，呼叫端應走降級階梯。
    """
    ffmpeg_ok = shutil.which('ffmpeg') is not None
    whisper_ok = True
    if not _have('faster_whisper'):
        try:
            _pip('faster-whisper')
        except subprocess.CalledProcessError:
            whisper_ok = False
    return ffmpeg_ok, whisper_ok


def ensure_ocr():
    """HTML 內嵌 PNG／JPG 圖片 OCR 所需：Tesseract（系統指令，含繁中語言包）
    ＋ pytesseract／Pillow（Python 套件）。回傳 tesseract 是否可用；
    不可用時呼叫端應走降級階梯，不假裝辨識成功。
    """
    if not _have('pytesseract'):
        try:
            _pip('pytesseract', 'pillow')
        except subprocess.CalledProcessError:
            return False
    if shutil.which('tesseract') is None:
        try:
            subprocess.run(['apt-get', 'update', '-qq'], check=True, capture_output=True)
            subprocess.run(
                ['apt-get', 'install', '-y', '-qq', 'tesseract-ocr', 'tesseract-ocr-chi-tra'],
                check=True, capture_output=True,
            )
        except subprocess.CalledProcessError:
            return False
    return shutil.which('tesseract') is not None


def ensure_heic():
    """HEIC／HEIF 圖片解碼所需：pillow-heif（純 Python wheel，內含 libheif，
    不需要另外裝系統套件）。回傳是否可用；不可用時呼叫端應走降級階梯，
    不假裝解碼成功。注意：這裡只負責「解碼成可讀的圖片」，實際 OCR 仍走
    `ensure_ocr()` 的 Tesseract，兩者互相獨立、缺一不影響另一個格式。
    """
    if _have('pillow_heif'):
        return True
    try:
        _pip('pillow-heif')
        return True
    except subprocess.CalledProcessError:
        return False


def ensure_tiktoken():
    """精確 token 計數所需：tiktoken。回傳是否安裝成功；
    失敗時呼叫端應降級回粗估 estimate_tokens()，不讓整支流程中斷。
    """
    if _have('tiktoken'):
        return True
    try:
        _pip('tiktoken')
        return True
    except subprocess.CalledProcessError:
        return False
