#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_jsonl.py — 把 Chunk 清單組成 JSONL（每行一筆切片），
方便直接餵進向量資料庫／embedding pipeline，不需要再自己解析 Markdown
frontmatter。與 build_markdown.py 並存，互不取代。
"""
import json
from typing import List

from chunker import Chunk


def build_jsonl(
    chunks: List[Chunk],
    source_file: str,
    source_type: str,
    chunk_strategy: str = 'hybrid-heading-then-semantic',
) -> str:
    lines = []
    for c in chunks:
        record = {
            'chunk_id': c.chunk_id,
            'source_file': source_file,
            'source_type': source_type,
            'chunk_strategy': chunk_strategy,
            'section_path': c.section_path,
            'section_level': c.section_level,
            'char_count': c.char_count,
            'token_estimate': c.token_estimate,
            'text': c.text,
        }
        if c.page_range:
            record['page_range'] = c.page_range
        if c.timestamp_range:
            record['timestamp_range'] = c.timestamp_range
        if c.image_path:
            record['image_path'] = c.image_path
        lines.append(json.dumps(record, ensure_ascii=False))
    return '\n'.join(lines) + ('\n' if lines else '')
