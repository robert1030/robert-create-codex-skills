#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_markdown.py — 把 Chunk 清單組成單一 Markdown 交付檔。
格式：檔首一份「文件層級 frontmatter」總覽，之後每個切片各自一份
frontmatter（chunk_id／source_file／source_type／section_path／
section_level／char_count／token_estimate／page_range／timestamp_range）
＋切片正文，彼此用 `---` 分隔，方便程式以 YAML 多文件方式解析。
"""
import datetime
from typing import List

from chunker import Chunk


def _yaml_escape(s: str) -> str:
    s = s.replace('"', '\\"')
    return f'"{s}"'


def build_markdown(
    chunks: List[Chunk],
    source_file: str,
    source_type: str,
    chunk_strategy: str = 'hybrid-heading-then-semantic',
) -> str:
    now = datetime.datetime.now().isoformat(timespec='seconds')
    lines = []
    lines.append('---')
    lines.append(f'doc_source_file: {_yaml_escape(source_file)}')
    lines.append(f'doc_source_type: {source_type}')
    lines.append(f'chunk_strategy: {chunk_strategy}')
    lines.append(f'total_chunks: {len(chunks)}')
    lines.append(f'generated_at: {now}')
    lines.append('---')
    lines.append('')

    for c in chunks:
        lines.append('---')
        lines.append(f'chunk_id: "{c.chunk_id}"')
        lines.append(f'source_file: {_yaml_escape(source_file)}')
        lines.append(f'source_type: {source_type}')
        lines.append(f'section_path: {_yaml_escape(c.section_path)}')
        lines.append(f'section_level: {c.section_level}')
        lines.append(f'char_count: {c.char_count}')
        lines.append(f'token_estimate: {c.token_estimate}')
        if c.page_range:
            lines.append(f'page_range: "{c.page_range}"')
        if c.timestamp_range:
            lines.append(f'timestamp_range: "{c.timestamp_range}"')
        if c.image_path:
            lines.append(f'image_path: {_yaml_escape(c.image_path)}')
        lines.append('---')
        lines.append(c.text)
        lines.append('')

    return '\n'.join(lines)
