#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
chunker.py：RAG 切片引擎核心（混合策略）。

策略：先依「結構區塊」（extract.py 給的 blocks，含 heading／paragraph／table_row／
audio_segment 等型別）切出區段，區段以標題階層（或 CSV 列、影片時間軸）為界；
區段內再依語意（句界）細切，逼近目標字元數區間，盡量不在句子中間斷開。

本檔不依賴任何重相依套件（不 import pymupdf／docx／whisper 等），可獨立單元測試。
"""
import hashlib
import re
from dataclasses import dataclass, field
from typing import List, Optional

# 句界：中文句號、問號、驚嘆號、分號、換行；英文句點＋空白＋大寫字母視為句界但保守處理。
_SENT_END = re.compile(r'(?<=[。！？；])|(?<=\n)')


def split_sentences(text: str) -> List[str]:
    """把一段文字切成句子清單（保留標點，丟掉純空白片段）。"""
    if not text:
        return []
    parts = _SENT_END.split(text)
    out = []
    for p in parts:
        p = p.strip('\n')
        if p.strip():
            out.append(p)
    return out


def estimate_tokens(text: str) -> int:
    """粗估 token 數：中日韓文字每字算一個 token，其餘以空白分詞估算（英數）。"""
    cjk = re.findall(r'[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]', text)
    rest = re.sub(r'[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]', ' ', text)
    words = [w for w in rest.split() if w.strip()]
    return len(cjk) + len(words)


@dataclass
class Block:
    """結構區塊（由各格式的 extractor 產生）。"""
    type: str  # 'heading' | 'paragraph' | 'table_row' | 'audio_segment' | 'image_ocr'
    text: str
    level: int = 0  # heading 用，1 為最高階
    page: Optional[int] = None
    timestamp: Optional[str] = None  # 影片用，例如 "00:01:23-00:01:45"
    image_path: Optional[str] = None  # image_ocr 用，圖片的相對路徑（相對於來源檔案）


@dataclass
class Chunk:
    chunk_id: str
    section_path: str
    section_level: int
    text: str
    char_count: int
    token_estimate: int
    page_range: Optional[str] = None
    timestamp_range: Optional[str] = None
    image_path: Optional[str] = None


def _new_section_path(stack: List[str], heading_text: str, level: int) -> List[str]:
    """維護標題堆疊：遇到新標題時，截斷到對應階層再附加。"""
    stack = stack[: max(level - 1, 0)]
    stack.append(heading_text)
    return stack


def semantic_chunk(
    sentences: List[str],
    target_min: int = 150,
    target_max: int = 400,
) -> List[str]:
    """把句子清單依語意細切，逼近 [target_min, target_max] 字元區間。
    單一句子若已超過 target_max，獨立成一塊（不強制斷句，避免破壞語意）。
    """
    chunks = []
    buf = ''
    for sent in sentences:
        candidate = buf + sent
        if len(candidate) <= target_max:
            buf = candidate
            if len(buf) >= target_min:
                # 已達下限，但先看下一句是否仍能塞進上限，採貪婪法在迴圈內繼續累積
                continue
        else:
            if buf:
                chunks.append(buf)
            if len(sent) > target_max:
                # 單句過長：保留完整句子，不切碎語意單位
                chunks.append(sent)
                buf = ''
            else:
                buf = sent
    if buf:
        chunks.append(buf)
    return chunks


def _hash_chunk_id(source_file: str, section_path: str, text: str) -> str:
    """內容雜湊式 chunk_id：以來源檔名＋標題路徑＋正文算 sha1，取前十二碼十六進位。

    設計目的：同一份原文重新切片時，只要某片的（來源檔、所屬標題路徑、正文）
    三者都沒變，這片的 chunk_id 就不會變，不受其他片增刪、整批重新編號影響，
    方便向量資料庫做增量索引（未變的片可跳過重新 embedding）。
    """
    key = f'{source_file}|{section_path}|{text}'.encode('utf-8')
    return hashlib.sha1(key).hexdigest()[:12]


def build_chunks(
    blocks: List[Block],
    source_file: str,
    source_type: str,
    target_min: int = 150,
    target_max: int = 400,
    token_fn=None,
    id_mode: str = 'sequential',
) -> List[Chunk]:
    """主流程：標題優先分區 → 區內語意細切 → 產生帶 metadata 的 Chunk 清單。

    token_fn：可選的 token 計數函式 text -> int。不傳則維持原本的粗估
    estimate_tokens()（向下相容，行為不變）；要用精確分詞器（如 tiktoken）
    時由呼叫端傳入，不影響預設行為與既有測試。

    id_mode：chunk_id 產生方式。'sequential'（預設，向下相容，行為與 v1.2
    以前完全相同）＝四位數連號 "0001"、"0002"……；'hash'＝內容雜湊
    （見 `_hash_chunk_id`），同內容重新切片時 chunk_id 保持穩定，方便增量索引。
    不傳一律沿用 'sequential'，既有呼叫端與回歸測試不受影響。
    """
    if id_mode not in ('sequential', 'hash'):
        raise ValueError(f"id_mode 必須是 'sequential' 或 'hash'，收到：{id_mode!r}")
    _count = token_fn or estimate_tokens
    chunks: List[Chunk] = []
    heading_stack: List[str] = []
    cur_level = 0
    cur_sentences: List[str] = []
    cur_pages: List[int] = []
    cur_ts: List[str] = []
    cur_image_path: Optional[str] = None

    def flush():
        nonlocal cur_sentences, cur_pages, cur_ts, cur_image_path
        if not cur_sentences:
            return
        section_path = ' > '.join(heading_stack) if heading_stack else '（無標題區）'
        pieces = semantic_chunk(cur_sentences, target_min, target_max)
        for piece in pieces:
            if id_mode == 'hash':
                cid = _hash_chunk_id(source_file, section_path, piece)
            else:
                cid = f'{len(chunks) + 1:04d}'
            page_range = None
            if cur_pages:
                lo, hi = min(cur_pages), max(cur_pages)
                page_range = f'{lo}-{hi}'
            ts_range = None
            if cur_ts:
                ts_range = f'{cur_ts[0].split("-")[0]}-{cur_ts[-1].split("-")[-1]}'
            chunks.append(
                Chunk(
                    chunk_id=cid,
                    section_path=section_path,
                    section_level=max(cur_level, 1),
                    text=piece,
                    char_count=len(piece),
                    token_estimate=_count(piece),
                    page_range=page_range,
                    timestamp_range=ts_range,
                    image_path=cur_image_path,
                )
            )
        cur_sentences = []
        cur_pages = []
        cur_ts = []
        cur_image_path = None

    for blk in blocks:
        if blk.type == 'heading':
            flush()
            heading_stack = _new_section_path(heading_stack, blk.text.strip(), blk.level or 1)
            cur_level = blk.level or 1
        elif blk.type == 'table_row':
            # 表格列是天生的原子單位（最高細緻度要求）：每列獨立成一塊，
            # 不與其他列合併、也不被字元區間門檻吃掉。
            flush()
            cur_sentences = [blk.text]
            if blk.page is not None:
                cur_pages.append(blk.page)
            flush()
        elif blk.type == 'image_ocr':
            # 內嵌圖片同樣是天生的原子單位：每張圖獨立成一塊，
            # 並把圖片相對路徑帶進 chunk metadata，方便回溯來源。
            flush()
            cur_sentences = [blk.text]
            cur_image_path = blk.image_path
            if blk.page is not None:
                cur_pages.append(blk.page)
            flush()
        elif blk.type in ('paragraph', 'audio_segment'):
            sents = split_sentences(blk.text)
            cur_sentences.extend(sents)
            if blk.page is not None:
                cur_pages.append(blk.page)
            if blk.timestamp is not None:
                cur_ts.append(blk.timestamp)
        else:
            # 未知型別，當作段落處理，不丟資料
            cur_sentences.extend(split_sentences(blk.text))
    flush()
    return chunks
