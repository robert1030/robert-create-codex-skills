#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""extract.py：各格式 → 結構區塊（Block）清單。
能力邊界（先講清楚，別硬做）：
  - .doc（舊版二進位）：需系統有 LibreOffice／soffice 才能轉檔，沒有就明確降級告知，
    不嘗試用不可靠的方式硬讀二進位內容。
  - 掃描版 PDF（純圖片無文字層）：本引擎不含 OCR，會回傳極少量文字並提示使用者，
    不會假裝抽到完整內容。
  - .xml：沒有固定 schema 時，以標籤階層當作虛擬標題路徑，是啟發式推測，
    不保證對應到語意章節，建議使用者確認後再用於正式 RAG 索引。
  - .mp4：語音轉文字依賴本機 ffmpeg＋faster-whisper 模型權重，若執行環境無法下載
    模型權重（離線或網路白名單限制），會降級為「只保留檔案中繼資料」並明確標示。
  - .png／.jpg／.jpeg／.heic／.heif（頂層獨立輸入）：仰賴 Tesseract OCR，HEIC／HEIF
    另外仰賴 pillow-heif 解碼；相依套件缺一即明確降級告知，不嘗試硬讀；OCR 準確度
    限制與 v1.5 起的強化前處理說明見 `extract_image.py` 的能力邊界段落。
"""
import csv
import os
import re
import sys
from typing import List

sys.path.insert(0, os.path.dirname(__file__))
import bootstrap  # noqa: E402
from chunker import Block  # noqa: E402


# ---------------------------------------------------------------- Markdown
def extract_markdown(path: str) -> List[Block]:
    blocks: List[Block] = []
    with open(path, encoding='utf-8') as f:
        text = f.read()
    para_buf = []

    def flush_para():
        if para_buf:
            joined = '\n'.join(para_buf).strip()
            if joined:
                blocks.append(Block(type='paragraph', text=joined))
            para_buf.clear()

    for line in text.splitlines():
        m = re.match(r'^(#{1,6})\s+(.*)', line)
        if m:
            flush_para()
            level = len(m.group(1))
            blocks.append(Block(type='heading', text=m.group(2).strip(), level=level))
        elif line.strip() == '':
            flush_para()
        else:
            para_buf.append(line)
    flush_para()
    return blocks


# ---------------------------------------------------------------- 純文字
def extract_txt(path: str) -> List[Block]:
    with open(path, encoding='utf-8', errors='replace') as f:
        text = f.read()
    paras = [p.strip() for p in re.split(r'\n\s*\n', text) if p.strip()]
    return [Block(type='paragraph', text=p) for p in paras]


# ---------------------------------------------------------------- HTML
def extract_html(path: str) -> List[Block]:
    bootstrap.ensure_html()
    from bs4 import BeautifulSoup
    from urllib.parse import unquote, urlparse

    with open(path, encoding='utf-8', errors='replace') as f:
        soup = BeautifulSoup(f.read(), 'lxml')
    for tag in soup(['script', 'style']):
        tag.decompose()

    base_dir = os.path.dirname(os.path.abspath(path))
    ocr_ready = None  # 延後到真的遇到圖片才偵測／安裝，避免無圖 HTML 白跑一趟

    blocks: List[Block] = []
    for el in soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'li', 'td', 'img']):
        if el.name == 'img':
            src = el.get('src', '').strip()
            if not src:
                continue
            parsed = urlparse(src)
            if parsed.scheme in ('http', 'https', 'data'):
                blocks.append(
                    Block(
                        type='image_ocr',
                        text=f'【能力邊界】此圖片為外部連結或內嵌資料（{src[:60]}…），不下載外部圖片做 OCR，已略過。',
                        image_path=src,
                    )
                )
                continue
            # 相對路徑解析，支援子目錄（如 images/a.png、./assets/sub/b.jpg）
            rel_path = unquote(src)
            abs_path = os.path.normpath(os.path.join(base_dir, rel_path))
            if ocr_ready is None:
                ocr_ready = bootstrap.ensure_ocr()
            if not ocr_ready:
                blocks.append(
                    Block(
                        type='image_ocr',
                        text='【能力邊界】此環境缺少可用的 Tesseract OCR，無法辨識此內嵌圖片文字，已降級為只保留圖片路徑。',
                        image_path=rel_path,
                    )
                )
                continue
            if not os.path.isfile(abs_path):
                blocks.append(
                    Block(
                        type='image_ocr',
                        text=f'【能力邊界】找不到內嵌圖片檔案（{rel_path}），可能路徑有誤或檔案未隨 HTML 一併提供，已略過 OCR。',
                        image_path=rel_path,
                    )
                )
                continue
            from extract_image import ocr_image

            try:
                text = ocr_image(abs_path)
            except Exception as e:  # noqa: BLE001：OCR 失敗要明確告知，不靜默吞掉
                text = f'【能力邊界】OCR 執行失敗（{e}），已略過此圖片內容辨識。'
            if not text:
                text = '（此圖片 OCR 辨識不到文字，可能為純視覺內容，無文字或文字過於模糊）'
            blocks.append(Block(type='image_ocr', text=text, image_path=rel_path))
            continue

        txt = el.get_text(strip=True)
        if not txt:
            continue
        if el.name.startswith('h') and el.name[1:].isdigit():
            blocks.append(Block(type='heading', text=txt, level=int(el.name[1])))
        else:
            blocks.append(Block(type='paragraph', text=txt))
    return blocks


# ---------------------------------------------------------------- XML（啟發式）
def extract_xml(path: str) -> List[Block]:
    import xml.etree.ElementTree as ET

    tree = ET.parse(path)
    root = tree.getroot()
    blocks: List[Block] = []

    def walk(elem, depth):
        tag = elem.tag.split('}')[-1]  # 去掉 namespace
        text = (elem.text or '').strip()
        if depth <= 2 and (text or list(elem)):
            blocks.append(Block(type='heading', text=tag, level=min(depth + 1, 6)))
        if text:
            blocks.append(Block(type='paragraph', text=text))
        for child in elem:
            walk(child, depth + 1)

    walk(root, 0)
    return blocks


# ---------------------------------------------------------------- CSV
def extract_csv(path: str) -> List[Block]:
    blocks: List[Block] = []
    with open(path, encoding='utf-8-sig', errors='replace', newline='') as f:
        reader = csv.reader(f)
        rows = list(reader)
    if not rows:
        return blocks
    header = rows[0]
    blocks.append(Block(type='heading', text=f'資料表（欄位：{"、".join(header)}）', level=1))
    for i, row in enumerate(rows[1:], 1):
        pairs = [f'{h}：{v}' for h, v in zip(header, row)]
        blocks.append(Block(type='table_row', text=f'第 {i} 列：' + '；'.join(pairs)))
    return blocks


# ---------------------------------------------------------------- DOCX
def extract_docx(path: str) -> List[Block]:
    bootstrap.ensure_docx()
    import docx

    doc = docx.Document(path)
    blocks: List[Block] = []
    for p in doc.paragraphs:
        text = p.text.strip()
        if not text:
            continue
        style = (p.style.name or '') if p.style else ''
        m = re.match(r'Heading (\d)', style)
        if m:
            blocks.append(Block(type='heading', text=text, level=int(m.group(1))))
        else:
            blocks.append(Block(type='paragraph', text=text))
    return blocks


# ---------------------------------------------------------------- DOC（舊版二進位）
def extract_doc_legacy(path: str) -> List[Block]:
    import subprocess
    import tempfile

    if not bootstrap.ensure_doc_legacy():
        return [
            Block(
                type='paragraph',
                text=(
                    '【能力邊界】此環境找不到 LibreOffice（soffice），無法安全轉換 .doc '
                    '（舊版二進位格式）。建議：在本機用 Word／LibreOffice 另存為 .docx 或 '
                    '.pdf 後再切片，以避免猜測性硬讀二進位造成內容失真。'
                ),
            )
        ]
    with tempfile.TemporaryDirectory() as tmp:
        subprocess.run(
            ['soffice', '--headless', '--convert-to', 'docx', '--outdir', tmp, path],
            check=True, capture_output=True,
        )
        base = os.path.splitext(os.path.basename(path))[0]
        converted = os.path.join(tmp, base + '.docx')
        return extract_docx(converted)


# ---------------------------------------------------------------- PDF
def extract_pdf(path: str) -> List[Block]:
    bootstrap.ensure_pdf()
    import fitz  # pymupdf

    doc = fitz.open(path)

    # 書籤（TOC）優先：文件有做書籤就用書籤當標題階層，比字級啟發式準確。
    raw_toc = doc.get_toc(simple=False)
    headings_by_page = {}
    if raw_toc:
        for entry in raw_toc:
            lvl, title, page = entry[0], entry[1], entry[2]
            dest = entry[3] if len(entry) > 3 else None
            y = -1.0
            if isinstance(dest, dict):
                pt = dest.get('to')
                if pt is not None:
                    y = float(pt.y) if hasattr(pt, 'y') else float(pt[1])
            headings_by_page.setdefault(page, []).append((y, lvl, title.strip()))
        for page in headings_by_page:
            headings_by_page[page].sort(key=lambda t: t[0])
    use_toc = bool(headings_by_page)

    blocks: List[Block] = []
    sizes = []
    page_items = []  # (page_no, [(y, size, text), ...])
    for page in doc:
        page_no = page.number + 1
        items = []
        d = page.get_text('dict')
        for blk in d.get('blocks', []):
            for line in blk.get('lines', []):
                y0 = line.get('bbox', [0, 0, 0, 0])[1]
                for span in line.get('spans', []):
                    t = span.get('text', '').strip()
                    if t:
                        sizes.append(span['size'])
                        items.append((y0, span['size'], t))
        page_items.append((page_no, items))

    if not sizes:
        return [
            Block(
                type='paragraph',
                text='【能力邊界】這個 PDF 偵測不到文字層，可能是掃描影像版（無 OCR），本引擎未內建 OCR，無法可靠抽取內容。',
            )
        ]

    body_size = sorted(sizes)[len(sizes) // 2]  # 字級啟發式只在沒有書籤時當備援

    for page_no, items in page_items:
        if use_toc:
            # 把該頁的書籤標題與內文行依 y 座標合併排序，書籤優先當標題，
            # 內文一律當段落（不再用字級猜標題，避免跟書籤打架）。
            heading_titles = {title.strip() for (_, _, title) in headings_by_page.get(page_no, [])}
            merged = [(y, 'heading', title, lvl) for (y, lvl, title) in headings_by_page.get(page_no, [])]
            merged += [(y, 'paragraph', text, None) for (y, size, text) in items]
            merged.sort(key=lambda t: t[0])
            seen_heading_text = set()
            for y, kind, text, lvl in merged:
                if kind == 'heading':
                    blocks.append(Block(type='heading', text=text, level=lvl or 1, page=page_no))
                else:
                    # 視覺上的標題文字本身（與書籤標題完全相同、且尚未當段落用過）
                    # 不重複收進內文，避免標題在切片正文裡出現兩次。
                    stripped = text.strip()
                    if stripped in heading_titles and stripped not in seen_heading_text:
                        seen_heading_text.add(stripped)
                        continue
                    blocks.append(Block(type='paragraph', text=text, page=page_no))
        else:
            for y, size, text in items:
                if size >= body_size * 1.2:
                    level = 1 if size >= body_size * 1.6 else 2
                    blocks.append(Block(type='heading', text=text, level=level, page=page_no))
                else:
                    blocks.append(Block(type='paragraph', text=text, page=page_no))
    return blocks


# ---------------------------------------------------------------- MP4
def extract_mp4(path: str) -> List[Block]:
    import subprocess
    import tempfile

    ffmpeg_ok, whisper_ok = bootstrap.ensure_audio_tools()
    if not ffmpeg_ok or not whisper_ok:
        size = os.path.getsize(path)
        return [
            Block(
                type='paragraph',
                text=(
                    f'【能力邊界】此環境缺少 ffmpeg 或 faster-whisper（或模型權重下載被網路'
                    f'白名單擋下），無法執行語音轉文字。已降級為只保留檔案中繼資料：'
                    f'檔名＝{os.path.basename(path)}，檔案大小＝{size} bytes。'
                    f'建議在可連網下載 Whisper 模型的本機環境執行本 skill 的 MP4 流程，'
                    f'或自行轉好逐字稿（.srt／.vtt／.txt）後改用對應格式輸入。'
                ),
            )
        ]

    from faster_whisper import WhisperModel

    with tempfile.TemporaryDirectory() as tmp:
        wav_path = os.path.join(tmp, 'audio.wav')
        subprocess.run(
            ['ffmpeg', '-y', '-i', path, '-ar', '16000', '-ac', '1', wav_path],
            check=True, capture_output=True,
        )
        model = WhisperModel('small', device='cpu', compute_type='int8')
        segments, _info = model.transcribe(wav_path, language=None)
        blocks: List[Block] = [Block(type='heading', text='語音轉文字逐字稿', level=1)]
        for seg in segments:
            ts = f'{_fmt_ts(seg.start)}-{_fmt_ts(seg.end)}'
            text = seg.text.strip()
            if text:
                blocks.append(Block(type='audio_segment', text=text, timestamp=ts))
        return blocks


def _fmt_ts(seconds: float) -> str:
    h, rem = divmod(int(seconds), 3600)
    m, s = divmod(rem, 60)
    return f'{h:02d}:{m:02d}:{s:02d}'


# ---------------------------------------------------------------- 圖片（頂層獨立輸入：PNG／JPG／JPEG／HEIC／HEIF）
def extract_image_standalone(path: str) -> List[Block]:
    """單張圖片檔（png／jpg／jpeg／heic／heif）當成獨立輸入文件：整張圖的
    OCR 文字強制獨立成一塊，行為與 HTML 內嵌圖片 OCR 一致（不論文字長短
    都不再依語意細切），切片帶 image_path（此處為檔名本身，供回溯來源）。
    """
    from extract_image import ocr_image

    bootstrap.ensure_ocr()
    filename = os.path.basename(path)
    try:
        text = ocr_image(path)
    except Exception as e:  # noqa: BLE001：OCR／解碼失敗要明確告知，不靜默吞掉
        text = f'【能力邊界】圖片處理失敗（{e}），已略過此圖片內容辨識。'
    if not text:
        text = '（此圖片 OCR 辨識不到文字，可能為純視覺內容，無文字或文字過於模糊）'
    return [Block(type='image_ocr', text=text, image_path=filename)]


# ---------------------------------------------------------------- 分派
_DISPATCH = {
    '.md': extract_markdown,
    '.markdown': extract_markdown,
    '.txt': extract_txt,
    '.html': extract_html,
    '.htm': extract_html,
    '.xml': extract_xml,
    '.csv': extract_csv,
    '.docx': extract_docx,
    '.doc': extract_doc_legacy,
    '.pdf': extract_pdf,
    '.mp4': extract_mp4,
    '.heic': extract_image_standalone,
    '.heif': extract_image_standalone,
    '.png': extract_image_standalone,
    '.jpg': extract_image_standalone,
    '.jpeg': extract_image_standalone,
}


def extract(path: str) -> List[Block]:
    ext = os.path.splitext(path)[1].lower()
    fn = _DISPATCH.get(ext)
    if fn is None:
        raise ValueError(f'不支援的格式：{ext}（支援：{", ".join(sorted(_DISPATCH))}）')
    return fn(path)


def source_type_of(path: str) -> str:
    return os.path.splitext(path)[1].lower().lstrip('.')
