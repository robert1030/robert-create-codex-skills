#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""extract_image.py：圖片 OCR（PNG／JPG／HEIC／HEIF）。
能力邊界（先講清楚，別硬做）：
  - 用 Tesseract 做傳統 OCR，吃文字型圖片（截圖、掃描頁、含文字的圖表標籤）效果好；
    對純視覺內容（照片、無文字的示意圖、手繪圖）OCR 不出東西是預期行為，不是錯誤。
  - v1.5 起：小尺寸圖片（長邊低於門檻）會先放大再辨識，並自動比較多種版面切割模式
    （PSM）取信心分數最高者，大幅改善小字截圖（如流程圖、對話框、表格截圖）的準確度。
  - v1.6 起：疊加兩道以信心分數為依據的強化，仍是傳統 OCR，不是視覺模型，這是刻意的
    定案（見 SKILL.md 對焦記錄），對「圖示緊貼文字」「工具列圖示密集」這類情境有實測
    改善，但遇到極低解析度、原始筆畫本身已缺失的情況仍無法突破，這是傳統 OCR 的物理
    限制，不是強化不夠。正式用於 RAG 索引前建議抽樣人工核對；不確定的辨識結果不會被
    美化或腦補成看似合理的文字。
    ① 圖示區域遮罩：依尺寸與信心分數啟發式判斷「圖示污染候選」框體，OCR 前塗成局部
      背景色再重跑，避免圖示像素跟旁邊真實文字的字元邊界黏在一起造成整詞誤判。這是
      尺寸與信心分數的啟發式判斷，不是真正的物件偵測，深色主題介面或圖示恰好落在
      文字尺寸區間時可能誤判，也可能誤蓋到極小的真實文字，正式使用前建議抽樣核對。
    ② 局部裁切放大：對信心分數仍偏低的個別詞，裁切該詞所在區域並用更高倍率單獨放大
      重辨識，只有新結果信心分數確實更高時才採用（驗證即閘門，不是重跑了就比較好），
      否則保留原辨識結果。對「字太小但輪廓還在」的情況有幫助，對原始像素本身已經
      不足以構成一個字的情況沒有用，這是原始圖片解析度的先天限制。
    上述兩道強化預設開啟（`ocr_image(..., enhance=True)`），關閉時完全等同 v1.5 行為，
    供除錯或效能比較之用；即使強化路徑因故辨識不出任何文字，也會退回 v1.5 的整圖
    辨識邏輯，不會讓使用者拿到空白結果。
  - 圖片含旋轉／浮水印疊字等複雜排版不做版面還原，純粹整段文字輸出。
  - HEIC／HEIF（iPhone 常見拍照格式）額外仰賴 pillow-heif 解碼，環境無法安裝時
    會明確拋出例外，由呼叫端降級告知，不嘗試用其他方式硬讀。
"""
import os

_HEIC_EXTS = {'.heic', '.heif'}

# 小圖放大門檻：長邊低於此值才觸發放大（已經夠大的圖片不做多餘處理，避免浪費時間）。
_UPSCALE_TARGET_LONG_SIDE = 1400
# 放大倍率上限：避免對極小的裝飾性圖示做無意義的暴力放大。
_UPSCALE_MAX_SCALE = 6

# 依序嘗試的 Tesseract 版面切割模式（PSM）：
#   6 = 假設整張圖是一塊排版一致的文字（截圖、表格、對話框最常見的情況）
#   3 = 全自動版面分析（預設值，適合複雜排版的完整頁面）
#   4 = 假設是單欄、不同行高可變的文字（部分表格／清單類截圖適用）
# 三種都跑一次，取「詞辨識信心分數平均」最高的一組當最終結果。
_PSM_CANDIDATES = (6, 3, 4)

# 圖示污染候選：框體寬高皆低於此值（像素，相對放大後的圖片）且長寬比接近方形，
# 才會被列入候選；純粹依尺寸還不夠，必須同時信心分數偏低才判定為圖示（見下）。
_ICON_MAX_SIZE = 22
_ICON_ASPECT_MIN = 0.4
_ICON_ASPECT_MAX = 2.5
_ICON_CONF_THRESHOLD = 40

# 局部裁切放大：單詞信心分數低於此值才觸發；裁切時四周留白，放大到目標長邊，
# 放大倍率上限比全圖前處理更高，因為只放大一小塊，計算量可負擔。
_CROP_CONF_THRESHOLD = 55
_CROP_PAD = 6
_CROP_MIN_LONG_SIDE = 200
_CROP_MAX_SCALE = 10
# 最小改善門檻：新信心分數要比原本高出這個幅度才採用，不是「有比較高就換」。
# 這是實測發現的必要防呆：信心分數只反映 Tesseract 對「自己這次猜測」的把握，
# 不代表猜對了，些微的信心提升可能只是換成另一個同樣錯誤、但湊巧信心分數
# 略高的猜測（例如把 cke 換成 cbse，兩個都不是正確的 else，只是後者信心分數
# 高一點），要求較大的改善幅度可以過濾掉這種雜訊換猜。
_CROP_MIN_IMPROVEMENT = 12


def _upscale_if_small(img):
    """長邊低於 `_UPSCALE_TARGET_LONG_SIDE` 才放大，用 LANCZOS 內插；
    已經夠大的圖片原樣返回，不做多餘運算。放大倍率上限 `_UPSCALE_MAX_SCALE`。
    """
    from PIL import Image

    long_side = max(img.width, img.height)
    if long_side >= _UPSCALE_TARGET_LONG_SIDE:
        return img
    scale = min(_UPSCALE_MAX_SCALE, _UPSCALE_TARGET_LONG_SIDE / long_side)
    if scale <= 1:
        return img
    new_size = (max(1, round(img.width * scale)), max(1, round(img.height * scale)))
    return img.resize(new_size, Image.LANCZOS)


def _preprocess_for_ocr(img):
    """OCR 前處理：正規化色彩模式 → 小圖放大 → 灰階 → 自動對比。
    這一路操作會產生新的 PIL Image 物件（`.format` 屬性會變成 None），
    pytesseract 遇到 `.format` 是 None 時會預設當成 PNG 處理，這同時
    也順便解決了 HEIC／HEIF 解碼後格式標記不被 pytesseract 辨識的問題，
    不需要再另外繞路轉存暫存檔。
    """
    from PIL import ImageOps

    img = img.convert('RGB')
    img = _upscale_if_small(img)
    gray = ImageOps.grayscale(img)
    gray = ImageOps.autocontrast(gray)
    return gray


def _ocr_best_effort(img, lang):
    """依序嘗試 `_PSM_CANDIDATES` 幾種版面切割模式，取詞辨識信心分數平均
    最高的一組文字。信心分數來自 Tesseract 自己回報的每個詞辨識信心
    （0～100），不是用文字長短或外觀猜的，符合「驗證即閘門、不靠肉眼」。
    全部模式都辨識不出任何文字時，退回最基本的預設模式再試一次，
    確保至少嘗試過，不會因為前面幾種模式失敗就直接放棄。
    """
    import pytesseract

    best_text, best_conf = '', -1.0
    for psm in _PSM_CANDIDATES:
        config = f'--psm {psm}'
        try:
            data = pytesseract.image_to_data(img, lang=lang, config=config, output_type=pytesseract.Output.DICT)
        except pytesseract.TesseractError:
            continue
        confs = [int(c) for c in data.get('conf', []) if str(c) not in ('-1', '')]
        mean_conf = sum(confs) / len(confs) if confs else -1.0
        has_text = any(w.strip() for w in data.get('text', []))
        if has_text and mean_conf > best_conf:
            best_conf = mean_conf
            best_text = pytesseract.image_to_string(img, lang=lang, config=config)

    if not best_text:
        best_text = pytesseract.image_to_string(img, lang=lang)
    return best_text.strip()


def _get_word_boxes(img, lang, psm):
    """回傳指定 PSM 下的逐詞結構化資料清單，每項含 text／conf／left／top／
    width／height／line_key。只保留有文字內容、且信心分數有效（非 -1）
    的項目，信心分數 -1 通常代表該框其實是空白或版面雜訊，不是真正的詞。

    `line_key` 直接取自 Tesseract 自己的 block_num／par_num／line_num，
    這是它內建版面分析算好的分行結果，對多欄並排的介面截圖（例如左側
    樹狀清單＋右側屬性面板）比自己用 top 座標重新分行準確得多；串列
    順序本身也已經是 Tesseract 判定的閱讀順序，後續重建文字時直接照
    原順序輸出即可，不需要也不應該再重新排序。
    """
    import pytesseract

    data = pytesseract.image_to_data(img, lang=lang, config=f'--psm {psm}', output_type=pytesseract.Output.DICT)
    words = []
    n = len(data.get('text', []))
    for i in range(n):
        text = data['text'][i]
        if not text.strip():
            continue
        try:
            conf = int(data['conf'][i])
        except (ValueError, TypeError):
            conf = -1
        if conf < 0:
            continue
        words.append({
            'text': text,
            'conf': conf,
            'left': data['left'][i],
            'top': data['top'][i],
            'width': data['width'][i],
            'height': data['height'][i],
            'line_key': (data['block_num'][i], data['par_num'][i], data['line_num'][i]),
        })
    return words


def _pick_best_psm_words(img, lang):
    """依序嘗試 `_PSM_CANDIDATES`，取詞辨識信心分數平均最高的一組結構化
    詞清單。挑選邏輯與 `_ocr_best_effort` 的字串版本一致，差別只在於
    這裡多保留逐詞座標，供圖示遮罩與局部裁切放大使用。
    """
    import pytesseract

    best_words, best_conf = [], -1.0
    for psm in _PSM_CANDIDATES:
        try:
            words = _get_word_boxes(img, lang, psm)
        except pytesseract.TesseractError:
            continue
        if not words:
            continue
        mean_conf = sum(w['conf'] for w in words) / len(words)
        if mean_conf > best_conf:
            best_conf = mean_conf
            best_words = words
    return best_words


def _is_icon_candidate(word):
    """圖示污染候選判斷（v1.6）：框體很小、近似方形、且信心分數偏低，
    這種輪廓通常是 UI 圖示（樹狀符號、勾選框、工具列按鈕）被誤讀成字元，
    而不是真正的文字。純粹依尺寸猜測不夠可靠，必須同時信心分數偏低，
    避免誤傷真正的小型文字（如單一數字編號、標點符號）。
    """
    w, h = word['width'], word['height']
    if w <= 0 or h <= 0:
        return False
    if w > _ICON_MAX_SIZE or h > _ICON_MAX_SIZE:
        return False
    aspect = w / h
    if not (_ICON_ASPECT_MIN <= aspect <= _ICON_ASPECT_MAX):
        return False
    return word['conf'] < _ICON_CONF_THRESHOLD


def _sample_background_color(img, box, pad=4):
    """從候選框外圍一圈取樣，估算局部背景色（取眾數），供遮罩時貼近
    周圍底色使用，避免硬塗固定顏色造成邊界突兀。僅支援灰階（'L'）輸入，
    符合本模組前處理後一律轉灰階的慣例。
    """
    left, top, w, h = box['left'], box['top'], box['width'], box['height']
    x0 = max(0, left - pad)
    y0 = max(0, top - pad)
    x1 = min(img.width, left + w + pad)
    y1 = min(img.height, top + h + pad)
    ring = img.crop((x0, y0, x1, y1))
    hist = ring.histogram()
    return hist.index(max(hist))


def _mask_icon_regions(img, icon_words):
    """把判定為圖示污染候選的框體區域塗成局部背景色，回傳遮罩後的新圖片
    （不修改原圖）。目的是避免圖示像素被硬讀成亂碼字元、甚至跟旁邊的
    真實文字黏在一起造成整詞辨識錯誤（例如緊貼的樹狀圖示把 elseif
    拖成 ekeif）。能力邊界見模組頂端說明。
    """
    from PIL import ImageDraw

    if not icon_words:
        return img
    out = img.copy()
    draw = ImageDraw.Draw(out)
    for word in icon_words:
        bg = _sample_background_color(img, word)
        left, top, w, h = word['left'], word['top'], word['width'], word['height']
        draw.rectangle([left, top, left + w, top + h], fill=bg)
    return out


def _crop_and_reocr(img, word, lang):
    """對單一低信心詞框做局部裁切放大重辨識（v1.6）：裁切（含留白）→
    放大到目標長邊（上限見 `_CROP_MAX_SCALE`）→自動對比→用單行版面
    模式（PSM 7）重跑一次。回傳（text, conf）；辨識不出東西時回傳
    （None, -1.0）。
    """
    from PIL import Image, ImageOps
    import pytesseract

    left, top, w, h = word['left'], word['top'], word['width'], word['height']
    x0 = max(0, left - _CROP_PAD)
    y0 = max(0, top - _CROP_PAD)
    x1 = min(img.width, left + w + _CROP_PAD)
    y1 = min(img.height, top + h + _CROP_PAD)
    crop = img.crop((x0, y0, x1, y1))

    long_side = max(crop.width, crop.height)
    if long_side > 0 and long_side < _CROP_MIN_LONG_SIDE:
        scale = min(_CROP_MAX_SCALE, _CROP_MIN_LONG_SIDE / long_side)
        if scale > 1:
            new_size = (max(1, round(crop.width * scale)), max(1, round(crop.height * scale)))
            crop = crop.resize(new_size, Image.LANCZOS)

    crop = ImageOps.autocontrast(crop.convert('L'))

    try:
        data = pytesseract.image_to_data(crop, lang=lang, config='--psm 7', output_type=pytesseract.Output.DICT)
    except pytesseract.TesseractError:
        return None, -1.0

    confs = [int(c) for c in data.get('conf', []) if str(c) not in ('-1', '')]
    texts = [t for t in data.get('text', []) if t.strip()]
    if not texts or not confs:
        return None, -1.0
    mean_conf = sum(confs) / len(confs)
    return ' '.join(texts).strip(), mean_conf


def _enhance_low_confidence_words(img, words, lang):
    """對信心分數低於 `_CROP_CONF_THRESHOLD` 的詞，嘗試局部裁切放大
    重辨識；只有新結果信心分數確實更高時才採用（驗證即閘門，不是
    重跑了就一定比較好），否則保留原辨識結果。回傳更新後的詞清單
    （複製一份，不修改輸入）。
    """
    updated = []
    for word in words:
        if word['conf'] >= _CROP_CONF_THRESHOLD:
            updated.append(word)
            continue
        new_text, new_conf = _crop_and_reocr(img, word, lang)
        if new_text and new_conf >= word['conf'] + _CROP_MIN_IMPROVEMENT:
            merged = dict(word)
            merged['text'] = new_text
            merged['conf'] = new_conf
            updated.append(merged)
        else:
            updated.append(word)
    return updated


def _words_to_text(words):
    """把詞清單組回一段文字。直接沿用輸入清單本身的順序（即 Tesseract
    `image_to_data` 回傳的原始順序，已經是它內建版面分析算好的閱讀
    順序），同一行（`line_key` 相同，即同一 block／par／line）用空白
    分隔，換行只在 `line_key` 改變時發生。改用 Tesseract 原生分行鍵值
    取代早期版本自製的 top 座標分行啟發式，避免多欄並排介面（例如左側
    樹狀清單＋右側屬性面板）被錯誤地依 y 座標打散重排。
    呼叫端（圖示遮罩、局部裁切放大）只會替換既有項目的文字或整批移除
    圖示候選項，不會重新排序、也不會插入新項目，因此輸入順序等同於
    原始辨識順序，這裡不需要也不應該再自行排序。
    """
    if not words:
        return ''
    lines = [[words[0]]]
    current_key = words[0].get('line_key')
    for word in words[1:]:
        if word.get('line_key') == current_key:
            lines[-1].append(word)
        else:
            lines.append([word])
            current_key = word.get('line_key')
    return '\n'.join(' '.join(w['text'] for w in line) for line in lines)


def _ocr_best_effort_v16(img, lang, enhance=True):
    """v1.6：在既有多 PSM 信心分數挑選（`_ocr_best_effort` 的邏輯）之上，
    疊加圖示區域遮罩與局部裁切放大兩道強化。`enhance=False` 時完全等同
    v1.5 行為，供除錯或效能比較之用。任何一步拿不到結構化詞資料，都會
    退回 `_ocr_best_effort` 的整圖辨識邏輯，確保不會讓使用者拿到空白
    結果（能力邊界誠實、降級階梯不造假）。
    """
    if not enhance:
        return _ocr_best_effort(img, lang)

    words = _pick_best_psm_words(img, lang)
    if not words:
        return _ocr_best_effort(img, lang)

    icon_words = [w for w in words if _is_icon_candidate(w)]
    if icon_words:
        masked = _mask_icon_regions(img, icon_words)
        remasked_words = _pick_best_psm_words(masked, lang)
        if remasked_words:
            orig_conf = sum(w['conf'] for w in words) / len(words)
            new_conf = sum(w['conf'] for w in remasked_words) / len(remasked_words)
            if new_conf >= orig_conf:
                words = remasked_words
                img = masked

    words = _enhance_low_confidence_words(img, words, lang)
    text = _words_to_text(words)
    return text if text else _ocr_best_effort(img, lang)


def ocr_image(path: str, lang: str = 'chi_tra+eng', enhance: bool = True) -> str:
    """對單張圖片做 OCR，回傳辨識出的文字（去頭尾空白）。
    讀取失敗或辨識不出文字時，回傳空字串，由呼叫端決定如何降級顯示。

    v1.5 起會先做前處理（小圖放大、灰階、自動對比），再比較多種 PSM
    版面切割模式取信心分數最高者，藉此改善小字截圖的辨識準確度；
    HEIC／HEIF 檔案在開圖前會先確保 pillow-heif 已安裝並註冊為 Pillow 的
    解碼外掛。

    v1.6 起，`enhance=True`（預設）會再疊加圖示區域遮罩與局部裁切放大
    兩道強化，詳見模組頂端能力邊界說明；設 `enhance=False` 可關閉，
    完全等同 v1.5 行為，供除錯或效能比較之用。
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(path)

    ext = os.path.splitext(path)[1].lower()
    if ext in _HEIC_EXTS:
        import bootstrap
        if not bootstrap.ensure_heic():
            raise RuntimeError('此環境缺少可用的 HEIC／HEIF 解碼器（pillow-heif 安裝失敗）')
        import pillow_heif
        pillow_heif.register_heif_opener()

    from PIL import Image

    with Image.open(path) as img:
        processed = _preprocess_for_ocr(img)
    return _ocr_best_effort_v16(processed, lang, enhance=enhance)
