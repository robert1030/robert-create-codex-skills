#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""run.py：RAG 切片產生器 CLI 入口。

用法（單檔）：
  python scripts/run.py <輸入檔> [--out 輸出路徑] [--min 150] [--max 400]

用法（批次，輸入是資料夾）：
  python scripts/run.py <輸入資料夾> [--recursive] [--out 輸出資料夾] ...

支援格式：pdf, docx, doc, html/htm, xml, csv, md/markdown, txt, mp4, heic/heif
輸出：單一 Markdown 檔，所有切片以 frontmatter 分隔（混合策略：標題優先分區，
區內語意細切）。批次模式下逐檔輸出到同一輸出資料夾，單檔失敗不中斷整批，
最後印出成功／失敗清單。
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from build_jsonl import build_jsonl  # noqa: E402
from build_markdown import build_markdown  # noqa: E402
from chunker import build_chunks  # noqa: E402
from extract import _DISPATCH, extract, source_type_of  # noqa: E402
from token_counter import get_token_counter  # noqa: E402


def process_one(input_path, out_prefix, target_min, target_max, out_format, tokenizer, id_mode):
    """處理單一檔案，回傳實際產出的檔案路徑清單。單檔模式與批次模式共用。"""
    blocks = extract(input_path)
    src_type = source_type_of(input_path)
    token_fn = get_token_counter(tokenizer)
    chunks = build_chunks(
        blocks,
        source_file=os.path.basename(input_path),
        source_type=src_type,
        target_min=target_min,
        target_max=target_max,
        token_fn=token_fn,
        id_mode=id_mode,
    )

    produced = []
    if out_format in ('md', 'both'):
        md = build_markdown(chunks, source_file=os.path.basename(input_path), source_type=src_type)
        md_path = out_prefix + '.chunks.md'
        with open(md_path, 'w', encoding='utf-8') as f:
            f.write(md)
        produced.append(md_path)
    if out_format in ('jsonl', 'both'):
        jsonl = build_jsonl(chunks, source_file=os.path.basename(input_path), source_type=src_type)
        jsonl_path = out_prefix + '.chunks.jsonl'
        with open(jsonl_path, 'w', encoding='utf-8') as f:
            f.write(jsonl)
        produced.append(jsonl_path)
    return len(chunks), produced


def _collect_batch_files(folder, recursive):
    """收集資料夾內支援格式的檔案清單（依副檔名比對 extract.py 的 _DISPATCH）。"""
    exts = set(_DISPATCH.keys())
    found = []
    if recursive:
        for root, _dirs, files in os.walk(folder):
            for name in files:
                if os.path.splitext(name)[1].lower() in exts:
                    found.append(os.path.join(root, name))
    else:
        for name in sorted(os.listdir(folder)):
            full = os.path.join(folder, name)
            if os.path.isfile(full) and os.path.splitext(name)[1].lower() in exts:
                found.append(full)
    return sorted(found)


def main():
    ap = argparse.ArgumentParser(description='RAG 切片產生器')
    ap.add_argument('input', help='輸入檔案路徑，或批次模式下的輸入資料夾路徑')
    ap.add_argument('--out', default=None, help='單檔模式：輸出路徑前綴；批次模式：輸出資料夾（預設：輸入資料夾）')
    ap.add_argument('--min', dest='target_min', type=int, default=150, help='切片目標下限字元數')
    ap.add_argument('--max', dest='target_max', type=int, default=400, help='切片目標上限字元數')
    ap.add_argument(
        '--format', dest='out_format', choices=['md', 'jsonl', 'both'], default='md',
        help='輸出格式：md（預設，單一 Markdown）／jsonl（每行一筆切片）／both（兩者都產出）',
    )
    ap.add_argument(
        '--tokenizer', choices=['heuristic', 'tiktoken'], default='heuristic',
        help='token 計數策略：heuristic（預設，免安裝粗估）／tiktoken（精確分詞器，需安裝）',
    )
    ap.add_argument(
        '--id-mode', dest='id_mode', choices=['sequential', 'hash'], default='sequential',
        help='chunk_id 產生方式：sequential（預設，向下相容，四位數連號）／'
             'hash（內容雜湊，同內容重新切片時 chunk_id 保持穩定，方便增量索引）',
    )
    ap.add_argument(
        '--recursive', action='store_true',
        help='批次模式（輸入為資料夾時）：連子資料夾一併掃描。預設只掃輸入資料夾本身。',
    )
    args = ap.parse_args()

    if not os.path.exists(args.input):
        print(f'錯誤：找不到路徑 {args.input}', file=sys.stderr)
        sys.exit(1)

    if os.path.isdir(args.input):
        out_dir = args.out or args.input
        os.makedirs(out_dir, exist_ok=True)
        files = _collect_batch_files(args.input, args.recursive)
        if not files:
            print(f'警告：{args.input} 內找不到任何支援格式的檔案（支援：{", ".join(sorted(_DISPATCH))}）')
            sys.exit(0)

        ok, failed = [], []
        for path in files:
            base = os.path.splitext(os.path.basename(path))[0]
            out_prefix = os.path.join(out_dir, base)
            try:
                n_chunks, produced = process_one(
                    path, out_prefix, args.target_min, args.target_max,
                    args.out_format, args.tokenizer, args.id_mode,
                )
                ok.append((path, n_chunks, produced))
                print(f'✓ {path} → {n_chunks} 個切片 → {", ".join(produced)}')
            except Exception as exc:  # noqa: BLE001：批次模式單檔失敗不可中斷整批
                failed.append((path, str(exc)))
                print(f'✗ {path} 失敗：{exc}', file=sys.stderr)

        print(f'\n批次完成：成功 {len(ok)} 檔，失敗 {len(failed)} 檔（共 {len(files)} 檔）。')
        if failed:
            print('失敗清單：')
            for path, msg in failed:
                print(f'  - {path}：{msg}')
            sys.exit(1)
        return

    out_prefix = args.out or os.path.splitext(args.input)[0]
    n_chunks, produced = process_one(
        args.input, out_prefix, args.target_min, args.target_max,
        args.out_format, args.tokenizer, args.id_mode,
    )
    print(f'完成：共產出 {n_chunks} 個切片 → {", ".join(produced)}')


if __name__ == '__main__':
    main()
