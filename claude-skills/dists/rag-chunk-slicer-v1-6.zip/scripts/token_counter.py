#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""token_counter.py — token 計數策略選擇器。
預設（'heuristic'）沿用 chunker.estimate_tokens 的粗估邏輯，行為不變、
不影響既有測試契約。要對齊特定 embedding 模型的精確 token 上限時，
改用 'tiktoken'。
"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import bootstrap  # noqa: E402
from chunker import estimate_tokens  # noqa: E402


def get_token_counter(name: str = 'heuristic', encoding_name: str = 'cl100k_base'):
    """回傳一個 text -> int 的計數函式。
    name='heuristic'：沿用粗估（中日韓逐字＋英數空白斷詞），免安裝，免網路。
    name='tiktoken'：精確分詞器計數，安裝失敗時自動降級回 heuristic 並印出警告。
    """
    if name == 'heuristic':
        return estimate_tokens

    if name == 'tiktoken':
        if not bootstrap.ensure_tiktoken():
            print('【能力邊界】tiktoken 安裝失敗，已降級回粗估 token 計數。', file=sys.stderr)
            return estimate_tokens
        import tiktoken

        try:
            enc = tiktoken.get_encoding(encoding_name)
        except Exception as e:  # noqa: BLE001 — 編碼檔下載失敗（常見於網路白名單限制環境）
            print(
                f'【能力邊界】tiktoken 編碼檔下載失敗（{e}），'
                f'此環境網路白名單可能未開放 openaipublic.blob.core.windows.net，'
                f'已降級回粗估 token 計數。建議在可連網下載編碼檔的環境使用 --tokenizer tiktoken。',
                file=sys.stderr,
            )
            return estimate_tokens

        def _count(text: str) -> int:
            return len(enc.encode(text))

        return _count

    raise ValueError(f'不支援的 token 計數策略：{name}（支援：heuristic, tiktoken）')
