#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""tests/test_chunker.py：切片引擎純邏輯回歸測試。
跑法：python -m pytest tests/test_chunker.py -v
或直接：python tests/test_chunker.py
"""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'scripts'))

from chunker import (  # noqa: E402
    Block,
    build_chunks,
    estimate_tokens,
    semantic_chunk,
    split_sentences,
)


class TestSentenceSplit(unittest.TestCase):
    def test_basic_split(self):
        text = '這是第一句。這是第二句！這是第三句嗎？'
        sents = split_sentences(text)
        self.assertEqual(sents, ['這是第一句。', '這是第二句！', '這是第三句嗎？'])

    def test_empty(self):
        self.assertEqual(split_sentences(''), [])
        self.assertEqual(split_sentences('   '), [])


class TestTokenEstimate(unittest.TestCase):
    def test_cjk_count(self):
        self.assertEqual(estimate_tokens('中文五字測試'), 6)

    def test_mixed(self):
        n = estimate_tokens('中文 hello world')
        self.assertEqual(n, 2 + 2)  # 2 個中文字 + 2 個英文詞


class TestSemanticChunk(unittest.TestCase):
    def test_respects_max(self):
        sents = ['句子一。'] * 50
        out = semantic_chunk(sents, target_min=5, target_max=20)
        for c in out:
            self.assertLessEqual(len(c), 20 + len('句子一。'))  # 容許單句不被截斷

    def test_oversized_single_sentence_kept_whole(self):
        long_sent = '長句' * 100 + '。'
        out = semantic_chunk([long_sent], target_min=10, target_max=50)
        self.assertEqual(out, [long_sent])

    def test_no_data_loss(self):
        sents = [f'句子{i}。' for i in range(10)]
        out = semantic_chunk(sents, target_min=5, target_max=15)
        joined = ''.join(out)
        self.assertEqual(joined, ''.join(sents))


class TestBuildChunks(unittest.TestCase):
    def test_heading_hierarchy_and_no_data_loss(self):
        blocks = [
            Block(type='heading', text='第一章', level=1),
            Block(type='paragraph', text='第一章內容句子一。第一章內容句子二。'),
            Block(type='heading', text='1.1 背景', level=2),
            Block(type='paragraph', text='背景說明句子一。背景說明句子二。'),
            Block(type='heading', text='第二章', level=1),
            Block(type='paragraph', text='第二章句子。'),
        ]
        chunks = build_chunks(blocks, 'demo.md', 'markdown', target_min=5, target_max=200)
        self.assertGreaterEqual(len(chunks), 3)
        paths = [c.section_path for c in chunks]
        self.assertIn('第一章', paths)
        self.assertIn('第一章 > 1.1 背景', paths)
        self.assertIn('第二章', paths)
        # 不丟資料：所有原文句子都要出現在某個切片裡
        all_text = ''.join(c.text for c in chunks)
        for s in ['第一章內容句子一。', '背景說明句子一。', '第二章句子。']:
            self.assertIn(s, all_text)

    def test_chunk_id_sequential(self):
        blocks = [Block(type='paragraph', text='句子。' * 3)]
        chunks = build_chunks(blocks, 'x.txt', 'text')
        ids = [c.chunk_id for c in chunks]
        self.assertEqual(ids, [f'{i+1:04d}' for i in range(len(ids))])

    def test_custom_token_fn_overrides_default(self):
        blocks = [Block(type='paragraph', text='測試句子。')]
        chunks_default = build_chunks(blocks, 'x.txt', 'text')
        chunks_custom = build_chunks(blocks, 'x.txt', 'text', token_fn=lambda t: 999)
        self.assertNotEqual(chunks_default[0].token_estimate, 999)
        self.assertEqual(chunks_custom[0].token_estimate, 999)

    def test_page_range_tracked(self):
        blocks = [
            Block(type='heading', text='章節', level=1),
            Block(type='paragraph', text='內容句子。', page=1),
            Block(type='paragraph', text='下一頁內容句子。', page=2),
        ]
        chunks = build_chunks(blocks, 'x.pdf', 'pdf', target_min=5, target_max=500)
        self.assertTrue(any(c.page_range == '1-2' for c in chunks))

    def test_image_ocr_forced_own_chunk_with_image_path(self):
        blocks = [
            Block(type='heading', text='產品手冊', level=1),
            Block(type='paragraph', text='前言段落句子。'),
            Block(type='image_ocr', text='圖片裡辨識出來的文字內容。', image_path='images/diagram1.png'),
            Block(type='paragraph', text='後續段落句子。'),
            Block(type='image_ocr', text='第二張圖的文字。', image_path='assets/sub/diagram2.jpg'),
        ]
        chunks = build_chunks(blocks, 'manual.html', 'html', target_min=5, target_max=500)
        image_chunks = [c for c in chunks if c.image_path]
        self.assertEqual(len(image_chunks), 2)
        self.assertEqual(image_chunks[0].image_path, 'images/diagram1.png')
        self.assertEqual(image_chunks[0].text, '圖片裡辨識出來的文字內容。')
        self.assertEqual(image_chunks[1].image_path, 'assets/sub/diagram2.jpg')
        # 圖片切片不應與前後段落文字合併
        non_image_chunks = [c for c in chunks if not c.image_path]
        for c in non_image_chunks:
            self.assertNotIn('圖片裡辨識出來的文字內容', c.text)
        # image_path 不應外溢到後面的一般段落切片
        self.assertIsNone(chunks[-1].image_path) if not chunks[-1].text.endswith('圖的文字。') else None
        trailing = [c for c in chunks if c.text == '後續段落句子。']
        self.assertTrue(trailing)
        self.assertIsNone(trailing[0].image_path)


    def test_chunk_id_hash_mode_format_and_default_unchanged(self):
        blocks = [Block(type='paragraph', text='句子。' * 3)]
        chunks_default = build_chunks(blocks, 'x.txt', 'text')
        self.assertEqual(chunks_default[0].chunk_id, '0001')
        chunks_hash = build_chunks(blocks, 'x.txt', 'text', id_mode='hash')
        cid = chunks_hash[0].chunk_id
        self.assertEqual(len(cid), 12)
        self.assertRegex(cid, r'^[0-9a-f]{12}$')

    def test_chunk_id_hash_stable_when_content_unchanged_across_reslice(self):
        blocks_v1 = [
            Block(type='heading', text='第一章', level=1),
            Block(type='paragraph', text='這是要追蹤穩定性的句子。'),
        ]
        blocks_v2 = [
            Block(type='heading', text='第零章', level=1),
            Block(type='paragraph', text='新插入的前言句子。'),
            Block(type='heading', text='第一章', level=1),
            Block(type='paragraph', text='這是要追蹤穩定性的句子。'),
        ]
        hash_v1 = build_chunks(blocks_v1, 'doc.md', 'markdown', target_min=5, target_max=200, id_mode='hash')
        hash_v2 = build_chunks(blocks_v2, 'doc.md', 'markdown', target_min=5, target_max=200, id_mode='hash')
        id_v1 = next(c.chunk_id for c in hash_v1 if c.text == '這是要追蹤穩定性的句子。')
        id_v2 = next(c.chunk_id for c in hash_v2 if c.text == '這是要追蹤穩定性的句子。')
        self.assertEqual(id_v1, id_v2)

        seq_v1 = build_chunks(blocks_v1, 'doc.md', 'markdown', target_min=5, target_max=200)
        seq_v2 = build_chunks(blocks_v2, 'doc.md', 'markdown', target_min=5, target_max=200)
        sid_v1 = next(c.chunk_id for c in seq_v1 if c.text == '這是要追蹤穩定性的句子。')
        sid_v2 = next(c.chunk_id for c in seq_v2 if c.text == '這是要追蹤穩定性的句子。')
        self.assertNotEqual(sid_v1, sid_v2)

    def test_invalid_id_mode_rejected(self):
        blocks = [Block(type='paragraph', text='句子。')]
        with self.assertRaises(ValueError):
            build_chunks(blocks, 'x.txt', 'text', id_mode='not-a-real-mode')


if __name__ == '__main__':
    unittest.main()
