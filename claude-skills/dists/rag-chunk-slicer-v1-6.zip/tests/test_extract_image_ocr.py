#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""tests/test_extract_image_ocr.py：OCR 強化前處理（v1.5）回歸測試。
跑法：python -m pytest tests/test_extract_image_ocr.py -v
或直接：python tests/test_extract_image_ocr.py

放大／灰階前處理只需要 Pillow（既有 ensure_ocr 依賴之一，不算新增重相依），
直接用真的 PIL 測試幾何與色彩模式；信心分數挑選邏輯用 mock 隔離 Tesseract
本體呼叫，驗證的是「有沒有真的照信心分數挑」而不是碰運氣過。
"""
import os
import sys
import unittest
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'scripts'))

try:
    from PIL import Image
    _PIL_OK = True
except ImportError:
    _PIL_OK = False

from extract_image import (  # noqa: E402
    _UPSCALE_MAX_SCALE,
    _UPSCALE_TARGET_LONG_SIDE,
    _ocr_best_effort,
    _preprocess_for_ocr,
    _upscale_if_small,
)


@unittest.skipUnless(_PIL_OK, 'Pillow 未安裝，跳過需要真的建圖的測試')
class TestUpscaleIfSmall(unittest.TestCase):
    def test_small_image_gets_upscaled_toward_target(self):
        img = Image.new('RGB', (200, 100))  # 長邊 200，遠低於門檻
        out = _upscale_if_small(img)
        self.assertGreater(max(out.width, out.height), max(img.width, img.height))
        # 長邊應該逼近門檻（在放大倍率上限內）
        expected_scale = min(_UPSCALE_MAX_SCALE, _UPSCALE_TARGET_LONG_SIDE / 200)
        self.assertEqual(out.width, round(200 * expected_scale))

    def test_scale_capped_for_extremely_tiny_image(self):
        img = Image.new('RGB', (10, 5))  # 長邊 10，理論倍率會遠超過上限
        out = _upscale_if_small(img)
        self.assertEqual(out.width, 10 * _UPSCALE_MAX_SCALE)

    def test_large_image_left_unchanged(self):
        img = Image.new('RGB', (2000, 800))  # 長邊已超過門檻
        out = _upscale_if_small(img)
        self.assertEqual(out.size, img.size)
        self.assertIs(out, img)  # 沒必要的處理直接原樣返回，不多做一次複製


@unittest.skipUnless(_PIL_OK, 'Pillow 未安裝，跳過需要真的建圖的測試')
class TestPreprocessForOcr(unittest.TestCase):
    def test_output_is_grayscale_mode_l(self):
        img = Image.new('RGB', (300, 200), color=(120, 200, 50))
        out = _preprocess_for_ocr(img)
        self.assertEqual(out.mode, 'L')

    def test_format_attribute_cleared_so_pytesseract_defaults_to_png(self):
        # 這是 HEIC 解碼問題的關鍵：前處理後 format 必須是 None，
        # 讓 pytesseract 的 prepare() 退回預設 PNG，而不是卡在無法辨識的格式標記。
        img = Image.new('RGB', (300, 200))
        img.format = 'HEIF'
        out = _preprocess_for_ocr(img)
        self.assertIsNone(out.format)


try:
    import pytesseract as _real_pytesseract
    _TESSERACT_MODULE_OK = True
except ImportError:
    _TESSERACT_MODULE_OK = False


@unittest.skipUnless(_TESSERACT_MODULE_OK, 'pytesseract 套件未安裝，跳過信心分數挑選邏輯測試')
class TestOcrBestEffortConfidenceSelection(unittest.TestCase):
    def test_picks_text_from_highest_confidence_psm(self):
        # 準備假資料：psm 6 的信心分數整體較高，應該被選中。
        def fake_image_to_data(img, lang, config, output_type):
            if '--psm 6' in config:
                return {'conf': ['95', '90', '-1'], 'text': ['Action', 'Session', '']}
            return {'conf': ['10', '5', '-1'], 'text': ['Acton', 'Sesion', '']}

        def fake_image_to_string(img, lang, config=None):
            if config and '--psm 6' in config:
                return '正確辨識的文字'
            return '亂碼辨識結果'

        with mock.patch.object(_real_pytesseract, 'image_to_data', side_effect=fake_image_to_data), \
             mock.patch.object(_real_pytesseract, 'image_to_string', side_effect=fake_image_to_string):
            result = _ocr_best_effort(img=object(), lang='chi_tra+eng')

        self.assertEqual(result, '正確辨識的文字')

    def test_falls_back_to_default_when_all_candidates_have_no_text(self):
        def fake_image_to_data(img, lang, config, output_type):
            return {'conf': ['-1'], 'text': ['']}

        with mock.patch.object(_real_pytesseract, 'image_to_data', side_effect=fake_image_to_data), \
             mock.patch.object(_real_pytesseract, 'image_to_string', return_value='') as fake_to_string:
            result = _ocr_best_effort(img=object(), lang='chi_tra+eng')

        self.assertEqual(result, '')
        # 全部候選都判定沒文字時，仍應該退回預設模式再試一次（不是直接放棄，見函式說明）。
        self.assertTrue(fake_to_string.called)


if __name__ == '__main__':
    unittest.main()
