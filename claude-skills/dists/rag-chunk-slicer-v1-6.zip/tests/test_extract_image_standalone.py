#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""tests/test_extract_image_standalone.py：獨立圖片輸入格式
（png／jpg／jpeg／heic／heif）回歸測試。
跑法：python -m pytest tests/test_extract_image_standalone.py -v
或直接：python tests/test_extract_image_standalone.py

只測「不需要真的安裝 pillow-heif／Tesseract」的部分：分派表註冊是否正確、
extract_image_standalone() 的降級與 image_ocr 強制獨立成塊邏輯（用 mock
隔離 ocr_image，不觸發真實 OCR／解碼）。真實解碼＋辨識效果需在裝好相依
套件的環境人工驗證，不寫進自動回歸測試（與既有 pdf／docx／html OCR 測試
的取捨一致）。
"""
import os
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'scripts'))

from extract import _DISPATCH, extract_image_standalone, source_type_of  # noqa: E402


class TestStandaloneImageDispatch(unittest.TestCase):
    def test_all_standalone_image_extensions_registered(self):
        for ext in ('.heic', '.heif', '.png', '.jpg', '.jpeg'):
            self.assertIs(_DISPATCH[ext], extract_image_standalone, msg=f'{ext} 未指向 extract_image_standalone')

    def test_source_type_of_each_extension(self):
        self.assertEqual(source_type_of('photo.heic'), 'heic')
        self.assertEqual(source_type_of('photo.HEIC'), 'heic')
        self.assertEqual(source_type_of('photo.heif'), 'heif')
        self.assertEqual(source_type_of('screenshot.png'), 'png')
        self.assertEqual(source_type_of('screenshot.JPG'), 'jpg')
        self.assertEqual(source_type_of('screenshot.jpeg'), 'jpeg')


class TestExtractImageStandalone(unittest.TestCase):
    def _touch(self, suffix):
        fd, path = tempfile.mkstemp(suffix=suffix)
        os.close(fd)
        return path

    def test_success_produces_single_image_ocr_block(self):
        for suffix in ('.heic', '.png', '.jpg'):
            path = self._touch(suffix)
            try:
                with mock.patch('extract_image.ocr_image', return_value='圖片裡辨識出來的文字。'):
                    blocks = extract_image_standalone(path)
            finally:
                os.remove(path)
            self.assertEqual(len(blocks), 1, msg=f'{suffix} 應該只產出一塊')
            self.assertEqual(blocks[0].type, 'image_ocr')
            self.assertEqual(blocks[0].text, '圖片裡辨識出來的文字。')
            self.assertEqual(blocks[0].image_path, os.path.basename(path))

    def test_no_text_recognized_gives_honest_fallback_message(self):
        path = self._touch('.jpg')
        try:
            with mock.patch('extract_image.ocr_image', return_value=''):
                blocks = extract_image_standalone(path)
        finally:
            os.remove(path)
        self.assertEqual(len(blocks), 1)
        self.assertIn('辨識不到文字', blocks[0].text)

    def test_ocr_failure_gives_capability_boundary_message_not_silent(self):
        path = self._touch('.png')
        try:
            with mock.patch('extract_image.ocr_image', side_effect=RuntimeError('缺少解碼器')):
                blocks = extract_image_standalone(path)
        finally:
            os.remove(path)
        self.assertEqual(len(blocks), 1)
        self.assertIn('【能力邊界】', blocks[0].text)
        self.assertIn('缺少解碼器', blocks[0].text)

    def test_whole_image_text_forced_single_chunk_regardless_of_length(self):
        # 對焦結論：切片細緻度維持「整張圖一塊」，不論 OCR 出來的文字多長都不再依語意細切。
        long_text = '很長很長的辨識文字。' * 200
        path = self._touch('.png')
        try:
            with mock.patch('extract_image.ocr_image', return_value=long_text):
                blocks = extract_image_standalone(path)
        finally:
            os.remove(path)
        self.assertEqual(len(blocks), 1)
        self.assertEqual(blocks[0].text, long_text)


if __name__ == '__main__':
    unittest.main()
