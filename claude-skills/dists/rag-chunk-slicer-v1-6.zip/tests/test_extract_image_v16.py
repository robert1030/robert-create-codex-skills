#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""tests/test_extract_image_v16.py：圖示區域遮罩與局部裁切放大（v1.6）回歸測試。
跑法：python -m pytest tests/test_extract_image_v16.py -v
或直接：python tests/test_extract_image_v16.py

純邏輯（尺寸與信心分數判斷、版面重建）直接測；需要真的建圖的部分
（遮罩、背景色取樣）用真的 PIL 圖片測幾何與像素結果；信心分數驅動
的重跑邏輯（局部裁切放大、整體強化流程）用 mock 隔離 Tesseract 本體，
驗證的是「有沒有真的照信心分數決定要不要採用」而不是碰運氣過。
"""
import os
import sys
import unittest
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'scripts'))

try:
    from PIL import Image
    _PIL_OK = True
except ImportError:
    _PIL_OK = False

from extract_image import (  # noqa: E402
    _CROP_CONF_THRESHOLD,
    _ICON_CONF_THRESHOLD,
    _ICON_MAX_SIZE,
    _crop_and_reocr,
    _enhance_low_confidence_words,
    _is_icon_candidate,
    _mask_icon_regions,
    _ocr_best_effort_v16,
    _sample_background_color,
    _words_to_text,
)


def _word(text='x', conf=90, left=0, top=0, width=10, height=10, line_key=(1, 1, 1)):
    return {
        'text': text, 'conf': conf, 'left': left, 'top': top,
        'width': width, 'height': height, 'line_key': line_key,
    }


class TestIsIconCandidate(unittest.TestCase):
    def test_small_low_confidence_square_is_icon_candidate(self):
        w = _word(conf=_ICON_CONF_THRESHOLD - 1, width=12, height=12)
        self.assertTrue(_is_icon_candidate(w))

    def test_small_but_high_confidence_is_not_icon(self):
        # 尺寸符合，但信心分數夠高，代表這其實是真的小型文字（如編號），不該當圖示。
        w = _word(conf=_ICON_CONF_THRESHOLD + 10, width=12, height=12)
        self.assertFalse(_is_icon_candidate(w))

    def test_large_low_confidence_is_not_icon(self):
        # 信心分數低，但尺寸已超過圖示門檻，通常是辨識錯誤的一般文字，不該被遮罩掉。
        w = _word(conf=10, width=_ICON_MAX_SIZE + 30, height=_ICON_MAX_SIZE + 30)
        self.assertFalse(_is_icon_candidate(w))

    def test_elongated_shape_is_not_icon(self):
        # 長寬比過於極端（一條細線），不符合圖示常見的近似方形輪廓。
        w = _word(conf=10, width=20, height=2)
        self.assertFalse(_is_icon_candidate(w))

    def test_zero_size_is_not_icon(self):
        w = _word(conf=10, width=0, height=0)
        self.assertFalse(_is_icon_candidate(w))


@unittest.skipUnless(_PIL_OK, 'Pillow 未安裝，跳過需要真的建圖的測試')
class TestMaskIconRegions(unittest.TestCase):
    def test_icon_region_gets_painted_to_background_color(self):
        img = Image.new('L', (100, 100), color=250)  # 淺色背景
        # 在圖上畫一塊深色方塊，模擬圖示
        for x in range(40, 50):
            for y in range(40, 50):
                img.putpixel((x, y), 10)
        icon = _word(conf=10, left=40, top=40, width=10, height=10)

        out = _mask_icon_regions(img, [icon])
        # 遮罩後，原本深色的圖示區域中心應該變成接近背景的淺色，不再是深色。
        self.assertGreater(out.getpixel((45, 45)), 200)

    def test_no_icon_words_returns_same_image(self):
        img = Image.new('L', (50, 50), color=255)
        out = _mask_icon_regions(img, [])
        self.assertIs(out, img)

    def test_sample_background_color_picks_dominant_ring_color(self):
        img = Image.new('L', (60, 60), color=230)
        box = _word(left=25, top=25, width=10, height=10)
        bg = _sample_background_color(img, box)
        self.assertEqual(bg, 230)


class TestWordsToText(unittest.TestCase):
    def test_empty_words_returns_empty_string(self):
        self.assertEqual(_words_to_text([]), '')

    def test_same_line_key_words_joined_by_space_in_original_order(self):
        # 直接沿用輸入順序（即 Tesseract 回傳的閱讀順序），不重新排序。
        words = [
            _word(text='Hello', line_key=(1, 1, 1)),
            _word(text='World', line_key=(1, 1, 1)),
        ]
        self.assertEqual(_words_to_text(words), 'Hello World')

    def test_different_line_key_separated_by_newline(self):
        words = [
            _word(text='Line1', line_key=(1, 1, 1)),
            _word(text='Line2', line_key=(1, 1, 2)),
        ]
        self.assertEqual(_words_to_text(words), 'Line1\nLine2')

    def test_two_column_layout_preserves_tesseract_native_grouping(self):
        # 模擬左側樹狀清單（block 1）＋右側屬性面板（block 2）並排的情況，
        # 只要 line_key 分屬不同 block，就不該被錯誤地依 y 座標打散重排。
        words = [
            _word(text='General', line_key=(1, 1, 1)),
            _word(text='Timing', line_key=(1, 1, 2)),
            _word(text='Skip', line_key=(2, 1, 1)),
            _word(text='this', line_key=(2, 1, 1)),
        ]
        self.assertEqual(_words_to_text(words), 'General\nTiming\nSkip this')


try:
    import pytesseract as _real_pytesseract
    _TESSERACT_MODULE_OK = True
except ImportError:
    _TESSERACT_MODULE_OK = False


@unittest.skipUnless(_TESSERACT_MODULE_OK, 'pytesseract 套件未安裝，跳過信心分數驅動邏輯測試')
class TestCropAndReocr(unittest.TestCase):
    @unittest.skipUnless(_PIL_OK, 'Pillow 未安裝，跳過需要真的建圖的測試')
    def test_returns_text_and_confidence_from_crop(self):
        img = Image.new('L', (200, 200), color=255)
        word = _word(left=50, top=50, width=20, height=20)

        def fake_image_to_data(crop_img, lang, config, output_type):
            return {'conf': ['80', '-1'], 'text': ['elseif', '']}

        with mock.patch.object(_real_pytesseract, 'image_to_data', side_effect=fake_image_to_data):
            text, conf = _crop_and_reocr(img, word, 'eng')

        self.assertEqual(text, 'elseif')
        self.assertEqual(conf, 80.0)

    @unittest.skipUnless(_PIL_OK, 'Pillow 未安裝，跳過需要真的建圖的測試')
    def test_returns_none_when_no_text_found(self):
        img = Image.new('L', (200, 200), color=255)
        word = _word(left=50, top=50, width=20, height=20)

        def fake_image_to_data(crop_img, lang, config, output_type):
            return {'conf': ['-1'], 'text': ['']}

        with mock.patch.object(_real_pytesseract, 'image_to_data', side_effect=fake_image_to_data):
            text, conf = _crop_and_reocr(img, word, 'eng')

        self.assertIsNone(text)
        self.assertEqual(conf, -1.0)


@unittest.skipUnless(_TESSERACT_MODULE_OK, 'pytesseract 套件未安裝，跳過信心分數驅動邏輯測試')
class TestEnhanceLowConfidenceWords(unittest.TestCase):
    def test_word_replaced_only_when_new_confidence_is_higher(self):
        low_word = _word(text='ekeif', conf=_CROP_CONF_THRESHOLD - 20)
        high_word = _word(text='procedure', conf=95)

        def fake_crop_and_reocr(img, word, lang):
            if word['text'] == 'ekeif':
                return 'elseif', 90.0
            raise AssertionError('不該對已經高信心的詞觸發局部裁切放大')

        with mock.patch('extract_image._crop_and_reocr', side_effect=fake_crop_and_reocr):
            result = _enhance_low_confidence_words(img=object(), words=[low_word, high_word], lang='eng')

        self.assertEqual(result[0]['text'], 'elseif')
        self.assertEqual(result[0]['conf'], 90.0)
        self.assertEqual(result[1]['text'], 'procedure')  # 高信心詞不受影響，原樣保留

    def test_keeps_original_when_improvement_below_margin(self):
        # 只小幅提升（低於 _CROP_MIN_IMPROVEMENT），可能只是換成另一個同樣
        # 錯誤但信心分數略高的猜測，不該採用，見常數旁的實測發現說明。
        low_word = _word(text='cke', conf=40)

        def fake_crop_and_reocr(img, word, lang):
            return 'cbse', 44.0  # 只高 4 分，不到門檻

        with mock.patch('extract_image._crop_and_reocr', side_effect=fake_crop_and_reocr):
            result = _enhance_low_confidence_words(img=object(), words=[low_word], lang='eng')

        self.assertEqual(result[0]['text'], 'cke')

    def test_keeps_original_when_reocr_not_better(self):
        low_word = _word(text='ekeif', conf=_CROP_CONF_THRESHOLD - 20)

        def fake_crop_and_reocr(img, word, lang):
            return 'ekeif2', 5.0  # 重跑結果信心分數更低，不該被採用

        with mock.patch('extract_image._crop_and_reocr', side_effect=fake_crop_and_reocr):
            result = _enhance_low_confidence_words(img=object(), words=[low_word], lang='eng')

        self.assertEqual(result[0]['text'], 'ekeif')  # 保留原辨識結果

    def test_keeps_original_when_reocr_returns_nothing(self):
        low_word = _word(text='ekeif', conf=_CROP_CONF_THRESHOLD - 20)

        def fake_crop_and_reocr(img, word, lang):
            return None, -1.0

        with mock.patch('extract_image._crop_and_reocr', side_effect=fake_crop_and_reocr):
            result = _enhance_low_confidence_words(img=object(), words=[low_word], lang='eng')

        self.assertEqual(result[0]['text'], 'ekeif')


@unittest.skipUnless(_TESSERACT_MODULE_OK, 'pytesseract 套件未安裝，跳過信心分數驅動邏輯測試')
class TestOcrBestEffortV16(unittest.TestCase):
    def test_enhance_false_delegates_to_v15_logic(self):
        with mock.patch('extract_image._ocr_best_effort', return_value='v1.5 結果') as fake_v15, \
             mock.patch('extract_image._pick_best_psm_words') as fake_pick:
            result = _ocr_best_effort_v16(img=object(), lang='eng', enhance=False)

        self.assertEqual(result, 'v1.5 結果')
        fake_pick.assert_not_called()  # enhance=False 時完全不該碰 v1.6 的邏輯

    def test_falls_back_to_v15_when_no_words_detected(self):
        with mock.patch('extract_image._pick_best_psm_words', return_value=[]), \
             mock.patch('extract_image._ocr_best_effort', return_value='退回 v1.5 結果') as fake_v15:
            result = _ocr_best_effort_v16(img=object(), lang='eng', enhance=True)

        self.assertEqual(result, '退回 v1.5 結果')
        fake_v15.assert_called_once()

    def test_end_to_end_reconstructs_text_from_words(self):
        words = [_word(text='Hello', conf=95, top=0, left=0), _word(text='World', conf=96, top=0, left=60)]
        with mock.patch('extract_image._pick_best_psm_words', return_value=words), \
             mock.patch('extract_image._enhance_low_confidence_words', return_value=words):
            result = _ocr_best_effort_v16(img=object(), lang='eng', enhance=True)

        self.assertEqual(result, 'Hello World')


if __name__ == '__main__':
    unittest.main()
