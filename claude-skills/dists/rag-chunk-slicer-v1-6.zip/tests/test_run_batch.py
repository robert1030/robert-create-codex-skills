#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""tests/test_run_batch.py：批次模式（run.py）回歸測試。
跑法：python -m pytest tests/test_run_batch.py -v
或直接：python tests/test_run_batch.py

只測「不需要重相依套件」的部分：純檔案篩選邏輯、以及用 .md／.txt（不需要
pymupdf／docx 等）跑一次完整批次流程，確認輸出檔與成功／失敗清單正確。
"""
import os
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'scripts'))

from run import _collect_batch_files  # noqa: E402

_RUN_PY = os.path.join(os.path.dirname(__file__), '..', 'scripts', 'run.py')


class TestCollectBatchFiles(unittest.TestCase):
    def test_non_recursive_only_top_level_supported_files(self):
        with tempfile.TemporaryDirectory() as d:
            open(os.path.join(d, 'a.md'), 'w').close()
            open(os.path.join(d, 'b.txt'), 'w').close()
            open(os.path.join(d, 'c.unsupported'), 'w').close()
            sub = os.path.join(d, 'sub')
            os.makedirs(sub)
            open(os.path.join(sub, 'd.md'), 'w').close()

            found = _collect_batch_files(d, recursive=False)
            names = sorted(os.path.basename(f) for f in found)
            self.assertEqual(names, ['a.md', 'b.txt'])

    def test_recursive_includes_subfolders(self):
        with tempfile.TemporaryDirectory() as d:
            open(os.path.join(d, 'a.md'), 'w').close()
            sub = os.path.join(d, 'sub')
            os.makedirs(sub)
            open(os.path.join(sub, 'd.md'), 'w').close()

            found = _collect_batch_files(d, recursive=True)
            names = sorted(os.path.basename(f) for f in found)
            self.assertEqual(names, ['a.md', 'd.md'])

    def test_empty_folder_returns_empty_list(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(_collect_batch_files(d, recursive=False), [])


class TestBatchEndToEnd(unittest.TestCase):
    def test_batch_mode_produces_output_per_file_and_summary(self):
        with tempfile.TemporaryDirectory() as d:
            with open(os.path.join(d, 'one.md'), 'w', encoding='utf-8') as f:
                f.write('# 標題一\n\n這是第一份文件的內容句子。\n')
            with open(os.path.join(d, 'two.txt'), 'w', encoding='utf-8') as f:
                f.write('這是第二份文件的內容句子。\n')

            result = subprocess.run(
                [sys.executable, _RUN_PY, d],
                capture_output=True, text=True, timeout=60,
            )
            self.assertEqual(result.returncode, 0, msg=result.stderr)
            self.assertTrue(os.path.isfile(os.path.join(d, 'one.chunks.md')))
            self.assertTrue(os.path.isfile(os.path.join(d, 'two.chunks.md')))
            self.assertIn('批次完成：成功 2 檔，失敗 0 檔', result.stdout)

    def test_batch_mode_id_hash_propagates(self):
        with tempfile.TemporaryDirectory() as d:
            with open(os.path.join(d, 'one.md'), 'w', encoding='utf-8') as f:
                f.write('# 標題一\n\n這是內容句子。\n')

            result = subprocess.run(
                [sys.executable, _RUN_PY, d, '--id-mode', 'hash'],
                capture_output=True, text=True, timeout=60,
            )
            self.assertEqual(result.returncode, 0, msg=result.stderr)
            with open(os.path.join(d, 'one.chunks.md'), encoding='utf-8') as f:
                content = f.read()
            self.assertRegex(content, r'chunk_id: "[0-9a-f]{12}"')


if __name__ == '__main__':
    unittest.main()
