# Portable Agent Skill Installer v1 設計

> **狀態：v1.0.0 契約已凍結，完整安裝器尚未實作。**

## 目標

把本機 ZIP 中的標準 Agent Skill、Hermes 原生 Plugin、Hermes Desktop Plugin 與 MCP bundle 分開辨識，產生跨 Hermes Agent、Codex CLI／IDE、Claude Code CLI 的安全安裝計畫。

核心承諾是「共同 Skill 可攜，原生能力誠實降級」，不是把所有平台的 Plugin 行為假裝成相同。

## 分層

### 核心層

核心層只處理無副作用的資料與契約：ZIP 讀取、路徑安全、檔案索引、雜湊、套件分類、計畫摘要、plan digest 比對與狀態聚合。

核心層不得呼叫平台 CLI，不得啟動 ZIP 內程式，不得直接寫入 Agent 目錄。

### Adapter 層

Hermes adapter 負責 `HERMES_HOME`、Hermes Skills、Hermes Plugin、Desktop Plugin、MCP 設定與啟用驗證。

Codex adapter 負責使用者層級與專案層級 `.agents/skills`，其他原生面在 v1.0.0 只回報 UNSUPPORTED。

Claude Code adapter 負責使用者層級與專案層級 `.claude/skills`，其他原生面在 v1.0.0 只回報 UNSUPPORTED。

### 確認層

核心先輸出 dry-run 計畫。使用者確認相同 plan digest 後，才允許 adapter 執行寫入。需要啟動 runtime 的動作必須再建立獨立副作用確認。

### 回復層

apply 前記錄既有檔案雜湊與目的地。apply 成功後寫入 rollback manifest。部分失敗時只回復本次已寫入的內容，不碰計畫外檔案。

## 端到端狀態機

```text
SOURCE
  ↓
INSPECTED
  ↓
CLASSIFIED
  ↓
PLANNED
  ↓ 使用者確認相同 plan_digest
APPLYING
  ↓
VERIFIED
  ↓
ROLLBACK_READY
```

任何安全或契約 gate 失敗都進入 `BLOCKED`。共同 Skill 成功、原生面不支援或被跳過時進入 `PARTIAL`。

## 計畫最小欄位

```text
plan_id
plan_version
source_zip
source_sha256
package_kind
surfaces
agent
scope
project_root
operations
conflicts
risks
unsupported
side_effects
rollback_manifest
plan_digest
```

`apply` 必須重新讀取來源 ZIP，重新計算 `source_sha256`，並對比計畫中的 digest。計畫過期或目的地狀態改變時必須停止。

## 交付階段

### 已完成

• v1.0.1 `SKILL.md`、`FROZEN.md` 與 ZIP 預檢政策 reference。

• Hermes、Codex、Claude Code 相容性矩陣。

• ZIP 套件分類契約。

• 純邏輯 contract guards。

• ZIP 路徑、分類、目的地與 plan digest 負向測試。

• Joan 全形標點與禁破折號驗證器自稽。

• 唯讀 ZIP inspector 與 JSON dry-run plan CLI。

• fail-closed apply、來源雜湊比對、獨立當前產出驗證與 rollback manifest。

• Hermes、Codex、Claude Code 三個 adapter。

• apply、verify、rollback CLI smoke test。

### 尚未實作

• Hermes 原生 Plugin 的自動 activation。計畫會輸出命令，但 apply 不會自動執行。

• Hermes MCP runtime 的自動 activation。計畫會輸出副作用摘要，但需要另行確認。

• ZIP 內檔案內容的深度語意安全稽核。v1 只做路徑、大小、類型與 manifest 層級檢查。

• HTTPS 與 Git 來源。

## 主要風險

• Codex 與 Claude Code 的原生 Plugin 介面可能隨產品版本變動，因此 v1 只承諾共同 `SKILL.md` 面。

• Hermes MCP 啟用會啟動外部 runtime，必須與檔案安裝分離。

• ZIP 的檔案名稱安全檢查不能取代內容安全稽核。執行檔與 script 仍需列入風險摘要。

• 使用者層級與專案層級若同名，不能默認合併。adapter 必須回報實際命中範圍。

## 發布閘門

未完成下列項目前，不得宣稱 v1 完整安裝器完成：

1．每個 adapter 都有真實檔案系統測試。

2．每個安全驗證器都有故意錯誤的負向測試。

3．部分套用失敗可依 rollback manifest 回復。

4．所有 apply 操作都重新驗證來源雜湊與 plan digest。

5．本機 ZIP 打包通過 `pack_skill.py` 的 UTF-8 路徑編碼、CRC 與路徑安全檢查；預檢 warning 與 hard blocker 邊界見 `references/zip-inspection-policy.md`。

6．Hermes、Codex、Claude Code 各有一個最小 smoke fixture，且 PASS、PARTIAL、BLOCKED 語意可重現。
