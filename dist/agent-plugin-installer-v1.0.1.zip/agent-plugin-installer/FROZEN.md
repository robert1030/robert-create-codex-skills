# 凍結紀錄

## v1.0.1｜2026-08-22｜已鎖定

本版本是 v1.0.0 的相容 patch 版本。它只修正 ZIP inspector 對非 ASCII 成員路徑的誤判，不改變來源範圍、平台目的地、確認閘門、狀態語意或 rollback 契約。

2026-08-22：非 ASCII 成員路徑由 hard blocker 改為 advisory warning。完整政策集中於 `references/zip-inspection-policy.md`；warning 會保留在 report 與 plan。

### v1.0.1 定版檔

• `SKILL.md`

• `references/zip-inspection-policy.md`

• `scripts/zip_inspector.py`

• `tests/test_zip_inspector.py`

## v1.0.0｜2026-08-22｜已鎖定

本版本是 agent-plugin-installer 的第一個凍結契約。後續不得就地改動本文件已列出的行為；新增能力應另開版本並保留相容性說明。

2026-08-22：本版本進行 identity-only rename，名稱由舊名稱改為 agent-plugin-installer。版本維持 v1.0.0，功能契約、測試、相容性與安全邊界不變。

### 已鎖定的範圍

• 來源只支援本機 ZIP。HTTPS 與 Git 來源延後到未來版本。

• 目標平台為 Hermes Agent、Codex CLI／IDE、Claude Code CLI。

• 共同相容面為標準 `SKILL.md`。

• Hermes 原生 Plugin、Hermes Desktop Plugin 與 MCP bundle 只能由 Hermes adapter 啟用。

• Codex 與 Claude Code 對 Hermes 原生面只做辨識與 UNSUPPORTED 報告。

• 預設目標為使用者層級。專案層級必須明確指定。

• 所有安裝先產生 dry-run 計畫，再等待使用者確認相同的 `plan_digest`。

• 未經確認不得執行 ZIP 內的 Python、Node、EXE 或 MCP runtime。

• 預設不覆寫既有不同內容。

• 可攜部分成功、原生部分不支援時，整體結果為 `PARTIAL`。

• 安全、契約、衝突或必要輸入檢查失敗時，整體結果為 `BLOCKED`，不得寫入任何部分。

• 成功套用後必須產生 rollback manifest，並支援回復與移除。

### 版本規則

• 只修正文案或測試而不改契約，可進 patch 版本。

• 新增不破壞既有契約的套件面或 adapter，可進 minor 版本。

• 改變來源範圍、確認政策、狀態語意、目的地規則或安全邊界，必須另開 major 版本，不得就地修改 v1.0.0。

### 定版檔

• `SKILL.md`

• `DESIGN.md`

• `references/compatibility-matrix.md`

• `references/package-taxonomy.md`

• `scripts/contract_guards.py`

• `scripts/zip_inspector.py`

• `scripts/apply_engine.py`

• `scripts/verify_engine.py`

• `scripts/rollback_engine.py`

• `scripts/inspect_zip.py`

• `scripts/apply_plan.py`

• `scripts/verify.py`

• `scripts/rollback.py`

• `scripts/adapters/`

• `tests/test_contract_guards.py`

• `tests/test_zip_inspector.py`

• `tests/test_apply_rollback.py`

• `tests/test_verify.py`

• `tests/test_adapters.py`

• `tests/test_punct_guard.py`

• `tests/fixtures/bad_punct.md`
