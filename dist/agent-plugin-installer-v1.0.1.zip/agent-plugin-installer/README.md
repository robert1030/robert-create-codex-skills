# Portable Agent Skill Installer

本 Skill 將本機 ZIP 內的 Agent Skill、Hermes Plugin、Hermes Desktop Plugin 與 MCP bundle 分開辨識，產生跨 Hermes Agent、Codex CLI／IDE、Claude Code CLI 的安全安裝計畫。

## 目前版本

```text
v1.0.1
來源：本機 ZIP
相依：Python 3 標準函式庫
狀態：可 inspect、產生 plan、apply、verify、rollback
預檢政策：見 `references/zip-inspection-policy.md`
```

Hermes 原生 Plugin 與 MCP 的 activation 只會列出明確命令，不會在普通 apply 中自動啟動。

## 使用方式

先在這個 Skill 目錄執行唯讀 inspect 與 dry-run：

```bash
python scripts/inspect_zip.py <ZIP_PATH> \
  --agent hermes \
  --scope user \
  --root <HERMES_HOME> \
  --output plan.json
```

確認輸出的 `status`、`operations`、`unsupported`、`risks` 與 `plan_digest`。只有確認同一個 digest 後才 apply：

```bash
python scripts/apply_plan.py plan.json --confirm <PLAN_DIGEST>
```

apply 會輸出 rollback manifest。用它驗證當前產出：

```bash
python scripts/verify.py <ROLLBACK_MANIFEST>
```

回復本次新增的檔案：

```bash
python scripts/rollback.py <ROLLBACK_MANIFEST>
```

## 平台目的地

```text
Hermes user：$HERMES_HOME/skills/<id>
Hermes project：<project>/.hermes/skills/<id>
Codex user：$HOME/.agents/skills/<id>
Codex project：<project>/.agents/skills/<id>
Claude user：$HOME/.claude/skills/<id>
Claude project：<project>/.claude/skills/<id>
```

## 測試

不需要 pytest 也能執行：

```bash
python tests/test_contract_guards.py
python tests/test_zip_inspector.py
python tests/test_apply_rollback.py
python tests/test_verify.py
python tests/test_adapters.py
python tests/test_punct_guard.py
```

完整 discovery：

```bash
python -c "import unittest; suite=unittest.defaultTestLoader.discover('tests'); result=unittest.TextTestRunner(verbosity=1).run(suite); raise SystemExit(0 if result.wasSuccessful() else 1)"
```

打包前使用 Joan 房規指定的中央打包器：

```bash
python <path-to-pack_skill.py> . --check-only
python <path-to-pack_skill.py> . -o agent-plugin-installer-v1.0.1.zip
```
