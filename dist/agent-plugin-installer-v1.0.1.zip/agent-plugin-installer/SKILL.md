---
name: agent-plugin-installer
description: "Inspect local ZIP skills and plan safe cross-agent installation."
license: MIT
compatibility: "Requires Python 3 and an existing Hermes, Codex, or Claude Code installation."
metadata:
  version: 1.0.1
  language: zh-TW
  category: ops
  supported_hosts: [hermes, codex, claude-code]
  source_scope: local-zip-only
---
# Portable Agent Skill Installer

> **v1.0.1｜2026-08-22**：凍結本機 ZIP 辨識、跨 Agent 相容性計畫、確認閘門與回復契約。ZIP 預檢政策與版本變更見 `references/zip-inspection-policy.md`。

## When to Use

當使用者要把本機 ZIP 打包的 Skill、Plugin、Desktop Plugin 或 MCP bundle 安全安裝到 Hermes Agent、Codex CLI／IDE 或 Claude Code 時使用。

不要用於遠端 URL、Git repository、套件管理器、未經使用者確認的執行檔啟動，或宣稱平台原生 Plugin 可以跨平台直接啟用的情境。

## 能力邊界

做得到：讀取本機 ZIP、建立內容索引、檢查安全風險、辨識套件面、產生平台相容性矩陣、產生 dry-run 計畫、在確認相同 plan digest 後安裝可攜部分、建立 rollback manifest、驗證當前產出，以及回復或移除已安裝內容。

不做：猜測遠端來源可信度、執行未經確認的 Python／Node／EXE、把 Hermes Desktop Plugin 偽裝成 Codex 或 Claude Code 功能、將缺少必要 manifest 的資料夾默認當成合法 Plugin、或在部分安裝後宣稱整包 PASS。

## Quick Reference

核心流程：

```text
inspect → dry-run plan → 顯示風險與 plan_digest → 使用者確認 → apply exact plan → verify → rollback manifest
```

結果狀態：

```text
PASS       所有要求的部分都已安裝並驗證。
PARTIAL    可攜部分已安裝，原生或平台不支援部分已清楚列出。
BLOCKED    安全、契約、衝突或必要輸入檢查失敗，未寫入任何部分。
```

CLI：

```bash
python scripts/inspect_zip.py <local.zip> --agent <hermes|codex|claude-code> --scope user --root <root> --output plan.json
python scripts/apply_plan.py plan.json --confirm <plan_digest>
python scripts/verify.py <rollback_manifest.json>
python scripts/rollback.py <rollback_manifest.json>
```

`apply_plan.py` 只複製經確認的檔案，不會啟動 MCP、Plugin runtime 或 ZIP 內的執行檔。計畫輸出中的 `manual_activation` 與 `activation_command` 必須另行審核。

平台目的地預設為使用者層級。專案層級必須由使用者明確指定。

## Prerequisites

• Python 3 標準函式庫。不得要求使用者先安裝第三方 Python 或 Node 套件。

• 目標平台已存在的 CLI 或 Skill 目錄。Hermes、Codex、Claude Code 的具體路徑與命令由對應 adapter 負責。

• 本機 ZIP。v1.0.0 不處理 HTTPS 或 Git 來源。

## Procedure

### 1．預檢來源

取得 ZIP 的絕對路徑，計算內容雜湊，建立檔案索引。ZIP 預檢的 hard blocker、advisory warning 與 plan 輸出規則見 `references/zip-inspection-policy.md`。

預檢必須是唯讀操作。hard blocker 失敗時回傳 BLOCKED，不可進入安裝階段；warning 必須保留在 report 與 plan 供使用者確認。

### 2．辨識套件面

依 `references/package-taxonomy.md` 辨識下列套件面：

• 標準 Agent Skill：存在 `SKILL.md`。

• Hermes 原生 Plugin：存在 `plugin.yaml` 與 Plugin 入口。

• Hermes Desktop Plugin：存在 `desktop-plugins/<id>/plugin.js`。

• MCP bundle：存在 MCP launcher、MCP manifest 或明確的 host 設定。

• Mixed bundle：同時包含兩種以上套件面。

只依實際檔案與 manifest 判定，不依 ZIP 檔名猜測。

### 3．建立 dry-run 計畫

計畫至少包含：來源 ZIP 雜湊、套件面、版本、目標 Agent、目標層級、目的地、檔案衝突、啟用動作、執行檔風險、warnings、可攜部分、Unsupported 部分、回復路徑與 plan_digest。

沒有必要輸入時必須 fail-closed。不能用空清單代表檢查通過。

### 4．取得確認

把計畫與風險摘要呈現給使用者。只有使用者明確確認相同 plan_digest，才可進入 apply。

確認不包含執行權限。若需要啟動 MCP、Plugin runtime 或 Desktop Plugin，必須把啟動列為獨立副作用，重新要求確認。

### 5．套用精確計畫

apply 階段重新讀取 ZIP，重新計算雜湊並比對 plan_digest。任何內容、目的地或平台狀態改變都必須停止，不得套用過期計畫。

預設不覆寫既有不同內容。若使用者要覆寫，必須在計畫中明確列出覆寫檔案與 rollback 資訊。

### 6．平台適配

• Hermes Agent：可攜 Skill、Hermes Plugin、Desktop Plugin 與 MCP bundle 由 Hermes adapter 分流。

• Codex CLI／IDE：只把標準 Skill 安裝到適當的 `.agents/skills` 位置。Hermes 原生面列為 UNSUPPORTED。

• Claude Code：只把標準 Skill 安裝到適當的 `.claude/skills` 位置。Hermes 原生面列為 UNSUPPORTED。

平台不支援的部分不可複製到猜測的目錄，也不可偽造啟用結果。

### 7．驗證與回復

驗證器必須讀取本次實際安裝的檔案，不得只驗暫存目錄或寫死範例。驗證成功後才寫入 rollback manifest。

若任何必要 gate 失敗，結論只能是 BLOCKED。若可攜部分成功但原生部分不支援，結論只能是 PARTIAL。

## 三種模式

• 套用：依既有 package taxonomy 與平台 adapter 安全安裝。

• 探索：只做 ZIP 稽核、相容性矩陣與 dry-run，不寫入任何目標目錄。

• 模仿：以使用者提供的參考 ZIP 只抽取目錄與 manifest 形狀，不能複製可疑 runtime、秘密或平台專用副作用。

## Pitfalls

• ZIP 內有 `SKILL.md` 不代表整包能在三個平台啟用。原生 Plugin 與 MCP 必須逐面判定。

• `PARTIAL` 不是成功的同義詞。回報時必須分開列出 PASS、UNSUPPORTED、SKIPPED 與 BLOCKED。

• 不得在讀取 ZIP 時執行其內的程式。檢查、計畫、套用檔案與啟動 runtime 是四個不同階段。

• 不得因目的地不存在就自動建立未知平台的目錄。目的地必須由 adapter 提供。

• 不得以同一套解析結果同時作為產出與驗證依據。驗證必須重新讀取當前產出。

## Verification

交付前必須通過：

1．ZIP 安全負向測試：故意加入絕對路徑、`..`、NUL、符號連結與大小寫碰撞，驗證器必須非 0。

2．分類負向測試：缺少必要 manifest、混合 bundle 不完整、未知套件面都必須被清楚標示，不得默認 PASS。

3．目的地測試：Hermes、Codex、Claude Code 的使用者層級與專案層級路徑必須不同且可預測。

4．plan digest 測試：ZIP 或目的地改變後，舊計畫必須拒絕套用。

5．回復測試：故意製造部分套用失敗，必須能依 rollback manifest 還原已寫入內容。

6．格式測試：繁體中文文件通過全形標點與禁破折號驗證器。

打包時使用 Joan 房規指定的 `assets/pack_skill.py`，不使用 GUI 壓縮軟體。打包後用 `zipfile.namelist()` 回讀檔名與 CRC。

## Delivery

每次交付後回報實際產出、驗證命令、PASS／PARTIAL／BLOCKED 狀態與剩餘風險，並詢問使用者是否滿意。若不滿意，回到計畫或內容修正，不修改已凍結契約。
