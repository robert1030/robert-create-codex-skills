# v1.0.0 相容性矩陣

## 矩陣用途

本文件固定三個 Agent 的共同相容面、平台專用面與降級語意。它不是功能宣傳，也不能被解讀成所有平台都能啟用同一套 Plugin。

## 平台定義

### Hermes Agent

使用者層級的 Skill 目錄由目前 Hermes 的 `HERMES_HOME` 決定。原生 Plugin、Desktop Plugin 與 MCP 必須透過 Hermes 自己的 CLI 或官方目錄處理。

### Codex CLI／IDE

共同 Skill 以 Agent Skills 目錄為目標。使用者層級預設使用 `$HOME/.agents/skills`，專案層級使用專案內 `.agents/skills`。Codex 原生 Plugin 若未提供專用 adapter，只能列為 UNSUPPORTED。

### Claude Code CLI

共同 Skill 的使用者層級預設使用 `$HOME/.claude/skills`，專案層級使用專案內 `.claude/skills`。Claude Code 的 Plugin 或 MCP 行為不因檔案名稱相似就自動推導，沒有專用 adapter 就列為 UNSUPPORTED。

## 套件面判定

### 標準 Agent Skill

必要條件：至少存在一個有效的 `SKILL.md`，且 frontmatter 有 `name` 與 `description`。

Hermes：PASS。

Codex：PASS。

Claude Code：PASS。

### Hermes 原生 Plugin

必要條件：存在 `plugin.yaml`，且有可辨識的 Plugin 入口。

Hermes：依 manifest 與能力檢查結果 PASS、PARTIAL 或 BLOCKED。

Codex：UNSUPPORTED，除非未來提供 Codex adapter。

Claude Code：UNSUPPORTED，除非未來提供 Claude adapter。

### Hermes Desktop Plugin

必要條件：存在 `desktop-plugins/<id>/plugin.js`，且使用受支援的 Desktop SDK import。

Hermes：可安裝到 `$HERMES_HOME/desktop-plugins/<id>/`，啟用前需要明確確認。

Codex：UNSUPPORTED。

Claude Code：UNSUPPORTED。

### MCP bundle

必要條件：存在 MCP launcher、MCP server manifest，或 README 明確提供 host 設定。

Hermes：可建立 MCP 設定，但連線與工具啟用是獨立副作用，必須再次確認。

Codex：v1.0.0 只辨識，不啟用。

Claude Code：v1.0.0 只辨識，不啟用。

### Mixed bundle

同時存在兩種以上套件面時，逐面產生結果。可攜 Skill PASS 而 Hermes 原生面 UNSUPPORTED 時，總結果為 PARTIAL，不得合併成單一 PASS。

## 狀態語意

`PASS`：該套件面在指定平台已安裝且當前產出驗證通過。

`PARTIAL`：至少一個可攜套件面 PASS，另有平台不支援、未啟用或被使用者跳過的套件面。

`UNSUPPORTED`：平台沒有對應 adapter，未複製、未啟用、未宣稱成功。

`SKIPPED`：使用者或計畫明確跳過，必須保留原因。

`BLOCKED`：安全、契約、衝突或必要輸入 gate 失敗。

## 目的地規則

所有目的地必須由 adapter 回傳，不由核心根據作業系統猜測。目的地至少要包含：平台、層級、絕對路徑、現有內容雜湊與預期回復路徑。

使用者層級是預設。專案層級需要明確的 project root。若 project root 無法可靠辨識，必須 BLOCKED。

## 版本與未知欄位

沒有版本欄位時，不能猜測版本。應回報 `version: unknown`，並把內容雜湊作為唯一識別。

未知 frontmatter 欄位不能直接刪除或改寫。核心只驗證共同必要欄位；平台專用欄位交給對應 adapter 判定。
