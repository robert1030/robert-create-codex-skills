# ZIP 套件分類契約

## 分類優先順序

分類器先做安全預檢，再做檔案索引，最後才依 manifest 與目錄形狀分類。ZIP 檔名、README 的宣傳文字與作者自稱不能單獨決定分類。

## 分類

### standard-skill

條件：存在 `SKILL.md`，frontmatter 可解析，且包含 `name` 與 `description`。

安裝面：Hermes、Codex、Claude Code 的共同可攜面。

### hermes-plugin

條件：存在 `plugin.yaml`，且 manifest 宣告的入口檔存在。缺入口時為 `BLOCKED`，不能只因有 manifest 就 PASS。

安裝面：Hermes Agent。

### desktop-plugin

條件：存在 `desktop-plugins/<id>/plugin.js`，Plugin id 與資料夾可對應，且入口沒有明顯未解析的本機路徑佔位符。

安裝面：Hermes Desktop。

### mcp-bundle

條件：存在 MCP launcher、MCP server manifest，或設定範例明確指定 command、args 與 host。

安裝面：由有 adapter 的 Agent 處理。v1.0.0 只有 Hermes 可啟用。

### mixed-bundle

條件：同一 ZIP 同時符合兩個以上分類。

處理方式：逐面產生安裝計畫，不把所有檔案複製到同一個目錄。

### unknown

條件：沒有有效的標準 Skill、Plugin、Desktop Plugin 或 MCP 證據。

處理方式：只回傳分類報告與缺少的證據，結果為 `BLOCKED`，不安裝。

## 安全預檢

以下任一項出現時，預設 `BLOCKED`：

• 絕對路徑，例如 `/etc/passwd`、`C:\Windows\System32\x` 或 UNC 路徑。

• 含有 `..` 的路徑元件。

• NUL 字元。

• ZIP symlink 或其他非一般檔案型別。

• 解壓後檔案總大小超過計畫上限。

• 同一目錄下的大小寫碰撞。

• Windows 保留名稱、結尾句點或空格。

• 目的地已存在不同內容但計畫沒有明確的覆寫與回復紀錄。

執行檔、shell script、Node launcher 與 MCP runtime 不一定代表惡意，但都必須列入風險摘要，且不得在 inspect 或 apply 階段自動執行。

## 失敗語意

分類不完整時不能以空清單放行。缺少必要 manifest、入口或來源證據時，應標為 `BLOCKED` 或 `UNSUPPORTED`，並列出補件條件。
