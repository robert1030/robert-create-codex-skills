# ZIP Inspection Policy

本文件定義 ZIP 預檢的 hard blocker、advisory warning 與 plan 輸出邊界。安裝器只讀取 ZIP，不執行其中的 Python、Node、shell、EXE 或 MCP runtime。

## Hard blockers

以下任一項必須放入 `issues`，預檢狀態為 `BLOCKED`，不得產生可套用計畫：

• 絕對路徑、UNC 路徑或 Windows 絕對路徑。

• `..` 路徑元件、NUL 字元或符號連結。

• 同一目錄下的大小寫碰撞或重複路徑。

• Windows 保留名稱、結尾句點或空格。

• 路徑、單一成員、總解壓大小或檔案數超過上限。

• ZIP 損毀、必要 frontmatter 無法解析、未知套件面或必要 manifest／入口缺失。

• 目的地衝突未在計畫中明確列出覆寫與 rollback 資訊。

## Advisory warnings

非 ASCII 成員路徑只放入 `warnings`，不放入 `issues`。在目標平台支援 UTF-8 路徑時，非 ASCII 路徑不應單獨造成 `BLOCKED`。

`warnings` 必須：

• 在 inspect report 中保留完整成員路徑。

• 原樣帶入 dry-run plan，供使用者在確認 `plan_digest` 前審閱。

• 不改變 `DETECTED`、`PASS` 或 `PARTIAL` 的狀態判定。

若目標平台或 adapter 有額外的編碼限制，應由該 adapter 明確回報 `UNSUPPORTED` 或 `BLOCKED`，不可由通用 ZIP inspector 猜測。

## v1.0.1 change

v1.0.1 將 v1.0.0 中過度保守的非 ASCII 路徑硬性阻擋改為 advisory warning。其他路徑安全檢查、分類契約、確認閘門、plan digest、apply、verify 與 rollback 行為不變。

## Verification boundary

這份政策只處理 ZIP 成員名稱、大小、類型、manifest 與目的地契約。Python、Node、shell、EXE、MCP launcher、subprocess、sudo 或環境變數存取仍須列入 `risks` 或安全掃描結果，不能因路徑預檢通過就視為內容安全。
