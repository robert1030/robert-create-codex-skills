#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Adapter registry for the portable ZIP installer."""
from __future__ import annotations

from . import claude_code, codex, hermes

ADAPTERS = {
    hermes.NAME: hermes,
    codex.NAME: codex,
    claude_code.NAME: claude_code,
}


def get_adapter(agent: str):
    try:
        return ADAPTERS[agent]
    except KeyError as exc:
        raise ValueError(f"unsupported agent: {agent}") from exc
