#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Claude Code adapter for portable Agent Skills."""
from __future__ import annotations

from pathlib import Path

NAME = "claude-code"
SUPPORTED_SURFACES = frozenset({"standard-skill"})


def supports(surface: str) -> bool:
    return surface in SUPPORTED_SURFACES


def destination(root: str, scope: str, surface: str, item_id: str) -> str:
    if surface != "standard-skill":
        raise ValueError(f"Claude Code adapter does not support {surface}")
    base = Path(root.replace("\\", "/").rstrip("/"))
    if scope not in {"user", "project"}:
        raise ValueError(f"unsupported scope: {scope}")
    return (base / ".claude" / "skills" / item_id).as_posix()


def activation(surface: str, item_id: str, destination_path: str) -> dict[str, str]:
    return {"mode": "automatic", "command": "", "reason": "Claude Code scans the Agent Skills directory."}
