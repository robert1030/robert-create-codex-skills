#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Codex CLI and IDE adapter for portable Agent Skills."""
from __future__ import annotations

from pathlib import Path

NAME = "codex"
SUPPORTED_SURFACES = frozenset({"standard-skill"})


def supports(surface: str) -> bool:
    return surface in SUPPORTED_SURFACES


def destination(root: str, scope: str, surface: str, item_id: str) -> str:
    if surface != "standard-skill":
        raise ValueError(f"Codex adapter does not support {surface}")
    base = Path(root.replace("\\", "/").rstrip("/"))
    if scope not in {"user", "project"}:
        raise ValueError(f"unsupported scope: {scope}")
    return (base / ".agents" / "skills" / item_id).as_posix()


def activation(surface: str, item_id: str, destination_path: str) -> dict[str, str]:
    return {"mode": "automatic", "command": "", "reason": "Codex scans the Agent Skills directory."}
