#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Hermes Agent adapter for the portable ZIP installer."""
from __future__ import annotations

from pathlib import Path

NAME = "hermes"
SUPPORTED_SURFACES = frozenset(
    {"standard-skill", "hermes-plugin", "desktop-plugin", "mcp-bundle"}
)


def supports(surface: str) -> bool:
    return surface in SUPPORTED_SURFACES


def destination(root: str, scope: str, surface: str, item_id: str) -> str:
    base = Path(root.replace("\\", "/").rstrip("/"))
    if scope == "user":
        roots = {
            "standard-skill": base / "skills",
            "hermes-plugin": base / "plugins",
            "desktop-plugin": base / "desktop-plugins",
            "mcp-bundle": base / "bundles",
        }
    elif scope == "project":
        roots = {
            "standard-skill": base / ".hermes" / "skills",
            "hermes-plugin": base / ".hermes" / "plugins",
        }
    else:
        raise ValueError(f"unsupported scope: {scope}")
    if surface not in roots:
        raise ValueError(f"Hermes does not support {surface} at {scope} scope")
    return (roots[surface] / item_id).as_posix()


def activation(surface: str, item_id: str, destination_path: str) -> dict[str, str]:
    if surface == "hermes-plugin":
        return {
            "mode": "manual-confirmation",
            "command": f"hermes plugins enable {item_id}",
            "reason": "啟用 Hermes 原生 Plugin 會載入外部程式碼。",
        }
    if surface == "desktop-plugin":
        return {
            "mode": "hot-reload-or-restart",
            "command": "Reload desktop plugins",
            "reason": "Desktop Plugin 複製後需要重新載入或重啟 Hermes Desktop。",
        }
    if surface == "mcp-bundle":
        return {
            "mode": "manual-confirmation",
            "command": "inspect bundle README and run hermes mcp add",
            "reason": "MCP 連線會啟動 runtime 並載入外部工具。",
        }
    return {"mode": "automatic", "command": "", "reason": "Hermes Skill 由目錄掃描載入。"}
