#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fail-closed file application for an inspected installation plan."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from zipfile import ZipFile

from contract_guards import inspect_member_name
from verify_engine import verify_manifest
from zip_inspector import compute_plan_digest, inspect_archive


class ApplyError(RuntimeError):
    """Raised before or during a guarded plan application."""


def _sha256_bytes(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _same_zip_member(archive: ZipFile, member: str, target: Path) -> bool:
    if not target.is_file():
        return False
    info = archive.getinfo(member)
    with archive.open(info, "r") as source, target.open("rb") as existing:
        while True:
            left = source.read(1024 * 1024)
            right = existing.read(1024 * 1024)
            if left != right:
                return False
            if not left:
                return True


def _zip_member_sha256(archive: ZipFile, member: str) -> str:
    digest = hashlib.sha256()
    with archive.open(archive.getinfo(member), "r") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_target(root: Path, destination: Path, relative: str) -> Path:
    if not relative or relative.startswith("/"):
        raise ApplyError(f"invalid relative destination: {relative!r}")
    target = (destination / relative).resolve(strict=False)
    root_resolved = root.resolve(strict=False)
    if not target.is_relative_to(root_resolved):
        raise ApplyError(f"destination escapes selected root: {target}")
    return target


def _manifest_path(plan: dict[str, Any]) -> Path:
    root = Path(plan["root"])
    relative = str(plan["rollback_manifest"]).replace("/", os.sep)
    path = (root / relative).resolve(strict=False)
    if not path.is_relative_to(root.resolve(strict=False)):
        raise ApplyError("rollback manifest escapes selected root")
    return path


def apply_plan(plan: dict[str, Any], *, confirmation: str) -> dict[str, Any]:
    """Apply only an exact, clean plan and create a rollback manifest."""
    if plan.get("status") not in {"PASS", "PARTIAL"}:
        raise ApplyError(f"plan status cannot be applied: {plan.get('status')}")
    if not confirmation or confirmation != plan.get("plan_digest"):
        raise ApplyError("confirmation does not match plan_digest")
    if compute_plan_digest(plan) != plan.get("plan_digest"):
        raise ApplyError("plan_digest is invalid or plan was modified")

    source = Path(plan["source_zip"]).expanduser().resolve()
    report = inspect_archive(source)
    if report.get("status") != "DETECTED":
        raise ApplyError("source ZIP no longer passes inspection")
    if report.get("source_sha256") != plan.get("source_sha256"):
        raise ApplyError("source ZIP changed after plan generation")

    root = Path(plan["root"]).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    pending: list[tuple[str, Path, Any, str]] = []
    conflicts: list[str] = []
    unchanged: list[str] = []

    with ZipFile(source) as archive:
        for operation in plan.get("operations", []):
            prefix = operation.get("source_prefix", "")
            destination = Path(operation["destination"]).expanduser().resolve()
            if not destination.is_relative_to(root):
                raise ApplyError(f"operation destination escapes root: {destination}")
            for member in operation.get("files", []):
                info = archive.getinfo(member)
                check = inspect_member_name(member, (info.external_attr >> 16) & 0xFFFF)
                if not check.ok:
                    raise ApplyError(f"planned member became unsafe: {check.reason}: {member}")
                if prefix and not member.startswith(prefix):
                    raise ApplyError(f"member is outside operation prefix: {member}")
                relative = member[len(prefix) :] if prefix else member
                target = _safe_target(root, destination, relative)
                if target.exists():
                    if _same_zip_member(archive, member, target):
                        unchanged.append(str(target).replace("\\", "/"))
                    else:
                        conflicts.append(str(target).replace("\\", "/"))
                else:
                    pending.append((member, target, info, _zip_member_sha256(archive, member)))

        if conflicts:
            raise ApplyError("existing file conflicts: " + ", ".join(sorted(conflicts)))

        created: list[str] = []
        file_hashes: dict[str, str] = {}
        try:
            for member, target, info, expected_hash in pending:
                target.parent.mkdir(parents=True, exist_ok=True)
                with tempfile.NamedTemporaryFile(
                    mode="wb", prefix=".agent-plugin-installer-", dir=target.parent, delete=False
                ) as temporary:
                    temp_path = Path(temporary.name)
                    with archive.open(info, "r") as source_handle:
                        shutil.copyfileobj(source_handle, temporary, length=1024 * 1024)
                    temporary.flush()
                    os.fsync(temporary.fileno())
                os.replace(temp_path, target)
                if _sha256_bytes(target) != expected_hash:
                    target.unlink(missing_ok=True)
                    raise ApplyError(f"written file differs from ZIP source: {member}")
                normalized = str(target).replace("\\", "/")
                created.append(normalized)
                file_hashes[normalized] = expected_hash
        except Exception as exc:
            for created_path in reversed(created):
                try:
                    Path(created_path).unlink(missing_ok=True)
                except OSError:
                    pass
            raise ApplyError(f"apply failed and created files were removed: {exc}") from exc

    manifest = {
        "manifest_version": "1.0.0",
        "plan_id": plan["plan_id"],
        "plan_digest": plan["plan_digest"],
        "source_zip": plan["source_zip"],
        "source_sha256": plan["source_sha256"],
        "root": str(root).replace("\\", "/"),
        "created_files": created,
        "unchanged_files": unchanged,
        "file_hashes": file_hashes,
        "manual_activation": [
            {"surface": op["surface"], "item_id": op["item_id"], "destination": op["destination"]}
            for op in plan.get("operations", [])
            if op.get("activation") == "manual-confirmation"
        ],
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    manifest_path = _manifest_path(plan)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_manifest = manifest_path.with_suffix(manifest_path.suffix + ".tmp")
    temporary_manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary_manifest, manifest_path)
    verification = verify_manifest(manifest_path)
    if verification["status"] != "PASS":
        from rollback_engine import rollback_manifest

        rollback_manifest(manifest_path)
        raise ApplyError("post-apply verification failed; created files were rolled back")
    result_status = "PARTIAL" if plan.get("status") == "PARTIAL" else "PASS"
    return {
        "status": result_status,
        "plan_id": plan["plan_id"],
        "manifest_path": str(manifest_path).replace("\\", "/"),
        "created_files": created,
        "unchanged_files": unchanged,
        "manual_activation": manifest["manual_activation"],
    }
