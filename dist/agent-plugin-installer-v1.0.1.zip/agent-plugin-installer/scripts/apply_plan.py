#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CLI for applying an exact dry-run plan after explicit confirmation."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from apply_engine import ApplyError, apply_plan


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Apply an exact agent-plugin-installer plan")
    parser.add_argument("plan", help="JSON plan produced by inspect_zip.py")
    parser.add_argument("--confirm", required=True, help="exact plan_digest shown in the dry-run")
    args = parser.parse_args(argv)
    try:
        plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
        result = apply_plan(plan, confirmation=args.confirm)
    except (OSError, json.JSONDecodeError, ApplyError) as exc:
        print(f"BLOCKED: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] in {"PASS", "PARTIAL"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
