#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pure v1 contract guards for agent-plugin-installer.

This module deliberately has no installation side effects. It only validates
member names, classifies package surfaces, maps destinations, and compares
plan digests.
"""
from __future__ import annotations

import re
import stat
from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Iterable


_WINDOWS_ABSOLUTE = re.compile(r"^[A-Za-z]:/")


@dataclass(frozen=True)
class Inspection:
    ok: bool
    reason: str = ""


@dataclass(frozen=True)
class Classification:
    kind: str
    surfaces: tuple[str, ...]
    status: str


def inspect_member_name(name: str, mode: int = 0) -> Inspection:
    """Return a fail-closed safety result for one ZIP member."""
    if "\x00" in name:
        return Inspection(False, "NUL character")

    normalized = name.replace("\\", "/")
    if normalized.startswith("/") or normalized.startswith("//"):
        return Inspection(False, "absolute path")
    if _WINDOWS_ABSOLUTE.match(normalized):
        return Inspection(False, "Windows absolute path")
    if stat.S_ISLNK(mode):
        return Inspection(False, "symbolic link")

    parts = PurePosixPath(normalized).parts
    if ".." in parts:
        return Inspection(False, "parent traversal")
    if not parts or normalized.endswith("/"):
        return Inspection(False, "empty or directory-only member")
    return Inspection(True)


def classify_members(members: Iterable[str]) -> Classification:
    """Classify package surfaces from an indexed member-name set."""
    names = {member.replace("\\", "/").lstrip("./") for member in members}
    surfaces: list[str] = []

    has_skill = any(name == "SKILL.md" or name.endswith("/SKILL.md") for name in names)
    if has_skill:
        surfaces.append("standard-skill")

    has_hermes_plugin = (
        any(name == "plugin.yaml" or name.endswith("/plugin.yaml") for name in names)
        and any(name == "__init__.py" or name.endswith("/__init__.py") for name in names)
    )
    if has_hermes_plugin:
        surfaces.append("hermes-plugin")

    desktop_pattern = re.compile(r"(?:^|/)desktop-plugins/[^/]+/plugin\.js$")
    if any(desktop_pattern.search(name) for name in names):
        surfaces.append("desktop-plugin")

    has_mcp = any(
        name.endswith(("/launch-mcp.mjs", "/launch-mcp.py", "/mcp_server.py"))
        or name in {"launch-mcp.mjs", "launch-mcp.py", "mcp_server.py"}
        or "/mcp/" in name
        for name in names
    )
    if has_mcp:
        surfaces.append("mcp-bundle")

    if not surfaces:
        return Classification("unknown", (), "BLOCKED")
    if len(surfaces) > 1:
        return Classification("mixed-bundle", tuple(surfaces), "DETECTED")
    return Classification(surfaces[0], tuple(surfaces), "DETECTED")


def destination_for(agent: str, scope: str, surface: str, root: str) -> str:
    """Return the v1 destination for a standard Skill.

    The v1 contract intentionally exposes only the portable Skill destination.
    Native surfaces must be mapped by their platform adapter before apply.
    """
    from adapters import get_adapter

    if surface != "standard-skill":
        raise ValueError("destination_for only maps the standard-skill surface")
    return get_adapter(agent).destination(root, scope, surface, "example")


def verify_plan_digest(expected: str, actual: str) -> bool:
    """Require an exact, non-empty digest match before apply."""
    return bool(expected and actual and expected == actual)
