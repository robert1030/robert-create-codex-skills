#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CLI for read-only local ZIP inspection and dry-run plan generation."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from zip_inspector import (
    DEFAULT_MAX_FILES,
    DEFAULT_MAX_MEMBER_BYTES,
    DEFAULT_MAX_TOTAL_BYTES,
    InspectionError,
    build_plan,
    inspect_archive,
)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Inspect a local ZIP and create a safe plan")
    parser.add_argument("zip_path", help="local ZIP file")
    parser.add_argument("--agent", choices=["hermes", "codex", "claude-code"])
    parser.add_argument("--scope", choices=["user", "project"], default="user")
    parser.add_argument("--root", help="user home, HERMES_HOME, or project root")
    parser.add_argument("--output", help="write JSON report or plan to this path")
    parser.add_argument("--max-files", type=int, default=DEFAULT_MAX_FILES)
    parser.add_argument("--max-total-bytes", type=int, default=DEFAULT_MAX_TOTAL_BYTES)
    parser.add_argument("--max-member-bytes", type=int, default=DEFAULT_MAX_MEMBER_BYTES)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if bool(args.agent) != bool(args.root):
        print("--agent and --root must be supplied together", file=sys.stderr)
        return 2
    try:
        report = inspect_archive(
            args.zip_path,
            max_files=args.max_files,
            max_total_bytes=args.max_total_bytes,
            max_member_bytes=args.max_member_bytes,
        )
        payload = report
        if args.agent:
            payload = build_plan(report, agent=args.agent, scope=args.scope, root=args.root)
    except InspectionError as exc:
        print(f"BLOCKED: {exc}", file=sys.stderr)
        return 2

    text = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        output = Path(args.output).expanduser()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(text, encoding="utf-8")
    print(text, end="")
    status = payload.get("status")
    return 0 if status in {"DETECTED", "PASS", "PARTIAL"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
