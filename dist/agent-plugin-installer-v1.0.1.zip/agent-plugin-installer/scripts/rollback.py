#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CLI for guarded rollback of an apply manifest."""
from __future__ import annotations

import argparse
import json
import sys

from rollback_engine import RollbackError, rollback_manifest


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Rollback a agent-plugin-installer manifest")
    parser.add_argument("manifest", help="rollback manifest JSON")
    args = parser.parse_args(argv)
    try:
        result = rollback_manifest(args.manifest)
    except RollbackError as exc:
        print(f"BLOCKED: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
