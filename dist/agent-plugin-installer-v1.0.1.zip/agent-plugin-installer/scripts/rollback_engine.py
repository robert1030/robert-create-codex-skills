#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Rollback engine for manifests produced by apply_engine."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


class RollbackError(RuntimeError):
    """Raised when a rollback manifest is invalid."""


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def rollback_manifest(manifest_path: str | Path) -> dict[str, Any]:
    path = Path(manifest_path).expanduser().resolve()
    if not path.is_file():
        raise RollbackError(f"manifest does not exist: {path}")
    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RollbackError(f"invalid manifest: {path}") from exc

    removed: list[str] = []
    modified: list[str] = []
    missing: list[str] = []
    for raw_path in manifest.get("created_files", []):
        target = Path(raw_path)
        expected = manifest.get("file_hashes", {}).get(raw_path)
        if not target.exists():
            missing.append(raw_path)
            continue
        if not target.is_file() or not expected or _sha256(target) != expected:
            modified.append(raw_path)
            continue
        target.unlink()
        removed.append(raw_path)

    for raw_path in removed:
        target = Path(raw_path).parent
        root = Path(manifest.get("root", target.anchor))
        while target != root and target.exists():
            try:
                target.rmdir()
            except OSError:
                break
            target = target.parent

    return {
        "status": "PARTIAL" if modified else "PASS",
        "manifest_path": str(path).replace("\\", "/"),
        "removed_files": removed,
        "modified_files": modified,
        "missing_files": missing,
    }
