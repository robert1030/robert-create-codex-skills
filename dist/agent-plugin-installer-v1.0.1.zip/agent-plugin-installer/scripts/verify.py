#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CLI for independent verification of a rollback manifest."""
from __future__ import annotations

import argparse
import json
import sys

from verify_engine import VerificationError, verify_manifest


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Verify current files against a rollback manifest")
    parser.add_argument("manifest", help="rollback manifest JSON")
    args = parser.parse_args(argv)
    try:
        result = verify_manifest(args.manifest)
    except VerificationError as exc:
        print(f"BLOCKED: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
