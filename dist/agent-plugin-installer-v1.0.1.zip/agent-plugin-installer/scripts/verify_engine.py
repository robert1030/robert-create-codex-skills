#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independent verification of files recorded in a rollback manifest."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


class VerificationError(RuntimeError):
    """Raised when a manifest cannot be verified."""


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_manifest(manifest_path: str | Path) -> dict[str, Any]:
    path = Path(manifest_path).expanduser().resolve()
    if not path.is_file():
        raise VerificationError(f"manifest does not exist: {path}")
    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise VerificationError(f"invalid manifest: {path}") from exc

    missing: list[str] = []
    modified: list[str] = []
    verified: list[str] = []
    for raw_path in manifest.get("created_files", []):
        target = Path(raw_path)
        if not target.is_file():
            missing.append(raw_path)
            continue
        expected = manifest.get("file_hashes", {}).get(raw_path)
        if not expected or _sha256(target) != expected:
            modified.append(raw_path)
            continue
        verified.append(raw_path)

    status = "PASS" if not missing and not modified else "BLOCKED"
    return {
        "status": status,
        "manifest_path": str(path).replace("\\", "/"),
        "verified_files": verified,
        "missing_files": missing,
        "modified_files": modified,
    }
