#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Read-only ZIP inspection and v1 installation-plan generation."""
from __future__ import annotations

import hashlib
import json
import os
import re
import stat
from pathlib import Path, PurePosixPath
from typing import Any, Iterable
from zipfile import BadZipFile, ZipFile

from adapters import get_adapter
from contract_guards import classify_members, inspect_member_name


class InspectionError(ValueError):
    """Raised when a report cannot be turned into a safe plan."""


DEFAULT_MAX_FILES = 10_000
DEFAULT_MAX_TOTAL_BYTES = 512 * 1024 * 1024
DEFAULT_MAX_MEMBER_BYTES = 128 * 1024 * 1024
MAX_MEMBER_PATH_CHARS = 240
WINDOWS_RESERVED_NAMES = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{index}" for index in range(1, 10)),
    *(f"LPT{index}" for index in range(1, 10)),
}
EXECUTABLE_SUFFIXES = {".exe", ".dll", ".bat", ".cmd", ".ps1", ".sh", ".py", ".js", ".mjs"}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _frontmatter(text: str) -> dict[str, str]:
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}
    try:
        end = lines.index("---", 1)
    except ValueError:
        return {}
    result: dict[str, str] = {}
    for line in lines[1:end]:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key:
            result[key] = value
    return result


def _skill_metadata(archive: ZipFile, member: str) -> dict[str, str]:
    try:
        raw = archive.read(member)
        text = raw.decode("utf-8")
    except (UnicodeDecodeError, KeyError):
        return {"member": member, "name": "", "description": "", "valid": "false"}
    metadata = _frontmatter(text)
    name = metadata.get("name", "")
    description = metadata.get("description", "")
    return {
        "member": member,
        "name": name,
        "description": description,
        "version": metadata.get("version", ""),
        "valid": str(bool(name and description)).lower(),
    }


def _parent_prefix(member: str) -> str:
    parent = str(PurePosixPath(member).parent)
    return "" if parent == "." else parent.rstrip("/") + "/"


def _common_root(members: Iterable[str]) -> str:
    parts = [PurePosixPath(member).parts for member in members if member]
    if not parts:
        return ""
    common: list[str] = []
    for group in zip(*parts):
        if len({part for part in group}) != 1:
            break
        common.append(group[0])
    if not common:
        return ""
    return "/".join(common).rstrip("/") + "/"


def _package_id(report: dict[str, Any]) -> str:
    roots = report.get("top_level_roots") or []
    if len(roots) == 1 and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", roots[0]):
        candidate = roots[0].lower().replace("_", "-")
    else:
        candidate = Path(report["source_zip"]).stem.lower().replace("_", "-")
    candidate = re.sub(r"[^a-z0-9._-]+", "-", candidate).strip(".-")
    return candidate or "package"


def _path_safety_issues(name: str) -> list[str]:
    issues: list[str] = []
    normalized = name.replace("\\\\", "/")
    if len(normalized) > MAX_MEMBER_PATH_CHARS:
        issues.append(f"path length exceeds limit: {name}")
    for part in PurePosixPath(normalized).parts:
        if part in {"", "."}:
            continue
        if part.endswith((".", " ")):
            issues.append(f"trailing dot or space: {name}")
        stem = part.split(".", 1)[0].upper()
        if stem in WINDOWS_RESERVED_NAMES:
            issues.append(f"reserved Windows name: {name}")
    return issues


def _member_files(archive: ZipFile) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for info in archive.infolist():
        name = info.filename.replace("\\", "/")
        if info.is_dir() or name.endswith("/"):
            continue
        result.append(
            {
                "name": name,
                "size": info.file_size,
                "crc": info.CRC,
                "mode": (info.external_attr >> 16) & 0xFFFF,
            }
        )
    return result


def inspect_archive(
    source_zip: str | os.PathLike[str],
    *,
    max_files: int = DEFAULT_MAX_FILES,
    max_total_bytes: int = DEFAULT_MAX_TOTAL_BYTES,
    max_member_bytes: int = DEFAULT_MAX_MEMBER_BYTES,
) -> dict[str, Any]:
    """Inspect a local ZIP without extracting or executing its contents."""
    path = Path(source_zip).expanduser().resolve()
    base_report: dict[str, Any] = {
        "source_zip": str(path),
        "source_sha256": "",
        "status": "BLOCKED",
        "package_kind": "unknown",
        "surfaces": [],
        "members": [],
        "skills": [],
        "issues": [],
        "warnings": [],
        "risks": [],
        "top_level_roots": [],
        "package_id": path.stem.lower().replace("_", "-"),
    }
    if not path.is_file():
        base_report["issues"].append("source ZIP does not exist")
        return base_report

    base_report["source_sha256"] = sha256_file(path)
    try:
        archive = ZipFile(path)
    except (BadZipFile, OSError) as exc:
        base_report["issues"].append(f"invalid ZIP: {exc}")
        return base_report

    with archive:
        infos = archive.infolist()
        if len(infos) > max_files:
            base_report["issues"].append(f"file count exceeds limit: {len(infos)} > {max_files}")
        file_members = _member_files(archive)
        total_bytes = sum(item["size"] for item in file_members)
        if total_bytes > max_total_bytes:
            base_report["issues"].append(
                f"uncompressed size exceeds limit: {total_bytes} > {max_total_bytes}"
            )

        names: list[str] = []
        seen_exact: set[str] = set()
        seen_casefold: dict[str, str] = {}
        for item in file_members:
            name = item["name"]
            names.append(name)
            if item["size"] > max_member_bytes:
                base_report["issues"].append(
                    f"member exceeds size limit: {name} > {max_member_bytes}"
                )
            check = inspect_member_name(name, item["mode"])
            if not check.ok:
                base_report["issues"].append(f"{check.reason}: {name}")
            base_report["issues"].extend(_path_safety_issues(name))
            try:
                name.encode("ascii")
            except UnicodeEncodeError:
                base_report["warnings"].append(f"non-ASCII path: {name}")
            if Path(name).suffix.lower() in EXECUTABLE_SUFFIXES:
                base_report["risks"].append(f"executable or script payload: {name}")
            if name in seen_exact:
                base_report["issues"].append(f"duplicate path: {name}")
            seen_exact.add(name)
            folded = name.casefold()
            previous = seen_casefold.get(folded)
            if previous and previous != name:
                base_report["issues"].append(f"case collision: {previous} and {name}")
            seen_casefold[folded] = name

        roots = sorted({name.split("/", 1)[0] for name in names if name})
        base_report["members"] = file_members
        base_report["top_level_roots"] = roots
        classification = classify_members(names)
        base_report["package_kind"] = classification.kind
        base_report["surfaces"] = list(classification.surfaces)
        base_report["package_id"] = _package_id(base_report)

        skill_members = [name for name in names if name == "SKILL.md" or name.endswith("/SKILL.md")]
        base_report["skills"] = [_skill_metadata(archive, name) for name in skill_members]
        for skill in base_report["skills"]:
            if skill["valid"] != "true":
                base_report["issues"].append(f"invalid SKILL.md frontmatter: {skill['member']}")

        if classification.kind == "unknown":
            base_report["issues"].append("unknown package: no supported surface detected")

    base_report["issues"] = sorted(set(base_report["issues"]))
    base_report["warnings"] = sorted(set(base_report["warnings"]))
    base_report["status"] = "BLOCKED" if base_report["issues"] else "DETECTED"
    return base_report


def _destination(agent: str, scope: str, surface: str, root: str, item_id: str) -> str:
    adapter = get_adapter(agent)
    try:
        return adapter.destination(root, scope, surface, item_id)
    except ValueError as exc:
        raise InspectionError(str(exc)) from exc


def _skill_id(skill: dict[str, str]) -> str:
    name = skill.get("name", "")
    if re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", name):
        return name
    parent = PurePosixPath(skill["member"]).parent.name
    candidate = re.sub(r"[^a-z0-9_-]+", "-", parent.lower()).strip("-")
    return candidate or "skill"


def _surface_prefixes(report: dict[str, Any], surface: str) -> list[tuple[str, str]]:
    names = [item["name"] for item in report["members"]]
    result: list[tuple[str, str]] = []
    if surface == "standard-skill":
        for skill in report["skills"]:
            result.append((_parent_prefix(skill["member"]), _skill_id(skill)))
    elif surface == "hermes-plugin":
        for name in names:
            if name.endswith("/plugin.yaml") or name == "plugin.yaml":
                prefix = _parent_prefix(name)
                result.append((prefix, PurePosixPath(name).parent.name or report["package_id"]))
    elif surface == "desktop-plugin":
        for name in names:
            match = re.search(r"(?:^|/)desktop-plugins/([^/]+)/plugin\.js$", name)
            if match:
                prefix = name[: name.index("desktop-plugins/")]
                prefix += f"desktop-plugins/{match.group(1)}/"
                result.append((prefix, match.group(1)))
    elif surface == "mcp-bundle":
        result.append((_common_root(names), report["package_id"]))
    return result


def compute_plan_digest(plan: dict[str, Any]) -> str:
    payload = dict(plan)
    payload.pop("plan_digest", None)
    encoded = json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def build_plan(report: dict[str, Any], *, agent: str, scope: str, root: str) -> dict[str, Any]:
    if report.get("status") != "DETECTED":
        raise InspectionError("only a clean DETECTED report can produce a plan")
    if report.get("package_kind") == "unknown":
        raise InspectionError("unknown package cannot produce a plan")

    adapter = get_adapter(agent)
    operations: list[dict[str, Any]] = []
    unsupported: list[dict[str, str]] = []
    surfaces = list(report.get("surfaces", []))
    for surface in surfaces:
        supported = adapter.supports(surface)
        if not supported:
            unsupported.append({"surface": surface, "reason": f"no {agent} adapter in v1.0.0"})
            continue
        for prefix, item_id in _surface_prefixes(report, surface):
            destination = _destination(agent, scope, surface, root, item_id)
            files = [
                item["name"]
                for item in report["members"]
                if item["name"].startswith(prefix) and item["name"] != prefix
            ]
            if not files:
                raise InspectionError(f"surface has no files: {surface} {prefix}")
            activation = adapter.activation(surface, item_id, destination)
            operations.append(
                {
                    "surface": surface,
                    "item_id": item_id,
                    "source_prefix": prefix,
                    "destination": destination,
                    "files": files,
                    "activation": activation["mode"],
                    "activation_command": activation["command"],
                    "activation_reason": activation["reason"],
                }
            )

    status = "PASS" if operations and not unsupported else "PARTIAL" if operations else "BLOCKED"
    plan: dict[str, Any] = {
        "plan_version": "1.0.0",
        "plan_id": f"pa-si-{report['source_sha256'][:16]}-{agent}-{scope}",
        "status": status,
        "agent": agent,
        "scope": scope,
        "root": root.replace("\\", "/").rstrip("/"),
        "source_zip": report["source_zip"],
        "source_sha256": report["source_sha256"],
        "package_id": report["package_id"],
        "package_kind": report["package_kind"],
        "surfaces": surfaces,
        "operations": operations,
        "unsupported": unsupported,
        "risks": report.get("risks", []),
        "warnings": report.get("warnings", []),
        "conflicts": [],
        "side_effects": [
            operation["surface"]
            for operation in operations
            if operation["activation"] == "manual-confirmation"
        ],
        "rollback_manifest": f".agent-plugin-installer/rollbacks/{report['source_sha256'][:16]}.json",
    }
    plan["plan_digest"] = compute_plan_digest(plan)
    return plan
