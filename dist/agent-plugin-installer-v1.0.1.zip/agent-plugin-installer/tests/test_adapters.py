#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Adapter contract tests."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "scripts"))

from adapters import get_adapter  # noqa: E402


class AdapterTests(unittest.TestCase):
    def test_hermes_project_skill_uses_native_project_directory(self) -> None:
        adapter = get_adapter("hermes")
        self.assertEqual(
            adapter.destination("C:/repo", "project", "standard-skill", "demo"),
            "C:/repo/.hermes/skills/demo",
        )

    def test_hermes_project_desktop_plugin_is_rejected(self) -> None:
        adapter = get_adapter("hermes")
        with self.assertRaises(ValueError):
            adapter.destination("C:/repo", "project", "desktop-plugin", "demo")

    def test_codex_only_supports_portable_skill(self) -> None:
        adapter = get_adapter("codex")
        self.assertTrue(adapter.supports("standard-skill"))
        self.assertFalse(adapter.supports("hermes-plugin"))

    def test_claude_code_uses_project_skill_directory(self) -> None:
        adapter = get_adapter("claude-code")
        self.assertEqual(
            adapter.destination("C:/repo", "project", "standard-skill", "demo"),
            "C:/repo/.claude/skills/demo",
        )


if __name__ == "__main__":
    unittest.main()
