#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fail-closed apply and rollback tests."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "scripts"))

from apply_engine import ApplyError, apply_plan  # noqa: E402
from rollback_engine import rollback_manifest  # noqa: E402
from zip_inspector import build_plan, inspect_archive  # noqa: E402


class ApplyRollbackTests(unittest.TestCase):
    def _zip(self, content: str = "demo") -> Path:
        handle = tempfile.NamedTemporaryFile(suffix=".zip", delete=False)
        handle.close()
        path = Path(handle.name)
        with ZipFile(path, "w", ZIP_DEFLATED) as archive:
            archive.writestr(
                "demo/SKILL.md",
                f"---\nname: demo\ndescription: {content}\n---\n# {content}\n",
            )
        self.addCleanup(path.unlink, missing_ok=True)
        return path

    def _plan(self, archive: Path, root: Path) -> dict:
        report = inspect_archive(archive)
        return build_plan(report, agent="codex", scope="user", root=str(root))

    def test_apply_writes_and_creates_rollback_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            archive = self._zip()
            plan = self._plan(archive, root)
            result = apply_plan(plan, confirmation=plan["plan_digest"])
            target = root / ".agents/skills/demo/SKILL.md"
            self.assertTrue(target.is_file())
            self.assertEqual(result["status"], "PASS")
            self.assertTrue(Path(result["manifest_path"]).is_file())
            self.assertIn(str(target).replace("\\", "/"), result["created_files"])

    def test_digest_mismatch_writes_nothing(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            archive = self._zip()
            plan = self._plan(archive, root)
            with self.assertRaises(ApplyError):
                apply_plan(plan, confirmation="sha256:not-the-plan")
            self.assertFalse((root / ".agents").exists())

    def test_conflict_does_not_overwrite_existing_file(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            target = root / ".agents/skills/demo/SKILL.md"
            target.parent.mkdir(parents=True)
            target.write_text("user content", encoding="utf-8")
            archive = self._zip()
            plan = self._plan(archive, root)
            with self.assertRaises(ApplyError):
                apply_plan(plan, confirmation=plan["plan_digest"])
            self.assertEqual(target.read_text(encoding="utf-8"), "user content")

    def test_rollback_removes_only_unchanged_created_files(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            archive = self._zip()
            plan = self._plan(archive, root)
            result = apply_plan(plan, confirmation=plan["plan_digest"])
            target = root / ".agents/skills/demo/SKILL.md"
            target.write_text("user changed this after install", encoding="utf-8")
            rollback = rollback_manifest(result["manifest_path"])
            self.assertEqual(rollback["status"], "PARTIAL")
            self.assertTrue(target.exists())
            self.assertIn(str(target).replace("\\", "/"), rollback["modified_files"])


if __name__ == "__main__":
    unittest.main()
