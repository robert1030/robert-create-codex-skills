#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v1.0.0 contract tests.

These tests are intentionally written before the contract helper implementation.
Run with: python tests/test_contract_guards.py
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "scripts"))

from contract_guards import (  # noqa: E402
    classify_members,
    destination_for,
    inspect_member_name,
    verify_plan_digest,
)


class ZipSafetyTests(unittest.TestCase):
    def test_rejects_absolute_posix_path(self) -> None:
        self.assertFalse(inspect_member_name("/etc/passwd").ok)

    def test_rejects_absolute_windows_path(self) -> None:
        self.assertFalse(inspect_member_name("C:/Windows/System32/x").ok)

    def test_rejects_parent_traversal(self) -> None:
        self.assertFalse(inspect_member_name("skill/../../escape").ok)

    def test_rejects_nul_character(self) -> None:
        self.assertFalse(inspect_member_name("skill/SKILL.md\x00").ok)

    def test_rejects_symlink_mode(self) -> None:
        symlink_mode = 0o120777
        self.assertFalse(inspect_member_name("skill/link", symlink_mode).ok)


class ClassificationTests(unittest.TestCase):
    def test_mixed_skillnow_shape_is_mixed_bundle(self) -> None:
        members = {
            "skillnow/skills/example/SKILL.md",
            "skillnow/hermes-config.yaml.example",
            "skillnow/scripts/launch-mcp.mjs",
            "skillnow/desktop-plugins/example/plugin.js",
        }
        result = classify_members(members)
        self.assertEqual(result.kind, "mixed-bundle")
        self.assertIn("standard-skill", result.surfaces)
        self.assertIn("desktop-plugin", result.surfaces)
        self.assertIn("mcp-bundle", result.surfaces)

    def test_unknown_package_is_not_pass(self) -> None:
        result = classify_members({"README.md", "assets/logo.png"})
        self.assertEqual(result.kind, "unknown")
        self.assertNotEqual(result.status, "PASS")


class DestinationTests(unittest.TestCase):
    def test_hermes_user_skill_destination(self) -> None:
        result = destination_for("hermes", "user", "standard-skill", "D:/Hermes")
        self.assertEqual(result, "D:/Hermes/skills/example")

    def test_codex_project_destination_is_not_hermes_path(self) -> None:
        result = destination_for("codex", "project", "standard-skill", "C:/work/repo")
        self.assertEqual(result, "C:/work/repo/.agents/skills/example")
        self.assertNotIn("Hermes", result)

    def test_claude_project_destination_is_not_codex_path(self) -> None:
        result = destination_for("claude-code", "project", "standard-skill", "C:/work/repo")
        self.assertEqual(result, "C:/work/repo/.claude/skills/example")
        self.assertNotIn(".agents", result)


class PlanDigestTests(unittest.TestCase):
    def test_changed_plan_digest_is_rejected(self) -> None:
        self.assertFalse(verify_plan_digest("sha256:old", "sha256:new"))

    def test_exact_plan_digest_is_accepted(self) -> None:
        self.assertTrue(verify_plan_digest("sha256:same", "sha256:same"))


if __name__ == "__main__":
    unittest.main()
