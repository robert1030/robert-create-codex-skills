#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""驗證器自稽：乾淨文件必過，故意錯誤文件必紅燈。"""
from __future__ import annotations

import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VALIDATOR = Path("D:/Hermes/skills/joan-skill-conventions/assets/validate_punct.py")
GOOD = ROOT / "SKILL.md"
BAD = ROOT / "tests/fixtures/bad_punct.md"


class PunctuationGuardTests(unittest.TestCase):
    def test_clean_skill_passes(self) -> None:
        result = subprocess.run(
            [sys.executable, str(VALIDATOR), str(GOOD)],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_bad_fixture_fails_closed(self) -> None:
        result = subprocess.run(
            [sys.executable, str(VALIDATOR), str(BAD)],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("半形", result.stdout)
        self.assertIn("破折號", result.stdout)


if __name__ == "__main__":
    unittest.main()
