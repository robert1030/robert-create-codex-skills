#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independent current-output verification tests."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "scripts"))

from apply_engine import apply_plan  # noqa: E402
from verify_engine import verify_manifest  # noqa: E402
from zip_inspector import build_plan, inspect_archive  # noqa: E402


class VerificationTests(unittest.TestCase):
    def test_current_output_passes_independent_manifest_check(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            archive = base / "demo.zip"
            with ZipFile(archive, "w", ZIP_DEFLATED) as z:
                z.writestr("demo/SKILL.md", "---\nname: demo\ndescription: Demo\n---\n")
            plan = build_plan(inspect_archive(archive), agent="codex", scope="user", root=str(base / "home"))
            result = apply_plan(plan, confirmation=plan["plan_digest"])
            verification = verify_manifest(result["manifest_path"])
            self.assertEqual(verification["status"], "PASS")

    def test_tampered_current_output_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            archive = base / "demo.zip"
            with ZipFile(archive, "w", ZIP_DEFLATED) as z:
                z.writestr("demo/SKILL.md", "---\nname: demo\ndescription: Demo\n---\n")
            plan = build_plan(inspect_archive(archive), agent="codex", scope="user", root=str(base / "home"))
            result = apply_plan(plan, confirmation=plan["plan_digest"])
            target = base / "home/.agents/skills/demo/SKILL.md"
            target.write_text("tampered", encoding="utf-8")
            verification = verify_manifest(result["manifest_path"])
            self.assertEqual(verification["status"], "BLOCKED")
            self.assertIn(str(target).replace("\\", "/"), verification["modified_files"])


if __name__ == "__main__":
    unittest.main()
