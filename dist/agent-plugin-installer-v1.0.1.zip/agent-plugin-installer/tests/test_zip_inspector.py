#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ZIP inspector tests for the v1 vertical slice."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "scripts"))

from zip_inspector import (  # noqa: E402
    InspectionError,
    build_plan,
    compute_plan_digest,
    inspect_archive,
)


class ZipInspectorTests(unittest.TestCase):
    def _zip(self, entries: dict[str, str], symlink: str | None = None) -> Path:
        handle = tempfile.NamedTemporaryFile(suffix=".zip", delete=False)
        handle.close()
        path = Path(handle.name)
        with ZipFile(path, "w", ZIP_DEFLATED) as archive:
            for name, content in entries.items():
                archive.writestr(name, content)
            if symlink:
                info = ZipInfo(symlink)
                info.external_attr = (0o120777 << 16) | 0xA000
                archive.writestr(info, "target")
        self.addCleanup(path.unlink, missing_ok=True)
        return path

    def test_valid_mixed_bundle_is_classified(self) -> None:
        path = self._zip(
            {
                "skillnow/skills/demo/SKILL.md": "---\nname: demo\ndescription: Demo skill\n---\n# Demo\n",
                "skillnow/desktop-plugins/demo/plugin.js": "export default {};\n",
                "skillnow/scripts/launch-mcp.mjs": "console.log('mcp');\n",
            }
        )
        report = inspect_archive(path)
        self.assertEqual(report["status"], "DETECTED")
        self.assertEqual(report["package_kind"], "mixed-bundle")
        self.assertEqual(
            report["surfaces"], ["standard-skill", "desktop-plugin", "mcp-bundle"]
        )

    def test_parent_traversal_is_blocked(self) -> None:
        path = self._zip({"../escape.txt": "bad"})
        report = inspect_archive(path)
        self.assertEqual(report["status"], "BLOCKED")
        self.assertTrue(any("parent traversal" in issue for issue in report["issues"]))

    def test_symlink_is_blocked(self) -> None:
        path = self._zip({"safe.txt": "ok"}, symlink="link")
        report = inspect_archive(path)
        self.assertEqual(report["status"], "BLOCKED")
        self.assertTrue(any("symbolic link" in issue for issue in report["issues"]))

    def test_unknown_package_is_blocked(self) -> None:
        path = self._zip({"README.txt": "not a skill"})
        report = inspect_archive(path)
        self.assertEqual(report["status"], "BLOCKED")
        self.assertEqual(report["package_kind"], "unknown")

    def test_windows_reserved_name_is_blocked(self) -> None:
        path = self._zip({"demo/CON.txt": "bad"})
        report = inspect_archive(path)
        self.assertEqual(report["status"], "BLOCKED")
        self.assertTrue(any("reserved Windows name" in issue for issue in report["issues"]))

    def test_non_ascii_path_is_advisory(self) -> None:
        path = self._zip(
            {
                "SKILL.md": "---\nname: demo\ndescription: Demo skill\n---\n",
                "demo/參考.md": "ok",
            }
        )
        report = inspect_archive(path)
        self.assertEqual(report["status"], "DETECTED")
        self.assertTrue(any("non-ASCII path" in warning for warning in report["warnings"]))
        self.assertFalse(any("non-ASCII path" in issue for issue in report["issues"]))

    def test_non_ascii_warning_is_carried_into_plan(self) -> None:
        path = self._zip(
            {
                "SKILL.md": "---\nname: demo\ndescription: Demo skill\n---\n",
                "demo/參考.md": "ok",
            }
        )
        report = inspect_archive(path)
        plan = build_plan(report, agent="codex", scope="user", root="C:/Users/test")
        self.assertEqual(plan["status"], "PASS")
        self.assertEqual(plan["warnings"], report["warnings"])

    def test_uncompressed_size_limit_is_blocked(self) -> None:
        path = self._zip({"demo/SKILL.md": "x" * 20})
        report = inspect_archive(path, max_total_bytes=10)
        self.assertEqual(report["status"], "BLOCKED")
        self.assertTrue(any("uncompressed size exceeds limit" in issue for issue in report["issues"]))

    def test_path_length_limit_is_blocked(self) -> None:
        long_name = "demo/" + ("a" * 240) + ".txt"
        path = self._zip({long_name: "bad"})
        report = inspect_archive(path)
        self.assertEqual(report["status"], "BLOCKED")
        self.assertTrue(any("path length exceeds limit" in issue for issue in report["issues"]))

    def test_plan_digest_is_stable_and_excludes_digest_field(self) -> None:
        path = self._zip(
            {
                "demo/SKILL.md": "---\nname: demo\ndescription: Demo skill\n---\n",
            }
        )
        report = inspect_archive(path)
        plan = build_plan(report, agent="codex", scope="user", root="C:/Users/test")
        digest = plan["plan_digest"]
        self.assertEqual(digest, compute_plan_digest(plan))
        cloned = json.loads(json.dumps(plan))
        self.assertEqual(digest, compute_plan_digest(cloned))

    def test_blocked_report_cannot_be_planned(self) -> None:
        path = self._zip({"../escape.txt": "bad"})
        report = inspect_archive(path)
        with self.assertRaises(InspectionError):
            build_plan(report, agent="hermes", scope="user", root="D:/Hermes")


if __name__ == "__main__":
    unittest.main()
