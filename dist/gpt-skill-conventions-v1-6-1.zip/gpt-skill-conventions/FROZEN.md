# FROZEN.md

## v1.6.1-chatgpt｜2026-07-07

本版是 Joan v1.2 可追蹤重移植基準版。以下契約凍結，後續不可在未經使用者同意下刪除、弱化、泛化或移出 `SKILL.md` 主檔。

| 凍結項目 | 契約 |
|---|---|
| Canonical source | `joan-skill-conventions_v1.2/SKILL.md` 是 Joan 規則移植主本。 |
| 九條房規 | 房規一至九的順序、語意與 hard gate 強度不可弱化。 |
| 標準驗證層 | 不得把頁面截斷、SymPy、KaTeX、領域驗證、回歸自測、bootstrap 測試、版面量測等具體規格泛化成抽象分類。 |
| 頁面截斷 gate | 列印模式逐頁量測，溢出 greater than 2px 即擋。 |
| 數理 gate | 每題用 SymPy 重算比對宣稱答案，不符即擋。答案不得靠肉眼。 |
| KaTeX gate | 無殘留佔位 token、無未渲染 `$$` 或 `\(`、無 `katex-error`。 |
| 領域 gate | 化學等領域結構必須先驗證再繪圖。 |
| 回歸自測 gate | 每支 Skill 應放 `tests/test_*.py`，覆蓋純邏輯、凍結契約、缺料降級、bootstrap 行為。 |
| bootstrap gate | `ensure_*` 必須在 import 前，測試時攔截 `_pip` 或 `subprocess`，不做真實安裝。 |
| 版面量測 gate | 版面量測需保留明確判準，例如 band width difference less than one card。 |
| 互動式建議 | 方向不明時，提出 2 至 4 個方案、風險、驗證影響、交付影響與建議預設，再請使用者裁決。 |
| Acceptance template | 驗收 prompt template 必須保留在 `SKILL.md` 主檔。 |
| Skill 交付 | Skill 建立或更新的主要交付物必須是完整可安裝 `skill.zip`。 |
| ChatGPT 平台限制 | 不得宣稱可直接修改已安裝 Web Skill，不得宣稱一定能真正 fresh-context。 |
| Traceability | Joan migration 必須維護 `references/migration-traceability.md`。 |

## 變更政策

允許新增說明、補充驗證範例、補測試與改善清楚度，但不可讓上述契約變弱。若需要改變任何凍結項，必須先向使用者說明理由、風險、相容性影響與替代方案，取得明確同意後再做。

## v1.6.1 patch freeze

| 項目 | 凍結內容 |
|---|---|
| 測試執行契約 | `tests/test_*.py` 必須同時支援 `python -m pytest tests -q` 與直接執行。 |
| skill gate runner | `scripts/skill_gate.py` 必須支援 `--test-runner auto`、`--test-runner pytest`、`--test-runner direct`。 |
| 範圍限制 | v1.6.1 只修測試相容性，不變更 Joan hard gate、九條房規、互動式建議、acceptance template 或交付契約。 |
