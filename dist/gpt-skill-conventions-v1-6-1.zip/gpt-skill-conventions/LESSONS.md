## 2026-07-07｜v1.6.1 測試必須同時支援 pytest 與直接執行
- 現象：`python -m pytest tests -q` 會因 script-style test 的 `sys.exit()` 造成 pytest internal error。
- 根因：`tests/test_*.py` 原本只保證可直接執行，沒有保證 pytest-compatible。
- 對策：將 `tests/test_validate_punct.py` 與 `tests/test_skill_contract.py` 改為 pytest function-style assertions，並保留直接執行 helper；`scripts/skill_gate.py` 新增 `--test-runner auto|pytest|direct`。
- 已固化：`tests/test_validate_punct.py`、`tests/test_skill_contract.py`、`scripts/skill_gate.py`、`FROZEN.md`。

# LESSONS.md

## 2026-07-07｜v1.6.0 以 Joan v1.2 重建基準
- 現象：使用者指出 v1.5.2 將 Joan v1.2 的標準驗證層泛化，導致頁面截斷、SymPy、KaTeX、領域驗證、回歸自測、bootstrap 測試與版面量測規格弱化。
- 根因：先前移植以 ChatGPT 版摘要為主，沒有建立逐段 traceability 與 contract tests。
- 對策：以 Joan v1.2 為 canonical source 重做 v1.6.0，將具體 hard gate 拉回 `SKILL.md` 主檔，新增 `references/migration-traceability.md` 與 `tests/test_skill_contract.py`。
- 已固化：房規二、房規六、交付前驗證清單、`tests/test_skill_contract.py`。

## 2026-07-06｜v1.5.2 補互動與驗收但不足以保證 Joan fidelity
- 現象：acceptance prompt template 與互動式建議流程雖補上，但無法補償 Joan 具體驗證層遺漏。
- 根因：新增功能沒有同時做 Joan v1.2 逐段對標。
- 對策：v1.6.0 將 v1.5.2 的有效新增內容保留，但改以 Joan v1.2 主本重移植。
- 已固化：`references/migration-traceability.md`。

## 2026-07-06｜v1.5.0 過度簡化
- 現象：中文觸發詞、Joan 原始生態、多格式交付、維護細則與檢查表沒有充分放在主檔。
- 根因：過度追求精簡，忽略主檔可見性會影響執行強度。
- 對策：主檔優先規則凍結，critical gates 不得只藏 references。
- 已固化：房規與 main-file priority。

## 2026-07-06｜v1.4.0 過度工程化
- 現象：外部 CLI 被誤設為標準 Web Skill 主流程。
- 根因：把 repository-level automation 和 ChatGPT Web Skill runtime 混在一起。
- 對策：外部 CI 或 CLI 只能是選配，標準流程保持 single-skill self-contained。
- 已固化：Core contract 與 ChatGPT migration constraints。
