---
name: gpt-skill-conventions
description: "Governance overlay for creating, updating, migrating, validating, packaging, reviewing, and maintaining ChatGPT Skills. Use with skill-creator whenever the user says or implies：開新 skill、做一個 skill、寫一支 skill、升級 skill、檢視 skill、重構 skill、skill 房規、skill 規範、驗證器、凍結契約、回歸測試、交付前檢查、create a skill、update a skill、refactor a skill、validate a skill、package a skill、or migrate a Claude skill to ChatGPT. Preserve Joan v1.2 house rules, hard validation gates, frozen contracts, traceable migration, interactive recommendation, acceptance prompts, and full installable skill.zip delivery."
---

# GPT Skill Conventions

> **v1.6.1-chatgpt｜2026-07-07**：pytest 相容修正版。延續 v1.6.0 的 Joan v1.2 可追蹤重移植基準，只修測試執行層：`tests/test_*.py` 必須同時支援 `pytest` 與直接執行，`scripts/skill_gate.py` 必須同時支援 `pytest` runner 與 direct runner。不改 Joan hard gate、互動式建議流程、acceptance prompt template、凍結契約或房規語意。

## Core contract

Use this skill as a governance overlay on top of `skill-creator` whenever building, migrating, validating, packaging, reviewing, or maintaining ChatGPT Skills. `skill-creator` provides the generic draft、test、iterate、package process. This skill adds Joan v1.2 house rules：frozen contracts, hard validation gates, fullwidth punctuation, engine／skin／content separation, capability boundaries, transparent bootstrap, focus gates, three-round retry limit, fresh-context acceptance, multi-format delivery, and maintenance discipline.

Do not replace `skill-creator`. Compose both workflows.

Hard default：every delivered Skill update must be a complete installable `skill.zip`, not a patch set, unless the user explicitly asks for analysis only.

Self-contained default：normal ChatGPT Web Skill use must not require the user to install a local validator CLI, run a separate application, or use a repository workflow. Use bundled instructions, references, scripts, and tests first. External CI or repo gates are optional future infrastructure only when the user explicitly asks.

Joan fidelity default：when migrating from Joan v1.2, concrete validation rules, numeric thresholds, examples, anti-patterns, and provenance names must be preserved unless a ChatGPT platform difference forces a documented conversion. Do not replace a concrete hard gate with a generic phrase.

Main-file priority：do not hide execution-critical rules only in references. Trigger terms, nine house rules, standard validation layers, interactive recommendation, acceptance template, multi-format delivery rules, checklists, and maintenance protocol must remain visible in this `SKILL.md`.

## Immediate trigger list

When the user says or implies any of the following, read and apply this skill before generating or modifying any Skill artifact：

- 開新 skill
- 做一個 skill
- 寫一支 skill
- 升級 skill
- 檢視 skill
- 重構 skill
- skill 房規
- skill 規範
- 驗證器
- 凍結契約
- 回歸測試
- 交付前檢查
- create a skill
- update a skill
- refactor a skill
- inspect a skill
- validate a skill
- package a skill
- migrate a Claude skill to ChatGPT

Even if the user only says「幫我做一個 XXX 的 skill」，first apply this governance skill and `skill-creator` together.

## Joan v1.2 lineage and ecology

This ChatGPT Skill is a migration of Joan Skill Conventions v1.2. Preserve the substance of the original house rules rather than flattening them into generic advice.

Original ecology to keep in mind when designing new Skills：

- `cornell-notes-generator`：Cornell notes, math verification, chemistry structure checks, and print-ready study material patterns.
- `constructivist-lesson-builder`：lesson generation, multi-question focus gate, page overflow checks, KaTeX checks, and SymPy answer verification.
- `knowledge-map-generator`：knowledge wall, band measurement, visual density checks, and reusable layout presets.
- `knowledge-card-generator`：skin registry, frozen palette contracts, card templates, and subject-agnostic rendering.
- `dex-card-generator`：subject defaults, visual fallback ladder, glyph fallback, and non-fake visual degradation.
- `course-handout-generator`：apply、explore、imitate mode discipline and satisfaction loop.

These examples are not mandatory dependencies. They are the design provenance behind the rules. Use them to preserve the original level of strictness.

## Workflow

1. Classify the task：new Skill、existing Skill update、Claude to ChatGPT migration、validator work、pre-delivery review、or maintenance.
2. If the user provides a ZIP or folder, inspect it first. Count `SKILL.md` entrypoints and preserve original behavior unless a ChatGPT runtime difference requires migration.
3. Run the focus gate before generating large artifacts. Ask only missing information that materially affects contract, input, output, connectors, validation, or delivery. If direction is unclear, use the interactive recommendation flow below before implementing.
4. Define the contract：expected input, expected output, connectors, frozen values, delivery formats, validation gates, fallback behavior, and acceptance criteria.
5. For Joan migration, build or update a traceability matrix：preserved, ChatGPT-converted, moved to reference with main-file hard rule retained, or impossible to equalize.
6. Plan reusable files：scripts for deterministic checks, references for long rules, assets only for output templates or static files.
7. Implement or edit the Skill. Keep `SKILL.md` readable, but never move critical gates out of the main file merely to shorten it.
8. Run in-skill machine checks before delivery when code execution is available. At minimum, run `scripts/skill_gate.py` if present, punctuation validation, and all regression tests under `tests/`.
9. If a required validator cannot run, do not call the package fully verified. Deliver a clearly labeled unverified draft, stop before final delivery, or state exactly which checks were not run and why.
10. If the same validation failure recurs three times, stop editing and report the validator output, three attempted fixes, likely root cause, and next decision needed.
11. Perform fresh-context acceptance when possible. If true isolation is unavailable, create a clean acceptance prompt from the template below and disclose that it is a best-effort substitute.
12. Package with the ChatGPT Skill packager and return the complete `skill.zip`.
13. Ask whether the user is satisfied after delivery.

## Interactive recommendation flow

Use this flow when the user wants to create, upgrade, inspect, or refactor a Skill, but the target behavior, validation strategy, delivery format, or maintenance direction is not fully defined.

Do not start with a large questionnaire. Provide a small decision table that lets the user choose a direction.

Required flow：

1. State the unclear decision in one sentence.
2. Offer 2 to 4 feasible options.
3. For each option, include when to use it, tradeoff, validation impact, delivery impact, and risk.
4. Mark one recommended default when evidence is sufficient.
5. Ask the user to choose or approve the default before implementing.
6. If the user has already supplied enough constraints, proceed without asking.

Decision table format：

| Decision | Option | Use when | Validation impact | Delivery impact | Risk | Recommendation |
|---|---|---|---|---|---|---|

Do not use the table to avoid work. Use it only for decisions that materially affect correctness, validation, or delivery.

## Nine house rules

### 1. Freeze contracts and create new versions

Once a layout, coordinate set, color palette, skin, schema, validator behavior, or delivery contract is finalized, mark it as frozen. Do not mutate frozen values in place.

Implementation requirements：

- Put frozen values in named constants, registries, or tables.
- Maintain `FROZEN.md` with version, locked items, owner, and change policy.
- Write regression assertions for frozen values wherever possible.
- Add new versions or registry entries instead of editing frozen ones.
- Preserve backward compatibility：unspecified values should keep using defaults or old behavior.
- For registry-based visual Skills, use named registries such as `SKINS`、`FROZEN`、`DEFAULTS`、preset functions, or subject mappings. Expansion means adding a token set or preset, not mutating frozen entries.

Anti-pattern：silently changing a fixed palette, coordinate, validator rule, output schema, or frozen delivery contract because it seems better.

### 2. Validation is the hard gate, never visual inspection

Every serious Skill deliverable needs required validators. Exit code nonzero means not ready for final delivery. Correctness belongs to executable checks, not subjective visual inspection.

Standard validation layers, stacked as each Skill requires：

- `validate_punct.py`：fullwidth Chinese punctuation and no dash punctuation. This is the shared baseline validator.
- Page truncation：for print or fixed-page outputs, measure overflow page by page in print mode. Screenshot review is insufficient because hidden cropping is easy to miss. Overflow greater than 2px is a hard block. Reference pattern：constructivist `check_pages.py`.
- Math correctness：for generated problems and claimed answers, recompute every item with SymPy and compare against the claimed answer. Mismatch is a hard block. Answer correctness must never rely on eyesight. Reference patterns：constructivist `check_math.py` and cornell `verify_math.py`.
- KaTeX rendering：there must be no leftover placeholder tokens, no unrendered `$$` or `\(`, and no `katex-error`. Reference pattern：`check_katex.py`.
- Domain correctness：domain structures must be validated before rendering. Examples include chemical carbon skeleton counts, reaction balancing, and label alignment. Reference pattern：cornell `verify_structures.py`.
- Regression self-tests：each Skill should include `tests/test_*.py` for parts that can run without heavy dependencies, including pure logic functions, frozen contract assertions for palettes, coordinates, registries, missing-input fallback branches, and automatic installation logic. Tests should be pytest-compatible and directly executable unless the user explicitly freezes a different runner contract.
- Bootstrap tests：when testing automatic installation, intercept `_pip` or `subprocess` so the test verifies that already-installed dependencies are skipped and missing dependencies trigger an install attempt without performing real installation.
- Engine-change gate：after changing an engine, run all relevant tests. All PASS is required before claiming the existing contract is preserved.
- Layout measurement：for knowledge-wall or band-based visuals, measure band widths and fill cards until the difference is less than one card. Reference pattern：kmap `measure_bands.py`.

Hard-gate rules：

- If a required validator fails, do not deliver as final.
- If a required validator cannot run in the current environment, do not mark the artifact as verified.
- If the user asks for speed, still run the minimum gate. Speed does not waive validation.
- If only text-level review is possible, label the result as a draft or best-effort review, not a fully verified final package.
- Do not convert a failed machine gate into a subjective statement such as「看起來沒問題」。

Anti-pattern：「看起來對就交付」。This is especially dangerous for numeric answers and page truncation.

### 3. Fullwidth Chinese punctuation and no dash punctuation

Chinese text must use fullwidth punctuation. Use halfwidth punctuation only inside English, numbers, code, file paths, URLs, command flags, and machine-readable formats.

Required punctuation style：

- Use：`，`、`。`、`、`、`：`、`；`、`？`、`！`、`「」`、`『』`、`（）`.
- Do not use em dash, en dash, or double hyphen as punctuation near Chinese text.
- Use fullwidth commas, periods, colons, semicolons, or shorter sentences instead of dash punctuation.
- `scripts/validate_punct.py` is the ChatGPT package copy of the shared validator. New Skills copy it into their own `scripts/` through `sync_validator.py` rather than creating a divergent validator.

Run `scripts/validate_punct.py` on Chinese-facing Markdown, HTML, YAML, and text outputs before delivery.

### 4. Keep engine, skin, and content orthogonal

Separate the rendering engine, visual skin, layout, and subject content. The engine should support multiple domains without hard-coding one subject.

Implementation requirements：

- Design visual Skills as skeleton × skin × layout × content, not as one-off hard-coded output.
- Put skins, palettes, layouts, and presets in named registries.
- Keep content data separate from rendering code.
- Provide defaults that preserve backward compatibility.
- Add new subjects through mappings or presets, not engine rewrites.
- Use subject defaults, visual fallback ladders, glyph fallback, and non-fake visual degradation where relevant.

Anti-pattern：hard-code a single subject into the engine so changing subjects requires editing the renderer.

### 5. Be honest about capability boundaries and degrade cleanly

State what the Skill cannot reliably do. Do not fake missing data, hidden tool access, image provenance, mathematical certainty, legal certainty, connector access, or unsupported rendering.

Implementation requirements：

- Add a capability boundary section to Skills that produce domain outputs.
- Define a fallback ladder for missing dependencies or missing inputs.
- Mark uncertain facts as requiring verification instead of inventing them.
- Prefer dignified text, glyph, icon, template, or placeholder fallback over empty holes or fake specificity.
- For visuals, do not copy protected illustration or proprietary design elements. Extract only non-copyrighted structural traits when using references.

Anti-pattern：generating a fake illustration, fake measurement, fake citation, fake connector result, or plausible-looking numeric value because it looks useful.

### 6. Make setup transparent and delivery offline-capable

Avoid asking the user to manually install dependencies when a script can do it safely in the current execution environment. For heavy dependencies, use idempotent bootstrap helpers and call them before imports that need those dependencies.

Implementation requirements：

- Put setup helpers in `scripts/bootstrap.py` when needed.
- Provide granular `ensure_*` functions such as `ensure_export` for Playwright and Chromium, `ensure_katex` for npm KaTeX, `ensure_math` for SymPy, and `ensure_font_tools` for fonttools and brotli.
- Keep setup idempotent：installed dependencies should be skipped quickly.
- Call `ensure_*` before the corresponding import. A top-level import can fail before the helper has a chance to install the dependency.
- pip installs in constrained environments may need `--break-system-packages`; setup helpers must be explicit and reproducible.
- Test bootstrap logic without doing real installs by intercepting `_pip` or `subprocess`.
- For generated HTML or print outputs, embed fonts and rendering assets when offline use is required.
- For KaTeX or math rendering, prefer server-side prerendering and embedded assets when the deliverable promises offline use.
- Deliver self-contained files when the Skill promises offline or print use, with print settings such as `print-color-adjust:exact`, `@page` size, and `margin:0` when relevant.

Anti-pattern：telling the user to run manual `pip install`, or producing HTML that requires online fonts or KaTeX CDN at open time.

### 7. Use a focus gate before generation

Do not generate a large Skill, deck, report, template, or artifact immediately from a vague topic. First align on the few parameters that affect correctness.

Ask about missing values such as：

- Expected input and output.
- Connectors or tools.
- Target users and level.
- Required formats.
- Frozen contract or versioning needs.
- Validation requirements.
- Acceptance criteria.

Infer obvious values from context and avoid questionnaire overload. Ask fewer questions, but make them material. If the uncertainty is directional rather than factual, use the interactive recommendation flow instead of asking disconnected questions.

Anti-pattern：getting a topic such as「分數加法」or「做一個 Skill」and immediately generating a full artifact without grade level, depth, examples, format, validator, and acceptance alignment.

### 8. Retry the same failure at most three times

For a fix-and-rerun loop, the same validation failure category may be retried at most three times. On the third failure, stop modifying and report：

- Validator name and full output.
- What changed in each attempt.
- Likely root cause.
- Recommended next decision for the user.

Same failure category is based on validator error type, not necessarily identical line number or page number. User-directed redesigns are requirement changes, not retry-loop failures.

Anti-pattern：retrying a page overflow, math mismatch, or punctuation failure for seven rounds without escalation.

### 9. Acceptance must not self-certify

The author must not be the only judge. Code and scripts must be checked by executable validators when possible. Text deliverables should receive fresh-context acceptance when possible.

For ChatGPT Skill work：

- Run executable tests and validators as independent checks when code execution is available.
- For `SKILL.md`, `FROZEN.md`, and long policy text, create an acceptance prompt that gives only the file contents and checklist.
- If the environment cannot create a truly separate context, perform a best-effort read-back and explicitly label it as not equivalent to external acceptance.
- For high-risk changes, get user confirmation before changing frozen rules, deleting validation, relaxing tests, or removing features.
- For changes to frozen contracts, common validators, or Joan migration fidelity, require a traceability check plus acceptance check.

Anti-pattern：editing the file and then saying「我自己看過，應該沒問題」。That is the document version of relying on eyesight.

## Acceptance prompt template

Use this template for fresh-context or best-effort acceptance. Give the checker only the final files and checklist, not the editing history.

Required fields：

- Role：independent acceptance checker.
- Input files：exact file names or pasted file contents.
- Acceptance criteria：specific pass／fail checks.
- Report format：fixed table with evidence.
- Retry limit：three rounds if fixes are delegated back.

Template：

```text
你是獨立驗收者，沒有參與產生這些檔案。請只根據我提供的檔案內容判斷，不要依賴外部記憶。

任務：驗收 <skill name> 的 <version>。

輸入檔案：
1. <file path or pasted content>
2. <file path or pasted content>

驗收條件：
1. SKILL.md 的 frontmatter 只有 name 與 description，且 description 有真實觸發條件。
2. Joan v1.2 的九條房規沒有被刪除或泛化。
3. 標準驗證層保留具體 hard gate：頁面截斷 > 2px 即擋、SymPy 每題重算、KaTeX 三項檢查、領域驗證先於繪圖、tests/test_*.py 回歸自測、bootstrap 攔截測試、measure_bands 類版面量測。
4. 中文標點符合全形要求，且沒有破折號。
5. ChatGPT 平台限制有明確揭露，沒有宣稱可直接修改已安裝 Web Skill。
6. 交付規則要求完整 skill.zip，而不是 patch set。

回報格式：
| 編號 | 驗收條件 | 結果 | 證據行號或摘錄 | 風險 |
|---|---|---|---|---|

若任一條不通過，請輸出「不通過」並列出最小修正建議。不要自行修改檔案。
```

## Three working modes

- **Apply**：use an existing frozen pattern, validator, or template for stable repeated production.
- **Explore**：try variants in skin, layout, density, or workflow until the user chooses one to freeze.
- **Imitate**：extract non-copyrighted structural traits from a user-provided reference, such as layout rhythm, field set, tone, or palette. Do not copy protected illustration or proprietary design elements.

## Satisfaction loop

Every delivery must ask whether the user is satisfied. Visual issues such as color, font, density, or layout should lead to parameter changes and regenerated output. Content issues should lead to content fixes and rerun validation. This loop is separate from the three-failure retry limit because user-directed redesign is a requirement change.

## Multi-format delivery rules

For Skill creation and Skill updates, the primary deliverable is always a complete installable `skill.zip`.

For artifact-producing Skills, preserve Joan v1.2 multi-format discipline unless the target task clearly does not need it：

- HTML：single self-contained file when feasible.
- PDF：print-ready output when the deliverable is meant to be printed or reviewed offline.
- PNG：multi-page visual outputs should be exported and packaged as a zip when useful.
- DOCX：instructional handouts, long-form documents, or editable office deliverables should include DOCX when the user needs editing.
- Spreadsheet or slides：use the appropriate artifact skill and preserve source data or layout templates.

ChatGPT replacement for Claude `present_files`：provide the generated files as downloadable artifact links. The rule is still「multi-format deliverables must all be provided」，not merely described.

## New Skill intake checklist

Before creating a new Skill, answer or infer the following. Ask only for missing items that materially affect correctness：

1. **Positioning**：What existing Skill or workflow does this overlap with？ Upgrade an existing Skill instead of creating a duplicate when appropriate.
2. **Input**：What files, text, URLs, connectors, or user prompts will the Skill receive？
3. **Output**：What exact artifact, answer, report, transformed text, code, or package should it produce？
4. **Connectors and tools**：Which tools must be used, and which are optional？
5. **Engine, skin, content**：What is the reusable engine？ What are the skins or presets？ What content is data？
6. **Capability boundary**：What must the Skill refuse, verify externally, or degrade gracefully？
7. **Focus gate**：What must be clarified before generation？ What can be inferred without asking？ Which unclear direction needs the interactive recommendation flow？
8. **Frozen contract**：Which values, schemas, palettes, coordinates, prompts, or validators must be frozen？
9. **Validation layers**：Which concrete validators and hard gates apply？ Fullwidth punctuation is baseline. Math uses SymPy. Fixed pages use print-mode overflow measurement. KaTeX uses placeholder, delimiter, and `katex-error` checks. Domain visuals validate before rendering.
10. **Dependencies**：Which heavy dependencies need bootstrap helpers？ Can output remain offline-capable？ How will bootstrap be tested without real installation？
11. **Delivery formats**：Which formats must be delivered？ For Skill work, include complete `skill.zip`.
12. **Regression tests**：Which pure logic, frozen values, fallback behavior, bootstrap behavior, and validator behavior must be covered under `tests/`？
13. **Acceptance**：What fresh-context or best-effort acceptance prompt will be used？

## Pre-delivery validation checklist

Use this checklist before delivering a Skill or artifact. Do not reduce it to a hidden reference.

1. [ ] `scripts/validate_punct.py` passes for Chinese-facing Markdown, HTML, YAML, and text outputs.
2. [ ] Required structure exists：`SKILL.md`、`agents/openai.yaml`、needed `scripts/`、needed `references/`、needed `tests/`、`FROZEN.md` when frozen contracts exist、`LESSONS.md` when maintaining conventions.
3. [ ] `SKILL.md` frontmatter has only `name` and `description`, and the description contains real trigger conditions.
4. [ ] Frozen contracts are unchanged or intentionally versioned.
5. [ ] Regression tests pass under `tests/test_*.py`, including contract assertions where relevant. For this Skill family, tests must pass through both `python -m pytest tests -q` and direct execution through `scripts/skill_gate.py --test-runner direct`.
6. [ ] Math outputs, if present, pass SymPy recomputation for every claimed answer.
7. [ ] KaTeX outputs, if present, have no leftover placeholder tokens, no unrendered `$$` or `\(`, and no `katex-error`.
8. [ ] Fixed-page outputs, if present, pass print-mode page overflow measurement. Overflow greater than 2px is blocked.
9. [ ] Domain structures, if present, validate before rendering. Examples：chemistry structures, reaction balancing, and label alignment.
10. [ ] Layout measurement, if present, satisfies the Skill-specific threshold, such as band width difference less than one card.
11. [ ] Dependencies are handled by bootstrap helpers when practical, and `ensure_*` happens before imports that need the dependency.
12. [ ] Bootstrap behavior is tested without real installation when applicable by intercepting `_pip` or `subprocess`.
13. [ ] Offline or print promises are honored with embedded assets, fonts, and print settings where relevant.
14. [ ] Multi-format deliverables are all created and linked, not only listed.
15. [ ] Fresh-context acceptance is performed with the template above when possible, or clearly labeled as best-effort when true isolation is unavailable.
16. [ ] Three-failure limit was respected.
17. [ ] The final delivery states actual checks run, checks not run, limitations, and gives the complete `skill.zip` when applicable.
18. [ ] The final response asks whether the user is satisfied.

## Maintenance protocol

### Changes allowed without prior user approval

These still require validation before delivery：

- Add a new non-frozen skin, layout, preset, or registry entry.
- Add a new lesson to `LESSONS.md`.
- Add new regression tests.
- Fix typos or examples without changing rule semantics.
- Improve wording that makes existing rules clearer but not weaker.
- Add traceability entries that document an existing migration decision.

### Changes requiring user approval before editing

- Any value listed in `FROZEN.md`.
- Any frozen registry, color token, coordinate, schema, validator rule, or delivery contract.
- The detection logic of `scripts/validate_punct.py`.
- Deleting or weakening any validator or test assertion.
- Changing the meaning or order of the nine house rules.
- Removing main-file trigger words, checklists, standard validation layers, multi-format rules, acceptance template, or maintenance protocol.
- Replacing a Joan v1.2 concrete hard gate with a generic phrase.
- Any major-version semantic change.

### LESSONS.md update format

After a validator catches a real issue, after a three-failure stop, or after the user identifies a migration flaw, append one concise lesson：

```markdown
## YYYY-MM-DD｜<一句話標題>
- 現象：<驗證器輸出的關鍵一行，或使用者指出的錯>
- 根因：<一句話>
- 對策：<改了哪個檔的哪條規則，或加了哪個測試>
- 已固化：<測試檔名或房規條號；寫「否」表示尚未固化，下次優先處理>
```

If a lesson can become a test, write the test. `LESSONS.md` is not a substitute for regression protection.

### Compaction rule

When `LESSONS.md` exceeds 30 entries, compact only lessons already marked as solidified. Keep unsolved or untested lessons visible. Before compaction, perform a fresh read-back check to avoid deleting unresolved problems.

### Installed Skill update rule

A mounted or installed Skill should be treated as read-only. To update it, produce a complete new package and ask the user to reinstall it. Do not claim that an already installed Web Skill has been modified in place.

## Delegation prompt rule

Any delegated task prompt must contain three fields：

- Acceptance criteria that can be checked.
- Fixed report format.
- Retry limit, defaulting to three rounds.

If any field is missing, the delegation prompt is incomplete.

## Delivery note template

Use this minimum delivery note：

```text
已完成：<一句話>
驗證：<列出實際跑過的檢查與結果>
限制：<未能完成、未能實跑、或未真正隔離驗收的項目>
下載：<skill.zip 或其他檔案連結>
是否滿意目前版本？
```

## Reference map

Load these files when the task needs deeper templates or supporting detail. They supplement this main file; they do not replace the visible rules above.

- `references/migration-traceability.md`：Joan v1.2 to ChatGPT v1.6.0 traceability matrix.
- `references/canonical-snippets.md`：copyable patterns for version stamps, frozen contracts, bootstrap, focus gates, capability boundaries, tests, and registries.
- `references/acceptance-checklists.md`：extended migration and validation checklists.
- `references/maintenance-protocol.md`：expanded maintenance rules.
- `references/migration-notes.md`：Claude to ChatGPT semantic mapping and known limits.
- `FROZEN.md`：frozen contract for this ChatGPT migration.
- `LESSONS.md`：maintenance lessons and historical failures.

## Script map

Use these scripts through the execution environment when relevant：

- `scripts/validate_punct.py <file>`：check Chinese-facing text for halfwidth punctuation near CJK and banned dash punctuation.
- `scripts/sync_validator.py [--check] <skill-dir> ...`：copy or compare the canonical punctuation validator across sibling Skill packages.
- `scripts/skill_gate.py <skill-root>`：run structural checks, punctuation checks, regression tests, and Joan v1.2 contract term checks for this Skill.
- `tests/test_validate_punct.py`：pytest-compatible and directly executable regression tests for the punctuation validator and validator-sync behavior.
- `tests/test_skill_contract.py`：pytest-compatible and directly executable regression tests that prevent Joan v1.2 hard gates from being accidentally generalized again.

## ChatGPT migration constraints

A ChatGPT Skill can strongly instruct, bundle scripts, and require checks. It cannot by itself mutate an already installed Skill in place or guarantee a truly fresh independent model session.

Normal use must remain single-skill and self-contained. Do not make an external validator CLI, local installation, GitHub Action, or separate application part of the required Web Skill workflow. Mention those only as optional future infrastructure when the user explicitly asks for team-level automation, repository-level blocking, or non-bypassable CI.
