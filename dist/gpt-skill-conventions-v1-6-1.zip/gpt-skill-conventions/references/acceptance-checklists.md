# Acceptance checklists

## v1.6.1 required acceptance checks

Use this file as supplemental detail. The executable contract remains in `SKILL.md` and tests.

| Area | Required check | Pass condition |
|---|---|---|
| Structure | Required files exist | `SKILL.md`、`agents/openai.yaml`、scripts、references、tests、`FROZEN.md`、`LESSONS.md` exist when relevant. |
| Frontmatter | Skill metadata | `SKILL.md` frontmatter contains only `name` and `description`. |
| Joan fidelity | Nine house rules | Rules one through nine are present and not generalized. |
| Standard validation layers | Concrete hard gates | Page overflow greater than 2px, SymPy per-item recomputation, KaTeX three checks, domain validation before rendering, regression tests, bootstrap interception, and layout measurement are visible. |
| ChatGPT conversion | Platform limits | `present_files` is converted to artifact links, installed Skills are read-only, fresh-context limitation is disclosed. |
| Interaction | Decision support | Unclear directions use the interactive recommendation flow before implementation. |
| Acceptance | Independent review | Use the acceptance prompt template from `SKILL.md`; label same-session checks as best-effort. |

## Short acceptance prompt

```text
你是獨立驗收者。請只根據提供的檔案內容檢查 <skill name> <version>。

請檢查：
1. 結構與 frontmatter 是否符合 ChatGPT Skill 規範。
2. Joan v1.2 九條房規是否主檔可見。
3. 具體驗證層是否完整，不能只剩抽象名詞。
4. 互動式建議與 acceptance template 是否主檔可見。
5. ChatGPT 平台限制是否誠實揭露。
6. 是否要求完整 skill.zip 交付。

請用表格回報：
| 項目 | 結果 | 證據 | 風險 |
```

## v1.6.1 test runner acceptance

- `python -m pytest tests -q` must pass.
- `python scripts/skill_gate.py . --test-runner pytest` must pass.
- `python scripts/skill_gate.py . --test-runner direct` must pass.
- Direct execution of every `tests/test_*.py` file must pass.
