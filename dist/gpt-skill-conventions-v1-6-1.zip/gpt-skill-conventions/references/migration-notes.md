# Claude to ChatGPT Migration Notes

This file records the semantic changes made while migrating the source Claude skill conventions into GPT Skill Conventions for ChatGPT.

## Preserved behavior

- The nine house rules remain the governing contract.
- The punctuation validator and its regression coverage remain central gates.
- Frozen contracts, `FROZEN.md`, `LESSONS.md`, maintenance rules, three-round retry limits, and fresh-context acceptance remain required concepts.
- The skill remains a governance overlay, not a replacement for the generic skill creation flow.

## ChatGPT-specific changes

| Claude-oriented concept | ChatGPT migration |
|---|---|
| `present_files` delivery wording | Return sandbox links to generated artifacts when packaging in this environment. |
| Claude execution paths | Treat installed skills as immutable and produce a complete replacement `skill.zip`. |
| `assets/validate_punct.py` as executable canonical file | Move executable canonical validator to `scripts/validate_punct.py`. |
| Fresh-context child task | Use a separate context when available；otherwise perform best-effort local read-back and disclose the limitation. |
| Skill creation flow | Compose with ChatGPT `skill-creator` instructions and packager. |
| Hard validation gate | Use bundled scripts and tests first；do not require a local external validator for the normal Web Skill workflow. |

## Non-equivalent capabilities

ChatGPT Skills can instruct and bundle scripts, but they cannot guarantee these actions by themselves：

- Prevent a user or model from skipping validation in every environment.
- Open a truly independent fresh context without a separate context.
- Modify an installed skill package in place.
- Enforce repository-wide CI or pull-request blocking without separate infrastructure.

The normal migration target is still a single self-contained ChatGPT Skill. If the user later asks for team-level automation, repository blocking, or non-bypassable CI, treat that as a separate optional project, not part of this Web Skill mainline.

## Migration validation expectations

A migrated package should pass all of these before delivery：

1. Original source tests, when still applicable.
2. Migrated `tests/test_validate_punct.py`.
3. `scripts/skill_gate.py`.
4. ChatGPT skill packager validation.
5. Manual or fresh-context acceptance against the migration checklist.

## v1.6.0 remigration note

`v1.6.0-chatgpt` treats `joan-skill-conventions_v1.2/SKILL.md` as the canonical source. The v1.5.x branch is not used as the primary source because it generalized several concrete Joan validation layers. Platform conversion is allowed only when explicitly documented：Claude `present_files` becomes ChatGPT artifact links, installed Web Skills are treated as read-only, and fresh-context acceptance is best-effort when true isolation is unavailable.

## v1.6.1 test runner note

`v1.6.1-chatgpt` does not change Joan v1.2 semantics. It only changes the test runner contract so that `tests/test_*.py` files are pytest-compatible while remaining directly executable. `scripts/skill_gate.py` supports `--test-runner auto`, `--test-runner pytest`, and `--test-runner direct`.
