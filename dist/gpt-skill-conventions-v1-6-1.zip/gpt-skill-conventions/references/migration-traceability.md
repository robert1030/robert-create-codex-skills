# Migration traceability：Joan v1.2 to GPT v1.6.0

本檔用來防止再次把 Joan v1.2 的具體房規泛化成抽象建議。`SKILL.md` 主檔仍是執行入口，本檔是對照證據。

| Joan v1.2 規則單位 | v1.6.0 處理 | 證據位置 | 備註 |
|---|---|---|---|
| 疊加在 `skill-creator` 之上 | 保留並 ChatGPT 化 | Core contract | 明確說 compose both workflows。 |
| 中文觸發詞 | 保留 | Immediate trigger list | 包含開新、升級、檢視、重構、驗證器、凍結契約、回歸測試、交付前檢查。 |
| Joan 原始生態 | 保留 | Joan lineage and ecology | 保留 cornell、constructivist、kmap、kcg、dex、course handout 脈絡。 |
| 房規一：凍結契約 | 保留 | House rule 1、FROZEN.md | registry、FROZEN、DEFAULTS、凍結斷言均保留。 |
| 房規二：驗證即閘門 | 保留並加強防泛化 | House rule 2、test_skill_contract.py | 具體標準驗證層主檔可見。 |
| validate_punct.py | 保留並平台轉換 | House rule 2、House rule 3 | Joan `assets/` 正本轉為 ChatGPT package 的 `scripts/` copy。 |
| 頁面截斷 | 保留 | House rule 2、Pre-delivery checklist | 列印模式逐頁量測，overflow greater than 2px blocked，參考 `check_pages.py`。 |
| 數理正確性 | 保留 | House rule 2、Pre-delivery checklist | 每題 SymPy 重算宣稱答案，不符即擋，答案不靠肉眼。 |
| KaTeX 渲染 | 保留 | House rule 2、Pre-delivery checklist | 無 placeholder、無未渲染 delimiter、無 `katex-error`。 |
| 領域正確性 | 保留 | House rule 2、Pre-delivery checklist | 化學例子與驗證先於繪圖保留。 |
| 回歸自測 | 保留 | House rule 2、Pre-delivery checklist | `tests/test_*.py`、純邏輯、凍結契約、fallback、bootstrap 測試。 |
| bootstrap 測試 | 保留 | House rule 2、House rule 6 | 攔截 `_pip` 或 `subprocess`，驗 skip 與 install attempt。 |
| 版面量測 | 保留 | House rule 2、Pre-delivery checklist | `measure_bands.py` 與差距小於一張卡。 |
| 房規三：全形標點與禁破折號 | 保留 | House rule 3 | 保留共用 validator 與不可分歧要求。 |
| 房規四：engine／skin／content | 保留 | House rule 4 | skeleton × skin × layout × content。 |
| 房規五：能力邊界與降級 | 保留 | House rule 5 | 不造假、fallback ladder、uncertain facts。 |
| 房規六：透明自動安裝與離線自包含 | 保留 | House rule 6 | `ensure_*` before import、offline assets、print settings。 |
| 房規七：生成前對焦 | 保留並補互動式建議 | House rule 7、Interactive recommendation flow | v1.5.2 有效新增內容保留。 |
| 房規八：三輪重試 | 保留 | House rule 8 | 同失敗類別三輪上限。 |
| 房規九：fresh-context 驗收 | 保留並 ChatGPT 化 | House rule 9、Acceptance prompt template | 誠實揭露 ChatGPT 無法保證真正隔離。 |
| 三種模式 | 保留 | Three working modes | Apply、Explore、Imitate。 |
| 滿意度迴圈 | 保留 | Satisfaction loop | 交付後必問是否滿意。 |
| 多格式交付 | 平台轉換 | Multi-format delivery rules | Claude `present_files` 轉 ChatGPT artifact links。 |
| 新 Skill 開工檢查表 | 保留並 ChatGPT 化 | New Skill intake checklist | 加入 connectors、acceptance、bootstrap test。 |
| 交付前驗證清單 | 保留並具體化 | Pre-delivery validation checklist | Joan hard gates 全列入。 |
| 維護協議 | 保留並 ChatGPT 化 | Maintenance protocol | 已安裝 Skill read-only，更新需產出完整 zip。 |
| 派工模板歸屬 | 保留 | Delegation prompt rule | 委派 prompt 必含驗收條件、格式、重試上限。 |

## 不可等價或需要平台轉換的項目

| Joan v1.2 語意 | ChatGPT v1.6.0 處理 | 原因 |
|---|---|---|
| `present_files` | artifact links | ChatGPT artifact 交付方式不同。 |
| 真正 fresh-context 子任務 | best-effort acceptance prompt when true isolation unavailable | ChatGPT Skill 無法單靠主檔保證真正獨立 session。 |
| 直接更新已安裝 Skill | 產出完整新 `skill.zip` 請使用者重新安裝 | Web Skill 掛載應視為 read-only。 |
| Joan `assets/validate_punct.py` 正本 | ChatGPT 包內 `scripts/validate_punct.py` copy | ChatGPT Skill 執行腳本習慣放 `scripts/`。 |
