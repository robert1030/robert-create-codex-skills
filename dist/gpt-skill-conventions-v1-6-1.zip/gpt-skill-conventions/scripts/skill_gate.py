#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""In-skill delivery gate：ChatGPT skill 交付前自檢。

檢查範圍：
1. 必要結構與 frontmatter。
2. 中文面向文字的全形標點與禁破折號。
3. 本包全部 tests/test_*.py 回歸測試。
4. Joan v1.2 contract terms。

用法：
    python scripts/skill_gate.py <skill-root>
    python scripts/skill_gate.py <skill-root> --test-runner pytest
    python scripts/skill_gate.py <skill-root> --test-runner direct

預設 `--test-runner auto` 會優先使用 pytest；若 pytest 不可用，改用直接執行測試檔。
"""
import argparse
import os
import re
import subprocess
import sys
from pathlib import Path

TEXT_SUFFIXES = {".md", ".txt", ".html", ".yaml", ".yml"}
SKIP_DIRS = {".git", "__pycache__", ".pytest_cache"}


def run(cmd, cwd):
    print("$ " + " ".join(cmd))
    return subprocess.run(cmd, cwd=cwd, text=True, capture_output=True)


def fail(message):
    print(f"[FAIL] {message}")
    return 1


def check_structure(root):
    required = [
        "SKILL.md",
        "agents/openai.yaml",
        "scripts/validate_punct.py",
        "scripts/sync_validator.py",
        "tests/test_validate_punct.py",
        "tests/test_skill_contract.py",
        "FROZEN.md",
        "LESSONS.md",
    ]
    missing = [p for p in required if not (root / p).exists()]
    if missing:
        return fail("缺少必要檔案：" + ", ".join(missing))

    skill_md = (root / "SKILL.md").read_text(encoding="utf-8")
    if not skill_md.startswith("---\n"):
        return fail("SKILL.md 缺少 YAML frontmatter")
    m = re.match(r"^---\n(.*?)\n---", skill_md, re.S)
    if not m:
        return fail("SKILL.md frontmatter 格式錯誤")
    fm = m.group(1)
    if "name:" not in fm or "description:" not in fm:
        return fail("SKILL.md frontmatter 必須包含 name 與 description")
    if "[TODO" in skill_md or "TODO:" in skill_md:
        return fail("SKILL.md 仍含 TODO")
    print("[PASS] 結構檢查")
    return 0


def iter_text_files(root):
    for current, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for name in files:
            path = Path(current) / name
            if path.suffix.lower() in TEXT_SUFFIXES:
                yield path


def check_punctuation(root):
    validator = root / "scripts" / "validate_punct.py"
    failures = []
    for path in iter_text_files(root):
        rel = path.relative_to(root)
        if str(rel).startswith("tests/"):
            continue
        r = run([sys.executable, str(validator), str(path)], root)
        if r.returncode != 0:
            failures.append((rel, r.stdout, r.stderr))
    if failures:
        print("[FAIL] 標點驗證失敗")
        for rel, out, err in failures:
            print(f"--- {rel}")
            print(out)
            if err:
                print(err)
        return 1
    print("[PASS] 標點驗證")
    return 0


def check_tests_direct(root):
    tests = sorted((root / "tests").glob("test_*.py"))
    if not tests:
        return fail("缺少 tests/test_*.py 回歸測試")
    failed = []
    for test in tests:
        r = run([sys.executable, str(test)], root)
        print(r.stdout)
        if r.stderr:
            print(r.stderr)
        if r.returncode != 0:
            failed.append(test.name)
    if failed:
        return fail("直接執行回歸測試失敗：" + ", ".join(failed))
    print("[PASS] 直接執行回歸測試")
    return 0


def check_tests_pytest(root):
    r = run([sys.executable, "-m", "pytest", "tests", "-q"], root)
    print(r.stdout)
    if r.stderr:
        print(r.stderr)
    if r.returncode != 0:
        return fail("pytest 回歸測試失敗")
    print("[PASS] pytest 回歸測試")
    return 0


def check_tests(root, runner):
    if runner == "direct":
        return check_tests_direct(root)
    if runner == "pytest":
        return check_tests_pytest(root)

    probe = run([sys.executable, "-m", "pytest", "--version"], root)
    if probe.returncode == 0:
        print("[INFO] auto test runner：pytest")
        return check_tests_pytest(root)
    print("[INFO] auto test runner：direct，pytest 不可用")
    return check_tests_direct(root)


def parse_args(argv):
    parser = argparse.ArgumentParser(description="Run the gpt-skill-conventions delivery gate.")
    parser.add_argument("root", nargs="?", default=".", help="Skill root directory.")
    parser.add_argument("--test-runner", choices=["auto", "pytest", "direct"], default="auto")
    return parser.parse_args(argv)


def main(argv):
    args = parse_args(argv)
    root = Path(args.root).resolve()
    if not root.is_dir():
        return fail(f"不是目錄：{root}")
    rc = 0
    rc |= check_structure(root)
    rc |= check_punctuation(root)
    rc |= check_tests(root, args.test_runner)
    if rc == 0:
        print("結果：in-skill gate 通過。")
    else:
        print("結果：in-skill gate 失敗。")
    return 0 if rc == 0 else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
