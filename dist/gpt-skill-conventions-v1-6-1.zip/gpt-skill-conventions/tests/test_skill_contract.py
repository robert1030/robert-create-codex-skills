#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Contract tests for Joan v1.2 fidelity in gpt-skill-conventions.

These tests are pytest-compatible and also directly executable with:

    python tests/test_skill_contract.py
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SKILL = (ROOT / "SKILL.md").read_text(encoding="utf-8")
FROZEN = (ROOT / "FROZEN.md").read_text(encoding="utf-8")
TRACE = (ROOT / "references" / "migration-traceability.md").read_text(encoding="utf-8")

REQUIRED_IN_SKILL = [
    "Joan v1.2 可追蹤重移植基準",
    "Joan fidelity default",
    "Interactive recommendation flow",
    "Acceptance prompt template",
    "Page truncation",
    "Overflow greater than 2px",
    "constructivist `check_pages.py`",
    "SymPy",
    "Mismatch is a hard block",
    "Answer correctness must never rely on eyesight",
    "no leftover placeholder tokens",
    "no unrendered `$$` or `\\(`",
    "no `katex-error`",
    "validate before rendering",
    "tests/test_*.py",
    "intercept `_pip` or `subprocess`",
    "less than one card",
    "Do not convert a failed machine gate",
    "scripts/validate_punct.py",
    "ChatGPT replacement for Claude `present_files`",
    "complete installable `skill.zip`",
]

REQUIRED_IN_FROZEN = [
    "不得把頁面截斷、SymPy、KaTeX、領域驗證、回歸自測、bootstrap 測試、版面量測等具體規格泛化成抽象分類",
    "頁面截斷 gate",
    "數理 gate",
    "KaTeX gate",
    "Traceability",
]

REQUIRED_IN_TRACE = [
    "頁面截斷",
    "數理正確性",
    "KaTeX 渲染",
    "領域正確性",
    "回歸自測",
    "bootstrap 測試",
    "版面量測",
    "不可等價或需要平台轉換的項目",
]


def missing_items(text: str, required: list[str], source_name: str) -> list[str]:
    return [f"{source_name} missing：{needle}" for needle in required if needle not in text]


def test_skill_contains_joan_contract_terms():
    missing = missing_items(SKILL, REQUIRED_IN_SKILL, "SKILL.md")
    assert not missing, "\n".join(missing)


def test_frozen_contains_non_generalization_contract():
    missing = missing_items(FROZEN, REQUIRED_IN_FROZEN, "FROZEN.md")
    assert not missing, "\n".join(missing)


def test_traceability_contains_required_rule_units():
    missing = missing_items(TRACE, REQUIRED_IN_TRACE, "migration-traceability.md")
    assert not missing, "\n".join(missing)


def _run_direct():
    tests = [
        test_skill_contains_joan_contract_terms,
        test_frozen_contains_non_generalization_contract,
        test_traceability_contains_required_rule_units,
    ]
    failures = []
    for test in tests:
        try:
            test()
            print(f"[PASS] {test.__name__}")
        except Exception as exc:  # pragma: no cover - direct execution helper
            failures.append((test.__name__, exc))
            print(f"[FAIL] {test.__name__}: {exc}")
    print(f"結果：{len(tests) - len(failures)} passed, {len(failures)} failed")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(_run_direct())
