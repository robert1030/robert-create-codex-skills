#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regression tests for validate_punct.py and sync_validator.py.

These tests are pytest-compatible and also directly executable with:

    python tests/test_validate_punct.py
"""
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
VP = ROOT / "scripts" / "validate_punct.py"


def run_vp(target: Path):
    return subprocess.run([sys.executable, str(VP), str(target)], capture_output=True, text=True)


def test_validator_scans_itself_successfully():
    result = run_vp(VP)
    assert result.returncode == 0, result.stdout + result.stderr


def test_validator_scans_skill_markdown_successfully():
    result = run_vp(ROOT / "SKILL.md")
    assert result.returncode == 0, result.stdout + result.stderr


def test_dirty_sample_is_rejected_and_reports_expected_tokens():
    with tempfile.TemporaryDirectory(prefix="gpt-skill-test-", dir="/tmp") as td:
        bad = Path(td) / "bad.html"
        bad.write_text(
            "這句用半形句號.繼續\n"
            "連字號--當破折號\n"
            "他說\"引號\"包中文\n"
            "再用'單引號'包中文\n"
            "破折號—在此\n",
            encoding="utf-8",
        )
        result = run_vp(bad)
        assert result.returncode == 1, result.stdout + result.stderr
        assert "「.」" in result.stdout
        assert '「\"」' in result.stdout
        assert "「'」" in result.stdout
        assert "「--」" in result.stdout
        assert "「—」" in result.stdout


def test_clean_sample_allows_command_flags_decimals_and_urls():
    with tempfile.TemporaryDirectory(prefix="gpt-skill-test-", dir="/tmp") as td:
        ok = Path(td) / "ok.html"
        ok.write_text(
            "全形標點，正常。安裝時請帶 --break-system-packages 參數，"
            "小數 3.14 與網址 example.com 不受影響。\n",
            encoding="utf-8",
        )
        result = run_vp(ok)
        assert result.returncode == 0, result.stdout + result.stderr


def test_sync_validator_auto_discovers_and_synchronizes_sibling_packages():
    with tempfile.TemporaryDirectory(prefix="gpt-skill-test-", dir="/tmp") as td:
        base = Path(td)
        for name in ("pkg-a", "pkg-b"):
            scripts_dir = base / name / "scripts"
            scripts_dir.mkdir(parents=True)
            (scripts_dir / "validate_punct.py").write_text("OLD\n", encoding="utf-8")

        me = base / "gpt-skill-conventions"
        shutil.copytree(ROOT, me)
        sync = me / "scripts" / "sync_validator.py"

        first = subprocess.run([sys.executable, str(sync), "--check"], capture_output=True, text=True)
        assert first.returncode == 1, first.stdout + first.stderr
        assert "2 個包" in first.stdout

        subprocess.run([sys.executable, str(sync)], capture_output=True, text=True, check=False)
        second = subprocess.run([sys.executable, str(sync), "--check"], capture_output=True, text=True)
        assert second.returncode == 0, second.stdout + second.stderr


def _run_direct():
    tests = [
        test_validator_scans_itself_successfully,
        test_validator_scans_skill_markdown_successfully,
        test_dirty_sample_is_rejected_and_reports_expected_tokens,
        test_clean_sample_allows_command_flags_decimals_and_urls,
        test_sync_validator_auto_discovers_and_synchronizes_sibling_packages,
    ]
    failures = []
    for test in tests:
        try:
            test()
            print(f"[PASS] {test.__name__}")
        except Exception as exc:  # pragma: no cover - direct execution helper
            failures.append((test.__name__, exc))
            print(f"[FAIL] {test.__name__}: {exc}")
    print(f"結果：{len(tests) - len(failures)} passed, {len(failures)} failed")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(_run_direct())
