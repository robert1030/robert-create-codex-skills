# 圖片：executing_tests_2.04.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(17x17)，判定為行內功能圖示
- 尺寸：17x17
- 引用來源 chunk：c_32ba52f597b2（topics/replay_view.htm）
