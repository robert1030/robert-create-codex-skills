# 圖片：snmp.19.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(17x18)，判定為行內功能圖示
- 尺寸：17x18
- 引用來源 chunk：c_2cdf0dd76c92（topics/snmp_session_editor_concept.htm）
