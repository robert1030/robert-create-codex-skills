# 圖片：spirent_testcenter_gui_3.07.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(17x18)，判定為行內功能圖示
- 尺寸：17x18
- 引用來源 chunk：c_7c719ea8a941（topics/spirent_testcenter_gui.06.htm）
