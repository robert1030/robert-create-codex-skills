# 圖片：snmp.34.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(19x19)，判定為行內功能圖示
- 尺寸：19x19
- 引用來源 chunk：c_13cb9ebb233d（topics/snmp_session_editor_concept.htm）
