# 圖片：spirent_testcenter_gui_3.14.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(18x18)，判定為行內功能圖示
- 尺寸：18x18
- 引用來源 chunk：c_fa12c6328ddf（topics/spirent_testcenter_gui.06.htm）
