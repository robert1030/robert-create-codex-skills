# 圖片：activity_pages.08.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(17x17)，判定為行內功能圖示
- 尺寸：17x17
- 引用來源 chunk：c_ae392cd48207（topics/activitywiz_tc_start_session.htm）
