# 圖片：test_reports_2.24.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(17x17)，判定為行內功能圖示
- 尺寸：17x17
- 引用來源 chunk：c_9eab58eb5d31（topics/test_reports_view.htm）
