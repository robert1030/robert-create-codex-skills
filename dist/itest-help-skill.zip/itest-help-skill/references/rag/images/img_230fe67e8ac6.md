# 圖片：capture_tasks_6.1.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(19x19)，判定為行內功能圖示
- 尺寸：19x19
- 引用來源 chunk：c_748c0463ec48（topics/capture_markers_inserting.htm）
