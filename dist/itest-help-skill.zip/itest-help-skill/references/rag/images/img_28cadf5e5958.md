# 圖片：ui_concepts.05.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(22x21)，判定為行內功能圖示
- 尺寸：22x21
- 引用來源 chunk：c_256d3a6995aa（topics/ui_toolbars_itest.htm）
