# 圖片：test_reports.09.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(16x17)，判定為行內功能圖示
- 尺寸：16x17
- 引用來源 chunk：c_4428b036146e（topics/test_report_editor.htm）
