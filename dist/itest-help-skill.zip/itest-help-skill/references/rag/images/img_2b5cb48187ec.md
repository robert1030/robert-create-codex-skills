# 圖片：snmp.50.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(19x19)，判定為行內功能圖示
- 尺寸：19x19
- 引用來源 chunk：c_5178d0ace313（topics/snmp_session_editor_concept.htm）
