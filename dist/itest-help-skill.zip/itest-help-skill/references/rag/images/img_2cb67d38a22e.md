# 圖片：charting.3.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(17x17)，判定為行內功能圖示
- 尺寸：17x17
- 引用來源 chunk：c_81eb8ee34018（topics/charting_view.htm）
