# 圖片：topologies_2.5.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(22x21)，判定為行內功能圖示
- 尺寸：22x21
- 引用來源 chunk：c_635c9cfda86f（topics/topo_add_session_profile_wizard.htm）
