---
{
  "image_chunk_id": "img_35e51a8a5d31df2a",
  "image_path": "topics/images/quickcalls.11.jpg",
  "category": "inline_icon",
  "dimensions": [
    22,
    16
  ],
  "ocr_status": "skipped_not_screenshot_or_diagram",
  "has_ocr_text": false,
  "referenced_by": [
    "topics/quickcalls_new_quickcall_library_wizard.htm"
  ],
  "usage_count": 1
}
---

# Image: topics/images/quickcalls.11.jpg

- category: inline_icon
- dimensions: (22, 16)
- ocr_status: skipped_not_screenshot_or_diagram
- referenced_by: topics/quickcalls_new_quickcall_library_wizard.htm

此圖片分類為行內小圖示（inline_icon），未執行 OCR（非畫面截圖／示意圖類別）。
