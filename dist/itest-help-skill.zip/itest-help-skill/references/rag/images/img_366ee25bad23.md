# 圖片：snmp.23.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(17x17)，判定為行內功能圖示
- 尺寸：17x17
- 引用來源 chunk：c_25872b0462a4（topics/snmp_session_editor_concept.htm）
