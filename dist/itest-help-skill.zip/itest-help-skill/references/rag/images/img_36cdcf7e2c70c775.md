---
{
  "image_chunk_id": "img_36cdcf7e2c70c775",
  "image_path": "topics/images/spirent_testcenter_gui_2.08.jpg",
  "category": "unknown",
  "dimensions": [
    49,
    19
  ],
  "ocr_status": "skipped_not_screenshot_or_diagram",
  "has_ocr_text": false,
  "referenced_by": [
    "topics/spirent_testcenter_gui.05.htm"
  ],
  "usage_count": 1
}
---

# Image: topics/images/spirent_testcenter_gui_2.08.jpg

- category: unknown
- dimensions: (49, 19)
- ocr_status: skipped_not_screenshot_or_diagram
- referenced_by: topics/spirent_testcenter_gui.05.htm

內容無法自動判讀，狀態標記為 unknown，未進行內容腦補。
