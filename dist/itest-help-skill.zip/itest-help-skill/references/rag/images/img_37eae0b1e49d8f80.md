---
{
  "image_chunk_id": "img_37eae0b1e49d8f80",
  "image_path": "topics/images/Git_in_iTest.5.jpg",
  "category": "screenshot",
  "dimensions": [
    371,
    118
  ],
  "ocr_status": "ok",
  "has_ocr_text": true,
  "referenced_by": [
    "topics/git_setting_up_Git_repository_in_iTest.htm"
  ],
  "usage_count": 1
}
---

# Image: topics/images/Git_in_iTest.5.jpg

- category: screenshot
- dimensions: (371, 118)
- ocr_status: ok
- referenced_by: topics/git_setting_up_Git_repository_in_iTest.htm

此圖片分類為畫面截圖（screenshot），已使用 Tesseract OCR（英文語言包）擷取圖片內文字，內容如下（OCR 結果，非人工校對，可能含辨識誤差，尤其是低解析度或特殊字元）：

```
YG localRepo (NO-HEAD] - C:\test\builds\itets-5AVa7\git\localRepo\.oit
¥ @ Branches
Fe ae ee ee

> G Reteences
```
