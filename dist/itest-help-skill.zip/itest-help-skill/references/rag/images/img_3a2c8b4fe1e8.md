# 圖片：topologies.09.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(22x21)，判定為行內功能圖示
- 尺寸：22x21
- 引用來源 chunk：c_6f5ba11f782b（topics/topology_quick_start.htm）
