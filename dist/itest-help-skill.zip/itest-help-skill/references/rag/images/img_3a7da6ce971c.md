# 圖片：test_case_editor.14.jpg

- 分類：inline_icon
- 判斷依據：尺寸小(24x24)，判定為行內功能圖示
- 尺寸：24x24
- 引用來源 chunk：c_c51875c26930（topics/test_case_editor_steps_page.htm）
