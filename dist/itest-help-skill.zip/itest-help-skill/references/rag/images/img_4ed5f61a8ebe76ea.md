---
{
  "image_chunk_id": "img_4ed5f61a8ebe76ea",
  "image_path": "topics/images/EncrytpDialog.png",
  "category": "screenshot",
  "dimensions": [
    379,
    182
  ],
  "ocr_status": "ok",
  "has_ocr_text": true,
  "referenced_by": [
    "topics/slcPasswordEncrypTool.htm"
  ],
  "usage_count": 1
}
---

# Image: topics/images/EncrytpDialog.png

- category: screenshot
- dimensions: (379, 182)
- ocr_status: ok
- referenced_by: topics/slcPasswordEncrypTool.htm

此圖片分類為畫面截圖（screenshot），已使用 Tesseract OCR（英文語言包）擷取圖片內文字，內容如下（OCR 結果，非人工校對，可能含辨識誤差，尤其是低解析度或特殊字元）：

```
© Encryptor
Encrypt the value,

x

‘The result can be used as a value for masked properties in SLC scripts.

Original value:

Encrypted value:

TestPasfword

GdV+0EBHakKvgACbAtkskA==

Close
```
