---
{
  "image_chunk_id": "img_5e28f91e09cfaa04",
  "image_path": "topics/images/views.31.jpg",
  "category": "inline_icon",
  "dimensions": [
    22,
    21
  ],
  "ocr_status": "skipped_not_screenshot_or_diagram",
  "has_ocr_text": false,
  "referenced_by": [
    "topics/activity_review_test_reports.htm"
  ],
  "usage_count": 1
}
---

# Image: topics/images/views.31.jpg

- category: inline_icon
- dimensions: (22, 21)
- ocr_status: skipped_not_screenshot_or_diagram
- referenced_by: topics/activity_review_test_reports.htm

此圖片分類為行內小圖示（inline_icon），未執行 OCR（非畫面截圖／示意圖類別）。
