---
{
  "image_chunk_id": "img_5fe40d01abd2d624",
  "image_path": "topics/images/spirent_testcenter_gui_3.10.jpg",
  "category": "unknown",
  "dimensions": [
    83,
    33
  ],
  "ocr_status": "skipped_not_screenshot_or_diagram",
  "has_ocr_text": false,
  "referenced_by": [
    "topics/tgen_results_testcenter.htm"
  ],
  "usage_count": 1
}
---

# Image: topics/images/spirent_testcenter_gui_3.10.jpg

- category: unknown
- dimensions: (83, 33)
- ocr_status: skipped_not_screenshot_or_diagram
- referenced_by: topics/tgen_results_testcenter.htm

內容無法自動判讀，狀態標記為 unknown，未進行內容腦補。
