---
{
  "image_chunk_id": "img_6508ea23aba47ab3",
  "image_path": "topics/images/chart_usingBar.png",
  "category": "diagram",
  "dimensions": [
    652,
    406
  ],
  "ocr_status": "ok",
  "has_ocr_text": true,
  "referenced_by": [
    "topics/chart_properties.htm"
  ],
  "usage_count": 1
}
---

# Image: topics/images/chart_usingBar.png

- category: diagram
- dimensions: (652, 406)
- ocr_status: ok
- referenced_by: topics/chart_properties.htm

此圖片分類為示意圖（diagram），已使用 Tesseract OCR（英文語言包）擷取圖片內文字，內容如下（OCR 結果，非人工校對，可能含辨識誤差，尤其是低解析度或特殊字元）：

```
~ Processor Properties

Chart Using Bar

‘Chart Using Bar

Chart Name:,, barchart

Title
Cistacked
Use Legend

X Axis Label,

V Axis Label,
}V Axis Must Include Zero

Category:,, category

Series Nameiy seriesl

Expression: | Svalue

Export image width:,, 1000

Export image height:,, 500
```
