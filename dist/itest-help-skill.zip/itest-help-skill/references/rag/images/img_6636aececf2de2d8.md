---
{
  "image_chunk_id": "img_6636aececf2de2d8",
  "image_path": "topics/images/spirent_testcenter_gui_3.3.jpg",
  "category": "unknown",
  "dimensions": [
    49,
    19
  ],
  "ocr_status": "skipped_not_screenshot_or_diagram",
  "has_ocr_text": false,
  "referenced_by": [
    "topics/add_host_dialog.htm"
  ],
  "usage_count": 1
}
---

# Image: topics/images/spirent_testcenter_gui_3.3.jpg

- category: unknown
- dimensions: (49, 19)
- ocr_status: skipped_not_screenshot_or_diagram
- referenced_by: topics/add_host_dialog.htm

內容無法自動判讀，狀態標記為 unknown，未進行內容腦補。
