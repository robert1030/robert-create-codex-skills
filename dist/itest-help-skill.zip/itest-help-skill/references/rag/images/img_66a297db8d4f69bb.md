---
{
  "image_chunk_id": "img_66a297db8d4f69bb",
  "image_path": "topics/images/capture_tasks.2.jpg",
  "category": "unknown",
  "dimensions": [
    69,
    19
  ],
  "ocr_status": "skipped_not_screenshot_or_diagram",
  "has_ocr_text": false,
  "referenced_by": [
    "topics/capture_view.htm"
  ],
  "usage_count": 1
}
---

# Image: topics/images/capture_tasks.2.jpg

- category: unknown
- dimensions: (69, 19)
- ocr_status: skipped_not_screenshot_or_diagram
- referenced_by: topics/capture_view.htm

內容無法自動判讀，狀態標記為 unknown，未進行內容腦補。
