# 凍結契約

## v1.0.0

- Skill 名稱固定為 `itest-help`。
- 產品與文件版本固定為 `iTest Help 26.2.0`。
- 唯一可作為內部主要依據的 RAG archive 為 `itest-help_26.2.0-rag-v1.2.1.zip`，SHA-256 為 `309BA7AACF41000C242FD0FBD1AF0B8B548F1EAB14A055284A3615DDE82BBC70`。
- 原始 source ZIP 的 7,004 個 member 路徑與 member SHA-256 已和 collection manifest 全數對齊。
- 本地優先、引用必填、外部資料揭露、版本不可混用與不確定性降級是不可移除的行為契約。
- 原始 collection 只有 1 個 `source_missing_target`，維持 `partial_success`。不得補造目標或將它宣稱為完整成功。

後續變更知識庫、版本政策、來源優先順序、引用格式或外部查證規則時，必須新增 skill 版本並重新執行驗證與封裝。
