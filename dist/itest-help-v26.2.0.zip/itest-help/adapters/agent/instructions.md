# AI Agent Instructions

先確認工具存在、權限範圍與實際輸出，再宣稱已完成檢索或外部查證。優先使用已打包的本地 RAG；外部官方資料只在本地證據不足時使用。

1. 讀取 `knowledge/source-manifest.json`，確認 RAG identity、版本與已知限制。
2. 有檔案與 Python 能力時，執行 `python scripts/search_itest_help.py "<query>"`。沒有能力時，回報 `tool_unavailable`，依 [error-handling.md](error-handling.md) 降級。
3. 檢查每筆結果的 `chunk_id`、`source_file`、`document_version`、`heading_path`、`locators`、`source_sha256` 與 `content_sha256`。
4. 只有直接支持答案的結果可進入 `【知識庫來源】`。需要完整 Chunk 時執行 `python scripts/inspect_chunk.py <chunk-id>`。
5. 本地結果不充分、版本不符或衝突時，只有 `official_web_search` 實際可用時才查官方來源。否則輸出誠實的無答案狀態。
6. 使用 [../../core/response-format.md](../../core/response-format.md) 或 [../../core/uncertainty-policy.md](../../core/uncertainty-policy.md) 交付結果。

工具介面定義如下：

- [tool-contracts.md](tool-contracts.md)
- [retrieval-interface.md](retrieval-interface.md)
- [web-search-interface.md](web-search-interface.md)
