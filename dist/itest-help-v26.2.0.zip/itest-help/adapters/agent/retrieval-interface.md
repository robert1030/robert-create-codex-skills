# Retrieval Interface

本地 reference implementation 是：

```text
python scripts/search_itest_help.py "<query>" --limit 5
```

等效的邏輯工具請接受：

```json
{
  "query": "Tcl Test Step",
  "version": "26.2.0",
  "component": "Tcl Test Step",
  "limit": 5
}
```

成功回應必須包含：

```json
{
  "status": "ok",
  "results": [
    {
      "chunk_id": "...",
      "source_file": "topics/...",
      "document_version": "26.2.0",
      "title": "...",
      "heading_path": ["..."],
      "locators": [{"dom_path": "..."}],
      "source_sha256": "...",
      "content_sha256": "...",
      "text": "..."
    }
  ]
}
```

沒有結果時回傳 `{"status":"no_results","results":[]}`。索引或來源資料不完整時回傳 `status: integrity_error`，不能把部分結果包裝成完整答案。
