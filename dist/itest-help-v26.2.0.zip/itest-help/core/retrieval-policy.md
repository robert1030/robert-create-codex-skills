# 檢索政策

來源優先順序固定如下：

1. 使用者版本完全相符的已驗證知識庫。
2. 相同 Major／Minor 的已驗證知識庫。
3. 知識庫明確標示為跨版本適用的內容。
4. iTest 官方外部文件。
5. 官方產品整合文件。

AI Agent 有本地資源時，使用 `scripts/search_itest_help.py` 搜尋 `knowledge/retrieval-index.jsonl`，再用 Chunk ID 與來源位置檢查原始記錄。AI Chat Web 只搜尋平台已配置的 `chat-web-knowledge.md`。

檢索結果不足、空白、版本不符或互相矛盾時，不得用模型記憶補齊。改依外部查證或不確定性政策處理。
