# reset

Clear the following fields in the email message that is currently being built:

attach

bcc

cc

from

subject

to

Field replacements are supported.

For details, see the online help: Sending email messages during test execution .
