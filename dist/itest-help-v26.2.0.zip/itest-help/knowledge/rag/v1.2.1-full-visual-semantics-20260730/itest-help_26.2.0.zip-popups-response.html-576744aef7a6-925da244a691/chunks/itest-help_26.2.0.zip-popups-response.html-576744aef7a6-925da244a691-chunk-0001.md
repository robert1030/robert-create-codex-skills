---
chunk_id: itest-help_26.2.0.zip-popups-response.html-576744aef7a6-925da244a691-chunk-0001
source_id: itest-help_26.2.0.zip-popups-response.html-576744aef7a6-925da244a691
title: Format
heading_path:
- Format
section_titles:
- response
- Format
source_block_ids:
- itest-help_26.2.0.zip-popups-response.html-576744aef7a6-925da244a691-block-0001
- itest-help_26.2.0.zip-popups-response.html-576744aef7a6-925da244a691-block-0002
- itest-help_26.2.0.zip-popups-response.html-576744aef7a6-925da244a691-block-0003
- itest-help_26.2.0.zip-popups-response.html-576744aef7a6-925da244a691-block-0004
- itest-help_26.2.0.zip-popups-response.html-576744aef7a6-925da244a691-block-0005
- itest-help_26.2.0.zip-popups-response.html-576744aef7a6-925da244a691-block-0006
- itest-help_26.2.0.zip-popups-response.html-576744aef7a6-925da244a691-block-0007
- itest-help_26.2.0.zip-popups-response.html-576744aef7a6-925da244a691-block-0008
- itest-help_26.2.0.zip-popups-response.html-576744aef7a6-925da244a691-block-0009
- itest-help_26.2.0.zip-popups-response.html-576744aef7a6-925da244a691-block-0010
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 205
source_hash: 925da244a691a75322e206a206e499ad8bb413b83e7a258d5e2b419561580f4e
normalized_document_hash: 72e32179d1a6cc80a26e129f11f79359094a248356fb32d9ec76c9b4a116ffc4
content_status: success
content_sha256: ca9e2c1df3f376215d6e993971aa692d65a9e896f4e2d02de705c1a76f9f6eb2
---

# response

Use the response command to insert the response content stored in the specified variable. (Responses are stored using the Store response in property for a step).

# Format

[response ?-alwayslist?  ?-group number_or_name?  variable_name  ?regex?]

The optional -alwaysList flag is useful when you use the return data as the argument in a foreach statement. See the online help for details.

The optional -group flag and group_number_or_name argument is a regular expression that defines something more specific to extract from the response text.

variable_name Is the name of the variable containing the stored response. If variable_name includes whitespace, it must be surrounded by double-quotes (which will be excluded from the location query before use).

The optional regex argument is a regular expression that defines something more specific to extract from the response text.

For details, see the online help: Using the response command in a field replacement .

Also: Field replacements: Substituting values into properties and commands .
