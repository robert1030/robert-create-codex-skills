---
chunk_id: itest-help_26.2.0.zip-popups-response_python.html-f25990dd8026-78bfa64c35f9-chunk-0001
source_id: itest-help_26.2.0.zip-popups-response_python.html-f25990dd8026-78bfa64c35f9
title: response
heading_path:
- response
section_titles:
- response
source_block_ids:
- itest-help_26.2.0.zip-popups-response_python.html-f25990dd8026-78bfa64c35f9-block-0001
- itest-help_26.2.0.zip-popups-response_python.html-f25990dd8026-78bfa64c35f9-block-0002
- itest-help_26.2.0.zip-popups-response_python.html-f25990dd8026-78bfa64c35f9-block-0003
- itest-help_26.2.0.zip-popups-response_python.html-f25990dd8026-78bfa64c35f9-block-0004
- itest-help_26.2.0.zip-popups-response_python.html-f25990dd8026-78bfa64c35f9-block-0005
- itest-help_26.2.0.zip-popups-response_python.html-f25990dd8026-78bfa64c35f9-block-0006
- itest-help_26.2.0.zip-popups-response_python.html-f25990dd8026-78bfa64c35f9-block-0007
- itest-help_26.2.0.zip-popups-response_python.html-f25990dd8026-78bfa64c35f9-block-0008
- itest-help_26.2.0.zip-popups-response_python.html-f25990dd8026-78bfa64c35f9-block-0009
- itest-help_26.2.0.zip-popups-response_python.html-f25990dd8026-78bfa64c35f9-block-0010
- itest-help_26.2.0.zip-popups-response_python.html-f25990dd8026-78bfa64c35f9-block-0011
- itest-help_26.2.0.zip-popups-response_python.html-f25990dd8026-78bfa64c35f9-block-0012
overlap_block_ids: []
overlap_token_count: 0
token_estimate: 267
source_hash: 78bfa64c35f909a73d922c50fc904d59fd78b539d7632a2559f59c157a89e739
normalized_document_hash: ca3f05b8845ace24d29c743832294e219813dd9139c7c18c3a644f8341711f73
content_status: success
content_sha256: 86b4eed14d87941cc87f55b4a5df37127a6091fe1ffdf7e3ade17adb90e9d3a3
---

# response

response ('variable_name', 'regex') #alwayslist=True, group='number_or_name'

Use the response command to insert the response content stored in the specified variable. (Responses are stored using the Store response in property for a step).

alwaysList : The optional flag is useful when you use the return data as the argument in a for statement. See the online help for details.

group: The optional flag and group='number_or_name' argument is a regular expression that defines something more specific to extract from the response text.

variable_Name Is the name of the variable containing the stored response. If varName includes whitespace, it must be surrounded by double-quotes (which will be excluded from the location query before use).

regex: The optional argument is a regular expression that defines something more specific to extract from the response text.

Example:

eval print("This string will be stored in a variable"), stores the response in a variable named "output" eval response("output")

Note: In Step Properties > Other Post-processing > Store Response, do not check the option Store only the text of the response .

For details, see the online help: Using the response command in a field replacement .

Also: Field replacements: Substituting values into properties and commands .
